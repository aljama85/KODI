# -*- coding: utf-8 -*-
import sys
l11ll1l_ll_ = sys.version_info [0] == 2
l1111l_ll_ = 2048
l11l1_ll_ = 7
def l11l111_ll_ (ll_ll_):
    global l1l1111_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l1l111_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l1l111_ll_)
    l11l_ll_ = l1l111_ll_ [:l1l1_ll_] + l1l111_ll_ [l1l1_ll_:]
    if l11ll1l_ll_:
        l1l1lll_ll_ = unicode () .join ([unichr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1lll_ll_ = str () .join ([chr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1lll_ll_)
l11l111_ll_ (u"ࠣࠤࠥࠎࠏࠦࠠࠡࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥ࠮ࡃࠪࠢ࠵࠴࠶࠺࠭࠳࠲࠴࠺ࠥࡨࡲࡰ࡯࡬ࡼࠥ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠊࠡࠢࠣࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࠩࡅࠬࠤ࠷࠶࠱࠷࠯࠵࠴࠶࠾ࠠࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠊࠋࠢࠣࠤ࡙ࠥࡐࡅ࡚࠰ࡐ࡮ࡩࡥ࡯ࡵࡨ࠱ࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲ࠻ࠢࡊࡔࡑ࠳࠲࠯࠲࠰ࡳࡳࡲࡹࠋࠢࠣࠤ࡙ࠥࡥࡦࠢࡏࡍࡈࡋࡎࡔࡇࡖ࠳ࡌࡖࡌ࠮࠴࠱࠴࠲ࡵ࡮࡭ࡻࠣࡪࡴࡸࠠ࡮ࡱࡵࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰ࠱ࠎࠧࠨࠢ䟏")
import re
class Cipher(object):
    def _1ll1l11ll11_ll_(self, l11l11llll11_ll_):
        l1l11111111_ll_ = self._11l1l111lll_ll_(l11l11llll11_ll_)
        if not l1l11111111_ll_:
            raise Exception(l11l111_ll_ (u"ࠩࡖ࡭࡬ࡴࡡࡵࡷࡵࡩࠥ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠪ䟐"))
        _11l11llll1l_ll_ = self._11l1l111111_ll_(l1l11111111_ll_, l11l11llll11_ll_)
        l11l11lll1l1_ll_ = _11l11llll1l_ll_[0].replace(l11l111_ll_ (u"ࠪࡠࡳ࠭䟑"), l11l111_ll_ (u"ࠫࠬ䟒")).split(l11l111_ll_ (u"ࠬ࠲ࠧ䟓"))
        l11l11ll1lll_ll_ = _11l11llll1l_ll_[1].replace(l11l111_ll_ (u"࠭࡜࡯ࠩ䟔"), l11l111_ll_ (u"ࠧࠨ䟕")).split(l11l111_ll_ (u"ࠨ࠽ࠪ䟖"))
        l1l1llllllll_ll_ = {l11l111_ll_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࡵࠪ䟗"): []}
        for line in l11l11ll1lll_ll_:
            l11l11lllll1_ll_ = re.match(l11l111_ll_ (u"ࡵࠫࠪࡹ࡜ࡴࡁࡀࡠࡸࡅࠥࡴ࠰ࡶࡴࡱ࡯ࡴ࡝ࠪࠥࠦࡡ࠯ࠧ䟘") % (l11l11lll1l1_ll_[0], l11l11lll1l1_ll_[0]), line)
            if l11l11lllll1_ll_:
                l1l1llllllll_ll_[l11l111_ll_ (u"ࠫࡦࡩࡴࡪࡱࡱࡷࠬ䟙")].append({l11l111_ll_ (u"ࠬ࡬ࡵ࡯ࡥࠪ䟚"): l11l111_ll_ (u"࠭࡬ࡪࡵࡷࠫ䟛"),
                                               l11l111_ll_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ䟜"): [l11l111_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䟝")]})
            l11l1l111l11_ll_ = re.match(l11l111_ll_ (u"ࡴࠪࡶࡪࡺࡵࡳࡰ࡟ࡷ࠰ࠫࡳ࠯࡬ࡲ࡭ࡳࡢࠨࠣࠤ࡟࠭ࠬ䟞") % l11l11lll1l1_ll_[0], line)
            if l11l1l111l11_ll_:
                l1l1llllllll_ll_[l11l111_ll_ (u"ࠪࡥࡨࡺࡩࡰࡰࡶࠫ䟟")].append({l11l111_ll_ (u"ࠫ࡫ࡻ࡮ࡤࠩ䟠"): l11l111_ll_ (u"ࠬࡰ࡯ࡪࡰࠪ䟡"),
                                               l11l111_ll_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭䟢"): [l11l111_ll_ (u"ࠧࠦࡕࡌࡋࠪ࠭䟣")]})
            l11l11llllll_ll_ = re.match(
                l11l111_ll_ (u"ࡳࠩࠫࡃࡕࡂ࡯ࡣ࡬ࡨࡧࡹࡥ࡮ࡢ࡯ࡨࡂࡠࠪࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡟࠮࠭ࡡ࠴࠿࡝࡝ࡂࠦࡄ࠮࠿ࡑ࠾ࡩࡹࡳࡩࡴࡪࡱࡱࡣࡳࡧ࡭ࡦࡀ࡞ࠨࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡝ࠬࠫࠥࡃࡡࡣ࠿࡝ࠪࠫࡃࡕࡂࡰࡢࡴࡤࡱࡪࡺࡥࡳࡀ࡞ࡢ࠮ࡣࠫࠪ࡞ࠬࠫ䟤"),
                line)
            if l11l11llllll_ll_:
                l11l1l11111l_ll_ = l11l11llllll_ll_.group(l11l111_ll_ (u"ࠩࡲࡦ࡯࡫ࡣࡵࡡࡱࡥࡲ࡫ࠧ䟥"))
                l1l11111111_ll_ = l11l11llllll_ll_.group(l11l111_ll_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࡤࡴࡡ࡮ࡧࠪ䟦"))
                l1lll1111l11_ll_ = l11l11llllll_ll_.group(l11l111_ll_ (u"ࠫࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࠧ䟧")).split(l11l111_ll_ (u"ࠬ࠲ࠧ䟨"))
                for i in range(len(l1lll1111l11_ll_)):
                    param = l1lll1111l11_ll_[i].strip()
                    if i == 0:
                        param = l11l111_ll_ (u"࠭ࠥࡔࡋࡊࠩࠬ䟩")
                    else:
                        param = int(param)
                    l1lll1111l11_ll_[i] = param
                _11l11llll1l_ll_ = self._11l11lll111_ll_(l11l1l11111l_ll_, l1l11111111_ll_, l11l11llll11_ll_)
                l11l1l1111l1_ll_ = re.match(l11l111_ll_ (u"ࡲࠨ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮࠲ࡸࡲࡩࡤࡧ࡟ࠬ࠭ࡅࡐ࠽ࡣࡁࡠࡩ࠱ࠩ࠭࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࡠ࠮࠭䟪"), _11l11llll1l_ll_[l11l111_ll_ (u"ࠨࡤࡲࡨࡾ࠭䟫")][0])
                if l11l1l1111l1_ll_:
                    a = int(l11l1l1111l1_ll_.group(l11l111_ll_ (u"ࠩࡤࠫ䟬")))
                    params = [l11l111_ll_ (u"ࠪࠩࡘࡏࡇࠦࠩ䟭"), a, l1lll1111l11_ll_[1]]
                    l1l1llllllll_ll_[l11l111_ll_ (u"ࠫࡦࡩࡴࡪࡱࡱࡷࠬ䟮")].append({l11l111_ll_ (u"ࠬ࡬ࡵ࡯ࡥࠪ䟯"): l11l111_ll_ (u"࠭ࡳ࡭࡫ࡦࡩࠬ䟰"),
                                                   l11l111_ll_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ䟱"): params})
                l11l11lll1ll_ll_ = re.match(l11l111_ll_ (u"ࡳࠩ࡞ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯࠳ࡹࡰ࡭࡫ࡦࡩࡡ࠮ࠨࡀࡒ࠿ࡥࡃࡢࡤࠬࠫ࠯࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰ࡢࠩࠨ䟲"), _11l11llll1l_ll_[l11l111_ll_ (u"ࠩࡥࡳࡩࡿࠧ䟳")][0])
                if l11l11lll1ll_ll_:
                    a = int(l11l11lll1ll_ll_.group(l11l111_ll_ (u"ࠪࡥࠬ䟴")))
                    params = [l11l111_ll_ (u"࡙ࠫࠪࡉࡈࠧࠪ䟵"), a, l1lll1111l11_ll_[1]]
                    l1l1llllllll_ll_[l11l111_ll_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡸ࠭䟶")].append({l11l111_ll_ (u"࠭ࡦࡶࡰࡦࠫ䟷"): l11l111_ll_ (u"ࠧࡴࡲ࡯࡭ࡨ࡫ࠧ䟸"),
                                                   l11l111_ll_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ䟹"): params})
                l11l1l111ll1_ll_ = re.match(l11l111_ll_ (u"ࡴࠪࡺࡦࡸ࡜ࡴࡁ࡞ࡥ࠲ࢀࡁ࠮࡜ࡠ࠯ࡂࡢࡳࡀ࡝ࡤ࠱ࡿࡇ࡛࠭࡟࠮ࡠࡠ࠶࡜࡞ࠩ䟺"), _11l11llll1l_ll_[l11l111_ll_ (u"ࠪࡦࡴࡪࡹࠨ䟻")][0])
                if l11l1l111ll1_ll_:
                    params = [l11l111_ll_ (u"࡙ࠫࠪࡉࡈࠧࠪ䟼"), l1lll1111l11_ll_[1]]
                    l1l1llllllll_ll_[l11l111_ll_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡸ࠭䟽")].append({l11l111_ll_ (u"࠭ࡦࡶࡰࡦࠫ䟾"): l11l111_ll_ (u"ࠧࡴࡹࡤࡴࠬ䟿"),
                                                   l11l111_ll_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ䠀"): params})
                l11l1l1111ll_ll_ = re.match(l11l111_ll_ (u"ࡴࠪ࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠳ࡸࡥࡷࡧࡵࡷࡪࡢࠨ࡝ࠫࠪ䠁"), _11l11llll1l_ll_[l11l111_ll_ (u"ࠪࡦࡴࡪࡹࠨ䠂")][0])
                if l11l1l1111ll_ll_:
                    params = [l11l111_ll_ (u"࡙ࠫࠪࡉࡈࠧࠪ䠃")]
                    l1l1llllllll_ll_[l11l111_ll_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡸ࠭䠄")].append({l11l111_ll_ (u"࠭ࡦࡶࡰࡦࠫ䠅"): l11l111_ll_ (u"ࠧࡳࡧࡹࡩࡷࡹࡥࠨ䠆"),
                                                   l11l111_ll_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ䠇"): params})
        return l1l1llllllll_ll_
    @staticmethod
    def _11l1l111lll_ll_(l11l11llll11_ll_):
        l11l11ll1ll1_ll_ = [
            l11l111_ll_ (u"ࡴࠪࡠࡧࡡࡣࡴ࡟࡟ࡷ࠯ࠬࠦ࡝ࡵ࠭࡟ࡦࡪࡦ࡞࡞࠱ࡷࡪࡺ࡜ࠩ࡝ࡡ࠰ࡢ࠱࡜ࡴࠬ࠯ࡠࡸ࠰ࡥ࡯ࡥࡲࡨࡪ࡛ࡒࡊࡅࡲࡱࡵࡵ࡮ࡦࡰࡷࡠࡸ࠰࡜ࠩ࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡ࠰࠯࡜ࠩࠩ䠈"),
            l11l111_ll_ (u"ࡵࠫࡡࡨ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡠ࠯ࡡࡹࠪࠧࠨ࡟ࡷ࠯ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡟࠮ࡠ࠳ࡹࡥࡵ࡞ࠫ࡟ࡣ࠲࡝ࠬ࡞ࡶ࠮࠱ࡢࡳࠫࡧࡱࡧࡴࡪࡥࡖࡔࡌࡇࡴࡳࡰࡰࡰࡨࡲࡹࡢࡳࠫ࡞ࠫࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࠫࠫ䠉"),
            l11l111_ll_ (u"ࡶࠬ࠮࠿࠻࡞ࡥࢀࡠࡤࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠭࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡࢀ࠸ࡽࠪ࡞ࡶ࠮ࡂࡢࡳࠫࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡡࡹࠪࡢ࡞ࡶ࠮ࡡ࠯࡜ࡴࠬࡾࡠࡸ࠰ࡡ࡝ࡵ࠭ࡁࡡࡹࠪࡢ࡞࠱ࡷࡵࡲࡩࡵ࡞ࠫࡠࡸ࠰ࠢࠣ࡞ࡶ࠮ࡡ࠯ࠧ䠊"),
            l11l111_ll_ (u"ࡷ࠭ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࡶ࠮ࡂࡢࡳࠫࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬࡡࡹࠪࡢ࡞ࡶ࠮ࡡ࠯࡜ࡴࠬࡾࡠࡸ࠰ࡡ࡝ࡵ࠭ࡁࡡࡹࠪࡢ࡞࠱ࡷࡵࡲࡩࡵ࡞ࠫࡠࡸ࠰ࠢࠣ࡞ࡶ࠮ࡡ࠯ࠧ䠋"),
            l11l111_ll_ (u"ࡸࠧࠩ࡝ࠥࡠࠬࡣࠩࡴ࡫ࡪࡲࡦࡺࡵࡳࡧ࡟࠵ࡡࡹࠪ࠭࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡ࠰࠯࡜ࠩࠩ䠌"),
            l11l111_ll_ (u"ࡲࠨ࡞࠱ࡷ࡮࡭࡜ࡽ࡞ࡿࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠯࠮ࡢࠨࠨ䠍"),
            l11l111_ll_ (u"ࡳࠩࡼࡸࡡ࠴ࡡ࡬ࡣࡰࡥ࡮ࢀࡥࡥ࡞࠱ࡲࡪࡺ࠯࡝ࠫ࡟ࡷ࠯ࡢࡼ࡝ࡾ࡟ࡷ࠯࠴ࠪࡀ࡞ࡶ࠮ࡠࡩࡳ࡞࡞ࡶ࠮ࠫࠬ࡜ࡴࠬ࡞ࡥࡩ࡬࡝࡝࠰ࡶࡩࡹࡢࠨ࡜ࡠ࠯ࡡ࠰ࡢࡳࠫ࠮࡟ࡷ࠯࠮࠿࠻ࡧࡱࡧࡴࡪࡥࡖࡔࡌࡇࡴࡳࡰࡰࡰࡨࡲࡹࡢࡳࠫ࡞ࠫ࠭ࡄࡢࡳࠫࠩ䠎")
            l11l111_ll_ (u"ࡴࠪࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠯࠮ࡢࠨࠨ䠏"),
            l11l111_ll_ (u"ࡵࠫࡡࡨ࡛ࡤࡵࡠࡠࡸ࠰ࠦࠧ࡞ࡶ࠮ࡠࡧࡤࡧ࡟࡟࠲ࡸ࡫ࡴ࡝ࠪ࡞ࡢ࠱ࡣࠫ࡝ࡵ࠭࠰ࡡࡹࠪࠩࡁࡓࡀࡳࡧ࡭ࡦࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠬࠫ࡟ࠬࠬ䠐"),
            l11l111_ll_ (u"ࡶࠬࡢࡢ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡡ࠰ࡢࡳࠫࠨࠩࡠࡸ࠰࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡠ࠯ࡡ࠴ࡳࡦࡶ࡟ࠬࡠࡤࠬ࡞࠭࡟ࡷ࠯࠲࡜ࡴࠬࠫࡃࡕࡂ࡮ࡢ࡯ࡨࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࠥ࡟࠮࠭ࡡ࠮ࠧ䠑"),
            l11l111_ll_ (u"ࡷ࠭࡜ࡣࡥ࡟ࡷ࠯ࠬࠦ࡝ࡵ࠭ࡥࡡ࠴ࡳࡦࡶ࡟ࠬࡠࡤࠬ࡞࠭࡟ࡷ࠯࠲࡜ࡴࠬ࡟ࠬࡠࡤࠩ࡞ࠬ࡟࠭ࡡࡹࠪ࡝ࠪ࡟ࡷ࠯࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࠨࡢ࠱ࠩ࡝ࠪࠪ䠒"),
            l11l111_ll_ (u"ࡸࠧ࡝ࡤࡦࡠࡸ࠰ࠦࠧ࡞ࡶ࠮ࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹࡞࠭࡟࠲ࡸ࡫ࡴ࡝ࠪ࡞ࡢ࠱ࡣࠫ࡝ࡵ࠭࠰ࡡࡹࠪ࡝ࠪ࡞ࡢ࠮ࡣࠪ࡝ࠫ࡟ࡷ࠯ࡢࠨ࡝ࡵ࠭ࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠯࠮ࡢࠨࠨ䠓"),
            l11l111_ll_ (u"ࡲࠨ࡞ࡥࡧࡡࡹࠪࠧࠨ࡟ࡷ࠯ࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡟࠮ࡠ࠳ࡹࡥࡵ࡞ࠫ࡟ࡣ࠲࡝ࠬ࡞ࡶ࠮࠱ࡢࡳࠫ࡞ࠫ࡟ࡣ࠯࡝ࠫ࡞ࠬࡠࡸ࠰࡜ࠩ࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡ࠰࠯࡜ࠩࠩ䠔")
        ]
        for pattern in l11l11ll1ll1_ll_:
            match = re.search(pattern, l11l11llll11_ll_)
            if match:
                return match.group(l11l111_ll_ (u"ࠨࡰࡤࡱࡪ࠭䠕"))
        return l11l111_ll_ (u"ࠩࠪ䠖")
    @staticmethod
    def _11l1l111111_ll_(l1l11111111_ll_, l11l11llll11_ll_):
        l1l11111111_ll_ = l1l11111111_ll_.replace(l11l111_ll_ (u"ࠪࠨࠬ䠗"), l11l111_ll_ (u"ࠫࡡࡢࠤࠨ䠘"))
        match = re.search(l11l111_ll_ (u"ࡷ࠭࡜ࡴࡁࠨࡷࡂ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࠪࡂࡔࡁࡶࡡࡳࡣࡰࡩࡹ࡫ࡲ࠿࡝ࡡ࠭ࡢ࠱ࠩ࡝ࠫ࡟ࡷࡄࢁ࡜ࡴࡁࠫࡃࡕࡂࡢࡰࡦࡼࡂࡠࡤࡽ࡞࠭ࠬࡠࡸࡅ࡜ࡾࠩ䠙") % l1l11111111_ll_, l11l11llll11_ll_)
        if match:
            return match.group(l11l111_ll_ (u"࠭ࡰࡢࡴࡤࡱࡪࡺࡥࡳࠩ䠚")), match.group(l11l111_ll_ (u"ࠧࡣࡱࡧࡽࠬ䠛"))
        return l11l111_ll_ (u"ࠨࠩ䠜"), l11l111_ll_ (u"ࠩࠪ䠝")
    @staticmethod
    def _11l1l111l1l_ll_(l11l1l11111l_ll_, l11l11llll11_ll_):
        l11l1l11111l_ll_ = l11l1l11111l_ll_.replace(l11l111_ll_ (u"ࠪࠨࠬ䠞"), l11l111_ll_ (u"ࠫࡡࡢࠤࠨ䠟"))
        match = re.search(l11l111_ll_ (u"ࡷ࠭ࡶࡢࡴࠣࠩࡸࡃࡻࠩࡁࡓࡀࡴࡨࡪࡦࡥࡷࡣࡧࡵࡤࡺࡀ࠱࠮ࡄࢃࠩࡾ࠽ࠪ䠠") % l11l1l11111l_ll_, l11l11llll11_ll_, re.S)
        if match:
            return match.group(l11l111_ll_ (u"࠭࡯ࡣ࡬ࡨࡧࡹࡥࡢࡰࡦࡼࠫ䠡"))
        return l11l111_ll_ (u"ࠧࠨ䠢")
    def _11l11lll111_ll_(self, l11l1l11111l_ll_, l1l11111111_ll_, l11l11llll11_ll_):
        if l11l1l11111l_ll_ not in self._1l1l1llllll_ll_:
            self._1l1l1llllll_ll_[l11l1l11111l_ll_] = {}
        else:
            if l1l11111111_ll_ in self._1l1l1llllll_ll_[l11l1l11111l_ll_]:
                return self._1l1l1llllll_ll_[l11l1l11111l_ll_][l1l11111111_ll_]
        _11l11lll11l_ll_ = self._11l1l111l1l_ll_(l11l1l11111l_ll_, l11l11llll11_ll_)
        _11l11lll11l_ll_ = _11l11lll11l_ll_.split(l11l111_ll_ (u"ࠨࡿ࠯ࠫ䠣"))
        for _11l11llll1l_ll_ in _11l11lll11l_ll_:
            if not _11l11llll1l_ll_.endswith(l11l111_ll_ (u"ࠩࢀࠫ䠤")):
                _11l11llll1l_ll_ = l11l111_ll_ (u"ࠪࠫ䠥").join([_11l11llll1l_ll_, l11l111_ll_ (u"ࠫࢂ࠭䠦")])
            _11l11llll1l_ll_ = _11l11llll1l_ll_.strip()
            match = re.match(l11l111_ll_ (u"ࡷ࠭ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡡ࠾ࡢ࠰ࠩ࠻ࡨࡸࡲࡨࡺࡩࡰࡰ࡟ࠬ࠭ࡅࡐ࠽ࡲࡤࡶࡦࡳࡥࡵࡧࡵࡂࡠࡤࠩ࡞ࠬࠬࡠ࠮ࢁࠨࡀࡒ࠿ࡦࡴࡪࡹ࠿࡝ࡡࢁࡢ࠱ࠩࡾࠩ䠧"), _11l11llll1l_ll_)
            if match:
                name = match.group(l11l111_ll_ (u"࠭࡮ࡢ࡯ࡨࠫ䠨")).replace(l11l111_ll_ (u"ࠧࠣࠩ䠩"), l11l111_ll_ (u"ࠨࠩ䠪"))
                l1lll1111l11_ll_ = match.group(l11l111_ll_ (u"ࠩࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࠬ䠫"))
                body = match.group(l11l111_ll_ (u"ࠪࡦࡴࡪࡹࠨ䠬")).split(l11l111_ll_ (u"ࠫࡀ࠭䠭"))
                self._1l1l1llllll_ll_[l11l1l11111l_ll_][name] = {l11l111_ll_ (u"ࠬࡴࡡ࡮ࡧࠪ䠮"): name,
                                                         l11l111_ll_ (u"࠭ࡢࡰࡦࡼࠫ䠯"): body,
                                                         l11l111_ll_ (u"ࠧࡱࡣࡵࡥࡲࡹࠧ䠰"): l1lll1111l11_ll_}
        return self._1l1l1llllll_ll_[l11l1l11111l_ll_][l1l11111111_ll_]