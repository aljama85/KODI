# -*- coding: utf-8 -*-
import sys
l11ll1l_ll_ = sys.version_info [0] == 2
l1111l_ll_ = 2048
l11l1_ll_ = 7
def l11l111_ll_ (ll_ll_):
    global l1l1111_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l1l111_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l1l111_ll_)
    l11l_ll_ = l1l111_ll_ [:l1l1_ll_] + l1l111_ll_ [l1l1_ll_:]
    if l11ll1l_ll_:
        l1l1lll_ll_ = unicode () .join ([unichr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1lll_ll_ = str () .join ([chr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1lll_ll_)
l11l111_ll_ (u"ࠣࠤࠥࠎࠏࠦࠠࠡࠢࡆࡳࡵࡿࡲࡪࡩ࡫ࡸࠥ࠮ࡃࠪࠢ࠵࠴࠶࠺࠭࠳࠲࠴࠺ࠥࡨࡲࡰ࡯࡬ࡼࠥ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠊࠡࠢࠣࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࠩࡅࠬࠤ࠷࠶࠱࠷࠯࠵࠴࠶࠾ࠠࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫ࠊࠋࠢࠣࠤ࡙ࠥࡐࡅ࡚࠰ࡐ࡮ࡩࡥ࡯ࡵࡨ࠱ࡎࡪࡥ࡯ࡶ࡬ࡪ࡮࡫ࡲ࠻ࠢࡊࡔࡑ࠳࠲࠯࠲࠰ࡳࡳࡲࡹࠋࠢࠣࠤ࡙ࠥࡥࡦࠢࡏࡍࡈࡋࡎࡔࡇࡖ࠳ࡌࡖࡌ࠮࠴࠱࠴࠲ࡵ࡮࡭ࡻࠣࡪࡴࡸࠠ࡮ࡱࡵࡩࠥ࡯࡮ࡧࡱࡵࡱࡦࡺࡩࡰࡰ࠱ࠎࠧࠨࠢ䠱")
#from six.moves import range
class l1ll11l11lll_ll_(object):
    def __init__(self, l1l1llllllll_ll_):
        self._11l11ll111l_ll_ = l1l1llllllll_ll_
    def execute(self, signature):
        _signature = signature
        _11l11l1lll1_ll_ = self._11l11ll111l_ll_[l11l111_ll_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࡵࠪ䠲")]
        for action in _11l11l1lll1_ll_:
            func = l11l111_ll_ (u"ࠪࠫ䠳").join([l11l111_ll_ (u"ࠫࡤ࠭䠴"), action[l11l111_ll_ (u"ࠬ࡬ࡵ࡯ࡥࠪ䠵")]])
            params = action[l11l111_ll_ (u"࠭ࡰࡢࡴࡤࡱࡸ࠭䠶")]
            if func == l11l111_ll_ (u"ࠧࡠࡴࡨࡸࡺࡸ࡮ࠨ䠷"):
                break
            for i in range(len(params)):
                param = params[i]
                if param == l11l111_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䠸"):
                    param = _signature
                    params[i] = param
                    break
            method = getattr(self, func)
            if method:
                _signature = method(*params)
            else:
                raise Exception(l11l111_ll_ (u"ࠤࡘࡲࡰࡴ࡯ࡸࡰࠣࡱࡪࡺࡨࡰࡦࠣࠫࠪࡹࠧࠣ䠹") % func)
        return _signature
    @staticmethod
    def _11l11ll11l1_ll_(signature):
        return l11l111_ll_ (u"ࠪࠫ䠺").join(signature)
    @staticmethod
    def _11l11ll1l1l_ll_(signature):
        return list(signature)
    @staticmethod
    def _11l11ll1111_ll_(signature, b):
        del signature[b:]
        return signature
    @staticmethod
    def _11l11ll11ll_ll_(signature, a, b):
        del signature[a:b]
        return signature
    @staticmethod
    def _11l11ll1l11_ll_(signature):
        return signature[::-1]
    @staticmethod
    def _11l11l1llll_ll_(signature, b):
        c = signature[0]
        signature[0] = signature[b % len(signature)]
        signature[b] = c
        return signature