﻿# -*- coding: utf-8 -*-
import sys
l11ll1l_ll_ = sys.version_info [0] == 2
l1111l_ll_ = 2048
l11l1_ll_ = 7
def l11l111_ll_ (ll_ll_):
    global l1l1111_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l1l111_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l1l111_ll_)
    l11l_ll_ = l1l111_ll_ [:l1l1_ll_] + l1l111_ll_ [l1l1_ll_:]
    if l11ll1l_ll_:
        l1l1lll_ll_ = unicode () .join ([unichr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1lll_ll_ = str () .join ([chr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1lll_ll_)
l11l111_ll_ (u"ࠦࠧࠨࠍࠋࠏࠍࠤࠥࠦࠠࡄࡱࡳࡽࡷ࡯ࡧࡩࡶࠣࠬࡈ࠯ࠠ࠳࠲࠴࠸࠲࠸࠰࠲࠸ࠣࡦࡷࡵ࡭ࡪࡺࠣࠬࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠭ࠒࠐࠠࠡࠢࠣࡇࡴࡶࡹࡳ࡫ࡪ࡬ࡹࠦࠨࡄࠫࠣ࠶࠵࠷࠶࠮࠴࠳࠵࠽ࠦࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪࠓࠊࠎࠌࠣࠤࠥࠦࡓࡑࡆ࡛࠱ࡑ࡯ࡣࡦࡰࡶࡩ࠲ࡏࡤࡦࡰࡷ࡭࡫࡯ࡥࡳ࠼ࠣࡋࡕࡒ࠭࠳࠰࠳࠱ࡴࡴ࡬ࡺࠏࠍࠤࠥࠦࠠࡔࡧࡨࠤࡑࡏࡃࡆࡐࡖࡉࡘ࠵ࡇࡑࡎ࠰࠶࠳࠶࠭ࡰࡰ࡯ࡽࠥ࡬࡯ࡳࠢࡰࡳࡷ࡫ࠠࡪࡰࡩࡳࡷࡳࡡࡵ࡫ࡲࡲ࠳ࠓࠊࠣࠤࠥ䠻")
#from ....youtube.helper.signature.cipher import Cipher
#__all__ = [l11l111_ll_ (u"ࠬࡉࡩࡱࡪࡨࡶࠬ䠼")]