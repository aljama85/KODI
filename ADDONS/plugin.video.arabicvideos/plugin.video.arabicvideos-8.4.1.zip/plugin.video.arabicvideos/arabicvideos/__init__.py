# -*- coding: utf-8 -*-
import sys
l11ll1l_ll_ = sys.version_info [0] == 2
l1111l_ll_ = 2048
l11l1_ll_ = 7
def l11l111_ll_ (ll_ll_):
    global l1l1111_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l1l111_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l1l111_ll_)
    l11l_ll_ = l1l111_ll_ [:l1l1_ll_] + l1l111_ll_ [l1l1_ll_:]
    if l11ll1l_ll_:
        l1l1lll_ll_ = unicode () .join ([unichr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1lll_ll_ = str () .join ([chr (ord (char) - l1111l_ll_ - (l1l1l1_ll_ + l11ll_ll_) % l11l1_ll_) for l1l1l1_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1lll_ll_)
from l1l1ll_ll_ import *
LOG_THIS(l11l111_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䟉"),l11l111_ll_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ䟊"))
#import l1l_ll_,l1l1llll_ll_,l1ll111_ll_,l11l11ll_ll_,l1lll111l_ll_,l1ll111ll_ll_,l1ll11111_ll_,l1l111lll_ll_,l11l1ll1l_ll_,l11l11ll1_ll_,l111l1l11_ll_,l1llll11ll_ll_,l1ll11l1ll_ll_,l1l11ll1l1_ll_,l1l11111l1_ll_,l11l1lll11_ll_,l111l111ll_ll_,l1lll1ll1l1_ll_,l1l1l1l1ll1_ll_,l11l1l1l111_ll_,l11l1l1ll1l_ll_,l1l11l1111l_ll_,l11l1ll1111_ll_,l1ll1ll1l11_ll_,l1l111l1l1l_ll_,l1ll1l1lll1_ll_,l11ll11l1l1_ll_,l1ll1lll1l1_ll_,l1l1lll11ll_ll_,l1l11lll1l1_ll_,l1_ll_,l1l11l1111_ll_,l1l1ll_ll_,EXCLUDES
l1ll1llll_ll_(l11l111_ll_ (u"ࠫࡸࡺࡡࡳࡶࠪ䟋"))
try: l111ll1_ll_()
except Exception as error: l1l111lll11_ll_(error)
l1ll1llll_ll_(l11l111_ll_ (u"ࠬࡹࡴࡰࡲࠪ䟌"))
#a = l1llll11l1l_ll_(l11l111_ll_ (u"࠭ࡍࡊࡕࡆࠫ䟍"),l11l111_ll_ (u"ࠧࡖࡕࡈࡖࡆࡍࡅࡏࡖ࠴࠶࠸࠭䟎"))
#DIALOG_OK(str(a),str(a))
#import l11ll11l11_ll_,l1l111111_ll_,l1l1l11l1l_ll_,l11l1llll1_ll_,l11ll1l1ll1_ll_,l1lll11lll1_ll_