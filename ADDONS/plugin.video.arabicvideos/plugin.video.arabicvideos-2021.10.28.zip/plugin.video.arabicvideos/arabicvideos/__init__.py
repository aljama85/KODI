# -*- coding: utf-8 -*-
import sys
l111ll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l111l1l_l1_ = 7
def l11111_l1_ (ll_l1_):
    global l11ll1l_l1_
    l1111_l1_ = ord (ll_l1_ [-1])
    l11ll1_l1_ = ll_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l111ll_l1_:
        l1l1ll1_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1ll1_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1ll1_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l11111_l1_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ佣"),l11111_l1_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࠪ佤"))
l1l1ll1l1_l1_(l11111_l1_ (u"ࠫࡸࡺࡡࡳࡶࠪ佥"))
try: l1111ll_l1_()
except Exception as error: l1l1ll1l1l1_l1_(error)
l1l1ll1l1_l1_(l11111_l1_ (u"ࠬࡹࡴࡰࡲࠪ佦"))
#xbmc.executebuiltin(l11111_l1_ (u"࠭ࡕࡱࡦࡤࡸࡪࡒ࡯ࡤࡣ࡯ࡅࡩࡪ࡯࡯ࡵࠪ佧"))
#result = l1ll1l1ll111_l1_(l11111_l1_ (u"ࠧࡺࡣ࡫ࡳࡴ࠴ࡣࡰ࡯ࠪ佨"),l11111_l1_ (u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ佩"))
#l1ll11_l1_(l11111_l1_ (u"ࠩࠪ佪"),l11111_l1_ (u"ࠪࠫ佫"),l11111_l1_ (u"ࠫࠬ佬"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1l1lll_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll1l111l_l1_,l11llll111_l1_,l111lll1ll_l1_,l11111ll1l_l1_,l1lll11lll1_l1_,l1ll111l1l1_l1_,l1111ll11ll_l1_,l11lll1l1l1_l1_,l11111ll1ll_l1_,l1l11111lll_l1_,l111111llll_l1_,l1l1111ll11_l1_,l1l1ll111ll_l1_,l1l1l1l111l_l1_,l1l11lll1l1_l1_,l111l1ll11_l1_
#import l1_l1_,l1l11l_l1_,l1l1l1ll11_l1_,l1lll11lll1l_l1_,l111l1111l_l1_,l1lll1ll1lll_l1_,l11ll11llll_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l11111_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡵࡲ࡮ࡲࡥࡩ࠴ࡣࡰ࡯࠲ࡩࡲࡨࡥࡥ࠯࠻࡬࡯࠶࠳࠷ࡼࡥࡱࡸ࠹࠴࠯ࡪࡷࡱࡱ࠭佭")
#url = l11111_l1_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡥࡴ࡬ࡺࡪ࠴ࡧࡰࡱࡪࡰࡪ࠴ࡣࡰ࡯࠲ࡪ࡮ࡲࡥ࠰ࡦ࠲࠴ࡇ࠷࡙ࡵࡈ࠰ࡺࡦ࡫࠵ࡺ࡯ࡐࡈࡩࡌࡒ࠳ࡱ࠷ࡗࡉ࡜ࡒࡎࡗ࡮࠳ࡵࡸࡥࡷ࡫ࡨࡻࠬ佮")
#import l111lll11ll1_l1_
#results = l111lll11ll1_l1_.resolve(url)
#l1llll11l_l1_(l11111_l1_ (u"ࠧࠨ佯"),l11111_l1_ (u"ࠨࡔࡈࡗࡔ࡜ࡅࡖࡔࡏࡣࡆ࡜ࠠ࠻ࠢࠣࠤࠬ佰")+str(results))
#import l111lll11lll_l1_
#l1l11lllll11_l1_ = l111lll11lll_l1_.YoutubeDL({l11111_l1_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ佱"): True})
#results = l1l11lllll11_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l11111_l1_ (u"ࠪࠫ佲"),l11111_l1_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࡉࡒ࡟ࡂࡘࠣ࠾ࠥࠦࠠࠨ佳")+str(results))
#l1ll11_l1_(l11111_l1_ (u"ࠬ࠭佴"),l11111_l1_ (u"࠭ࠧ併"),str(results))
#sys.exit()