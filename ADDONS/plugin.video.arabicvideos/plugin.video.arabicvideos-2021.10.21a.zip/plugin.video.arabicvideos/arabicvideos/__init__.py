# -*- coding: utf-8 -*-
import sys
l111ll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l111l1l_l1_ = 7
def l11111_l1_ (ll_l1_):
    global l11ll1l_l1_
    l1111_l1_ = ord (ll_l1_ [-1])
    l11ll1_l1_ = ll_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l111ll_l1_:
        l1l1ll1_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1ll1_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1ll1_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l11111_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ佃"),l11111_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭佄"))
l1l1ll1l1_l1_(l11111_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭佅"))
try: l1111ll_l1_()
except Exception as error: l1ll1ll1l1l1_l1_(error)
l1l1ll1l1_l1_(l11111_l1_ (u"ࠨࡵࡷࡳࡵ࠭但"))
#xbmc.executebuiltin(l11111_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭佇"))
#result = l1ll1ll111l1_l1_(l11111_l1_ (u"ࠪࡽࡦ࡮࡯ࡰ࠰ࡦࡳࡲ࠭佈"),l11111_l1_ (u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬ佉"))
#l1ll11_l1_(l11111_l1_ (u"ࠬ࠭佊"),l11111_l1_ (u"࠭ࠧ佋"),l11111_l1_ (u"ࠧࠨ佌"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1l1lll_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll1l111l_l1_,l11llll111_l1_,l111lll1ll_l1_,l11111ll1l_l1_,l1lll11lll1_l1_,l1ll111l1l1_l1_,l1111lll111_l1_,l11lll1ll11_l1_,l1111l1111l_l1_,l1l1111l11l_l1_,l11111l1ll1_l1_,l1l1111lll1_l1_,l1l1ll11l11_l1_,l1l1l1l111l_l1_,l1l11lll1ll_l1_,l111l1ll11_l1_
#import l1_l1_,l1l11l_l1_,l1l1l1ll11_l1_,l1lll1l11lll_l1_,l111l1111l_l1_,l1llll111111_l1_,l11ll1l11l1_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l11111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡸࡵࡱࡵࡡࡥ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠲࠾ࡨ࡫࠲࠶࠺ࡿࡨ࡭ࡴ࠵࠷࠲࡭ࡺ࡭࡭ࠩ位")
#url = l11111_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡨࡷ࡯ࡶࡦ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡦࡪ࡮ࡨ࠳ࡩ࠵࠰ࡃ࠳࡜ࡸࡋ࠳ࡶࡢࡧ࠸ࡽࡲࡓࡄࡥࡈࡕ࠶ࡴ࠺ࡓࡅࡘࡕࡑ࡚ࡱ࠯ࡱࡴࡨࡺ࡮࡫ࡷࠨ低")
#import resolveurl_av
#results = resolveurl_av.resolve(url)
#l1llll11l_l1_(l11111_l1_ (u"ࠪࠫ住"),l11111_l1_ (u"ࠫࡗࡋࡓࡐࡘࡈ࡙ࡗࡒ࡟ࡂࡘࠣ࠾ࠥࠦࠠࠨ佐")+str(results))
#import youtubedl_av
#l1l1l1111l11_l1_ = youtubedl_av.YoutubeDL({l11111_l1_ (u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸࠧ佑"): True})
#results = l1l1l1111l11_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l11111_l1_ (u"࠭ࠧ佒"),l11111_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࡅࡎࡢࡅ࡛ࠦ࠺ࠡࠢࠣࠫ体")+str(results))
#l1ll11_l1_(l11111_l1_ (u"ࠨࠩ佔"),l11111_l1_ (u"ࠩࠪ何"),str(results))
#sys.exit()