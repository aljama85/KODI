# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_ = l111lll_ll_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜ࠬ䃃")
l1l1l1l_ll_=l111lll_ll_ (u"ࠫࡤ࡙ࡈࡇࡡࠪ䃄")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1l1llll1_ll_ = l11l11l_ll_[l1ll_ll_][1]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==50: results = l11l1ll_ll_(url)
	elif mode==51: results = l1l11l1_ll_(url)
	elif mode==52: results = l1l11ll_ll_(url)
	elif mode==53: results = l11_ll_(url)
	elif mode==55: results = l11ll11ll11l_ll_()
	elif mode==56: results = l11ll11l1l1l_ll_()
	elif mode==57: results = l11ll11l1ll1_ll_(url,1)
	elif mode==58: results = l11ll11l1ll1_ll_(url,2)
	elif mode==59: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠬ࠭䃅")):
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃆"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ䃇"),l111lll_ll_ (u"ࠨࠩ䃈"),59,l111lll_ll_ (u"ࠩࠪ䃉"),l111lll_ll_ (u"ࠪࠫ䃊"),l111lll_ll_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ䃋"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䃌"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ䃍")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆ่ืู้ไศฬࠪ䃎"),l111lll_ll_ (u"ࠨࠩ䃏"),56)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃐"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ䃑")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊วโๆส้ࠬ䃒"),l111lll_ll_ (u"ࠬ࠭䃓"),55)
	return l111lll_ll_ (u"࠭ࠧ䃔")
def l11ll11ll11l_ll_():
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃕"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษะำะࠦวๅษไ่ฬ๋ࠧ䃖"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡳ࡫ࡷࡦࡵࡷࠫ䃗"),51)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃘"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ็ไศ็ࠣีฬฬฬสࠩ䃙"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩ࠴࠷࠯ࡱࡱࡳࡹࡱࡧࡲࠨ䃚"),51)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃛"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧศะิࠤฬ฼วโษอࠤฬ๊วโๆส้ࠬ䃜"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥ࠰࠳࠲ࡰࡦࡺࡥࡴࡶࠪ䃝"),51)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃞"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪหๆ๊วๆࠢๆ่ฬู๊ไ์ฬࠫ䃟"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨ࠳࠶࠵ࡣ࡭ࡣࡶࡷ࡮ࡩࠧ䃠"),51)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ䃡"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䃢"),l111lll_ll_ (u"ࠧࠨ䃣"),9999)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䃤"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩสาฯ๐วาࠢสๅ้อๅࠡ็ิฮอฯࠠษี้อࠥอไศ่อหั࠭䃥"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡲࡵࡶࡪࡧ࠲࠵࠴ࡿ࡯ࡱࠩ䃦"),57)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䃧"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอฮห์สีࠥอแๅษ่ࠤ๊ืสษหࠣฬฬ๊วโุ็ࠤฯ่๊๋็ࠪ䃨"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵࠱࠰ࡴࡨࡺ࡮࡫ࡷࠨ䃩"),57)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃪"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษัฮ๏อัࠡษไ่ฬ๋ࠠๆำอฬฮࠦศศๆส็ะืࠠๆึส๋ิฯࠧ䃫"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡱࡴࡼࡩࡦ࠱࠴࠳ࡻ࡯ࡥࡸࡵࠪ䃬"),57)
	return
def l11ll11l1l1l_ll_():
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䃭"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬำฯฬࠢสู่๊ไิๆสฮࠬ䃮"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡰࡨࡻࡪࡹࡴࠨ䃯"),51)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䃰"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧๆี็ื้อสࠡำสสัฯࠧ䃱"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱࠴࠳ࡵࡵࡰࡶ࡮ࡤࡶࠬ䃲"),51)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䃳"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪหำืࠠศุสๅฬะࠠศๆ่ืู้ไศฬࠪ䃴"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠷࠯࡭ࡣࡷࡩࡸࡺࠧ䃵"),51)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䃶"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅิๆึ่ฬะࠠไๆสื๏้๊สࠩ䃷"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰࠳࠲ࡧࡱࡧࡳࡴ࡫ࡦࠫ䃸"),51)
	l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭䃹"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ䃺"),l111lll_ll_ (u"ࠪࠫ䃻"),9999)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䃼"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอฮห์สี๋ࠥำๅี็หฯࠦๅาฬหอࠥฮำ็หࠣห้อๆหษฯࠫ䃽"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯࠲࠱ࡼࡳࡵ࠭䃾"),57)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䃿"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษัฮ๏อัࠡ็ึุ่๊วห่ࠢีฯฮษࠡสส่ฬ็ึๅࠢอๆ๏๐ๅࠨ䄀"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲࠵࠴ࡸࡥࡷ࡫ࡨࡻࠬ䄁"),57)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䄂"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬิส๋ษิࠤู๊ไิๆสฮ๋ࠥัหสฬࠤออไศๅฮี๋ࠥิศ้าอࠬ䄃"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵࠱࠰ࡸ࡬ࡩࡼࡹࠧ䄄"),57)
	return
def l1l11l1_ll_(url):
	#l1ll1l_ll_(url,url)
	if l111lll_ll_ (u"࠭࠿ࠨ䄅") in url:
		parts = url.split(l111lll_ll_ (u"ࠧࡀࠩ䄆"))
		url = parts[0]
		filter = l111lll_ll_ (u"ࠨࡁࠪ䄇") + l1lll111_ll_(parts[1],l111lll_ll_ (u"ࠩࡀࠪ࠿࠵ࠥࠨ䄈"))
	else: filter = l111lll_ll_ (u"ࠪࠫ䄉")
	#l1ll1l_ll_(filter,l111lll_ll_ (u"ࠫࠬ䄊"))
	parts = url.split(l111lll_ll_ (u"ࠬ࠵ࠧ䄋"))
	sort,page,type = parts[-1],parts[-2],parts[-3]
	if sort in [l111lll_ll_ (u"࠭ࡹࡰࡲࠪ䄌"),l111lll_ll_ (u"ࠧࡳࡧࡹ࡭ࡪࡽࠧ䄍"),l111lll_ll_ (u"ࠨࡸ࡬ࡩࡼࡹࠧ䄎")]:
		if type==l111lll_ll_ (u"ࠩࡰࡳࡻ࡯ࡥࠨ䄏"): l11ll111llll_ll_=l111lll_ll_ (u"ࠪๅ๏๊ๅࠨ䄐")
		elif type==l111lll_ll_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ䄑"): l11ll111llll_ll_=l111lll_ll_ (u"๋ࠬำๅี็ࠫ䄒")
		url = l1ll1l1_ll_ + l111lll_ll_ (u"࠭࠯ࡧ࡫࡯ࡸࡪࡸ࠭ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪ䄓") + l1lll111_ll_(l11ll111llll_ll_) + l111lll_ll_ (u"ࠧ࠰ࠩ䄔") + page + l111lll_ll_ (u"ࠨ࠱ࠪ䄕") + sort + filter
		#l1ll1l_ll_(url,page)
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠩࠪ䄖"),l111lll_ll_ (u"ࠪࠫ䄗"),l111lll_ll_ (u"ࠫࠬ䄘"),l111lll_ll_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ䄙"))
		items = re.findall(l111lll_ll_ (u"࠭ࠢࡳࡧࡩࠦ࠿࠮࠮ࠫࡁࠬ࠰࠳࠰࠿ࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠮ࡃࠧࡴࡵ࡮ࡧࡳࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠧࡸࡥࡴࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䄚"),html,re.DOTALL)
		l11l111lll_ll_=0
		for id,title,l11ll11l111l_ll_,img in items:
			l11l111lll_ll_ += 1
			img = l1l1llll1_ll_ + l111lll_ll_ (u"ࠧ࠰࡫ࡰ࡫࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ䄛") + img + l111lll_ll_ (u"ࠨ࠯࠵࠲࡯ࡶࡧࠨ䄜")
			link = l1ll1l1_ll_ + l111lll_ll_ (u"ࠩ࠲ࡴࡷࡵࡧࡳࡣࡰ࠳ࠬ䄝") + id
			if type==l111lll_ll_ (u"ࠪࡱࡴࡼࡩࡦࠩ䄞"): l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䄟"),l1l1l1l_ll_+title,link,53,img)
			if type==l111lll_ll_ (u"ࠬࡹࡥࡳ࡫ࡨࡷࠬ䄠"): l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䄡"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧๆี็ื้ࠦࠧ䄢")+title,link+l111lll_ll_ (u"ࠨࡁࡨࡴࡂ࠭䄣")+l11ll11l111l_ll_+l111lll_ll_ (u"ࠩࡀࠫ䄤")+title+l111lll_ll_ (u"ࠪࡁࠬ䄥")+img,52,img)
	else:
		if type==l111lll_ll_ (u"ࠫࡲࡵࡶࡪࡧࠪ䄦"): l11ll111llll_ll_=l111lll_ll_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࠬ䄧")
		elif type==l111lll_ll_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭䄨"): l11ll111llll_ll_=l111lll_ll_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䄩")
		url = l1l1llll1_ll_ + l111lll_ll_ (u"ࠨ࠱࡭ࡷࡴࡴ࠯ࡴࡧ࡯ࡩࡨࡺࡥࡥ࠱ࠪ䄪") + sort + l111lll_ll_ (u"ࠩ࠰ࠫ䄫") + l11ll111llll_ll_ + l111lll_ll_ (u"ࠪ࠱࡜࡝࠮࡫ࡵࡲࡲࠬ䄬")
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬ䄭"),l111lll_ll_ (u"ࠬ࠭䄮"),l111lll_ll_ (u"࠭ࠧ䄯"),l111lll_ll_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭䄰"))
		items = re.findall(l111lll_ll_ (u"ࠨࠤࡵࡩ࡫ࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡦࡲࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠦࡧࡧࡳࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䄱"),html,re.DOTALL)
		l11l111lll_ll_=0
		for id,l11ll11l111l_ll_,img,title in items:
			l11l111lll_ll_ += 1
			img = l1l1llll1_ll_ + l111lll_ll_ (u"ࠩ࠲࡭ࡲ࡭࠯ࡱࡴࡲ࡫ࡷࡧ࡭࠰ࠩ䄲") + img + l111lll_ll_ (u"ࠪ࠱࠷࠴ࡪࡱࡩࠪ䄳")
			link = l1ll1l1_ll_ + l111lll_ll_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲ࠵ࠧ䄴") + id
			if type==l111lll_ll_ (u"ࠬࡳ࡯ࡷ࡫ࡨࠫ䄵"): l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ䄶"),l1l1l1l_ll_+title,link,53,img)
			if type==l111lll_ll_ (u"ࠧࡴࡧࡵ࡭ࡪࡹࠧ䄷"): l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䄸"),l1l1l1l_ll_+l111lll_ll_ (u"่ࠩืู้ไࠡࠩ䄹")+title,link+l111lll_ll_ (u"ࠪࡃࡪࡶ࠽ࠨ䄺")+l11ll11l111l_ll_+l111lll_ll_ (u"ࠫࡂ࠭䄻")+title+l111lll_ll_ (u"ࠬࡃࠧ䄼")+img,52,img)
	title=l111lll_ll_ (u"࠭ีโฯฬࠤࠬ䄽")
	if l11l111lll_ll_==16:
		for l11l1l11l1_ll_ in range(1,13) :
			if not page==str(l11l1l11l1_ll_):
				url = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡨ࡬ࡰࡹ࡫ࡲ࠮ࡲࡵࡳ࡬ࡸࡡ࡮ࡵ࠲ࠫ䄾")+type+l111lll_ll_ (u"ࠨ࠱ࠪ䄿")+str(l11l1l11l1_ll_)+l111lll_ll_ (u"ࠩ࠲ࠫ䅀")+sort + filter
				l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䅁"),l1l1l1l_ll_+title+str(l11l1l11l1_ll_),url,51)
	return
def l1l11ll_ll_(url):
	parts = url.split(l111lll_ll_ (u"ࠫࡂ࠭䅂"))
	l11ll11l111l_ll_ = int(parts[1])
	name = l1111_ll_(parts[2])
	name = name.replace(l111lll_ll_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪ䅃"),l111lll_ll_ (u"࠭ࠧ䅄"))
	img = parts[3]
	url = url.split(l111lll_ll_ (u"ࠧࡀࠩ䅅"))[0]
	if l11ll11l111l_ll_==0:
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠨࠩ䅆"),l111lll_ll_ (u"ࠩࠪ䅇"),l111lll_ll_ (u"ࠪࠫ䅈"),l111lll_ll_ (u"ࠫࡘࡎࡏࡐࡈࡐࡅ࡝࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ䅉"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥ࡭ࡧࡦࡸࡃ࠭䅊"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䅋"),block,re.DOTALL)
		l11ll11l111l_ll_ = int(items[-1])
		#l1ll1l_ll_(l11ll11l111l_ll_,l111lll_ll_ (u"ࠧࠨ䅌"))
	#name = xbmc.getInfoLabel( l111lll_ll_ (u"ࠣࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡘ࡮ࡺ࡬ࡦࠤ䅍") )
	#img = xbmc.getInfoLabel( l111lll_ll_ (u"ࠤࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲࡙࡮ࡵ࡮ࡤࠥ䅎") )
	for episode in range(l11ll11l111l_ll_,0,-1):
		link = url + l111lll_ll_ (u"ࠪࡃࡪࡶ࠽ࠨ䅏") + str(episode)
		title = l111lll_ll_ (u"ࠫࡤࡓࡏࡅࡡ่ืู้ไࠡࠩ䅐")+name+l111lll_ll_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩ䅑")+str(episode)
		l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ䅒"),l1l1l1l_ll_+title,link,53,img)
	return
def l11_ll_(url):
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠧࠨ䅓"),l111lll_ll_ (u"ࠨࠩ䅔"),l111lll_ll_ (u"ࠩࠪ䅕"),l111lll_ll_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧ䅖"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫ࡮ࡴࡴࡳࡱࡢࡩࡳࡪࠨ࠯ࠬࡂ࠭࡮ࡴࡩࡵ࡫ࡤࡰ࡮ࢀࡥࠨ䅗"),html,re.DOTALL)
	if not l1lll_ll_:
		l11ll11l1l11_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠮ๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯࠪ࠰࠭ࡃࡲࡵ࡭ࡦࡰࡷࡠ࠭ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䅘"),html,re.DOTALL)
		if l11ll11l1l11_ll_:
			time = l11ll11l1l11_ll_[0][1].replace(l111lll_ll_ (u"࠭ࡔࠨ䅙"),l111lll_ll_ (u"ࠧࠡࠢࠣࠤࠬ䅚"))
			l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ䅛"),l111lll_ll_ (u"๊ࠩิฬࠦวๅใํำ๏๎ࠠิ์ๆ์๋ࠦๅห๊ไีࠥ฿ไ๊ࠢื์ๆࠦๅศๅึࠤอ฿ฯ้ࠡำหࠥอไ้ไอࠫ䅜")+l111lll_ll_ (u"ࠪࡠࡳ࠭䅝")+time)
		return
	block = l1lll_ll_[0]
	l11ll111ll1l_ll_ = []
	l11ll11l1lll_ll_ = []
	l11ll111lll1_ll_ = []
	l11ll11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠫࡻࡧࡲࠡࡱࡵ࡭࡬࡯࡮ࡠ࡮࡬ࡲࡰࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩ䅞"),block,re.DOTALL)[0]
	l11ll11l11ll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡼࡡࡳࠢࡥࡥࡨࡱࡵࡱࡡࡲࡶ࡮࡭ࡩ࡯ࡡ࡯࡭ࡳࡱࠠ࠾ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ䅟"),block,re.DOTALL)[0]
	links = re.findall(l111lll_ll_ (u"࠭࡭ࡱ࠶࠽࠲࠯ࡅ࡟࡭࡫ࡱ࡯࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䅠"),block,re.DOTALL)
	links += re.findall(l111lll_ll_ (u"ࠧ࡮ࡲ࠷࠾࠳࠰࠿࡝ࡶࠫ࠲࠯ࡅࠩࡠ࡮࡬ࡲࡰࡢࠫࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䅡"),block,re.DOTALL)
	for server,link in links:
		filename = link.split(l111lll_ll_ (u"ࠨ࠱ࠪ䅢"))[-1]
		filename = filename.replace(l111lll_ll_ (u"ࠩࡩࡥࡱࡲࡢࡢࡥ࡮ࠫ䅣"),l111lll_ll_ (u"ࠪࠫ䅤"))
		filename = filename.replace(l111lll_ll_ (u"ࠫ࠳ࡳࡰ࠵ࠩ䅥"),l111lll_ll_ (u"ࠬ࠭䅦"))
		filename = filename.replace(l111lll_ll_ (u"࠭࠭ࠨ䅧"),l111lll_ll_ (u"ࠧࠨ䅨"))
		if l111lll_ll_ (u"ࠨࡤࡤࡧࡰࡻࡰࠨ䅩") in server:
			server = l111lll_ll_ (u"ࠩࡥࡥࡨࡱࡵࡱࠢࡶࡩࡷࡼࡥࡳࠩ䅪")
			url = l11ll11l11ll_ll_ + link
		else:
			server = l111lll_ll_ (u"ࠪࡱࡦ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲࠨ䅫")
			url = l11ll11ll111_ll_ + link
		l11ll111ll1l_ll_.append(url)
		l11ll11l1lll_ll_.append(l111lll_ll_ (u"ࠫࡲࡶ࠴ࠡࠢࠪ䅬")+server+l111lll_ll_ (u"ࠬࠦࠠࠨ䅭")+filename)
	links = re.findall(l111lll_ll_ (u"࠭ࡨ࡭ࡵ࠽ࠤ࠭࠴ࠪࡀࠫࡢࡰ࡮ࡴ࡫࡝࠭ࠥࠬ࠳࠰࠿ࠪࠤࠪ䅮"),block,re.DOTALL)
	for server,link in links:
		if l111lll_ll_ (u"ࠧࡣࡣࡦ࡯ࡺࡶࠧ䅯") in server:
			server = l111lll_ll_ (u"ࠨࡤࡤࡧࡰࡻࡰࠡࡵࡨࡶࡻ࡫ࡲࠨ䅰")
			url = l11ll11l11ll_ll_ + link
		else:
			server = l111lll_ll_ (u"ࠩࡰࡥ࡮ࡴࠠࡴࡧࡵࡺࡪࡸࠧ䅱")
			url = l11ll11ll111_ll_ + link
		if l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ䅲") in url:
			l1111ll_ll_,l1l111l_ll_ = l11l1l1l_ll_(url)
			if l1111ll_ll_[0]==l111lll_ll_ (u"ࠫ࠲࠷ࠧ䅳"):
				l11ll111ll1l_ll_.append(url)
				l11ll11l1lll_ll_.append(l111lll_ll_ (u"ࠬࡳ࠳ࡶ࠺ࠣࠤࠬ䅴")+server)
			else:
				for i in range(len(l1111ll_ll_)):
					l11ll111ll1l_ll_.append(l1l111l_ll_[i])
					filetype = l1111ll_ll_[i].split(l111lll_ll_ (u"࠭ࠠࠨ䅵"))[0]
					title = l1111ll_ll_[i].replace(filetype,l111lll_ll_ (u"ࠧࠨ䅶")).strip(l111lll_ll_ (u"ࠨࠢࠪ䅷")).replace(l111lll_ll_ (u"ࠩࠣࠤࠥ࠭䅸"),l111lll_ll_ (u"ࠪࠤࠥ࠭䅹"))
					l11ll11l1lll_ll_.append(filetype+l111lll_ll_ (u"ࠫࠥࠦࠧ䅺")+server+l111lll_ll_ (u"ࠬࠦࠠࠨ䅻")+title)
	selection = l1l1111_ll_(l111lll_ll_ (u"࠭ࡓࡦ࡮ࡨࡧࡹࠦࡖࡪࡦࡨࡳࠥࡗࡵࡢ࡮࡬ࡸࡾࡀࠧ䅼"), l11ll11l1lll_ll_)
	if selection == -1 : return
	url = l11ll111ll1l_ll_[selection]
	#url = l1lll1l1lll_ll_(url)
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䅽"))
	return
def l11ll11l1ll1_ll_(url,type):
	#l1ll1l_ll_(url,url)
	if l111lll_ll_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨ䅾") in url: l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠩ࠲࡫ࡪࡴࡲࡦ࠱่ืู้ไࠨ䅿")
	else: l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠪ࠳࡬࡫࡮ࡳࡧ࠲ๅ๏๊ๅࠨ䆀")
	l1ll111_ll_ = l1lll111_ll_(l1ll111_ll_)
	html = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠫࠬ䆁"),l111lll_ll_ (u"ࠬ࠭䆂"),l111lll_ll_ (u"࠭ࠧ䆃"),l111lll_ll_ (u"ࠧࡔࡊࡒࡓࡋࡓࡁ࡙࠯ࡉࡍࡑ࡚ࡅࡓࡕ࠰࠵ࡸࡺࠧ䆄"))
	#l1ll1l_ll_(url,html)
	if type==1: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡵࡸࡦ࡬࡫࡮ࡳࡧࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䆅"),html,re.DOTALL)
	elif type==2: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ䆆"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪࡳࡵࡺࡩࡰࡰࠣࡺࡦࡲࡵࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡳࡵࡺࡩࡰࡰࠪ䆇"),block,re.DOTALL)
	if type==1:
		for l11ll11l1111_ll_,title in reversed(items):
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䆈"),l1l1l1l_ll_+title,url+l111lll_ll_ (u"ࠬࡅࡳࡶࡤࡪࡩࡳࡸࡥ࠾ࠩ䆉")+l11ll11l1111_ll_,58)
	elif type==2:
		url,l11ll11l1111_ll_ = url.split(l111lll_ll_ (u"࠭࠿ࠨ䆊"))
		for country,title in reversed(items):
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䆋"),l1l1l1l_ll_+title,url+l111lll_ll_ (u"ࠨࡁࡦࡳࡺࡴࡴࡳࡻࡀࠫ䆌")+country+l111lll_ll_ (u"ࠩࠩࠫ䆍")+l11ll11l1111_ll_,51)
	return
def l1lll1_ll_(search=l111lll_ll_ (u"ࠪࠫ䆎")):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠫࠬ䆏"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠬ࠭䆐"): return
	#l1ll1l_ll_(search,search)
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"࠭ࠠࠨ䆑"),l111lll_ll_ (u"ࠧࠦ࠴࠳ࠫ䆒"))
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ䆓"), l1ll1l1_ll_, l111lll_ll_ (u"ࠩࠪ䆔"), l111lll_ll_ (u"ࠪࠫ䆕"), True,l111lll_ll_ (u"ࠫࠬ䆖"),l111lll_ll_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞࠭ࡔࡇࡄࡖࡈࡎ࠭࠲ࡵࡷࠫ䆗"))
	html = response.content
	cookies = response.cookies.get_dict()
	cookie = cookies[l111lll_ll_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴࠧ䆘")]
	l11ll11l11l1_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡯ࡣࡰࡩࡂࠨ࡟ࡤࡵࡵࡪࠧࠦࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠧ䆙"),html,re.DOTALL)
	l11ll11l11l1_ll_ = l11ll11l11l1_ll_[0]
	payload = l111lll_ll_ (u"ࠨࡡࡦࡷࡷ࡬࠽ࠨ䆚") + l11ll11l11l1_ll_ + l111lll_ll_ (u"ࠩࠩࡵࡂ࠭䆛") + l1lll111_ll_(l1llll1_ll_)
	headers = { l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷ࠱ࡹࡿࡰࡦࠩ䆜"):l111lll_ll_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ䆝") , l111lll_ll_ (u"ࠬࡩ࡯ࡰ࡭࡬ࡩࠬ䆞"):l111lll_ll_ (u"࠭ࡳࡦࡵࡶ࡭ࡴࡴ࠽ࠨ䆟")+cookie }
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠢ࠰ࡵࡨࡥࡷࡩࡨࠣ䆠")
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠨࡒࡒࡗ࡙࠭䆡"), url, payload, headers, True,l111lll_ll_ (u"ࠩࠪ䆢"),l111lll_ll_ (u"ࠪࡗࡍࡕࡏࡇࡏࡄ࡜࠲࡙ࡅࡂࡔࡆࡌ࠲࠸࡮ࡥࠩ䆣"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫ࡬࡫࡮ࡦࡴࡤࡰ࠲ࡨ࡯ࡥࡻࠫ࠲࠯ࡅࠩࡴࡧࡤࡶࡨ࡮࠭ࡣࡱࡷࡸࡴࡳ࠭ࡱࡣࡧࡨ࡮ࡴࡧࠨ䆤"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ䆥"),block,re.DOTALL)
	if items:
		for link,img,title in items:
			title = title.decode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠻ࠫ䆦")).encode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬ䆧"))
			url = l1ll1l1_ll_ + link
			if l111lll_ll_ (u"ࠨ࠱ࡳࡶࡴ࡭ࡲࡢ࡯࠲ࠫ䆨") in url:
				if l111lll_ll_ (u"ࠩࡂࡩࡵࡃࠧ䆩") in url:
					title = l111lll_ll_ (u"ࠪࡣࡒࡕࡄࡠ็ึุ่๊ࠠࠨ䆪")+title
					url = url.replace(l111lll_ll_ (u"ࠫࡄ࡫ࡰ࠾࠳ࠪ䆫"),l111lll_ll_ (u"ࠬࡅࡥࡱ࠿࠳ࠫ䆬"))
					url = url+l111lll_ll_ (u"࠭࠽ࠨ䆭")+l1lll111_ll_(title)+l111lll_ll_ (u"ࠧ࠾ࠩ䆮")+img
					l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䆯"),l1l1l1l_ll_+title,url,52,img)
				else:
					title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟โ์็้ࠥ࠭䆰")+title
					l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䆱"),l1l1l1l_ll_+title,url,53,img)
	#else: l1ll1l_ll_(l111lll_ll_ (u"ࠫࡳࡵࠠࡳࡧࡶࡹࡱࡺࡳࠨ䆲"),l111lll_ll_ (u"๊ࠬวࠡฬ๋ะิࠦๆหษษะ๊ࠥไษฯฮࠫ䆳"))
	return