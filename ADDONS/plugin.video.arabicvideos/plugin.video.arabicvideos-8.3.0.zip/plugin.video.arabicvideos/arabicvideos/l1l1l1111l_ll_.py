# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡧࡪࡽ࠳ࡨࡥࡴࡶࠪ᜷")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾ࠷࠮ࡣࡧࡶࡸࠬ᜸")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡩ࡬ࡿࡢࡦࡵࡷ࠵࠳ࡩ࡯࡮ࠩ᜹")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ᜺")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴࡫ࡧࡺ࠶ࡥࡩࡸࡺ࠮ࡤࡱࡰࠫ᜻")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡥࡨࡻࡥࡩࡸࡺ࠭ࡷ࡫ࡳ࠲ࡸ࡮࡯ࡧࡦࡤ࠲ࡨࡵ࡭ࠨ᜼")
#l1ll1l1_ll_ = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡳࡱࡰࡩ࠳࡫ࡧࡺࡤࡨࡷࡹ࠴࡮࡭ࠩ᜽")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡸ࡬࠲ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡼࡩࡱࠩ᜾")
l1ll_ll_ = l111lll_ll_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕࡘࡌࡔࠬ᜿")
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡉࡌ࡜࡟ࠨᝀ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,page,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==220: results = l11l1ll_ll_(url)
	elif mode==221: results = l1l11l1_ll_(url,page)
	elif mode==222: results = l1l1l11l1_ll_(url)
	elif mode==223: results = l11_ll_(url)
	elif mode==224: results = l1111l1_ll_(url)
	elif mode==229: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫᝁ")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬᝂ"):
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᝃ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ᝄ"),l111lll_ll_ (u"ࠧࠨᝅ"),229,l111lll_ll_ (u"ࠨࠩᝆ"),l111lll_ll_ (u"ࠩࠪᝇ"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᝈ"))
		#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᝉ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็ไหำ้ࠣาีฯࠨᝊ"),l1ll1l1_ll_,226,l111lll_ll_ (u"࠭ࠧᝋ"),l111lll_ll_ (u"ࠧࠨᝌ"),l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨᝍ"))
		#l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᝎ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪๅ้ะัࠡๅส้้࠭ᝏ"),l1ll1l1_ll_,226,l111lll_ll_ (u"ࠫࠬᝐ"),l111lll_ll_ (u"ࠬ࠭ᝑ"),l111lll_ll_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪᝒ"))
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬᝓ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᝔"),l111lll_ll_ (u"ࠩࠪ᝕"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ᝖"),l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬ᝗"),l111lll_ll_ (u"ࠬ࠭᝘"),l111lll_ll_ (u"࠭ࠧ᝙"),l111lll_ll_ (u"ࠧࠨ᝚"),l111lll_ll_ (u"ࠨࡇࡊ࡝ࡇࡋࡓࡕ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ᝛"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡬ࠤ࡮࠳ࡨࡰ࡯ࡨࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ᝜"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫ᝝"),block,re.DOTALL)
	for link,title in items:
		if l111lll_ll_ (u"ࠫࡁ࠵ࡩ࠿ࠩ᝞") in title: title = title.split(l111lll_ll_ (u"ࠬࡂ࠯ࡪࡀࠪ᝟"))[1]
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᝠ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫᝡ")+l1l1l1l_ll_+title,link,222)
	if l1111l_ll_==l111lll_ll_ (u"ࠨࠩᝢ"): l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᝣ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᝤ"),l111lll_ll_ (u"ࠫࠬᝥ"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࠩ࠰࠭ࡃ࠮ࡂࡳࡤࡴ࡬ࡴࡹ࠭ᝦ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"࠭ࡰࡥࡣࠣࡦࡩࡨࠢ࠿࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᝧ"),html,re.DOTALL)
	for title,link in items:
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᝨ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᝩ")+l1l1l1l_ll_+title,link,221)
	if l1111l_ll_==l111lll_ll_ (u"ࠩࠪᝪ"): l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨᝫ"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᝬ"),l111lll_ll_ (u"ࠬ࠭᝭"),9999)
	items = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᝮ"),block,re.DOTALL)
	for link,title in items:
		if l111lll_ll_ (u"ࠧࡩࡶࡰࡰࠬᝯ") not in link: continue
		if not link.endswith(l111lll_ll_ (u"ࠨ࠱ࠪᝰ")): l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᝱"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧᝲ")+l1l1l1l_ll_+title,link,221)
	return html
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊࠥࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰࠭วื฼ฺࠤ์์วࠡๆสฺฬ็ษࠡษึ้ࠥีฮ้ๆࠣ์่๊ๅสࠢสุ่ืࠧ࠭ࠩࠪ࠰࠷࠸࠵ࠪࠌࠌࠧࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨฬะิ๏ืࠧ࠭ࠩࠪ࠰࠷࠸࠶ࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠤ࡭ࡺ࡭࡭ࠫࠍࠍࠨ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࡫ࡧࡁࠧࡳࡥ࡯ࡷࠥࠬ࠳࠰࠿ࠪ࡯ࡤ࡭ࡳࡒ࡯ࡢࡦࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠤࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍࠨ࡯ࡴࡦ࡯ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡃ࠮࠮ࠫࡁࠬࡠࡳ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠨ࡬࡯ࡳࠢࡸࡶࡱ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠦࠍ࡮࡬ࠠࡶࡴ࡯ࠥࡂࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡺࡸ࡬࠭࠴࠵࠸࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ࠱࠭ࠧ࠭࠴࠵࠽࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩࠬࠎࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠱ࠧࡠࡡࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࠩส่ศ้หาุ่ࠢฬํฯสࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠱ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ࠰࠷࠸࠱ࠪࠌࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡻࡪࡨࡳࡪࡶࡨ࠯ࠬࡥ࡟ࡠࠩ࠮ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧศๆสๅ้อๅࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰࠭࠯࡮ࡱࡹ࡭ࡪࡹࠧ࠭࠴࠵࠸࠮ࠐࠉࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬࡸࡧࡥࡷ࡮ࡺࡥࠬࠩࡢࡣࡤ࠭ࠫ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࠫฬ๊ๅิๆึ่ฬะࠧ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠲ࡤ࠯ࠬ࠵ࡴࡷࠩ࠯࠶࠷࠺ࠩࠋࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨ࡮࡬ࡲࡰ࠭ࠬࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ࠱࠭ࠧ࠭࠻࠼࠽࠾࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡏࡓࡓࡍ࡟ࡄࡃࡆࡌࡊ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡧࡱࡧࡳࡴ࠿ࠥࡦࡦࠦ࡭ࡨࡤࠫ࠲࠯ࡅࠩ࠿ࡇࡪࡽࡇ࡫ࡳࡵ࠾࠲ࡥࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡺࡩࡧࡹࡩࡵࡧ࠮ࠫࡤࡥ࡟ࠨ࠭ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡࡪࡷࡱࡱࠐࠉࠤࠢࡨ࡫ࡾࡨࡥࡴࡶ࠴࠲ࡨࡵ࡭ࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࠽ࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡥࡰࡴࡩ࡫ࠡ࠿ࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࡜࠲ࡠࠎࠎࠩࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡶࡨࡱࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡝࠴࠳ࡢࡡࡩࠣ࡟ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࠬ࠲ࡢ࡭ࡱࡦ࡯࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡪࡴࡸࠠ࡭࡫ࡱ࡯࠱ࡺࡩࡵ࡮ࡨࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋ࡬ࡪࠥ࠭ࡴࡰࡴࡵࡩࡳࡺࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡢࡦࡧࡑࡪࡴࡵࡊࡶࡨࡱ࠭࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ࡸ࡮ࡺ࡬ࡦ࠮࡯࡭ࡳࡱࠬ࠳࠴࠴࠭ࠏࠏࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶࡁࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡷࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࡤ࡯ࡳࡨࡱࠠ࠾ࠢ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹ࡛࠱࡟ࠍࠍ࡮ࡺࡥ࡮ࡵࡀࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍ࡮࡬ࠠࠨࡶࡲࡶࡷ࡫࡮ࡵࠩࠣࡲࡴࡺࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠶࠶࠯ࠊࠊࠤࠥࠦᝳ")
def l1l1l11l1_ll_(url):
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ᝴"),url,l111lll_ll_ (u"࠭ࠧ᝵"),l111lll_ll_ (u"ࠧࠨ᝶"),l111lll_ll_ (u"ࠨࠩ᝷"),l111lll_ll_ (u"ࠩࠪ᝸"),l111lll_ll_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖ࠭ࡔࡗࡅࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᝹"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡷࡹ࡟ࡴࡥࡵࡳࡱࡲࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ᝺"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡥࡃ࠭᝻"),block,re.DOTALL)
	for link,title in items:
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᝼"),l1l1l1l_ll_+title,link,224)
	return
def l1111l1_ll_(url):
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᝽"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ะ๊๐ูࠨ᝾"),url,221)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠩࠪ᝿"),l111lll_ll_ (u"ࠪࠫក"),l111lll_ll_ (u"ࠫࠬខ"),l111lll_ll_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬគ"))
	l111lll_ll_ (u"ࠨࠢࠣࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠾ࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡩࡥ࠿ࠥࡱࡦ࡯࡮ࠣࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࡂࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࡛࡝ࡴ࡟ࡲࡢ࠱ࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎ࡬࡯ࡳࠢ࡯࡭ࡳࡱࠬࡵ࡫ࡷࡰࡪࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠷࠸࠱ࠪࠌࠌࠦࠧࠨឃ")
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡴࡷࡥࡣࡳࡧࡶࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡰࡳࡻ࡯ࡥࡴࠩង"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠬࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪច"),block,re.DOTALL)
		for link,title in items:
			if link==l111lll_ll_ (u"ࠩࠦࠫឆ"): name = title
			else:
				title = title + l111lll_ll_ (u"ࠪࠤࠥࡀࠠࠡࠩជ") + l111lll_ll_ (u"ࠫๆ๊สาࠢࠪឈ") + name
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬញ"),l1l1l1l_ll_+title,link,221)
	else: l1l11l1_ll_(url)
	return
def l1l11l1_ll_(url,page=l111lll_ll_ (u"࠭࠱ࠨដ")):
	if page==l111lll_ll_ (u"ࠧࠨឋ"): page = l111lll_ll_ (u"ࠨ࠳ࠪឌ")
	#l1ll1l_ll_(str(url), str(page))
	if l111lll_ll_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࠪឍ") in url or l111lll_ll_ (u"ࠪࡃࠬណ") in url: l1ll111_ll_ = url + l111lll_ll_ (u"ࠫࠫ࠭ត")
	else: l1ll111_ll_ = url + l111lll_ll_ (u"ࠬࡅࠧថ")
	#l1ll111_ll_ = l1ll111_ll_ + l111lll_ll_ (u"࠭࡯ࡶࡶࡳࡹࡹࡥࡦࡰࡴࡰࡥࡹࡃࡪࡴࡱࡱࠪࡴࡻࡴࡱࡷࡷࡣࡲࡵࡤࡦ࠿ࡰࡳࡻ࡯ࡥࡴࡡ࡯࡭ࡸࡺࠦࡱࡣࡪࡩࡂ࠭ទ")+page
	l1ll111_ll_ = l1ll111_ll_ + l111lll_ll_ (u"ࠧࡱࡣࡪࡩࡂ࠭ធ") + page
	html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩន"),l111lll_ll_ (u"ࠩࠪប"),l111lll_ll_ (u"ࠪࠫផ"),l111lll_ll_ (u"ࠫࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬព"))
	#name = l111lll_ll_ (u"ࠬ࠭ភ")
	#if l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴࠧម") in url:
	#	name = re.findall(l111lll_ll_ (u"ࠧ࠽ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿ࠫយ"),html,re.DOTALL)
	#	if name: name = l1l1l11ll_ll_(name[0]).strip(l111lll_ll_ (u"ࠨࠢࠪរ")) + l111lll_ll_ (u"ࠩࠣ࠱ࠥ࠭ល")
	#	else: name = xbmc.getInfoLabel( l111lll_ll_ (u"ࠥࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠦវ") ) + l111lll_ll_ (u"ࠫࠥ࠳ࠠࠨឝ")
	if l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠭ឞ") in url:
		l1lll_ll_=re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡥࡣࠥࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬស"),html,re.DOTALL)
		block = l1lll_ll_[-1]
	# l1l11lll1l_ll_ seasons
	elif l111lll_ll_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩហ") in url:
		l1lll_ll_=re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡱࡺࡰ࠲ࡩࡡࡳࡱࡸࡷࡪࡲࠠࡰࡹ࡯࠱ࡨࡧࡲࡰࡷࡶࡩࡱ࠮࠮ࠫࡁࠬࡨ࡮ࡼࠧឡ"),html,re.DOTALL)
		block = l1lll_ll_[0]
	else:
		l1lll_ll_=re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪអ"),html,re.DOTALL)
		block = l1lll_ll_[-1]
	items = re.findall(l111lll_ll_ (u"ࠪࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧឣ"),block,re.DOTALL)
	for link,img,title in items:
		l111lll_ll_ (u"ࠦࠧࠨࠊࠊࠋ࡬ࡪࠥ࠭࠯ࡴࡧࡵ࡭ࡪࡹࠧࠡ࡫ࡱࠤࡺࡸ࡬ࠡࡣࡱࡨࠥ࠭࠯ࡴࡧࡤࡷࡴࡴࠧࠡࡰࡲࡸࠥ࡯࡮ࠡ࡮࡬ࡲࡰࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍ࡮࡬ࠠࠨ࠱ࡶࡩࡦࡹ࡯࡯ࠩࠣ࡭ࡳࠦࡵࡳ࡮ࠣࡥࡳࡪࠠࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡧࡴࡴࡴࡪࡰࡸࡩࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࡹ࡯ࡴ࡭ࡧ࠯ࠤࡸࡺࡲࠩ࡮࡬ࡲࡰ࠯ࠩࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡳࡧ࡭ࡦࠢ࠮ࠤࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠲ࡸࡺࡲࡪࡲࠫࠫࠥ࠭ࠩࠋࠋࠌࠦࠧࠨឤ")
		title = unescapeHTML(title)
		l111lll_ll_ (u"ࠧࠨࠢࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࡢ࡮ࠨ࠮ࠪࠫ࠮ࠐࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࡞࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࠎ࡯࡭ࡨࠢࡀࠤ࡮ࡳࡧ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡠ࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠉࡪࡨࠣࠫ࡭ࡺࡴࡱࠩࠣࡲࡴࡺࠠࡪࡰࠣ࡭ࡲ࡭࠺ࠡ࡫ࡰ࡫ࠥࡃࠠࠨࡪࡷࡸࡵࡀࠧࠡ࠭ࠣ࡭ࡲ࡭ࠊࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡒࡔ࡚ࡉࡇࡋࡆࡅ࡙ࡏࡏࡏࠪ࡬ࡱ࡬࠲ࠧࠨࠫࠍࠍࠎࡻࡲ࡭࠴ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠦࠧࠨឥ")
		if l111lll_ll_ (u"࠭࠯࡮ࡱࡹ࡭ࡪ࠵ࠧឦ") in link or l111lll_ll_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࠩឧ") in link:
			l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧឨ"),l1l1l1l_ll_+title,link.rstrip(l111lll_ll_ (u"ࠩ࠲ࠫឩ")),223,img)
		else:
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪឪ"),l1l1l1l_ll_+title,link,221,img)
	if len(items)>=16:
		l1ll1l1111_ll_ = [l111lll_ll_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬឫ"),l111lll_ll_ (u"ࠬ࠵ࡴࡷࠩឬ"),l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧឭ"),l111lll_ll_ (u"ࠧ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪឮ")]
		page = int(page)
		if any(value in url for value in l1ll1l1111_ll_):
			for n in range(0,1000,100):
				if int(page/100)*100==n:
					for i in range(n,n+100,10):
						if int(page/10)*10==i:
							for j in range(i,i+10,1):
								if not page==j and j!=0:
									l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨឯ"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨឰ")+str(j),url,221,l111lll_ll_ (u"ࠪࠫឱ"),str(j))
						elif i!=0: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫឲ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣࠫឳ")+str(i),url,221,l111lll_ll_ (u"࠭ࠧ឴"),str(i))
						else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ឵"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦࠧា")+str(1),url,221,l111lll_ll_ (u"ࠩࠪិ"),str(1))
				elif n!=0: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪី"),l1l1l1l_ll_+l111lll_ll_ (u"ฺࠫ็อสࠢࠪឹ")+str(n),url,221,l111lll_ll_ (u"ࠬ࠭ឺ"),str(n))
				else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ុ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧึใะอࠥ࠭ូ")+str(1),url,221)
	return
def l11_ll_(url):
	#global l111lll_ll_ (u"ࠨࠩួ")
	l1111ll_ll_,l1l111l_ll_ = [],[]
	#l1ll1l_ll_(url, url[-45:])
	# l1ll1l1l_ll_://l1l1l1l111_ll_.l1lll1l11_ll_/movie/فيلم-the-l1l1l1llll_ll_-l1l11llll1_ll_-2019-مترجم
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠩࠪើ"),l111lll_ll_ (u"ࠪࠫឿ"),l111lll_ll_ (u"ࠫࠬៀ"),l111lll_ll_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫេ"))
	l1llll_ll_ = re.findall(l111lll_ll_ (u"࠭࠼ࡵࡦࡁห้ะี็์ไࡀ࠴ࡺࡤ࠿࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ែ"),html,re.DOTALL)
	if False and l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	# l1ll1l1l_ll_://l1ll1l1l11_ll_.l1l11lll11_ll_/movie/فيلم-the-l1l1l1llll_ll_-l1l11llll1_ll_-2019-مترجم
	l1l11l1ll_ll_,l1l11l1l1_ll_ = l111lll_ll_ (u"ࠧࠨៃ"),l111lll_ll_ (u"ࠨࠩោ")
	l1l1ll1111_ll_,l1l1l11l1l_ll_ = html,html
	l1l1l1l1l1_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶ࡬ࡴࡽ࡟ࡥ࡮ࠣࡥࡵ࡯ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧៅ"),html,re.DOTALL)
	if l1l1l1l1l1_ll_:
		for link in l1l1l1l1l1_ll_:
			if l111lll_ll_ (u"ࠪ࠳ࡼࡧࡴࡤࡪ࠲ࠫំ") in link: l1l11l1ll_ll_ = link
			elif l111lll_ll_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨះ") in link: l1l11l1l1_ll_ = link
		if l1l11l1ll_ll_!=l111lll_ll_ (u"ࠬ࠭ៈ"): l1l1ll1111_ll_ = l111ll1_ll_(l11l1l_ll_,l1l11l1ll_ll_,l111lll_ll_ (u"࠭ࠧ៉"),l111lll_ll_ (u"ࠧࠨ៊"),l111lll_ll_ (u"ࠨࠩ់"),l111lll_ll_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ៌"))
		if l1l11l1l1_ll_!=l111lll_ll_ (u"ࠪࠫ៍"): l1l1l11l1l_ll_ = l111ll1_ll_(l11l1l_ll_,l1l11l1l1_ll_,l111lll_ll_ (u"ࠫࠬ៎"),l111lll_ll_ (u"ࠬ࠭៏"),l111lll_ll_ (u"࠭ࠧ័"),l111lll_ll_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭៑"))
	#l1ll1l_ll_(l1l11l1l1_ll_,l1l11l1ll_ll_)
	# l1ll1l1l_ll_://l1l1l11l11_ll_.l1ll1l1l11_ll_.download/?id=__1l1l1lll1_ll_
	l1l1l1l1ll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࡫ࡧࡁࠧࡼࡩࡥࡧࡲࠦ࠳࠰࠿ࡥࡣࡷࡥ࠲ࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ្ࠪ"),l1l1ll1111_ll_,re.DOTALL)
	if l1l1l1l1ll_ll_:
		l1ll111_ll_ = l1l1l1l1ll_ll_[0]#+l111lll_ll_ (u"ࠩࡿࢀࡒࡿࡐࡳࡱࡻࡽ࡚ࡸ࡬࠾ࡪࡷࡸࡵࡀ࠯࠰࠹࠼࠲࠶࠼࠵࠯࠴࠷࠶࠳࠾࠴࠻࠶࠴࠸࠺࠭៓")
		if l1ll111_ll_!=l111lll_ll_ (u"ࠪࠫ។") and l111lll_ll_ (u"ࠫࡺࡶ࡬ࡰࡣࡧࡩࡩ࠴ࡥࡨࡻࡥࡩࡸࡺ࠮ࡥࡱࡺࡲࡱࡵࡡࡥࠩ៕") in l1ll111_ll_ and l111lll_ll_ (u"ࠬ࠵࠿ࡪࡦࡀࡣࠬ៖") not in l1ll111_ll_:
			l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"࠭ࠧៗ"),l111lll_ll_ (u"ࠧࠨ៘"),l111lll_ll_ (u"ࠨࠩ៙"),l111lll_ll_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ៚"))
			l1l11ll11l_ll_ = re.findall(l111lll_ll_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៛"),l1l111l1_ll_,re.DOTALL)
			if l1l11ll11l_ll_:
				for link,quality in l1l11ll11l_ll_:
					l1l111l_ll_.append(link+l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡪࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࡲࡣࡤࡽࡡࡵࡥ࡫ࡣࡤࡳࡰ࠵ࡡࡢࠫៜ")+quality)
			else:
				server = l1ll111_ll_.split(l111lll_ll_ (u"ࠬ࠵ࠧ៝"))[2]
				l1l111l_ll_.append(l1ll111_ll_+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ៞")+server+l111lll_ll_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ៟"))
		elif l1ll111_ll_!=l111lll_ll_ (u"ࠨࠩ០"):
			#l1ll1l_ll_(l1ll111_ll_,str(l1l1l1l1ll_ll_))
			server = l1ll111_ll_.split(l111lll_ll_ (u"ࠩ࠲ࠫ១"))[2]
			l1l111l_ll_.append(l1ll111_ll_+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ២")+server+l111lll_ll_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ៣"))
	# l1ll1l1l_ll_://l1l1l11111_ll_.cc/l1l1l1ll1l_ll_
	# l1ll1l1l_ll_://l1l1l1ll11_ll_.org/l1l1l1ll1l_ll_
	l1l1l111ll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡴࡢࡤ࡯ࡩࠥࡩ࡬ࡢࡵࡶࡁࠧࡪ࡬ࡴࡡࡷࡥࡧࡲࡥࠩ࠰࠭ࡃ࠮ࡂ࠯ࡵࡣࡥࡰࡪࡄࠧ៤"),l1l1l11l1l_ll_,re.DOTALL)
	if l1l1l111ll_ll_:
		l1l1l111ll_ll_ = l1l1l111ll_ll_[0]
		l1l1l1l11l_ll_ = re.findall(l111lll_ll_ (u"࠭࠼ࡵࡦࡁ࠲࠯ࡅ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ៥"),l1l1l111ll_ll_,re.DOTALL)
		if l1l1l1l11l_ll_:
			for quality,link in l1l1l1l11l_ll_:
				if l111lll_ll_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ៦") not in link: continue
				if link.count(l111lll_ll_ (u"ࠨ࠱ࠪ៧"))>=2:
					server = link.split(l111lll_ll_ (u"ࠩ࠲ࠫ៨"))[2]
					l1l111l_ll_.append(link+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ៩")+server+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡰࡴ࠹ࡥ࡟ࠨ៪")+quality)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠬอฮหำࠣห้็๊ะ์๋ࠤฬ๊ๅ็ษึฬ࠿࠭៫"), l1l111l_ll_)
	#if selection == -1 : return
	l1l1l111l1_ll_ = []
	for link in l1l111l_ll_:
		# l1l11lllll_ll_	l1ll1l1l_ll_://l1l11ll1l1_ll_.l1ll1l1l11_ll_.l1l11lll11_ll_/movie/watch/فيلم-the-space-l1l1l11lll_ll_-l1l11ll1ll_ll_-2017-مترجم/l1l1l11ll1_ll_
		#if l111lll_ll_ (u"࠭ࡦࡢࡵࡨࡰ࡭ࡪࠧ៬") in link: continue
		#if l111lll_ll_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࡄࡴࡡ࡮ࡧࠪ៭") in link: continue
		#if l111lll_ll_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵ࠰ࡹ࡭ࡵ࠭៮") in link: continue
		#if l111lll_ll_ (u"ࠩࡰࡽࡪ࡭ࡹࡷ࡫ࡳࠫ៯") not in link: continue
		l1l1l111l1_ll_.append(link)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ៰"), l1l1l111l1_ll_)
	if len(l1l1l111l1_ll_)==0: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ៱"),l111lll_ll_ (u"ࠬํะศࠢส่ๆ๐ฯ๋๊ࠣ๎ุะฮะ็ࠣีํอศุࠢ฽๎ึࠦๅฺำ๋ๅฮࠦแ๋๊ࠢิฬࠦวๅสิ๊ฬ๋ฬ๊ࠡส่๊ฮัๆฮ่๊๊ࠣࠦิฬฺ๎฾ࠦล๋ฯสำࠥำไࠡๆ๊ิ์ࠦวๅ็ื็้ฯࠧ៲"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l1l111l1_ll_,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ៳"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠧࠨ៴"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠨࠩ៵"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠩࠣࠫ៶"),l111lll_ll_ (u"ࠪ࠯ࠬ៷"))
	html = l111ll1_ll_(l11111l1_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬ៸"),l111lll_ll_ (u"ࠬ࠭៹"),l111lll_ll_ (u"࠭ࠧ៺"),l111lll_ll_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡘࡋࡁࡓࡅࡋ࠱࠶ࡹࡴࠨ៻"))
	token = re.findall(l111lll_ll_ (u"ࠨࡰࡤࡱࡪࡃࠢࡠࡶࡲ࡯ࡪࡴࠢࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ៼"),html,re.DOTALL)
	if token:
		url = l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡣࡹࡵ࡫ࡦࡰࡀࠫ៽")+token[0]+l111lll_ll_ (u"ࠪࠪࡶࡃࠧ៾")+l1llll1_ll_
		l1l11l1_ll_(url)
		#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ៿"), l111lll_ll_ (u"ࠬ࠭᠀"))
	return