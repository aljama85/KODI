# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠩࡉࡅ࡛ࡕࡕࡓࡋࡗࡉࡘ࠭ᣤ")
def l111l1l_ll_(mode,l1l1111111_ll_):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==270: results = l11l1ll_ll_(l1l1111111_ll_)
	#elif mode==271: results = l11ll1lll1_ll_(l1l1111111_ll_)
	else: results = False
	return results
def l11l1ll_ll_(l1l111l1l1_ll_):
	l11llll111_ll_ = l11llll11l_ll_()
	if l1l111l1l1_ll_ in l11llll111_ll_.keys():
		#l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᣥ"),l111lll_ll_ (u"ู๊ࠫอ้ࠡำ๋ࠥอไใษษ้ฮ࠭ᣦ"),l111lll_ll_ (u"ࠬ࠭ᣧ"),271,l111lll_ll_ (u"࠭ࠧᣨ"),l111lll_ll_ (u"ࠧࠨᣩ"),l111lll_ll_ (u"ࠨࠩᣪ"),l1l111l1l1_ll_)
		#l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᣫ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᣬ"),l111lll_ll_ (u"ࠫࠬᣭ"),9999)
		l1l1111lll_ll_ = l11llll111_ll_[l1l111l1l1_ll_]
		for type,name,url,mode,image,page,text in l1l1111lll_ll_:
			l111_ll_(type,name,url,mode,image,page,text,l1l111l1l1_ll_)
	return
def l1l111l11l_ll_(context):
	if context==l111lll_ll_ (u"ࠬ࠭ᣮ"): return
	if l111lll_ll_ (u"࠭࡟ࠨᣯ") in context: l1l111l1l1_ll_,l1l11111ll_ll_ = context.split(l111lll_ll_ (u"ࠧࡠࠩᣰ"),1)
	else: l1l111l1l1_ll_,l1l11111ll_ll_ = context,l111lll_ll_ (u"ࠨࠩᣱ")
	#l1ll1l_ll_(l1l111l1l1_ll_,context)
	if   l1l11111ll_ll_==l111lll_ll_ (u"ࠩࡘࡔ࠶࠭ᣲ")	: l11lll11l1_ll_(l1l111l1l1_ll_,True,1)
	elif l1l11111ll_ll_==l111lll_ll_ (u"ࠪࡈࡔ࡝ࡎ࠲ࠩᣳ")	: l11lll11l1_ll_(l1l111l1l1_ll_,False,1)
	elif l1l11111ll_ll_==l111lll_ll_ (u"࡚ࠫࡖ࠴ࠨᣴ")	: l11lll11l1_ll_(l1l111l1l1_ll_,True,4)
	elif l1l11111ll_ll_==l111lll_ll_ (u"ࠬࡊࡏࡘࡐ࠷ࠫᣵ")	: l11lll11l1_ll_(l1l111l1l1_ll_,False,4)
	elif l1l11111ll_ll_==l111lll_ll_ (u"࠭ࡁࡅࡆ࠴ࠫ᣶")	: l1l111111l_ll_(l1l111l1l1_ll_)
	elif l1l11111ll_ll_==l111lll_ll_ (u"ࠧࡓࡇࡐࡓ࡛ࡋ࠱ࠨ᣷"): l11lll1111_ll_(l1l111l1l1_ll_)
	elif l1l11111ll_ll_==l111lll_ll_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࡍࡋࡖࡘࠬ᣸"): l11ll1lll1_ll_(l1l111l1l1_ll_)
	return
def l11lll11l1_ll_(l1l111l1l1_ll_,l1l1111ll1_ll_,repeat):
	type,name,url,mode,image,page,text,context = l11lllllll_ll_()
	l11lll1l11_ll_ = (type,name,url,mode,image,page,text)
	l11llll111_ll_ = l11llll11l_ll_()
	if l1l111l1l1_ll_ in l11llll111_ll_.keys():
		l1l11111l1_ll_ = l11llll111_ll_[l1l111l1l1_ll_]
		size = len(l1l11111l1_ll_)
		for i in range(0,repeat):
			l11lll1lll_ll_ = l1l11111l1_ll_.index(l11lll1l11_ll_)
			if l1l1111ll1_ll_: l11lll111l_ll_ = l11lll1lll_ll_-1
			else: l11lll111l_ll_ = l11lll1lll_ll_+1
			if l11lll111l_ll_>=size: l11lll111l_ll_ = l11lll111l_ll_-size
			if l11lll111l_ll_<0: l11lll111l_ll_ = l11lll111l_ll_+size
			l1l11111l1_ll_.insert(l11lll111l_ll_, l1l11111l1_ll_.pop(l11lll1lll_ll_))
		l11llll111_ll_[l1l111l1l1_ll_] = l1l11111l1_ll_
		l1l1111l1l_ll_ = str(l11llll111_ll_)
		with open(l11llll1l1_ll_,l111lll_ll_ (u"ࠩࡺࡦࠬ᣹")) as f: f.write(l1l1111l1l_ll_)
	return
def l1l111111l_ll_(l1l111l1l1_ll_):
	type,name,url,mode,image,page,text,context = l11lllllll_ll_()
	l1l111l111_ll_ = (type,name,url,mode,image,page,text)
	l11lll1l1l_ll_ = l11llll11l_ll_()
	l1l1111l1l_ll_ = {}
	for l11lll11ll_ll_ in l11lll1l1l_ll_.keys():
		if l11lll11ll_ll_!=l1l111l1l1_ll_: l1l1111l1l_ll_[l11lll11ll_ll_] = l11lll1l1l_ll_[l11lll11ll_ll_]
		else:
			if name!=l111lll_ll_ (u"ࠪ࠲࠳࠭᣺") and name!=l111lll_ll_ (u"ࠫࠬ᣻"):
				l1l11111l1_ll_ = l11lll1l1l_ll_[l11lll11ll_ll_]
				if l1l111l111_ll_ in l1l11111l1_ll_:
					index = l1l11111l1_ll_.index(l1l111l111_ll_)
					del l1l11111l1_ll_[index]
				l1l1l111l1_ll_ = l1l11111l1_ll_+[l1l111l111_ll_]
				l1l1111l1l_ll_[l11lll11ll_ll_] = l1l1l111l1_ll_
			else: l1l1111l1l_ll_[l11lll11ll_ll_] = l11lll1l1l_ll_[l11lll11ll_ll_]
	if l1l111l1l1_ll_ not in l1l1111l1l_ll_.keys(): l1l1111l1l_ll_[l1l111l1l1_ll_] = [l1l111l111_ll_]
	l1l1111l1l_ll_ = str(l1l1111l1l_ll_)
	with open(l11llll1l1_ll_,l111lll_ll_ (u"ࠬࡽࡢࠨ᣼")) as f: f.write(l1l1111l1l_ll_)
	return
def l11lll1111_ll_(l1l111l1l1_ll_):
	type,name,url,mode,image,page,text,context = l11lllllll_ll_()
	l11lll1l11_ll_ = (type,name,url,mode,image,page,text)
	l11llll111_ll_ = l11llll11l_ll_()
	if l1l111l1l1_ll_ in l11llll111_ll_.keys() and l11lll1l11_ll_ in l11llll111_ll_[l1l111l1l1_ll_]:
		l11llll111_ll_[l1l111l1l1_ll_].remove(l11lll1l11_ll_)
		l1l1111l1l_ll_ = str(l11llll111_ll_)
		with open(l11llll1l1_ll_,l111lll_ll_ (u"࠭ࡷࡣࠩ᣽")) as f: f.write(l1l1111l1l_ll_)
	return
def l11ll1lll1_ll_(l1l111l1l1_ll_):
	l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᣾"),l111lll_ll_ (u"ࠨ้็ࠤฯื๊ะࠢไ฽้อࠠๆีะࠤัฺ๋๊่ࠢัฯ๎๊ศฬࠣๆฬฬๅสࠢส่๊็ึๅหࠣࠫ᣿")+l1l111l1l1_ll_+l111lll_ll_ (u"ࠩࠣรࠦ࠭ᤀ"),l111lll_ll_ (u"ࠪࠫᤁ"),l111lll_ll_ (u"ࠫࠬᤂ"),l111lll_ll_ (u"้ࠬไศࠩᤃ"),l111lll_ll_ (u"࠭ๆฺ็ࠪᤄ"))
	if l111111l1_ll_!=1: return
	l11llll111_ll_ = l11llll11l_ll_()
	if l1l111l1l1_ll_ in l11llll111_ll_.keys():
		del l11llll111_ll_[l1l111l1l1_ll_]
		l1l1111l1l_ll_ = str(l11llll111_ll_)
		with open(l11llll1l1_ll_,l111lll_ll_ (u"ࠧࡸࡤࠪᤅ")) as f: f.write(l1l1111l1l_ll_)
		l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᤆ"),l111lll_ll_ (u"ࠩอ้๋ࠥำฮࠢฯ้๏฿ࠠๆฯอ์๏อสࠡไสส๊ฯࠠศๆ่ๅ฻๊ษࠡࠩᤇ")+l1l111l1l1_ll_)
	return
def l11llll11l_ll_():
	if os.path.exists(l11llll1l1_ll_):
		with open(l11llll1l1_ll_,l111lll_ll_ (u"ࠪࡶࡧ࠭ᤈ")) as f: l11lll1l1l_ll_ = f.read()
		l11llll111_ll_ = eval(l11lll1l1l_ll_)
	else: l11llll111_ll_ = {}
	return l11llll111_ll_
def l1l1111l11_ll_(path):
	l11lllll1l_ll_ = []
	l11lll1l11_ll_ = l11lllllll_ll_(path)
	type,name,url,mode,image,page,text,context = l11lll1l11_ll_
	l11llll111_ll_ = l11llll11l_ll_()
	l11lll1ll1_ll_ = []
	#for l1l111l1l1_ll_ in [l111lll_ll_ (u"ࠫ࠶࠭ᤉ"),l111lll_ll_ (u"ࠬ࠸ࠧᤊ"),l111lll_ll_ (u"࠭࠳ࠨᤋ"),l111lll_ll_ (u"ࠧ࠵ࠩᤌ"),l111lll_ll_ (u"ࠨ࠷ࠪᤍ")]:
	#	if (type,name,url,mode,image,page,text) in l11llll111_ll_[l1l111l1l1_ll_]:
	#		l11lll1ll1_ll_.append(l1l111l1l1_ll_)
	#if l11lll1ll1_ll_: context = l11lll1ll1_ll_[0]
	#else: context = l111lll_ll_ (u"ࠩࠪᤎ")
	if mode==l111lll_ll_ (u"ࠪ࠶࠼࠶ࠧᤏ"):
		if context in l11llll111_ll_.keys() and len(l11llll111_ll_[context])>0:
			l11lllll1l_ll_.append((l111lll_ll_ (u"ู๊ࠫอࠡไสส๊ฯࠠๆใู่ฮࠦࠧᤐ")+context,l111lll_ll_ (u"ࠬ࡞ࡂࡎࡅ࠱ࡖࡺࡴࡐ࡭ࡷࡪ࡭ࡳ࠮ࠧᤑ")+path+l111lll_ll_ (u"࠭ࠦࡤࡱࡱࡸࡪࡾࡴ࠾ࠩᤒ")+context+l111lll_ll_ (u"ࠧࡠࡆࡈࡐࡊ࡚ࡅࡍࡋࡖࡘࠬᤓ")+l111lll_ll_ (u"ࠨࠫࠪᤔ")))
	else:
		l11lll1l11_ll_ = l11lll1l11_ll_[:-1]
		l11lll1l11_ll_ = tuple(l11lll1l11_ll_)
		l1l111l1l1_ll_ = context
		if l1l111l1l1_ll_ in l11llll111_ll_.keys():
			count = len(l11llll111_ll_[l1l111l1l1_ll_])
			if count>1: l11lllll1l_ll_.append((l111lll_ll_ (u"ࠩอัึ๐ใࠡ࠳่้ࠣษูๅ๋ࠪᤕ"),l111lll_ll_ (u"ࠪ࡜ࡇࡓࡃ࠯ࡔࡸࡲࡕࡲࡵࡨ࡫ࡱࠬࠬᤖ")+path+l111lll_ll_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃࠧᤗ")+l1l111l1l1_ll_+l111lll_ll_ (u"ࠬࡥࡕࡑ࠳ࠬࠫᤘ")))
			if count>4: l11lllll1l_ll_.append((l111lll_ll_ (u"࠭สฮำํ็ࠥ࠺ࠠๅๆฦ฽้๏ࠧᤙ"),l111lll_ll_ (u"࡙ࠧࡄࡐࡇ࠳ࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࠩᤚ")+path+l111lll_ll_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀࠫᤛ")+l1l111l1l1_ll_+l111lll_ll_ (u"ࠩࡢ࡙ࡕ࠺ࠩࠨᤜ")))
			if count>1: l11lllll1l_ll_.append((l111lll_ll_ (u"ࠪฮาื๊ไࠢ࠴ࠤ้๊ริใ็ࠫᤝ"),l111lll_ll_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡕࡹࡳࡖ࡬ࡶࡩ࡬ࡲ࠭࠭ᤞ")+path+l111lll_ll_ (u"ࠬࠬࡣࡰࡰࡷࡩࡽࡺ࠽ࠨ᤟")+l1l111l1l1_ll_+l111lll_ll_ (u"࠭࡟ࡅࡑ࡚ࡒ࠶࠯ࠧᤠ")))
			if count>4: l11lllll1l_ll_.append((l111lll_ll_ (u"ࠧหฯิ๎่ࠦ࠴ࠡๆ็วุ็ไࠨᤡ"),l111lll_ll_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡒࡶࡰࡓࡰࡺ࡭ࡩ࡯ࠪࠪᤢ")+path+l111lll_ll_ (u"ࠩࠩࡧࡴࡴࡴࡦࡺࡷࡁࠬᤣ")+l1l111l1l1_ll_+l111lll_ll_ (u"ࠪࡣࡉࡕࡗࡏ࠶ࠬࠫᤤ")))
		for l1l111l1l1_ll_ in [l111lll_ll_ (u"ࠫ࠶࠭ᤥ"),l111lll_ll_ (u"ࠬ࠸ࠧᤦ"),l111lll_ll_ (u"࠭࠳ࠨᤧ"),l111lll_ll_ (u"ࠧ࠵ࠩᤨ"),l111lll_ll_ (u"ࠨ࠷ࠪᤩ")]:
			l11lllll1l_ll_ += l11ll1ll1l_ll_(l1l111l1l1_ll_,context,path,l11lll1l11_ll_,l11llll111_ll_)
	l11ll1llll_ll_ = []
	for l11lllll11_ll_,l11llll1ll_ll_ in l11lllll1l_ll_:
		#l11lllll11_ll_ = l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡋࡌࡆࡇ࠲࠳ࡡࡠࡈ࡝ࠨᤪ")+l11lllll11_ll_+l111lll_ll_ (u"ࠪ࡟࠴ࡈ࡝࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᤫ")
		l11lllll11_ll_ = l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࠧ᤬")+l11lllll11_ll_+l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᤭")
		l11ll1llll_ll_.append((l11lllll11_ll_,l11llll1ll_ll_,))
	return l11ll1llll_ll_
def l11ll1ll1l_ll_(l1l111l1l1_ll_,context,path,l11lll1l11_ll_,l11llll111_ll_):
	l11lllll1l_ll_ = []
	if l1l111l1l1_ll_ in l11llll111_ll_.keys() and l11lll1l11_ll_ in l11llll111_ll_[l1l111l1l1_ll_]:
		l11lllll1l_ll_.append((l111lll_ll_ (u"࠭ๅิฯ้๋ࠣࠦๅโุ็อࠥ࠭᤮")+l1l111l1l1_ll_,l111lll_ll_ (u"࡙ࠧࡄࡐࡇ࠳ࡘࡵ࡯ࡒ࡯ࡹ࡬࡯࡮ࠩࠩ᤯")+path+l111lll_ll_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀࠫᤰ")+l1l111l1l1_ll_+l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡏࡗࡇ࠴࠭ࠬᤱ")))
		#l1ll1l_ll_(context,l1l111l1l1_ll_)
	else: l11lllll1l_ll_.append((l111lll_ll_ (u"ࠪษ฻อแสࠢศ่๎ࠦๅโุ็อࠥ࠭ᤲ")+l1l111l1l1_ll_,l111lll_ll_ (u"ࠫ࡝ࡈࡍࡄ࠰ࡕࡹࡳࡖ࡬ࡶࡩ࡬ࡲ࠭࠭ᤳ")+path+l111lll_ll_ (u"ࠬࠬࡣࡰࡰࡷࡩࡽࡺ࠽ࠨᤴ")+l1l111l1l1_ll_+l111lll_ll_ (u"࠭࡟ࡂࡆࡇ࠵࠮࠭ᤵ")))
	return l11lllll1l_ll_