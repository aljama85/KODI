# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_ = l111lll_ll_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘࠧ೗")
l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡥࡋࡘࡖࡢࠫ೘")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,page,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==130: results = l11l1ll_ll_(url)
	#elif mode==131: results = l1l11l1_ll_(url)
	elif mode==132: results = CATEGORIES(url)
	elif mode==133: results = l1l11ll_ll_(url,page)
	elif mode==134: results = l11_ll_(url)
	elif mode==135: results = l1ll11ll1_ll_()
	elif mode==139: results = l1lll1_ll_(text,url)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"࠭ࠧ೙")):
	if l1111l_ll_==l111lll_ll_ (u"ࠧࠨ೚"):
		#l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭೛"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่อัࠠศๆะ๎๊ࠥโ็ษฬࠤฬ๊ใ้อิࠫ೜"),l111lll_ll_ (u"ࠪࠫೝ"),135)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫೞ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ೟"),l111lll_ll_ (u"࠭ࠧೠ"),139,l111lll_ll_ (u"ࠧࠨೡ"),l111lll_ll_ (u"ࠨࠩೢ"),l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ೣ"))
		l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ೤"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ೥"),l111lll_ll_ (u"ࠬ࠭೦"),9999)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭೧"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ೨")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ุ้๊ำๅษอࠫ೩"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠴࠴ࠩ೪"),132,l111lll_ll_ (u"ࠪࠫ೫"),l111lll_ll_ (u"ࠫ࠶࠭೬"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ೭"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ೮")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆสๅ้อๅࠨ೯"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠻࠸࠸ࠨ೰"),132,l111lll_ll_ (u"ࠩࠪೱ"),l111lll_ll_ (u"ࠪ࠵ࠬೲ"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫೳ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ೴")+l1l1l1l_ll_+l111lll_ll_ (u"࠭ศาษ่ะࠥอไึ฼สีࠥ๎วๅึหหอ࠭೵"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠶࠽ࠧ೶"),132,l111lll_ll_ (u"ࠨࠩ೷"),l111lll_ll_ (u"ࠩ࠴ࠫ೸"))
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ೹"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ೺")+l1l1l1l_ll_+l111lll_ll_ (u"ࠬอศาิࠣห้ฮัศ็ฯࠫ೻"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠴࠻࠻࠹ࠧ೼"),132,l111lll_ll_ (u"ࠧࠨ೽"),l111lll_ll_ (u"ࠨ࠳ࠪ೾"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ೿"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧഀ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ๅฮษูีฬะࠧഁ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠻࠷࠷ࠬം"),132,l111lll_ll_ (u"࠭ࠧഃ"),l111lll_ll_ (u"ࠧ࠲ࠩഄ"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨഅ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ആ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪ฽ฬฺ่าษฤࠫഇ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠲࠵࠸࠷ࠬഈ"),132,l111lll_ll_ (u"ࠬ࠭ഉ"),l111lll_ll_ (u"࠭࠱ࠨഊ"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧഋ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬഌ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่อืวๆฮࠣห้อฬห็ส฽๏ฯࠧ഍"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵࠵࠱࠳ࠪഎ"),132,l111lll_ll_ (u"ࠫࠬഏ"),l111lll_ll_ (u"ࠬ࠷ࠧഐ"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭഑"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫഒ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ฬึอๅอࠢส่ิ๐ๆ๋หࠪഓ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠻࠰࠺ࠩഔ"),132,l111lll_ll_ (u"ࠪࠫക"),l111lll_ll_ (u"ࠫ࠶࠭ഖ"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬഗ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪഘ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆหีฬ๋ฬࠡษ็์ะอฦใ์ฬࠫങ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡦࡥࡹ࡫ࡧࡰࡴࡼ࠳࠺࠻࠳ࠨച"),132,l111lll_ll_ (u"ࠩࠪഛ"),l111lll_ll_ (u"ࠪ࠵ࠬജ"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫഝ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩഞ")+l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅสิห๊าࠠศๆึ๎ฬู๊สࠩട"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲࠹࠹࠻ࠧഠ"),132,l111lll_ll_ (u"ࠨࠩഡ"),l111lll_ll_ (u"ࠩ࠴ࠫഢ"))
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪണ"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨത")+l1l1l1l_ll_+l111lll_ll_ (u"้ࠬสษࠩഥ"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠵࠽࠶࠭ദ"),132,l111lll_ll_ (u"ࠧࠨധ"),l111lll_ll_ (u"ࠨ࠳ࠪന"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩഩ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧപ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฯ฿ไๆࠢส่ๆอัิ์ฬࠫഫ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰࠺࠻ࠫബ"),132,l111lll_ll_ (u"࠭ࠧഭ"),l111lll_ll_ (u"ࠧ࠲ࠩമ"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨയ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ര")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪหึฺ๊โࠢส่อืวๆฮࠪറ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯࠲࠴࠺࠽ࠬല"),132,l111lll_ll_ (u"ࠬ࠭ള"),l111lll_ll_ (u"࠭࠱ࠨഴ"))
	return l111lll_ll_ (u"ࠧࠨവ")
	l111lll_ll_ (u"ࠣࠤࠥࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡷࡦࡤࡶ࡭ࡹ࡫࠰ࡢ࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ࠯ࠊࠊࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡃࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡩࡸ࡯ࡱࡦࡲࡻࡳ࠳࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪࡦࡵࡳࡵࡪ࡯ࡸࡰ࠰ࡸࡴ࡭ࡧ࡭ࡧࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡣ࡮ࡲࡧࡰࠦ࠽ࠡࡪࡷࡱࡱࡥࡢ࡭ࡱࡦ࡯ࡸࡡ࠱࡞ࠌࠌ࡭ࡹ࡫࡭ࡴ࠿ࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡴࡪࡶ࡯ࡩࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠺ࠋࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࡷࡽࡵ࡫ࡌࡊࡕࡗࠤࡂ࡛ࠦࠨ࠱ࡵࡩࡱ࡯ࡧࡪࡱࡸࡷࠬ࠲ࠧ࠰ࡵࡲࡧ࡮ࡧ࡬ࠨ࠮ࠪ࠳ࡵࡵ࡬ࡪࡶ࡬ࡧࡦࡲࠧ࡞ࠌࠌࠍ࡮࡬ࠠࡢࡰࡼࠬࡻࡧ࡬ࡶࡧࠣ࡭ࡳࠦ࡬ࡪࡰ࡮ࠤ࡫ࡵࡲࠡࡸࡤࡰࡺ࡫ࠠࡪࡰࠣࡸࡾࡶࡥࡍࡋࡖࡘ࠮ࡀࠊࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࠬอไษำส้ัࠦࠧࠡ࠭ࠣࡸ࡮ࡺ࡬ࡦࠌࠌࠍࡺࡸ࡬ࠡ࠿ࠣࡻࡪࡨࡳࡪࡶࡨ࠴ࡦࠦࠫࠡ࡮࡬ࡲࡰࠐࠉࠊ࡫ࡩࠤࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹࠨࠢ࡬ࡲࠥࡻࡲ࡭࠼ࠣࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡻࡲ࡭࠮࠴࠷࠷࠲ࠧࠨ࠮ࠪ࠵ࠬ࠯ࠊࠊࠋࡨࡰ࡮࡬ࠠࠨ࠱ࡦࡳࡳࡪࡵࡤࡶࡲࡶࠬࠦ࡮ࡰࡶࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲ࡵࡳ࡮࠯࠵࠸࠷ࠬࠨࠩ࠯ࠫ࠶࠭ࠩࠋࠋࠥࠦࠧശ")
l111lll_ll_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡗࡍ࡙ࡒࡅࡔࠪࡸࡶࡱ࠯࠺ࠋࠋࡷࡽࡵ࡫ࡌࡊࡕࡗࠤࡂ࡛ࠦࠨ࠱ࡵࡩࡱ࡯ࡧࡪࡱࡸࡷࠬ࠲ࠧ࠰ࡵࡲࡧ࡮ࡧ࡬ࠨ࠮ࠪ࠳ࡵࡵ࡬ࡪࡶ࡬ࡧࡦࡲࠧ࠭ࠩ࠲ࡪ࡮ࡲ࡭ࡴࠩ࠯ࠫ࠴ࡹࡥࡳ࡫ࡨࡷࠬࡣࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡆࡅࡈࡎࡅࡅࠪࡕࡉࡌ࡛ࡌࡂࡔࡢࡇࡆࡉࡈࡆ࠮ࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࡚ࡲࡶࡧ࠯ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ࠮ࠐࠉࡩࡶࡰࡰࡤࡨ࡬ࡰࡥ࡮ࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡺࡩࡵ࡮ࡨࡦࡦࡸࠨ࠯ࠬࡂ࠭ࡹ࡯ࡴ࡭ࡧࡥࡥࡷ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡧࠢࡤࡲࡾ࠮ࡶࡢ࡮ࡸࡩࠥ࡯࡮ࠡࡷࡵࡰࠥ࡬࡯ࡳࠢࡹࡥࡱࡻࡥࠡ࡫ࡱࠤࡹࡿࡰࡦࡎࡌࡗ࡙࠯࠺ࠋࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠤࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡪࡴࡸࠠࡪ࡯ࡪ࠰ࡱ࡯࡮࡬࠮ࡷ࡭ࡹࡲࡥࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࡵ࡫ࡷࡰࡪࠦ࠽ࠡࡶ࡬ࡸࡱ࡫࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰ࠲࠱࠴࠵࠯࡭ࡲ࡭ࠬࠨ࠳ࠪ࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬ࠵ࡤࡰࡥࡶࠫࠥ࡯࡮ࠡࡷࡵࡰ࠿ࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠢࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠽ࡪ࠵ࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠸࠾࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠩࠫ࠲࠯ࡅࠩࠨࠤ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡨࡲࡶࠥ࡯࡭ࡨ࠮ࡷ࡭ࡹࡲࡥ࠭࡮࡬ࡲࡰࠦࡩ࡯ࠢ࡬ࡸࡪࡳࡳ࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡹࡴࡳ࡫ࡳࠬࠬࠦࠧࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࠣࡁࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡࠡ࠭ࠣࡰ࡮ࡴ࡫ࠋࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࡵ࡫ࡷࡰࡪ࠲࡬ࡪࡰ࡮࠰࠶࠹࠳࠭࡫ࡰ࡫࠱࠭࠱ࠨࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠎࠧࠨࠢഷ")
def CATEGORIES(url):
	category = url.split(l111lll_ll_ (u"ࠪ࠳ࠬസ"))[-1]
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠫࠬഹ"),l111lll_ll_ (u"ࠬ࠭ഺ"),True,l111lll_ll_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠳࠱ࡴࡶ഻ࠪ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡱࡣࡵࡩࡳࡺࡣࡢࡶࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ഼ࠧ"),html,re.DOTALL)
	if not l1lll_ll_:
		l1l11ll_ll_(url,l111lll_ll_ (u"ࠨ࠳ࠪഽ"))
		return
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠤ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠦാ"),block,re.DOTALL)
	for link,title in items:
		#l1ll1l11l_ll_ = url.split(l111lll_ll_ (u"ࠪ࠳ࠬി"))[-1]
		#if category==l1ll1l11l_ll_: continue
		title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭ീ"))
		link = l1ll1l1_ll_ + link
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬു"),l1l1l1l_ll_+title,link,132,l111lll_ll_ (u"࠭ࠧൂ"),l111lll_ll_ (u"ࠧ࠲ࠩൃ"))
	return
def l1l11ll_ll_(url,page):
	#l1ll1l_ll_(url, page)
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠨࠩൄ"),l111lll_ll_ (u"ࠩࠪ൅"),True,l111lll_ll_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬെ"))
	items = re.findall(l111lll_ll_ (u"ࠫࡹࡵࡴࡢ࡮ࡳࡥ࡬࡫ࡣࡰࡷࡱࡸࡂࡡ࡜ࠨࠤࡠࠬ࠳࠰࠿ࠪ࡝࡟ࠫࠧࡣࠧേ"),html,re.DOTALL)
	if items[0]==l111lll_ll_ (u"ࠬ࠭ൈ"):
		l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ൉"),l111lll_ll_ (u"ࠧๅษࠣ๎ําฯࠡฯส่๏อࠠๆๆไหฯࠦแ๋ัํ์ࠥ็๊้ࠡำหࠥอไโำ฼ࠫൊ"))
		return
	l1ll111ll_ll_ = int(items[0])
	name = re.findall(l111lll_ll_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠽࠱ࡤࡂࠥࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ോ"),html,re.DOTALL)
	if name: name = name[0].strip(l111lll_ll_ (u"ࠩࠣࠫൌ"))
	else: name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯്ࠫ"))
	#l1ll1l_ll_(name, str(l111lll_ll_ (u"ࠫࠬൎ")))
	if l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ൏") in url:
		category = url.split(l111lll_ll_ (u"࠭࠯ࠨ൐"))[-1]
		l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫ൑") + category + l111lll_ll_ (u"ࠨ࠱ࠪ൒") + page
		html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠩࠪ൓"),l111lll_ll_ (u"ࠪࠫൔ"),True,l111lll_ll_ (u"ࠫࡆࡒࡋࡂ࡙ࡗࡌࡆࡘ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠵ࡲࡩ࠭ൕ"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩࡵࡳࡴࡨࡲࡹࡶࡡࡨࡧࡱࡹࡲࡨࡥࡳࠪ࠱࠮ࡄ࠯ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪൖ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡦࡶ࡮࡯ࠬ࠳࠰࠿ࠪࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧൗ"),block,re.DOTALL)
		for img,type,link,title in items:
			if l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭൘") not in type: continue
			if l111lll_ll_ (u"ࠨ็ึุ่๊ࠧ൙") in title and l111lll_ll_ (u"ࠩะ่็ฯࠧ൚") not in title: continue
			title = title.replace(l111lll_ll_ (u"ࠪࡠࡷࡢ࡮ࠨ൛"),l111lll_ll_ (u"ࠫࠬ൜"))
			title = title.strip(l111lll_ll_ (u"ࠬࠦࠧ൝"))
			if l111lll_ll_ (u"࠭ๅิๆึ่ࠬ൞") in name and l111lll_ll_ (u"ࠧฮๆๅอࠬൟ") in title and l111lll_ll_ (u"ࠨ็ึุ่๊ࠧൠ") not in title:
				title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟ࠨൡ") + name + l111lll_ll_ (u"ࠪࠤ࠲ࠦࠧൢ") + title
			link = l1ll1l1_ll_ + link
			if category==l111lll_ll_ (u"ࠫ࠻࠸࠸ࠨൣ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ൤"),l1l1l1l_ll_+title,link,133,img,l111lll_ll_ (u"࠭࠱ࠨ൥"))
			else: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭൦"),l1l1l1l_ll_+title,link,134,img)
	elif l111lll_ll_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ൧") in url:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷࠬ࠳࠰࠿ࠪࡥࡲࡰ࠲ࡳࡤ࠮࠳࠵ࠫ൨"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠥࡺ࡮ࡪࡥࡰ࠯ࡷࡶࡦࡩ࡫࠮ࡶࡨࡼࡹ࠴ࠪࡀ࡮ࡲࡥࡩ࡜ࡩࡥࡧࡲࡠ࠭࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠥ൩"),block,re.DOTALL)
			for link,img,title in items:
				title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭൪"))
				l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ൫"),l1l1l1l_ll_+title,link,134,img)
		elif l111lll_ll_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱࠹࠶࠽࠭൬") in html:
				title = l111lll_ll_ (u"ࠧࡠࡏࡒࡈࡤ࠭൭") + l111lll_ll_ (u"ࠨ็็ๅࠥอไหึ฽๎้ࠦ࠭ࠡࠩ൮") + name
				l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ൯"),l1l1l1l_ll_+title,url,134)
		else:
			items = re.findall(l111lll_ll_ (u"ࠪ࡭ࡩࡃࠢࡄࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ൰"),html,re.DOTALL)
			category = items[0].split(l111lll_ll_ (u"ࠫ࠴࠭൱"))[-1]
			url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ൲") + category
			CATEGORIES(url)
			return
		l1ll111ll_ll_ = 0
		l111lll_ll_ (u"ࠨࠢࠣࠌࠌࠍࠎ࡫ࡰࡪࡵࡲࡨࡪࡏࡄࠡ࠿ࠣࡹࡷࡲ࠮ࡴࡲ࡯࡭ࡹ࠮ࠧ࠰ࠩࠬ࡟࠲࠷࡝ࠋࠋࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢࡄࡣࡷࡩ࡬ࡵࡲࡪࡧࡶ࠲࠯ࡅࡨࡳࡧࡩࡁࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭ࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࠏࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠿ࠣ࡭ࡹ࡫࡭ࡴ࡝࠳ࡡ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠵ࠧࠪ࡝࠰࠵ࡢࠐࠉࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡤ࡮ࡦࡾ࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱ࠪࠤ࠰ࠦࡣࡢࡶࡨ࡫ࡴࡸࡹࠡ࠭ࠣࠫ࠴࠭ࠠࠬࠢࡳࡥ࡬࡫ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࠭ࠧ࠭ࡖࡵࡹࡪ࠲ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠹ࡲࡥࠩࠬࠎࠎࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࠦ࠼ࡩ࠷ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࠋࡩࡳࡷࠦࡩ࡮ࡩ࠯ࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥࡲࡩ࡯࡭ࠍࠍࠎࠏࠉࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠯ࠨࠫ࡞࠱࠶ࡣࠊࠊࠋࠌࠍ࡮࡬ࠠࡦࡲ࡬ࡷࡴࡪࡥࡊࡆࡱࡩࡼࡃ࠽ࡦࡲ࡬ࡷࡴࡪࡥࡊࡆ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࡸ࡮ࡺ࡬ࡦࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠊࠊࠋࠌࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡺ࡮ࡪࡥࡰࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࡴࡪࡶ࡯ࡩ࠱ࡲࡩ࡯࡭࠯࠵࠸࠺ࠬࡪ࡯ࡪ࠭ࠏࠏࠉࠣࠤࠥ൳")
	title = l111lll_ll_ (u"ࠧึใะอࠥ࠭൴")
	for i in range(1,1+l1ll111ll_ll_):
		if page!=str(i):
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ൵"),l1l1l1l_ll_+title+str(i),url,133,l111lll_ll_ (u"ࠩࠪ൶"),str(i))
	return
def l11_ll_(url):
	#l1ll1l_ll_(url, l111lll_ll_ (u"ࠪࠫ൷"))
	if l111lll_ll_ (u"ࠫ࠴ࡴࡥࡸࡵ࠲ࠫ൸") in url or l111lll_ll_ (u"ࠬ࠵ࡥࡱ࡫ࡶࡳࡩ࡫࠯ࠨ൹") in url:
		html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"࠭ࠧൺ"),l111lll_ll_ (u"ࠧࠨൻ"),True,l111lll_ll_ (u"ࠨࡃࡏࡏࡆ࡝ࡔࡉࡃࡕ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ർ"))
		items = re.findall(l111lll_ll_ (u"ࠤࡰࡳࡧ࡯࡬ࡦࡸ࡬ࡨࡪࡵࡰࡢࡶ࡫࠲࠯ࡅࡶࡢ࡮ࡸࡩࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨൽ"),html,re.DOTALL)
		if items: url = items[0]
		else:
			l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ൾ"),l111lll_ll_ (u"้ࠫอ๋๊ࠠฯำ๋ࠥไโࠢไ๎ิ๐่ࠨൿ"))
			return
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ඀"))
	return
def l1ll11ll1_ll_():
	#l1ll1ll11_ll_(l111lll_ll_ (u"࠭ࡳࡵࡣࡵࡸࠬඁ"))
	#l1ll11l_ll_(l111lll_ll_ (u"ࠧอษิ๎ࠥะิ฻์็ࠤฬ๊โ็ษฬࠫං"),l111lll_ll_ (u"ࠨࠩඃ"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡰ࡮ࡼࡥࠨ඄")
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠪࠫඅ"),l111lll_ll_ (u"ࠫࠬආ"),True,l111lll_ll_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪඇ"))
	items = re.findall(l111lll_ll_ (u"࠭࡬ࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧඈ"),html,re.DOTALL)
	url = items[0]
	html = l111ll1_ll_(l1l11lll_ll_,url,l111lll_ll_ (u"ࠧࠨඉ"),l111lll_ll_ (u"ࠨࠩඊ"),True,l111lll_ll_ (u"ࠩࡄࡐࡐࡇࡗࡕࡊࡄࡖ࠲ࡒࡉࡗࡇ࠰࠶ࡳࡪࠧඋ"))
	token = re.findall(l111lll_ll_ (u"ࠪࡧࡸࡸࡦ࠮ࡶࡲ࡯ࡪࡴࠢࠡࡥࡲࡲࡹ࡫࡮ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪඌ"),html,re.DOTALL)
	token = token[0]
	server = l1ll1l111_ll_(url)
	url = re.findall(l111lll_ll_ (u"ࠦࡵࡲࡡࡺࡗࡵࡰࠥࡃࠠࠨࠪ࠱࠮ࡄ࠯ࠧࠣඍ"),html,re.DOTALL)
	url = server+url[0]
	l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫඎ"):l111lll_ll_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬඏ") , l111lll_ll_ (u"࡙ࠧ࠯ࡆࡗࡗࡌ࠭ࡕࡑࡎࡉࡓ࠭ඐ"):token }
	response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠨࡒࡒࡗ࡙࠭එ"),url,l111lll_ll_ (u"ࠩࠪඒ"),l1ll11l1l_ll_,False,True,l111lll_ll_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠳ࡌࡊࡘࡈ࠱࠸ࡸࡤࠨඓ"))
	html = response.content
	url = re.findall(l111lll_ll_ (u"ࠫࠧ࠮࠮ࠫࡁࠬࠦࠬඔ"),html,re.DOTALL)
	url = url[0].replace(l111lll_ll_ (u"ࠬࡢ࠯ࠨඕ"),l111lll_ll_ (u"࠭࠯ࠨඖ"))
	#l1ll1l_ll_(url,html)
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠧࡴࡶࡲࡴࠬ඗"))
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭඘"))
	return
def l1lll1_ll_(search,url=l111lll_ll_ (u"ࠩࠪ඙")):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if url==l111lll_ll_ (u"ࠪࠫක"):
		#search = l111lll_ll_ (u"ࠫࡲࡧ࡮ࠨඛ")
		if search==l111lll_ll_ (u"ࠬ࠭ග"): search = l1ll1_ll_()
		if search==l111lll_ll_ (u"࠭ࠧඝ"): return
		#search = search.replace(l111lll_ll_ (u"ࠧࠡࠩඞ"),l111lll_ll_ (u"ࠨ࠭ࠪඟ"))
		#search = l111lll_ll_ (u"ࠩ࠰ࡸࡦ࡭ࠠࡥࡱࡦࡷࠥࡕࡒࠡࡨ࡬ࡰࡲࡹࠠࡐࡔࠣࡷࡪࡸࡩࡦࡵࠣࡓࡗࠦࡥࡱ࡫ࡶࡳࡩ࡫ࠠࡐࡔࠣࡩࡵ࡯ࡳࡰࡦࡨࡷࠥࡕࡒࠡࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡓࡗࠦ࡮ࡦࡹࡶࠤࡲࡶ࠴ࠡࠩච")+search
		search = l111lll_ll_ (u"ࠪࠦࡲࡶ࠴ࠣࠢࠪඡ")+search
		search = l1lll111_ll_(search)
		url = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡷ࠽ࠨජ")+search
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭ඣ"),l111lll_ll_ (u"࠭ࠧඤ"),True,l111lll_ll_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧඥ"))
		#with open(l111lll_ll_ (u"ࠨࡕ࠽ࡠࡡ࡫࡭ࡢࡦ࠴࠲࡭ࡺ࡭࡭ࠩඦ"), l111lll_ll_ (u"ࠩࡺࠫට")) as f: f.write(html)
		cx = re.findall(l111lll_ll_ (u"ࠥࡺࡦࡸࠠࡤࡺࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨඨ"),html,re.DOTALL)[0]
		url = re.findall(l111lll_ll_ (u"ࠦ࡬ࡩࡳࡦ࠰ࡶࡶࡨࠦ࠽ࠡࠩࠫ࠲࠯ࡅࠩࠨࠤඩ"),html,re.DOTALL)[0]
		url = url+cx
		#l1ll1l_ll_(url,cx)
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭ඪ"),l111lll_ll_ (u"࠭ࠧණ"),True,l111lll_ll_ (u"ࠧࡂࡎࡎࡅ࡜࡚ࡈࡂࡔ࠰ࡗࡊࡇࡒࡄࡊ࠰࠶ࡳࡪࠧඬ"))
		#with open(l111lll_ll_ (u"ࠨࡕ࠽ࡠࡡ࡫࡭ࡢࡦ࠵࠲࡭ࡺ࡭࡭ࠩත"), l111lll_ll_ (u"ࠩࡺࠫථ")) as f: f.write(html)
		l1ll1111l_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡸ࡫࡟ࡵࡱ࡮ࡩࡳࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣࠩද"),html,re.DOTALL)[0]
		l1ll1l1l1_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡹࡥ࡭࡫ࡥ࡚ࡪࡸࡳࡪࡱࡱࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧධ"),html,re.DOTALL)[0]
		l1ll1l1ll_ll_ = str(random.randint(1111,9999))
		url = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡣࡴࡧ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡤࡵࡨ࠳ࡪࡲࡥ࡮ࡧࡱࡸ࠴ࡼ࠱ࡀࡴࡶࡾࡂ࡬ࡩ࡭ࡶࡨࡶࡪࡪ࡟ࡤࡵࡨࠪࡳࡻ࡭࠾࠳࠳ࠪ࡭ࡲ࠽ࡢࡴࠩࡷࡴࡻࡲࡤࡧࡀ࡫ࡨࡹࡣࠧࡩࡶࡷࡂ࠴ࡣࡰ࡯ࠩࡧࡸ࡫࡬ࡪࡤࡹࡁࠬන")+l1ll1l1l1_ll_+l111lll_ll_ (u"࠭ࠦࡤࡺࡀࠫ඲")+cx+l111lll_ll_ (u"ࠧࠧࡳࡀࠫඳ")+search+l111lll_ll_ (u"ࠨࠨࡶࡥ࡫࡫࠽ࡰࡨࡩࠪࡨࡹࡥࡠࡶࡲ࡯ࡂ࠭ප")+l1ll1111l_ll_+l111lll_ll_ (u"ࠩࠩࡷࡴࡸࡴ࠾ࠨࡨࡼࡵࡃࡣࡴࡳࡵ࠰ࡨࡩࠦࡤࡣ࡯ࡰࡧࡧࡣ࡬࠿ࡪࡳࡴ࡭࡬ࡦ࠰ࡶࡩࡦࡸࡣࡩ࠰ࡦࡷࡪ࠴ࡡࡱ࡫ࠪඵ")+l1ll1l1ll_ll_+l111lll_ll_ (u"ࠪࠪࡸࡺࡡࡳࡶࡀ࠴ࠬබ")
	l1ll11l11_ll_ = l1ll11lll_ll_()
	headers = {l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨභ"):l1ll11l11_ll_}
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭ම"),headers,True,l111lll_ll_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓ࠯ࡖࡉࡆࡘࡃࡉ࠯࠶ࡶࡩ࠭ඹ"))
	#with open(l111lll_ll_ (u"ࠧࡔ࠼࡟ࡠࡪࡳࡡࡥ࠵࠱࡬ࡹࡳ࡬ࠨය"), l111lll_ll_ (u"ࠨࡹࠪර")) as f: f.write(html)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ඼"),l111lll_ll_ (u"ࠪࡉࡒࡇࡄࠡࠢࠪල")+url)
	items = re.findall(l111lll_ll_ (u"ࠫࡨࡧࡣࡩࡧࡘࡶࡱࠨ࠺࠯ࠬࡂࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠥࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡸࡶࡱࠨ࠺ࠡࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡳࡥࡵࡣࡷࡥ࡬ࡹࠢ࠻ࠢࡾࠬ࠳࠰࠿ࠪࡿࠪ඾"),html,re.DOTALL)
	for title,link,tags in items:
		if l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ඿") not in tags: continue
		title = unescapeHTML(title)
		title = title.replace(l111lll_ll_ (u"࠭࡜ࡶ࠲࠳࠷ࡨ࠭ව"),l111lll_ll_ (u"ࠧ࠽ࠩශ")).replace(l111lll_ll_ (u"ࠨ࡞ࡸ࠴࠵࠹ࡥࠨෂ"),l111lll_ll_ (u"ࠩࡁࠫස"))
		title = title.replace(l111lll_ll_ (u"ࠪࡀࡧࡄࠧහ"),l111lll_ll_ (u"ࠫࠬළ")).replace(l111lll_ll_ (u"ࠬࡂ࠯ࡣࡀࠪෆ"),l111lll_ll_ (u"࠭ࠧ෇")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪ෈"),l111lll_ll_ (u"ࠨࠢࠪ෉"))
		if l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴්࠭") in link:	# or l111lll_ll_ (u"ࠪ࠳ࡵࡸ࡯ࡨࡴࡤࡱ࠴࠭෋") in link:
			vars = link.split(l111lll_ll_ (u"ࠫ࠴࠭෌"))
			category = vars[4]
			url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩ෍") + category
			if len(vars)>5:
				l1l1lllll_ll_ = vars[5]
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭෎"),l1l1l1l_ll_+title,url,133,l111lll_ll_ (u"ࠧࠨා"),l1l1lllll_ll_)
			else: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨැ"),l1l1l1l_ll_+title,url,132)
		elif l111lll_ll_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬෑ") in link: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪි"),l1l1l1l_ll_+title,link,133,l111lll_ll_ (u"ࠫࠬී"),l111lll_ll_ (u"ࠬ࠷ࠧු"))
		else: l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ෕"),l1l1l1l_ll_+title,link,134)
	items = re.findall(l111lll_ll_ (u"ࠧࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠢࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࠧࡹࡴࡢࡴࡷࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧූ"),html,re.DOTALL)
	if items:
		l1ll111l1_ll_ = re.findall(l111lll_ll_ (u"ࠨࠤࡦࡹࡷࡸࡥ࡯ࡶࡓࡥ࡬࡫ࡉ࡯ࡦࡨࡼࠧࡀࠠࠩ࠰࠭ࡃ࠮࠲ࠧ෗"),html,re.DOTALL)
		l1ll111l1_ll_ = str(int(l1ll111l1_ll_[0])+1)
		for title,start in items:
			if title==l1ll111l1_ll_: continue
			url = url.split(l111lll_ll_ (u"ࠩࡶࡸࡦࡸࡴ࠾ࠩෘ"))[0]+l111lll_ll_ (u"ࠪࡷࡹࡧࡲࡵ࠿ࠪෙ")+start
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫේ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣࠫෛ")+title,url,139)
	return