# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡪࡧ࠲࠹࡮ࡥ࡭ࡣ࡯࠲ࡹࡼࠧ᧥")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱࠷࡬ࡪࡲࡡ࡭࠰ࡷࡺࠬ᧦")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮࠵ࡪࡨࡰࡦࡲ࠮ࡵࡸࠪ᧧")
l1ll_ll_=l111lll_ll_ (u"ࠪࡌࡊࡒࡁࡍࠩ᧨")
headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᧩") : l111lll_ll_ (u"ࠬ࠭᧪") }
l1l1l1l_ll_=l111lll_ll_ (u"࠭࡟ࡉࡇࡏࡣࠬ᧫")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==90: results = l11l1ll_ll_(url)
	elif mode==91: results = l11ll1l11l_ll_(url)
	elif mode==92: results = l11_ll_(url)
	elif mode==94: results = l1111l11_ll_()
	elif mode==95: results = l1l11ll_ll_(url)
	elif mode==99: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠧࠨ᧬")):
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᧭"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ᧮"),l111lll_ll_ (u"ࠪࠫ᧯"),99,l111lll_ll_ (u"ࠫࠬ᧰"),l111lll_ll_ (u"ࠬ࠭᧱"),l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᧲"))
	l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᧳"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᧴"),l111lll_ll_ (u"ࠩࠪ᧵"),9999)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᧶"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ᧷")+l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไๆุสๅࠥำฯ๋อสࠫ᧸"),l111lll_ll_ (u"࠭ࠧ᧹"),94)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᧺"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬ᧻")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่ศำฯฬࠩ᧼"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡄࡺࡹࡱࡧࡀࡰࡦࡺࡥࡴࡶࠪ᧽"),91)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᧾"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ᧿")+l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅล฼่๎ࠦสใ์่ห๐࠭ᨀ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡁࡷࡽࡵ࡫࠽ࡪ࡯ࡧࡦࠬᨁ"),91)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᨂ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ᨃ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้ษใฬำู้ࠣอ็ะหࠪᨄ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡅࡴࡺࡲࡨࡁࡻ࡯ࡥࡸࠩᨅ"),91)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᨆ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪᨇ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆ่ฯอะࠧᨈ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡂࡸࡾࡶࡥ࠾ࡲ࡬ࡲࠬᨉ"),91)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᨊ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧᨋ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫัี๊ะࠢส่ศ็ไศ็ࠪᨌ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵࠿ࡵࡻࡳࡩࡂࡴࡥࡸࡏࡲࡺ࡮࡫ࡳࠨᨍ"),91)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨎ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫᨏ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨฮา๎ิࠦวๅฯ็ๆฬะࠧᨐ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡃࡹࡿࡰࡦ࠿ࡱࡩࡼࡋࡰࡪࡵࡲࡨࡪࡹࠧᨑ"),91)
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨᨒ"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᨓ"),l111lll_ll_ (u"ࠬ࠭ᨔ"),9999)
	#l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨕ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫᨖ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨฮา๎ิࠦวๅ็๋ๆ฾࠭ᨗ"),l1ll1l1_ll_,91)
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ᨘࠩࠪ"),headers,l111lll_ll_ (u"ࠪࠫᨙ"),l111lll_ll_ (u"ࠫࡍࡋࡌࡂࡎ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬᨚ"))
	#upper l11l1llll1_ll_
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡳࡡࡪࡰࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡳࡧࡶࠨᨛ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"࠭࠼࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᨜"),block,re.DOTALL)
	l11lll1_ll_ = [l111lll_ll_ (u"ࠧศใ็ห๊ࠦไๅๅหหึࠦแใูࠪ᨝"),l111lll_ll_ (u"ࠨำํห฻ฯࠧ᨞")]
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"ࠩࠣࠫ᨟"))
		if not any(value in title for value in l11lll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨠ"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨᨡ")+l1l1l1l_ll_+title,link,91)
	return html
def l11ll1l11l_ll_(url):
	#l1ll1l_ll_(str(url),str(l111lll_ll_ (u"ࠬ࠭ᨢ")))
	if l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡱࡪࡳࠫᨣ") in url:
		url,search = url.split(l111lll_ll_ (u"ࠧࡀࡶࡀࠫᨤ"))
		headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᨥ") : l111lll_ll_ (u"ࠩࠪᨦ") , l111lll_ll_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩᨧ") : l111lll_ll_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪᨨ") }
		data = { l111lll_ll_ (u"ࠬࡺࠧᨩ") : search }
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫᨪ"),url,data,headers,l111lll_ll_ (u"ࠧࠨᨫ"),l111lll_ll_ (u"ࠨࠩᨬ"),l111lll_ll_ (u"ࠩࡋࡉࡑࡇࡌ࠮ࡋࡗࡉࡒ࡙࠭࠲ࡵࡷࠫᨭ"))
		html = response.content
	else:
		headers = { l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᨮ") : l111lll_ll_ (u"ࠫࠬᨯ") }
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠬ࠭ᨰ"),headers,l111lll_ll_ (u"࠭ࠧᨱ"),l111lll_ll_ (u"ࠧࡉࡇࡏࡅࡑ࠳ࡉࡕࡇࡐࡗ࠲࠸࡮ࡥࠩᨲ"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩᨳ"),str(html))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨ࡭ࡰࡸ࡬ࡩࡸ࠳ࡩࡵࡧࡰࡷ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺࡦࡰࡱࡷࠦࠬᨴ"),html,re.DOTALL)
	if l1lll_ll_: block = l1lll_ll_[0]
	else: block = l111lll_ll_ (u"ࠪࠫᨵ")
	items = re.findall(l111lll_ll_ (u"ࠫࡧࡧࡣ࡬ࡩࡵࡳࡺࡴࡤ࠮࡫ࡰࡥ࡬࡫࠺ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡰࡳࡻ࡯ࡥ࠮ࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᨶ"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for img,link,title in items:
		if l111lll_ll_ (u"ࠬอไฮๆๅอࠬᨷ") in title and l111lll_ll_ (u"࠭࠯ࡤ࠱ࠪᨸ") not in url and l111lll_ll_ (u"ࠧ࠰ࡥࡤࡸ࠴࠭ᨹ") not in url:
			episode = re.findall(l111lll_ll_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡜࠲࠰࠽ࡢ࠱ࠧᨺ"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟ࠨᨻ")+episode[0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᨼ"),l1l1l1l_ll_+title,link,95,img)
					l1ll11ll_ll_.append(title)
		elif l111lll_ll_ (u"ࠫ࠴ࡼࡩࡥࡧࡲ࠳ࠬᨽ") in link: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫᨾ"),l1l1l1l_ll_+title,link,92,img)
		else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᨿ"),l1l1l1l_ll_+title,link,91,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠬᩀ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᩁ"),block,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l111lll_ll_ (u"ࠩสฺ่็อสࠢࠪᩂ"),l111lll_ll_ (u"ࠪࠫᩃ"))
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᩄ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣࠫᩅ")+title,link,91)
	return
def l1l11ll_ll_(url):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"࠭ࠧᩆ"),headers,l111lll_ll_ (u"ࠧࠨᩇ"),l111lll_ll_ (u"ࠨࡊࡈࡐࡆࡒ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭ᩈ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨࡥࡱ࡫ࡶࡳࡩ࡫ࡳ࠮ࡲࡤࡲࡪࡲࠨ࠯ࠬࡂ࠭ࡩ࡯ࡶࠨᩉ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	img = re.findall(l111lll_ll_ (u"ࠪ࡭ࡲࡧࡧࡦࠤ࠽࠲࠯ࡅࠢࠩ࠰࠭ࡃ࠮ࠨࠧᩊ"),html,re.DOTALL)[0]
	name = re.findall(l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᩋ"),html,re.DOTALL)
	if name: name = name[1]
	else:
		name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡍࡣࡥࡩࡱ࠭ᩌ"))
		if l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨᩍ") in name: name = name.split(l111lll_ll_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᩎ"),1)[1]
	items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᩏ"),block,re.DOTALL)
	for link,title in items:
		l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᩐ"),l1l1l1l_ll_+name+l111lll_ll_ (u"ࠪࠤ࠲ࠦࠧᩑ")+title,link,92,img)
	return
def l11_ll_(url):
	l1l111l_ll_,l11l1lllll_ll_ = [],[]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬᩒ"),headers,l111lll_ll_ (u"ࠬ࠭ᩓ"),l111lll_ll_ (u"࠭ࡈࡆࡎࡄࡐ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᩔ"))
	l1llll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡵࡧࡻࡸ࠲ࡹࡨࡢࡦࡲࡻ࠿ࠦ࡮ࡰࡰࡨ࠿ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᩕ"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࡫ࡧࡁࠧࡲࡩ࡯࡭ࡶ࠱ࡵࡧ࡮ࡦ࡮ࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫᩖ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᩗ"),block,re.DOTALL)
		for link in items:
			l1l111l_ll_.append(link)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡲࡦࡼ࠭ࡵࡣࡥࡷࠧ࠮࠮ࠫࡁࠬࡺ࡮ࡪࡥࡰ࠯ࡳࡥࡳ࡫࡬࠮࡯ࡲࡶࡪ࠭ᩘ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫ࡮ࡪ࠽ࠣࡣ࡭ࡥࡽ࠳ࡦࡪ࡮ࡨ࠱࡮ࡪ࠮ࠫࡁࡹࡥࡱࡻࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᩙ"),block,re.DOTALL)
	id = items[0]
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭ᩚ"),id)
	items = re.findall(l111lll_ll_ (u"࠭ࡤࡢࡶࡤ࠱ࡸ࡫ࡲࡷࡧࡵ࠱ࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩᩛ"),block,re.DOTALL)
	for link in items:
		if l111lll_ll_ (u"ࠧࡩࡶࡷࡴࠬᩜ") not in link: link = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀࠧᩝ") + link
		link = l1111_ll_(link)
		l1l111l_ll_.append(link)
	l111lll_ll_ (u"ࠤࠥࠦࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡪࡡࡵࡣ࠰ࡷࡪࡸࡶࡦࡴࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠊࠊࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡤ࡮ࡦࡾ࠮ࡱࡪࡳࡃ࡮ࡪ࠽ࠨ࠭࡬ࡨ࠰࠭ࠦࡢ࡬ࡤࡼࡂࡺࡲࡶࡧࠩࡷࡪࡸࡶࡦࡴࡀࠫ࠰ࡲࡩ࡯࡭ࠍࠍࠎࠩ࡬ࡪࡰ࡮ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠶࠱࠭ࠧ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࡈࡆࡎࡄࡐ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧࠪࠌࠌࠍࠨࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࡷࡵࡰࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡸࡶࡱ࠸ࠩࠋࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡈࡇࡃࡉࡇࡇࠬࡗࡋࡇࡖࡎࡄࡖࡤࡉࡁࡄࡊࡈ࠰ࡺࡸ࡬࠳࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࠧࠨ࠮ࠪࡌࡊࡒࡁࡍ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ࠮ࠐࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭ࡻࡲ࡭࠴࠯࡬ࡹࡳ࡬ࠪࠌࠌࡧࡴࡻ࡮ࡵࠢࡀࠤࡱ࡫࡮ࠩࡷࡵࡰࡑࡏࡓࡕࠫࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡨࡵ࡮ࡤࡷࡵࡶࡪࡴࡴ࠯ࡨࡸࡸࡺࡸࡥࡴࠌࠌࡻ࡮ࡺࡨࠡࡥࡲࡲࡨࡻࡲࡳࡧࡱࡸ࠳࡬ࡵࡵࡷࡵࡩࡸ࠴ࡔࡩࡴࡨࡥࡩࡖ࡯ࡰ࡮ࡈࡼࡪࡩࡵࡵࡱࡵࠬࡲࡧࡸࡠࡹࡲࡶࡰ࡫ࡲࡴ࠿࠵࠴࠮ࠦࡡࡴࠢࡨࡼࡪࡩࡵࡵࡱࡵ࠾ࠏࠏࠉࡳࡧࡶࡴࡴࡴࡣࡦࡵࡇࡍࡈ࡚ࠠ࠾ࠢࡧ࡭ࡨࡺࠨࠡࠪࡨࡼࡪࡩࡵࡵࡱࡵ࠲ࡸࡻࡢ࡮࡫ࡷࠬࡴࡶࡥ࡯ࡗࡕࡐ࠱ࠦࡵࡳ࡮ࡏࡍࡘ࡚࡛ࡪ࡟࠯ࠤࠬ࠭ࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࡈࡆࡎࡄࡐ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧࠪ࠮ࠣ࡭࠮ࠦࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠱࠮ࡦࡳࡺࡴࡴࠪࠢࠬࠎࠎ࡬࡯ࡳࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠶࠷ࠦࡩ࡯ࠢࡦࡳࡳࡩࡵࡳࡴࡨࡲࡹ࠴ࡦࡶࡶࡸࡶࡪࡹ࠮ࡢࡵࡢࡧࡴࡳࡰ࡭ࡧࡷࡩࡩ࠮ࡲࡦࡵࡳࡳࡳࡩࡥࡴࡆࡌࡇ࡙࠯࠺ࠋࠋࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࠦࡲࡦࡵࡳࡳࡳࡹࡥ࠳࠴࠱ࡶࡪࡹࡵ࡭ࡶࠫ࠭ࠥ࠯ࠊࠊࠤࠥࠦᩞ")
	import l1_ll_
	l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ᩟"))
	return
def l1111l11_ll_():
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_,l111lll_ll_ (u"᩠ࠫࠬ"),headers,l111lll_ll_ (u"ࠬ࠭ᩡ"),l111lll_ll_ (u"࠭ࡈࡆࡎࡄࡐ࠲ࡒࡁࡕࡇࡖࡘ࠲࠷ࡳࡵࠩᩢ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡪࡦࡀࠦ࡮ࡴࡤࡦࡺ࠰ࡰࡦࡹࡴ࠮࡯ࡲࡺ࡮࡫ࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣ࡫ࡱࡨࡪࡾ࠭ࡴ࡮࡬ࡨࡪࡸ࠭࡮ࡱࡹ࡭ࡪ࠭ᩣ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧᩤ"),block,re.DOTALL)
	for img,link,title in items:
		if l111lll_ll_ (u"ࠩ࠲ࡺ࡮ࡪࡥࡰ࠱ࠪᩥ") in link: l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᩦ"),l1l1l1l_ll_+title,link,92,img)
		else: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᩧ"),l1l1l1l_ll_+title,link,91,img)
	return
def l1lll1_ll_(search=l111lll_ll_ (u"ࠬ࠭ᩨ")):
	#l1ll1l_ll_(str(search),str(l111lll_ll_ (u"࠭ࠧᩩ")))
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠧࠨᩪ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠨࠩᩫ"): return
	search = search.replace(l111lll_ll_ (u"ࠩࠣࠫᩬ"),l111lll_ll_ (u"ࠪ࠯ࠬᩭ"))
	#l1ll1l_ll_(str(search),str(l111lll_ll_ (u"ࠫࠬᩮ")))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡸࡂ࠭ᩯ")+search
	l11ll1l11l_ll_(url)
	return