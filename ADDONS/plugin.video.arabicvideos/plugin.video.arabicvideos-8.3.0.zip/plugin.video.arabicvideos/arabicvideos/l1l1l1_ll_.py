﻿# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
# total l1l1ll1ll11_ll_ = 0 ms
# l1ll111ll1l_ll_ l1ll11ll111_ll_ are l1l11l11l11_ll_ included with l1ll1ll11l_ll_ other modules
import xbmcplugin,xbmcgui,xbmcaddon,xbmc,sys,os,re,time    #,_thread   #,threading
import random,base64    #,pickle # total l1l1ll1ll11_ll_ = 0ms
import socket,struct,traceback # total l1l1ll1ll11_ll_ = 0ms
#import zlib,ssl,hashlib,string
#import sqlite3		# 50ms (with threading 71ms)
import zlib,pickle
try:
	from urllib.parse import quote as _11l1l11l1l_ll_
	from urllib.parse import unquote as _1l11l1llll_ll_
except:
	from urllib import quote as _11l1l11l1l_ll_
	from urllib import unquote as _1l11l1llll_ll_
def l1lll111_ll_(url,exceptions=l111lll_ll_ (u"ࠫ࠿࠵ࠧ₸")):
	return _11l1l11l1l_ll_(url,exceptions)
	#return l11llll11l1_ll_.quote(url,ignore)
def l1111_ll_(url):
	return _1l11l1llll_ll_(url)
	#return l11llll11l1_ll_.unquote(url)
#import urllib		# 160ms
#import l11llll11l1_ll_		# 354ms (contains urllib)
#import requests   	# 986ms (contains urllib,l11llll11l1_ll_,urllib3)
#import threading	# 54ms (with sqlite3 71ms)
#import urllib3		# 621ms (contains urllib)
#import l1l1ll111ll_ll_		# 10ms
#import urlresolver	# 2170ms (contains urllib,l11llll11l1_ll_,urllib3,requests)
#import platform	# 20ms
#import uuid		# 75ms
#import HTMLParser	# 18ms
#import unicodedata	# 4ms
#import l1l1lll1l1l_ll_	# 1922ms
#import BaseHTTPServer		# 44ms
# l1ll1ll1ll1_ll_ the l11l11llll1_ll_ time needed to import a main-module and how l1l11ll1l11_ll_ sub-modules will be l1l1ll1111l_ll_ with it
l111lll_ll_ (u"ࠧࠨࠢࠋ࡫ࡰࡴࡴࡸࡴࠡࡵࡼࡷ࠱ࡺࡩ࡮ࡧࠍࡸࡴࡺࡡ࡭ࡧ࡯ࡴࡦࡹࡥࡥࠢࡀࠤ࠵ࠐࡦࡰࡴࠣ࡭ࠥ࡯࡮ࠡࡴࡤࡲ࡬࡫ࠨ࠳࠲ࠬ࠾ࠏࠏࡴ࠲ࠢࡀࠤࡹ࡯࡭ࡦ࠰ࡷ࡭ࡲ࡫ࠨࠪࠌࠌࡦࡪ࡬࡯ࡳࡧࡢ࡭ࡲࡶ࡯ࡳࡶࠣࡁࠥࡹࡹࡴ࠰ࡰࡳࡩࡻ࡬ࡦࡵ࠱࡯ࡪࡿࡳࠩࠫࠍࠍ࡮ࡳࡰࡰࡴࡷࠤࡹࡸࡡࡤࡧࡥࡥࡨࡱࠊࠊࡣࡩࡸࡪࡸ࡟ࡪ࡯ࡳࡳࡷࡺࠠ࠾ࠢࡶࡽࡸ࠴࡭ࡰࡦࡸࡰࡪࡹ࠮࡬ࡧࡼࡷ࠭࠯ࠊࠊ࡫ࡰࡴࡴࡸࡴࡠ࡮࡬ࡷࡹࠦ࠽ࠡ࡮࡬ࡷࡹ࠮ࡳࡦࡶࠫࡥ࡫ࡺࡥࡳࡡ࡬ࡱࡵࡵࡲࡵࠫ࠰ࡷࡪࡺࠨࡣࡧࡩࡳࡷ࡫࡟ࡪ࡯ࡳࡳࡷࡺࠩࠪࠌࠌࡪࡴࡸࠠ࡮ࡱࡧࡹࠥ࡯࡮ࠡ࡫ࡰࡴࡴࡸࡴࡠ࡮࡬ࡷࡹࡀࠊࠊࠋࡧࡩࡱ࠮ࡳࡺࡵ࠱ࡱࡴࡪࡵ࡭ࡧࡶ࡟ࡲࡵࡤࡶ࡟ࠬࠎࠎࡧࡦࡵࡧࡵࡣࡩ࡫࡬ࡦࡶࡨࠤࡂࠦࡳࡺࡵ࠱ࡱࡴࡪࡵ࡭ࡧࡶ࠲ࡰ࡫ࡹࡴࠪࠬࠎࠎࡺ࠲ࠡ࠿ࠣࡸ࡮ࡳࡥ࠯ࡶ࡬ࡱࡪ࠮ࠩࠋࠋࡨࡰࡵࡧࡳࡦࡦࠣࡁࠥࡺ࠲࠮ࡶ࠴ࠎࠎࡺ࡯ࡵࡣ࡯ࡩࡱࡶࡡࡴࡧࡧࠤ࠰ࡃࠠࡦ࡮ࡳࡥࡸ࡫ࡤࠋࡤࡨࡪࡴࡸࡥࡠ࡫ࡰࡴࡴࡸࡴࡠࡥࡲࡹࡳࡺࠠ࠾ࠢ࡯ࡩࡳ࠮ࡢࡦࡨࡲࡶࡪࡥࡩ࡮ࡲࡲࡶࡹ࠯ࠊࡢࡨࡷࡩࡷࡥࡩ࡮ࡲࡲࡶࡹࡥࡣࡰࡷࡱࡸࠥࡃࠠ࡭ࡧࡱࠬࡦ࡬ࡴࡦࡴࡢ࡭ࡲࡶ࡯ࡳࡶࠬࠎ࡮ࡳࡰࡰࡴࡷࡣࡨࡵࡵ࡯ࡶࠣࡁࠥࡲࡥ࡯ࠪ࡬ࡱࡵࡵࡲࡵࡡ࡯࡭ࡸࡺࠩࠋࡣࡩࡸࡪࡸ࡟ࡥࡧ࡯ࡩࡹ࡫࡟ࡤࡱࡸࡲࡹࠦ࠽ࠡ࡮ࡨࡲ࠭ࡧࡦࡵࡧࡵࡣࡩ࡫࡬ࡦࡶࡨ࠭ࠏࠩࡰࡳ࡫ࡱࡸ࠭࠭ࡩ࡮ࡲࡲࡶࡹࡥࡣࡰࡷࡱࡸ࠿ࠦࠧࠬࡵࡷࡶ࠭࡯࡭ࡱࡱࡵࡸࡤࡩ࡯ࡶࡰࡷ࠭࠮ࠐࠣࡱࡴ࡬ࡲࡹ࠮ࠧࡢࡸࡨࡶࡦ࡭ࡥࠡࡶ࡬ࡱࡪࠦ࡭ࡴ࠼ࠣࠫ࠰ࡹࡴࡳࠪࡷࡳࡹࡧ࡬ࡦ࡮ࡳࡥࡸ࡫ࡤࠫ࠳࠳࠴࠵࠵࠲࠱ࠫࠬࠎ࡮ࡳࡰࡰࡴࡷࠤࡽࡨ࡭ࡤࡩࡸ࡭ࠏࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࡱࡹࡲࡨࡥࡳࠢࡲࡪࠥࡳ࡯ࡥࡷ࡯ࡩࡸࠦࡩ࡮ࡲࡲࡶࡹ࡫ࡤ࠻ࠢࠪ࠯ࡸࡺࡲࠩ࡫ࡰࡴࡴࡸࡴࡠࡥࡲࡹࡳࡺࠩ࠭ࠩࡤࡺࡪࡸࡡࡨࡧࠣࡸ࡮ࡳࡥࠡ࡯ࡶ࠾ࠥ࠭ࠫࡴࡶࡵࠬࡹࡵࡴࡢ࡮ࡨࡰࡵࡧࡳࡦࡦ࠭࠵࠵࠶࠰࠰࠴࠳࠭࠮ࠐࡅ࡙ࡋࡗࡣࡺࡹࡩ࡯ࡩࡢࡉࡗࡘࡏࡓࠌࠥࠦࠧ₹")
# to check if main-module will import what sub-modules
# l11ll1l1l11_ll_: l11l1llllll_ll_ l111lll_ll_ (u"ࠨࡲࡦࡳࡸࡩࡸࡺࡳࠣ₺") will also import l111lll_ll_ (u"ࠢࡶࡴ࡯ࡰ࡮ࡨࠢ₻"),l111lll_ll_ (u"ࠣࡷࡵࡰࡱ࡯ࡢ࠳ࠤ₼") and l111lll_ll_ (u"ࠤࡸࡶࡱࡲࡩࡣ࠵ࠥ₽")
l111lll_ll_ (u"ࠥࠦࠧࠐࡩ࡮ࡲࡲࡶࡹࠦࡳࡺࡵࠍࡦࡪ࡬࡯ࡳࡧࡢ࡭ࡲࡶ࡯ࡳࡶࠣࡁࠥࡹࡹࡴ࠰ࡰࡳࡩࡻ࡬ࡦࡵ࠱࡯ࡪࡿࡳࠩࠫࠍ࡭ࡲࡶ࡯ࡳࡶࠣࡹࡷࡲࡲࡦࡵࡲࡰࡻ࡫ࡲࠋࡣࡩࡸࡪࡸ࡟ࡪ࡯ࡳࡳࡷࡺࠠ࠾ࠢࡶࡽࡸ࠴࡭ࡰࡦࡸࡰࡪࡹ࠮࡬ࡧࡼࡷ࠭࠯ࠊࡪ࡯ࡳࡳࡷࡺ࡟࡭࡫ࡶࡸࠥࡃࠠ࡭࡫ࡶࡸ࠭ࡹࡥࡵࠪࡤࡪࡹ࡫ࡲࡠ࡫ࡰࡴࡴࡸࡴࠪ࠯ࡶࡩࡹ࠮ࡢࡦࡨࡲࡶࡪࡥࡩ࡮ࡲࡲࡶࡹ࠯ࠩࠋ࡮࡬ࡷࡹࠦ࠽ࠡࠩࠪࠎ࡮࡬ࠠࠨࡷࡵࡰࡱ࡯ࡢࠨࠢ࡬ࡲࠥࡧࡦࡵࡧࡵࡣ࡮ࡳࡰࡰࡴࡷ࠾ࠥࡲࡩࡴࡶࠣ࠯ࡂࠦࠧࡶࡴ࡯ࡰ࡮ࡨࠠࠨࠌ࡬ࡪࠥ࠭ࡵࡳ࡮࡯࡭ࡧ࠸ࠧࠡ࡫ࡱࠤࡦ࡬ࡴࡦࡴࡢ࡭ࡲࡶ࡯ࡳࡶ࠽ࠤࡱ࡯ࡳࡵࠢ࠮ࡁࠥ࠭ࡵࡳ࡮࡯࡭ࡧ࠸ࠠࠨࠌ࡬ࡪࠥ࠭ࡵࡳ࡮࡯࡭ࡧ࠹ࠧࠡ࡫ࡱࠤࡦ࡬ࡴࡦࡴࡢ࡭ࡲࡶ࡯ࡳࡶ࠽ࠤࡱ࡯ࡳࡵࠢ࠮ࡁࠥ࠭ࡵࡳ࡮࡯࡭ࡧ࠹ࠠࠨࠌ࡬ࡪࠥ࠭ࡲࡦࡳࡸࡩࡸࡺࡳࠨࠢ࡬ࡲࠥࡧࡦࡵࡧࡵࡣ࡮ࡳࡰࡰࡴࡷ࠾ࠥࡲࡩࡴࡶࠣ࠯ࡂࠦࠧࡳࡧࡴࡹࡪࡹࡴࡴࠢࠪࠎ࡮ࡳࡰࡰࡴࡷࠤࡽࡨ࡭ࡤࡩࡸ࡭ࠏࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࡼࡩࡸࠦࡥࡹ࡫ࡶࡸࡸࡀࠠࠨ࠮࡯࡭ࡸࡺࠩࠋࠤࠥࠦ₾")
l1ll_ll_ = l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝ࠬ₿")
l1l1l11l1ll_ll_ = int(sys.argv[1])
l1ll11lll11_ll_ = sys.argv[0].split(l111lll_ll_ (u"ࠬ࠵ࠧ⃀"))[2]	# l1l1llll11_ll_.video.l11l1l11lll_ll_
l11ll11l111_ll_ = l1ll11lll11_ll_.split(l111lll_ll_ (u"࠭࠮ࠨ⃁"))[2]		# l11l1l11lll_ll_
l11ll11ll11_ll_ = sys.argv[2]				# ?mode=12&url=http://test.l1lll1l11_ll_
#l1l1lll1lll_ll_ = sys.argv[0]+l11ll11ll11_ll_		# l1l1llll11_ll_://l1l1llll11_ll_.video.l11l1l11lll_ll_/?mode=12&url=http://test.l1lll1l11_ll_
#l11ll11ll11_ll_ = xbmc.getInfoLabel( l111lll_ll_ (u"ࠢࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡉࡳࡱࡪࡥࡳࡒࡤࡸ࡭ࠨ⃂") )
l11l1lll11l_ll_ = xbmc.getInfoLabel( l111lll_ll_ (u"ࠣࡕࡼࡷࡹ࡫࡭࠯ࡃࡧࡨࡴࡴࡖࡦࡴࡶ࡭ࡴࡴࠨࠣ⃃")+l1ll11lll11_ll_+l111lll_ll_ (u"ࠤࠬࠦ⃄") )
#l11l1lll11l_ll_ = l111lll_ll_ (u"ࠪ࠼࠳࠷࠮࠵ࠩ⃅")
settings = xbmcaddon.Addon(id=l1ll11lll11_ll_)
l11l1l1_ll_ = l1111_ll_(l11ll11ll11_ll_).replace(l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ⃆"),l111lll_ll_ (u"ࠬ࠭⃇")).replace(l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ⃈"),l111lll_ll_ (u"ࠧࠨ⃉")).strip(l111lll_ll_ (u"ࠨࠢࠪ⃊"))
l1l1l_ll_ = xbmc.getInfoLabel(l111lll_ll_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ⃋")).replace(l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭⃌"),l111lll_ll_ (u"ࠫࠬ⃍")).replace(l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⃎"),l111lll_ll_ (u"࠭ࠧ⃏")).strip(l111lll_ll_ (u"ࠧࠡࠩ⃐"))
if l1l1l_ll_==l111lll_ll_ (u"ࠨࠩ⃑"): l1l1l_ll_ = l111lll_ll_ (u"ࠩࡐࡥ࡮ࡴࠠࡎࡧࡱࡹ⃒ࠬ")
l11ll11lll1_ll_ = xbmc.getInfoLabel(l111lll_ll_ (u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡆࡺ࡯࡬ࡥࡘࡨࡶࡸ࡯࡯࡯ࠤ⃓"))
l1ll1l111l1_ll_ = re.findall(l111lll_ll_ (u"ࠫࡣ࠮࠮ࠫࡁࠬ࡟ࠥ࠳࡝ࠨ⃔"),l11ll11lll1_ll_+l111lll_ll_ (u"ࠬࠦࠧ⃕"),re.DOTALL)
l1ll1l111l1_ll_ = float(l1ll1l111l1_ll_[0])
l1ll111l111_ll_ = xbmc.translatePath(l111lll_ll_ (u"࠭ࡳࡱࡧࡦ࡭ࡦࡲ࠺࠰࠱࡯ࡳ࡬ࡶࡡࡵࡪࠪ⃖"))
l1ll11l11ll_ll_ = os.path.join(l1ll111l111_ll_,l111lll_ll_ (u"ࠧ࡬ࡱࡧ࡭࠳ࡲ࡯ࡨࠩ⃗"))
l11l1l111l1_ll_ = os.path.join(l1ll111l111_ll_,l111lll_ll_ (u"ࠨ࡭ࡲࡨ࡮࠴࡯࡭ࡦ࠱ࡰࡴ࡭⃘ࠧ"))
l11ll1l1111_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡟ࡨ࠰ࡢ࠮࡝ࡦ࠮⃙ࠫ"),l11l1lll11l_ll_,re.DOTALL)[0]
#if l11ll1l1111_ll_==l111lll_ll_ (u"ࠪ࠼࠳࠶⃚ࠧ"): l11ll1l1111_ll_ = l111lll_ll_ (u"ࠫ࠽࠴࠰࠯࠲ࠪ⃛")
l1lll11ll1_ll_ = os.path.join(xbmc.translatePath(l111lll_ll_ (u"ࠬࡹࡰࡦࡥ࡬ࡥࡱࡀ࠯࠰ࡶࡨࡱࡵ࠭⃜")),l1ll11lll11_ll_)
l11ll11ll1l_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠨࡶࡦࡴࡶ࡭ࡴࡴ࡟ࠣ⃝")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠢ࠯ࡶࡰࡴࠧ⃞"))
l1l1lll11l1_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠣࡹࡨࡦࡨࡧࡣࡩࡧࡢࠦ⃟")+l11ll1l1111_ll_+l111lll_ll_ (u"ࠤ࠱ࡨࡧࠨ⃠"))
l1l11l11lll_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠥࡰࡦࡹࡴࡷ࡫ࡧࡩࡴࡹ࠮࡭ࡵࡷࠦ⃡"))
l11llll1ll1_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠦࡱࡧࡳࡵ࡯ࡨࡲࡺ࠴࡬ࡴࡶࠥ⃢"))
l11llll1l1_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠧ࡬ࡡࡷࡱࡸࡶ࡮ࡺࡥࡴ࠰࡯ࡷࡹࠨ⃣"))
l1llllll1ll_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠨࡤࡶ࡯ࡰࡽ࠳࡯ࡰࡵࡸࠥ⃤"))
l1111l111l_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠢࡧࡷ࡯ࡰ࡮ࡶࡴࡷࡨ࡬ࡰࡪ࠴࡭࠴ࡷ⃥ࠥ"))
l11l1l1llll_ll_ = os.path.join(l1lll11ll1_ll_,l111lll_ll_ (u"ࠣ࡯ࡨࡷࡸࡧࡧࡦࡵ࠱ࡰࡸࡺ⃦ࠢ"))
l1l1l1111l1_ll_ = xbmcaddon.Addon().getAddonInfo(l111lll_ll_ (u"ࠩࡳࡥࡹ࡮ࠧ⃧"))    #.decode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠭࠹⃨ࠩ"))
l1ll1l11lll_ll_ = os.path.join(l1l1l1111l1_ll_,l111lll_ll_ (u"ࠫ࡮ࡩ࡯࡯࠰ࡳࡲ࡬࠭⃩"))
l11l1l1l1ll_ll_ = os.path.join(l1l1l1111l1_ll_,l111lll_ll_ (u"ࠬࡺࡨࡶ࡯ࡥ࠲ࡵࡴࡧࠨ⃪"))
l1lll111111_ll_ = os.path.join(l1l1l1111l1_ll_,l111lll_ll_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠴ࡪࡱࡩ⃫ࠪ"))
l11ll1l1lll_ll_ = os.path.join(l1l1l1111l1_ll_,l111lll_ll_ (u"ࠧࡤࡪࡤࡲ࡬࡫࡬ࡰࡩ࠱ࡸࡽࡺ⃬ࠧ"))
l1ll11ll1l1_ll_ = os.path.join(l1l1l1111l1_ll_,l111lll_ll_ (u"ࠨࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹ⃭ࠧ"),l111lll_ll_ (u"ࠩࡸࡷࡪࡸࡡࡨࡧࡱࡸࡸ࠴ࡴࡹࡶ⃮ࠪ"))
l1l1l1l1l11_ll_ = xbmc.translatePath(l111lll_ll_ (u"ࠪࡷࡵ࡫ࡣࡪࡣ࡯࠾࠴࠵ࡨࡰ࡯ࡨ⃯ࠫ"))
l11ll1l111l_ll_ = os.path.join(l1l1l1l1l11_ll_,l111lll_ll_ (u"ࠫࡦࡪࡤࡰࡰࡶࠫ⃰"))
l11ll11111l_ll_ = os.path.join(l1l1l1l1l11_ll_,l111lll_ll_ (u"ࠬࡻࡳࡦࡴࡧࡥࡹࡧࠧ⃱"),l111lll_ll_ (u"࠭ࡡࡥࡦࡲࡲࡤࡪࡡࡵࡣࠪ⃲"),l1ll11lll11_ll_,l111lll_ll_ (u"ࠧࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡻࡱࡱ࠭⃳"))
l1ll11l111l_ll_ = 60
l11111ll11_ll_ = 60*l1ll11l111l_ll_
l11l1l1l11l_ll_ = 24*l11111ll11_ll_
l1ll1111ll1_ll_ = 30*l11l1l1l11l_ll_
l1l11lll_ll_ = 0
l1l1l11ll1l_ll_ = 30*l1ll11l111l_ll_
l11111l1_ll_ = 2*l11111ll11_ll_
l111l11_ll_ = 16*l11111ll11_ll_
l11l1l_ll_ = l11l1l1l11l_ll_*3
l11ll11l1ll_ll_ = l11l1l1l11l_ll_*30
l11l111l11_ll_ = l1ll1111ll1_ll_*12
l11l1lll111_ll_ = l11111ll11_ll_
now = int(time.time())
l11ll1111ll_ll_ = [l111lll_ll_ (u"ࠨ࠺࠱࠼࠳࠾࠮࠹ࠩ⃴"),l111lll_ll_ (u"ࠩ࠴࠲࠶࠴࠱࠯࠳ࠪ⃵"),l111lll_ll_ (u"ࠪ࠵࠳࠶࠮࠱࠰࠴ࠫ⃶"),l111lll_ll_ (u"ࠫ࠽࠴࠸࠯࠶࠱࠸ࠬ⃷"),l111lll_ll_ (u"ࠬ࠸࠰࠹࠰࠹࠻࠳࠸࠲࠳࠰࠵࠶࠷࠭⃸"),l111lll_ll_ (u"࠭࠲࠱࠺࠱࠺࠼࠴࠲࠳࠲࠱࠶࠷࠶ࠧ⃹")]
l11l11l_ll_ = { l111lll_ll_ (u"ࠧࡂࡍࡒࡅࡒ࠭⃺")		:[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤ࡯ࡴࡧ࡭࠯ࡰࡨࡸࠬ⃻")]
			,l111lll_ll_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐࠫ⃼")		:[l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡱ࡯ࡢ࡯࠱ࡧࡦࡳࠧ⃽")]
			,l111lll_ll_ (u"ࠫࡆࡒࡁࡓࡃࡅࠫ⃾")		:[l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡰࡦ࠱ࡥࡱࡧࡲࡢࡤ࠱ࡧࡴࡳࠧ⃿")]
			,l111lll_ll_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉࠨ℀")		:[l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡢ࡮ࡩࡥࡹ࡯࡭ࡪ࠰ࡷࡺࠬ℁")]
			,l111lll_ll_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆࠪℂ")		:[l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡧࡢࡴࡧࡨࡨ࠳ࡴࡥࡵࠩ℃")]
			,l111lll_ll_ (u"ࠪࡅࡑࡑࡁࡘࡖࡋࡅࡗ࠭℄")	:[l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡤࡰࡰࡧࡷࡵࡪࡤࡶࡹࡼ࠮ࡤࡱࡰࠫ℅")]
			,l111lll_ll_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌࠧ℆")		:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡥࡱࡳࡡࡢࡴࡨࡪࡹࡼ࠮ࡤࡱࡰ࠳ࡴࡲࡤࠨℇ"),l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲ࡦࡲ࡭ࡢࡣࡵࡩ࡫ࡺࡶ࠯ࡥࡲࡱࠬ℈")]
			,l111lll_ll_ (u"ࠨࡄࡒࡏࡗࡇࠧ℉")		:[l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡶ࡬ࡴࡵࡦࡷࡱࡧ࠲ࡨࡵ࡭ࠨℊ")]	#,l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡡࡩ࡫ࡧࡰ࡮ࡼࡥ࠯ࡥࡲࠫℋ")]
			,l111lll_ll_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏࠩℌ")	:[l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮࠯ࡥࡲࡱࠬℍ"),l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡨࡴࡤࡴ࡭ࡷ࡬࠯ࡣࡳ࡭࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳࠧℎ")]
			,l111lll_ll_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪℏ")	:[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶ࡬ࡴࡽ࠮ࡢ࡮ࡩࡥ࡯࡫ࡲࡵࡸ࠱ࡧࡴࡳࠧℐ")] # l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡪࡦࡰࡥࡳ࠰ࡶ࡬ࡴࡽࠧℑ")
			,l111lll_ll_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪℒ")		:[l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡰࡳࡻࡹ࠴ࡶ࠰ࡺࡷࠬℓ")] # .l1l1l111111_ll_  .life  .tv  .l1lll1l11_ll_
			,l111lll_ll_ (u"ࠬࡏࡆࡊࡎࡐࠫ℔")		:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡡࡳ࠰࡬ࡪ࡮ࡲ࡭ࡵࡸ࠱ࡧࡴࡳࠧℕ"),l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦࡰ࠱࡭࡫࡯࡬࡮ࡶࡹ࠲ࡨࡵ࡭ࠨ№"),l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡨࡤ࠲࡮࡬ࡩ࡭࡯ࡷࡺ࠳ࡩ࡯࡮ࠩ℗"),l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡩࡥ࠷࠴ࡩࡧ࡫࡯ࡱࡹࡼ࠮ࡤࡱࡰࠫ℘")]
			,l111lll_ll_ (u"ࠪࡔࡆࡔࡅࡕࠩℙ")		:[l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡲࡤࡲࡪࡺ࠮ࡤࡱ࠱࡭ࡱ࠭ℚ")]
			,l111lll_ll_ (u"࡙ࠬࡈࡂࡊࡌࡈ࠹࡛ࠧℛ")		:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡴࡪࡤ࡬࡮ࡪ࠴ࡶ࠰ࡦࡳࡲ࠭ℜ"),l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡵ࡫ࡥ࡭࡯ࡤ࠵ࡷ࠱ࡳࡳࡲࠧℝ")]
			,l111lll_ll_ (u"ࠨࡕࡋࡓࡔࡌࡍࡂ࡚ࠪ℞")		:[l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷ࡭ࡵ࡯ࡧ࡯ࡤࡼ࠳ࡩ࡯࡮ࠩ℟"),l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸࡺࡡࡵ࡫ࡦ࠲ࡸ࡮࡯ࡰࡨࡰࡥࡽ࠴ࡣࡰ࡯ࠪ℠")]
			,l111lll_ll_ (u"ࠫ࡞ࡕࡕࡕࡗࡅࡉࠬ℡")		:[l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭ࠨ™")]
			,l111lll_ll_ (u"࠭ࡐ࡚ࡖࡋࡓࡓ࠭℣")		:[l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰࡮࡬ࡷࡹࡶ࡬ࡢࡻࠪℤ"),l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡧࡰࡥࡩࡳࡡࡩࡦ࡬࠲ࡵࡿࡴࡩࡱࡱࡥࡳࡿࡷࡩࡧࡵࡩ࠳ࡩ࡯࡮࠱ࡸࡷࡦ࡭ࡥࡳࡧࡳࡳࡷࡺࠧ℥"),l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡨࡱࡦࡪ࡭ࡢࡪࡧ࡭࠳ࡶࡹࡵࡪࡲࡲࡦࡴࡹࡸࡪࡨࡶࡪ࠴ࡣࡰ࡯࠲ࡷࡪࡴࡤࡦ࡯ࡤ࡭ࡱ࠭Ω"),l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡩࡲࡧࡤ࡮ࡣ࡫ࡨ࡮࠴ࡰࡺࡶ࡫ࡳࡳࡧ࡮ࡺࡹ࡫ࡩࡷ࡫࠮ࡤࡱࡰ࠳࡬࡫ࡴ࡮ࡧࡶࡷࡦ࡭ࡥࡴࠩ℧"),l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡳࡡࡥ࡯ࡤ࡬ࡩ࡯࠮ࡱࡻࡷ࡬ࡴࡴࡡ࡯ࡻࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱ࠴࡭ࡥࡵ࡫ࡶࡰࡦࡳࡩࡤࠩℨ")]
			,l111lll_ll_ (u"ࠬࡏࡐࡕࡘࠪ℩")			:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡯ࡱࡺ࡬ࡪࡸࡥ࠯ࡥࡲࡱࠬK")]
			,l111lll_ll_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗࠨÅ")		:[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡦ࡭ࡲࡧ࠭࡯ࡱࡺ࠲ࡨࡵ࡭ࠨℬ")]
			,l111lll_ll_ (u"ࠩࡖࡌࡎࡇࡖࡐࡋࡆࡉࠬℭ")	:[l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡸ࡮ࡩࡢࡸࡲ࡭ࡨ࡫࠮ࡤࡱࡰࠫ℮")]
			,l111lll_ll_ (u"ࠫࡐࡇࡒࡃࡃࡏࡅ࡙࡜ࠧℯ")	:[l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡫ࡢࡴࡥࡥࡱࡧ࠭ࡵࡸ࠱ࡲࡪࡺࠧℰ")]
			,l111lll_ll_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠭ℱ")		:[l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰࡯ࡼࡧ࡮ࡳࡡ࠯ࡥࡲࠫℲ")]
			,l111lll_ll_ (u"ࠨࡃࡎ࡛ࡆࡓࠧℳ")		:[l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡰࡽࡡ࡮࠰ࡱࡩࡹ࠭ℴ")]
			,l111lll_ll_ (u"ࠪࡉࡌ࡟ࡂࡆࡕࡗࠫℵ")		:[l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࡭ࡹࡣࡧࡶࡸ࠳ࡴࡥࡵࠩℶ")] #  l1ll1l1l11_ll_.org  l11l11l11l1_ll_.l1l1ll11ll1_ll_  l1ll1l1l11_ll_.l11l1l11111_ll_  l1ll1l1l11_ll_.me
			#,l111lll_ll_ (u"ࠬࡎࡅࡍࡃࡏࠫℷ")		:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࠵ࡪࡨࡰࡦࡲ࠮࡮ࡧࠪℸ")] # l1ll1l1l_ll_://4helal.tv l1ll1l1l_ll_://4helal.cc
			#,l111lll_ll_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛ࠩℹ")		:[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡤࡶࡧࡲࡩࡰࡰࡽ࠲ࡳ࡫ࡴࠨ℺")] # l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡩ࡯࡮ࠩ℻"),l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡢ࡭࡫ࡲࡲࡿ࠴ࡡࡳࡶࠪℼ"),l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡼࡽࡷ࠯ࡣࡵࡦࡱ࡯࡯࡯ࡼ࠱ࡳࡷ࡭ࠧℽ")]
			#,l111lll_ll_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩℾ")	:[l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡦࡩࡼࡦࡪࡹࡴ࠯ࡸ࡬ࡴࠬℿ")]
			#,l111lll_ll_ (u"ࠧࡆࡉ࡜࠸ࡇࡋࡓࡕࠩ⅀")	:[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡨ࡫ࡾࡨࡥࡴࡶ࠱ࡺ࡮ࡶࠧ⅁")]
			#,l111lll_ll_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄࠫ⅂")	:[l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡼࡽࡷ࠯ࡪࡤࡰࡦࡩࡩ࡮ࡣ࠱ࡧࡴ࠭⅃")]
			#,l111lll_ll_ (u"ࠫࡒࡕࡖࡊ࡜ࡏࡅࡓࡊࠧ⅄")	:[l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࡲࡲࡱ࡯࡮ࡦࠩⅅ"),l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯࡮࠰ࡰࡳࡻ࡯ࡺ࡭ࡣࡱࡨ࠳ࡵ࡮࡭࡫ࡱࡩࠬⅆ")]
			#,l111lll_ll_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭ⅇ"):[l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡶࡩࡷ࡯ࡥࡴ࠶ࡺࡥࡹࡩࡨ࠯ࡰࡨࡸࠬⅈ")]
			}
def l111l1l_ll_():
	if l1ll1l111l1_ll_>=19:
		l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬⅉ"),l111lll_ll_ (u"ࠪฬึ์วๆฮࠣ฽๊อฯࠡๆ็ๅ๏ี๊้้สฮࠥอไฺำห๎ฮࠦไศࠢํ฽๊๊ࠠๆ฻ࠣ็ํี๊ࠡ࠳࠼ࠤ࠳ࠦโๆࠢหุ้ำࠠไ๊า๎ࠥ࠷࠹ࠡสส่่อๅๅࠢฮ้ࠥอูะࠢอฯอ๐สࠡๅ๋ำ๏่ࠦศๆหี๋อๅอ๋ࠢห้าไะࠢหหุะฮะษ่ࠤ์ึวࠡษ็ีฬฮืࠡ࡞ࡱ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡌࡆࡇࡈ࠳࠴ࡢ࡮ࡴࡵࡲ࠽࠳࠴ࡺࡩ࡯ࡻ࠱ࡧࡨ࠵࡫ࡰࡦ࡬ࡩࡲࡧࡤ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⅊"))
		l1ll1l_ll_(l111lll_ll_ (u"ࠫࡒ࡫ࡳࡴࡣࡪࡩࠥ࡬ࡲࡰ࡯ࠣࡉࡲࡧࡤࠨ⅋"),l111lll_ll_ (u"ࠬࡋࡍࡂࡆࠣࠦࡆࡸࡡࡣ࡫ࡦࠤ࡛࡯ࡤࡦࡱࡶࠦࠥ࡯ࡳࠡࡰࡲࡸࠥࡩ࡯࡮ࡲࡤࡸ࡮ࡨ࡬ࡦࠢࡺ࡭ࡹ࡮ࠠࡌࡱࡧ࡭ࠥ࠷࠹ࠡ࠰ࠣࡈࡪࡲࡥࡵࡧࠣࡥࡱࡲࠠ࡬ࡱࡧ࡭ࠥ࠷࠹ࠡࡣࡱࡨࠥ࡯࡮ࡴࡶࡤࡰࡱࠦࠢࡌࡱࡧ࡭ࡊࡳࡡࡥࠤࠣࡥࡵࡶࠠࡧࡴࡲࡱࠥࡺࡨࡪࡵࠣࠤࡺࡸ࡬ࠡࠪ࡬ࡸࠥࡩ࡯࡯ࡶࡤ࡭ࡳࡹࠠ࡬ࡱࡧ࡭ࠥ࠷࠸࠯࠻࠯ࠤࡸࡱࡩ࡯࠮ࠣࡥࡳࡪࠠࡢࡴࡤࡦ࡮ࡩࠠࡷ࡫ࡧࡩࡴࡹࠠࡱࡴࡲ࡫ࡷࡧ࡭ࠪ࠼࡟ࡲࡠࡉࡏࡍࡑࡕࠤࡋࡌࡆࡇࡈࡉ࠴࠵ࡣࡨࡵࡶࡳ࠾࠴࠵ࡴࡪࡰࡼ࠲ࡨࡩ࠯࡬ࡱࡧ࡭ࡪࡳࡡࡥ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⅌"))
		return
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡍࡂࡋࡑࠫ⅍"),l111lll_ll_ (u"ࠧࡎࡃࡌࡒࠬⅎ"))
	l1ll_ll_ = l111lll_ll_ (u"ࠨࡏࡄࡍࡓ࠭⅏")
	type,name,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,context = l11lllllll_ll_()
	#l1ll1l_ll_(context,l111lll_ll_ (u"ࠩࠪ⅐"))
	l11l1ll1ll1_ll_ = int(mode)
	l1l11lll11l_ll_ = int(l11l1ll1ll1_ll_%10)
	l1l111lll11_ll_ = int(l11l1ll1ll1_ll_/10)
	#message += l111lll_ll_ (u"ࠪࡠࡳ࠭⅑")+l111lll_ll_ (u"ࠫࡑࡧࡢࡦ࡮࠽࡟ࠬ⅒")+l1l1l_ll_+l111lll_ll_ (u"ࠬࡣࠠࠡࠢࡓࡥࡹ࡮࠺࡜ࠩ⅓")+l11l1l1_ll_+l111lll_ll_ (u"࠭࡝ࠨ⅔")
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧ࡜ࠩ⅕")+l11l1l1_ll_+l111lll_ll_ (u"ࠨ࡟ࠪ⅖"),l111lll_ll_ (u"ࠩ࡞ࠫ⅗")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠪࡡࠬ⅘"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡠ࠭⅙")+l1l1l_ll_+l111lll_ll_ (u"ࠬࡣࠧ⅚"),l111lll_ll_ (u"࡛࠭ࠨ⅛")+l11l1l1_ll_+l111lll_ll_ (u"ࠧ࡞ࠩ⅜"))
	if l11l1ll1ll1_ll_==260: message = l111lll_ll_ (u"ࠨࠢࠣࠤ࡛࡫ࡲࡴ࡫ࡲࡲ࠿࡛ࠦࠡࠩ⅝")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡌࡱࡧ࡭࠿࡛ࠦࠡࠩ⅞")+l11ll11lll1_ll_+l111lll_ll_ (u"ࠪࠤࡢ࠭⅟")
	else:
		l1l1lll1111_ll_ = l1l1l_ll_.replace(l111lll_ll_ (u"ࠫࠥࠦࠠࠨⅠ"),l111lll_ll_ (u"ࠬࠦࠠࠨⅡ")).replace(l111lll_ll_ (u"࠭ࠠࠡࠢࠪⅢ"),l111lll_ll_ (u"ࠧࠡࠢࠪⅣ")).replace(l111lll_ll_ (u"ࠨࠢࠣࠤࠬⅤ"),l111lll_ll_ (u"ࠩࠣࠤࠬⅥ"))
		l1ll11l1lll_ll_ = l11l1l1_ll_.replace(l111lll_ll_ (u"ࠪࠤࠥࠦࠧⅦ"),l111lll_ll_ (u"ࠫࠥࠦࠧⅧ")).replace(l111lll_ll_ (u"ࠬࠦࠠࠡࠩⅨ"),l111lll_ll_ (u"࠭ࠠࠡࠩⅩ")).replace(l111lll_ll_ (u"ࠧࠡࠢࠣࠫⅪ"),l111lll_ll_ (u"ࠨࠢࠣࠫⅫ"))
		message = l111lll_ll_ (u"ࠩࠣࠤࠥࡒࡡࡣࡧ࡯࠾ࠥࡡࠠࠨⅬ")+l1l1lll1111_ll_+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡏࡲࡨࡪࡀࠠ࡜ࠢࠪⅭ")+mode+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡓࡥࡹ࡮࠺ࠡ࡝ࠣࠫⅮ")+l1ll11l1lll_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠨⅯ")
	l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ⅰ"),l111111l_ll_(l1ll_ll_)+message)
	l1l1l1l111l_ll_ = (not os.path.exists(l11ll11ll1l_ll_))
	if l1l1l1l111l_ll_:
		if not os.path.exists(l1lll11ll1_ll_): os.makedirs(l1lll11ll1_ll_)
		#l11111llll_ll_([l1l1lll11l1_ll_])
		with open(l11ll11ll1l_ll_,l111lll_ll_ (u"ࠧࡸࠩⅱ")) as f: f.write(l111lll_ll_ (u"ࠨࠩⅲ"))
		if os.path.exists(l1l1lll11l1_ll_):
			l1ll11l_ll_(l111lll_ll_ (u"ࠩอ้ࠥะอะ์ฮࠤอืๆศ็ฯࠤ฾๋วะࠩⅳ"),l111lll_ll_ (u"ࠪษ้๏ࠠศๆศูิอัࠡำๅ้ࠥ࠭ⅴ")+l11l1lll11l_ll_)
			l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫⅵ"),l111lll_ll_ (u"ࠬ࠴ࠠࠡࠢࡄࡶࡦࡨࡩࡤࡘ࡬ࡨࡪࡵࡳ࠻ࠢࠣࡊ࡮ࡲࡥࡴࠢࡸࡴࡩࡧࡴࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࠣࠤࡕࡧࡴࡩ࠼ࠣ࡟ࠥ࠭ⅶ")+l11ll11ll11_ll_+l111lll_ll_ (u"࠭ࠠ࡞ࠩⅷ"))
		else:
			l11111llll_ll_([l11ll11ll1l_ll_])
			l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧⅸ"),l111lll_ll_ (u"ࠨ࠰ࠣࠤࠥࡇࡲࡢࡤ࡬ࡧ࡛࡯ࡤࡦࡱࡶ࠾ࠥࠦࡆࡶ࡮࡯ࡽࠥࡻࡰࡥࡣࡷࡩࡩ࠲ࠠࡏࡧࡺࡰࡾࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥ࠮ࠣࡳࡷࠦࡃࡢࡥ࡫ࡩࠥࡪࡥ࡭ࡧࡷࡩࡩࠦࠠࠡࡒࡤࡸ࡭ࡀࠠ࡜ࠢࠪⅹ")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠩࠣࡡࠬⅺ"))
			import sqlite3
			conn = sqlite3.connect(l1l1lll11l1_ll_)
			l111lll_ll_ (u"ࠥࠦࠧࠐࠉࠊࠋࡦࡳࡳࡴ࠮ࡤࡷࡵࡷࡴࡸࠨࠪ࠰ࡨࡼࡪࡩࡵࡵࡧࠫࠫࡕࡘࡁࡈࡏࡄࠤࡸࡿ࡮ࡤࡪࡵࡳࡳࡵࡵࡴࠢࡀࠤࡔࡌࡆࠨࠫࠍࠍࠎࠏࡣࡰࡰࡱ࠲ࡨࡻࡲࡴࡱࡵࠬ࠮࠴ࡥࡹࡧࡦࡹࡹ࡫ࠨࠨࡒࡕࡅࡌࡓࡁࠡ࡬ࡲࡹࡷࡴࡡ࡭ࡡࡰࡳࡩ࡫ࠠ࠾ࠢࡒࡊࡋ࠭ࠩࠋࠋࠌࠍࡨࡵ࡮࡯࠰ࡦࡹࡷࡹ࡯ࡳࠪࠬ࠲ࡪࡾࡥࡤࡷࡷࡩ࠭࠭ࡐࡓࡃࡊࡑࡆࠦࡴࡦ࡯ࡳࡣࡸࡺ࡯ࡳࡧࠣࡁࠥࡓࡅࡎࡑࡕ࡝ࠬ࠯ࠊࠊࠋࠌࡧࡴࡴ࡮࠯ࡥࡸࡶࡸࡵࡲࠩࠫ࠱ࡩࡽ࡫ࡣࡶࡶࡨࠬࠬࡖࡒࡂࡉࡐࡅࠥࡩࡡࡤࡪࡨࡣࡸ࡯ࡺࡦࠢࡀࠤ࠲࠷࠰࠱࠲࠳࠴ࠬ࠯ࠊࠊࠋࠌࠦࠧࠨⅻ")
			conn.close()
			import l1l111ll111_ll_
			l1l111ll111_ll_.l1lll11ll1l_ll_()
			l1ll1l_ll_(l111lll_ll_ (u"ࠫอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧⅼ"),l111lll_ll_ (u"ࠬะๅࠡฬฮฬ๏ะࠠฤ๊ࠣฮาี๊ฬࠢส่ส฻ฯศำࠣห้าฯ๋ั่ࠣอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠠ࠯ࠢฦ์ࠥะๅࠡ็ึั้ࠥวีࠢส่อืๆศ็ฯࠤ࠳ࠦวๅฤ้ࠤุ๐โ้็ࠣห้ฮั็ษ่ะࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪⅽ"))
			l11llllllll_ll_(False)
			l1ll11llll1_ll_(False)
			l1l111ll111_ll_.l1l111lll1l_ll_(False)
			l1l111ll111_ll_.l11l1l1l1l1_ll_(False)
			import l1111lllll_ll_
			if l1111lllll_ll_.l11111111l_ll_(False):
				l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩⅾ"),l111lll_ll_ (u"ࠧฦาสࠤ่์สࠡฬึฮำีๅࠡะา้ฮࠦࡉࡑࡖ࡙ࠤฬ๊ๅ้ฮ๋ำฮࠦแ๋๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡใึ์ๆ๊ࠦใ๊่ࠤฬ๊ศา่ส้ัࠦวๅฤ้ࠤศ๎ส้็สฮ๏้๊ศࠢหะ้ฮࠠๆๆไหฯࠦࡉࡑࡖ࡙ࠤัี๊ะหࠪⅿ"))
				l1111lllll_ll_.l1lllllll11_ll_(False)
			try:
				l1l11111l11_ll_ = os.path.join(l1l1l1l1l11_ll_,l111lll_ll_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪↀ"),l111lll_ll_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ↁ"),l111lll_ll_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡶࡪࡹ࡯࡭ࡸࡨࡹࡷࡲࠧↂ"),l111lll_ll_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪↃ"))
				if not os.path.exists(l1l11111l11_ll_):
					l11llll1lll_ll_ = xbmcaddon.Addon(id=l111lll_ll_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࠩↄ"))
					l11llll1lll_ll_.setSetting(l111lll_ll_ (u"࠭ࡡࡶࡶࡲࡣࡵ࡯ࡣ࡬ࠩↅ"),l111lll_ll_ (u"ࠧࡧࡣ࡯ࡷࡪ࠭ↆ"))
			except: pass
			try:
				l1l11111l11_ll_ = os.path.join(l1l1l1l1l11_ll_,l111lll_ll_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪↇ"),l111lll_ll_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭ↈ"),l111lll_ll_ (u"ࠪࡷࡨࡸࡩࡱࡶ࠱ࡱࡴࡪࡵ࡭ࡧ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡩࡲࠧ↉"),l111lll_ll_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ↊"))
				if not os.path.exists(l1l11111l11_ll_):
					l11llll1lll_ll_ = xbmcaddon.Addon(id=l111lll_ll_ (u"ࠬࡹࡣࡳ࡫ࡳࡸ࠳ࡳ࡯ࡥࡷ࡯ࡩ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡤ࡭ࠩ↋"))
					l11llll1lll_ll_.setSetting(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࡤࡷࡵࡢ࡮࡬ࡸࡾ࠭↌"),l111lll_ll_ (u"ࠧ࠴ࠩ↍"))
			except: pass
			try:
				l1l11111l11_ll_ = os.path.join(l1l1l1l1l11_ll_,l111lll_ll_ (u"ࠨࡷࡶࡩࡷࡪࡡࡵࡣࠪ↎"),l111lll_ll_ (u"ࠩࡤࡨࡩࡵ࡮ࡠࡦࡤࡸࡦ࠭↏"),l111lll_ll_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠪ←"),l111lll_ll_ (u"ࠫࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡸ࡮࡮ࠪ↑"))
				if not os.path.exists(l1l11111l11_ll_):
					l11llll1lll_ll_ = xbmcaddon.Addon(id=l111lll_ll_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩࠬ→"))
					l11llll1lll_ll_.setSetting(l111lll_ll_ (u"࠭ࡓࡕࡔࡈࡅࡒ࡙ࡅࡍࡇࡆࡘࡎࡕࡎࠨ↓"),l111lll_ll_ (u"ࠧ࠳ࠩ↔"))
			except: pass
	l11l11lll11_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨ࡮ࡤࡷࡹࡩࡨࡦࡥ࡮࠲ࡲ࡫ࡳࡴࡣࡪࡩࡸ࠭↕"))
	if l1l1l1l111l_ll_ or l11l11lll11_ll_==l111lll_ll_ (u"ࠩࠪ↖") or now-int(l11l11lll11_ll_)>l111l11_ll_:
		import l11l1l1ll1l_ll_
		l11l1ll111l_ll_ = l11l1l1ll1l_ll_.l1l11l1l1ll_ll_(False)
	l11ll1lllll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠪࡰࡦࡹࡴࡤࡪࡨࡧࡰ࠴ࡩ࡯ࡨࡲࡷࠬ↗"))
	if l1l1l1l111l_ll_ or l11ll1lllll_ll_==l111lll_ll_ (u"ࠫࠬ↘") or now-int(l11ll1lllll_ll_)>l11111l1_ll_:
		messages = l11l11l1ll1_ll_()
		default = messages[-1][2]
		messages = messages[:-1]
		message = random.sample(messages,1)[0][2]
		message = message+l111lll_ll_ (u"ࠬࡢ࡮࡝ࡰ࡟ࡲࡡࡴࠧ↙")
		message = message.split(l111lll_ll_ (u"࠭࡜࡯ࠩ↚"))
		separator = l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࡟࠴ࡉࡏࡍࡑࡕࡡࠬ↛")
		if message[1]==l111lll_ll_ (u"ࠨࠩ↜"): l11ll11l11l_ll_ = message[0]
		else: l11ll11l11l_ll_ = message[0]+l111lll_ll_ (u"ࠩ࡟ࡲࠬ↝")+separator+l111lll_ll_ (u"ࠪࡠࡳ࠭↞")+message[1]
		settings.setSetting(l111lll_ll_ (u"ࠫࡱࡧࡳࡵࡥ࡫ࡩࡨࡱ࠮ࡪࡰࡩࡳࡸ࠭↟"),str(now))
		l11ll11l_ll_ = [l111lll_ll_ (u"ࠬืำ้ๆࠣหฺฺ้๊หࠪ↠"),l111lll_ll_ (u"࠭ัิ๊็ࠤฬ๊ำ็หࠪ↡")]#,l111lll_ll_ (u"ࠧๅษࠣว฾ืแࠨ↢")]
		l1ll11l1111_ll_,choice = l11ll11l_ll_,-1
		while choice==-1:
			l1ll11l1111_ll_ = random.sample(l11ll11l_ll_,2)
			#choice = l1lll11l1ll_ll_(l111lll_ll_ (u"ࠨ็้ࠤ์๎ࠠศๆ้ฬ๏ࠦวๅลไฺ้࠭↣"),message,l1ll11l1111_ll_[0],l1ll11l1111_ll_[1],l1ll11l1111_ll_[2])
			t1 = time.time()
			choice = l1llll1111_ll_(l111lll_ll_ (u"่๊ࠩࠥํ่ࠡษ็๊อ๐ࠠศๆฦๅ฻๊ࠧ↤"),l11ll11l11l_ll_,l111lll_ll_ (u"ࠪࠫ↥"),l111lll_ll_ (u"ࠫࠬ↦"),l1ll11l1111_ll_[0],l1ll11l1111_ll_[1])
			if time.time()-t1<3: choice = -1
			elif l11ll11l_ll_[0]!=l1ll11l1111_ll_[choice]:
				if message[2]!=l111lll_ll_ (u"ࠬ࠭↧"): default = message[2]
				l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ↨"),default)
				choice = -1
		#l1111l11l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ↩"),message,l111lll_ll_ (u"ࠨࡤ࡬࡫ࠬ↪"),l111lll_ll_ (u"ࠩࡵ࡭࡬࡮ࡴࠨ↫"))
	if l111lll_ll_ (u"ࠪࡣࠬ↬") in context: l1l1111l1l1_ll_,l1l11111ll_ll_ = context.split(l111lll_ll_ (u"ࠫࡤ࠭↭"),1)
	else: l1l1111l1l1_ll_,l1l11111ll_ll_ = context,l111lll_ll_ (u"ࠬ࠭↮")
	if l1l1111l1l1_ll_==l111lll_ll_ (u"࠭࠶ࠨ↯"):
		if l1l11111ll_ll_==l111lll_ll_ (u"ࠧࠨ↰"): l1ll11l_ll_(l111lll_ll_ (u"ࠨ์ิะ๎ࠦวๅษ้ฮ฽อัࠨ↱"),l111lll_ll_ (u"ࠩฯหึ๐ࠠโฯุࠤ๊๊แࠡษ็ฮา๋๊ๅࠩ↲"))
		results = l1lll1111ll_ll_(type,name,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,context)
		xbmc.executebuiltin(l111lll_ll_ (u"ࠥࡇࡴࡴࡴࡢ࡫ࡱࡩࡷ࠴ࡒࡦࡨࡵࡩࡸ࡮ࠢ↳"))
		#l1l111l1l11_ll_(l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡓࡁࡊࡐ࠰࠵ࡸࡺࠧ↴"))
		return
	elif l1l1111l1l1_ll_ in [l111lll_ll_ (u"ࠬ࠷ࠧ↵"),l111lll_ll_ (u"࠭࠲ࠨ↶"),l111lll_ll_ (u"ࠧ࠴ࠩ↷"),l111lll_ll_ (u"ࠨ࠶ࠪ↸"),l111lll_ll_ (u"ࠩ࠸ࠫ↹")] and l1l11111ll_ll_!=l111lll_ll_ (u"ࠪࠫ↺"):
		import l11llllll1_ll_
		l11llllll1_ll_.l1l111l11l_ll_(context)
		#l111lll_ll_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠣ↻") l1l1lll111l_ll_ l1l1llll11l_ll_ l1l1111l11l_ll_ is no l1l1l11l1ll_ll_ number to l1l1111llll_ll_ for l1lll111l1l_ll_ directory
		#l111lll_ll_ (u"ࠧࡉ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࡗࡳࡨࡦࡺࡥࠣ↼") l1l1lll111l_ll_ to open a l11l1llll1_ll_ list l1ll11l1l1l_ll_ l1ll1111l1l_ll_ l11ll11ll11_ll_
		#xbmc.executebuiltin(l111lll_ll_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡘࡴࡩࡧࡴࡦࠪࠥ↽")+sys.argv[0]+l11ll11ll11_ll_.split(l111lll_ll_ (u"ࠧࠧࡥࡲࡲࡹ࡫ࡸࡵ࠿ࠪ↾"))[0]+l111lll_ll_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀ࠴ࠬ↿")+l111lll_ll_ (u"ࠤࠬࠦ⇀"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠪ࡟࠶࠷࠱࠲࠳࠴࠵࠶࠷࠱ࠡࠩ⇁")+l1l1111l1l1_ll_+l111lll_ll_ (u"ࠫࡢ࠭⇂"),l111lll_ll_ (u"ࠬࡡࠧ⇃")+l1l11111ll_ll_+l111lll_ll_ (u"࠭࡝ࠨ⇄"))
		xbmc.executebuiltin(l111lll_ll_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱ࡖࡪ࡬ࡲࡦࡵ࡫ࠦ⇅"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠨ࡝࠵࠶࠷࠸࠲࠳࠴࠵࠶࠷ࠦࠧ⇆")+l1l1111l1l1_ll_+l111lll_ll_ (u"ࠩࡠࠫ⇇"),l111lll_ll_ (u"ࠪ࡟ࠬ⇈")+l1l11111ll_ll_+l111lll_ll_ (u"ࠫࡢ࠭⇉"))
		#l1l111l1l11_ll_(l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡍࡂࡋࡑ࠱࠷ࡴࡤࠨ⇊"))
		return
	if l11l1ll1ll1_ll_==266:
		import l11l1l1ll1l_ll_
		l11l1l1ll1l_ll_.l11l111l11l_ll_(text)
		xbmc.executebuiltin(l111lll_ll_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠥ⇋"))
		#l1l111l1l11_ll_(l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡏࡄࡍࡓ࠳࠳ࡳࡦࠪ⇌"))
		return
	# l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⇍")	l1l1111llll_ll_ file to read/write the l1lll111ll1_ll_ l11l1llll1_ll_ list
	# l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⇎")		no go l11lll1lll1_ll_ to the l1lll111ll1_ll_ l11l1llll1_ll_ list
	l11ll1lll1l_ll_ = (l11l1ll1ll1_ll_==145)
	l1l1ll11l11_ll_ = (l11l1ll1ll1_ll_==262)
	l1l11ll1ll1_ll_ = [0,10,15,16,17,19,26,27,33,34]
	l1l11l1l111_ll_ = (l1l111lll11_ll_ not in l1l11ll1ll1_ll_)
	l11ll111ll1_ll_ = (l1l11l1l111_ll_ and l1l11lll11l_ll_==9)
	l1ll111l1l1_ll_ = (l11ll111ll1_ll_ or l11ll1lll1l_ll_)
	l11l11ll11l_ll_ = (l1l111lll11_ll_==16 and l11l1ll1ll1_ll_!=160)
	l1l111111l1_ll_ = (l1l111lll11_ll_==23 and text!=l111lll_ll_ (u"ࠪࠫ⇏"))
	l1l111l11ll_ll_ = l1l1l_ll_.replace(l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧ⇐"),l111lll_ll_ (u"ࠬ࠭⇑")).replace(l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ⇒"),l111lll_ll_ (u"ࠧࠨ⇓")).strip(l111lll_ll_ (u"ࠨࠢࠪ⇔"))
	l1l11ll1111_ll_ = name.replace(l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ⇕"),l111lll_ll_ (u"ࠪࠫ⇖")).replace(l111lll_ll_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⇗"),l111lll_ll_ (u"ࠬ࠭⇘")).strip(l111lll_ll_ (u"࠭ࠠࠨ⇙"))
	if l1ll111l1l1_ll_ or l11l11ll11l_ll_:
		if l11l11ll11l_ll_: l1111l1111_ll_ = (l1l111l11ll_ll_ in [l111lll_ll_ (u"ࠧ࠯࠰ࠪ⇚"),l111lll_ll_ (u"ࠨࡏࡤ࡭ࡳࠦࡍࡦࡰࡸࠫ⇛")])
		elif l1ll111l1l1_ll_: l1111l1111_ll_ = (l1l111l11ll_ll_!=l1l11ll1111_ll_)
		#l1111l1111_ll_ = (l1l1l_ll_!=l11ll1l1ll1_ll_) or (l1l1l_ll_ in [l111lll_ll_ (u"ࠩ࠱࠲ࠬ⇜"),l111lll_ll_ (u"ࠪࡑࡦ࡯࡮ࠡࡏࡨࡲࡺ࠭⇝")])
		#l1lll11l111_ll_ = xbmc.getInfoLabel(l111lll_ll_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡆࡰ࡮ࡧࡩࡷࡖࡡࡵࡪࠪ⇞"))
		#l1lll11l111_ll_ = l1111_ll_(l1lll11l111_ll_)
		#l1ll1l_ll_(str(l1l111l11ll_ll_),str(l1l11ll1111_ll_))
		#if l111lll_ll_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⇟") in text and (l1l1l_ll_!=name or l1l1l_ll_ in [l111lll_ll_ (u"࠭࠮࠯ࠩ⇠"),l111lll_ll_ (u"ࠧࡎࡣ࡬ࡲࠥࡓࡥ࡯ࡷࠪ⇡")]) and os.path.exists(l11llll1ll1_ll_):
		if l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⇢") in text and l1111l1111_ll_ and os.path.exists(l11llll1ll1_ll_):
			l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⇣"),l111lll_ll_ (u"ࠪ࠲ࠥࠦࠠࡓࡧࡤࡨ࡮ࡴࡧࠡ࡮ࡤࡷࡹࠦ࡭ࡦࡰࡸࠤࠥࠦࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ⇤")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠫࠥࡣࠧ⇥"))
			with open(l11llll1ll1_ll_,l111lll_ll_ (u"ࠬࡸࠧ⇦")) as f: l11lll1l1l_ll_ = f.read()
			l11l11lll_ll_[:] = eval(l11lll1l1l_ll_)
		else:
			l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⇧"),l111lll_ll_ (u"ࠧ࠯ࠢࠣࠤ࡜ࡸࡩࡵ࡫ࡱ࡫ࠥࡲࡡࡴࡶࠣࡱࡪࡴࡵࠡࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ⇨")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫ⇩"))
			results = l1lll1111ll_ll_(type,l1l11ll1111_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,context)
			l1l1111l1l_ll_ = str(l11l11lll_ll_)
			with open(l11llll1ll1_ll_,l111lll_ll_ (u"ࠩࡺࠫ⇪")) as f: f.write(l1l1111l1l_ll_)
	else: results = l1lll1111ll_ll_(type,l1l11ll1111_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,context)
	# l11lll1111l_ll_ defaults: succeeded,updateListing,cacheToDisc = True,False,True
	# updateListing = True => l1ll1l1111l_ll_ this list is l11l1l11l11_ll_ and will be l1ll1l11ll1_ll_ by the next list
	# updateListing = False => l1ll1l1111l_ll_ this list is l1ll1l1ll1l_ll_ and the new list will generate new l11l1llll1_ll_
	succeeded,updateListing,cacheToDisc = True,False,True
	if l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⇫") in text: updateListing = True
	if type==l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⇬") and l1l111l11ll_ll_!=l111lll_ll_ (u"ࠬ࠴࠮ࠨ⇭") and (l1l11l1l111_ll_ or l1l111111l1_ll_):
		l1l1l11llll_ll_()
	if type==l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⇮") and l1l1l11l1ll_ll_>-1:
		l11ll1ll1l1_ll_ = []
		for l11lll1l11_ll_ in l11l11lll_ll_:
			l1l1111lll1_ll_ = l1ll1ll1lll_ll_(l11lll1l11_ll_)
			l11ll1ll1l1_ll_.append(l1l1111lll1_ll_)
		l11lllll11l_ll_ = xbmcplugin.addDirectoryItems(l1l1l11l1ll_ll_,l11ll1ll1l1_ll_)
		xbmcplugin.setContent(l1l1l11l1ll_ll_,l111lll_ll_ (u"ࠧࡵࡸࡶ࡬ࡴࡽࡳࠨ⇯"))
		#succeeded,updateListing,cacheToDisc = True,False,True
		xbmcplugin.endOfDirectory(l1l1l11l1ll_ll_,succeeded,updateListing,cacheToDisc)
	l1l11lllll1_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨࡦࡱࡷ࠳ࡹࡴࡢࡶࡸࡷࠬ⇰"))
	l1ll111llll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ⇱"))
	if l1l11lllll1_ll_ in [l111lll_ll_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ⇲"),l111lll_ll_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭⇳")]: settings.setSetting(l111lll_ll_ (u"ࠬࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ⇴"),l111lll_ll_ (u"࠭ࡁࡔࡍࡌࡒࡌ࠭⇵"))
	if l1ll111llll_ll_ in [l111lll_ll_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ⇶"),l111lll_ll_ (u"ࠨࡔࡈࡎࡊࡉࡔࡆࡆࠪ⇷")]: settings.setSetting(l111lll_ll_ (u"ࠩࡳࡶࡴࡾࡹ࠯ࡵࡷࡥࡹࡻࡳࠨ⇸"),l111lll_ll_ (u"ࠪࡅࡘࡑࡉࡏࡉࠪ⇹"))
	return
def l1lll1111ll_ll_(type,name,url,mode,image,page,text,context):
	mode = int(mode)
	l1l111lll11_ll_ = int(mode/10)
	#l1ll1l_ll_(str(mode),str(l1l111lll11_ll_))
	results = None
	if   l1l111lll11_ll_==0:  import l1l111ll111_ll_ 	; results = l1l111ll111_ll_.l111l1l_ll_(mode,text)
	elif l1l111lll11_ll_==1:  import l11l111l_ll_ 		; results = l11l111l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==2:  import l11l1ll1ll_ll_ 		; results = l11l1ll1ll_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==3:  import l11l1ll1l1l_ll_ 		; results = l11l1ll1l1l_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==4:  import l1l1lll1l_ll_ 	; results = l1l1lll1l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==5:  import l1ll1lll111_ll_ 	; results = l1ll1lll111_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==6:  import l1ll1lll1_ll_ 	; results = l1ll1lll1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==7:  import l1l_ll_ 		; results = l1l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==8:  import l11ll111l1_ll_ 	; results = l11ll111l1_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==9:  import l11l1lll1l_ll_ 		; results = l11l1lll1l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==10: import l1l1l1l1ll1_ll_ 		; results = l1l1l1l1ll1_ll_.l111l1l_ll_(mode,url)
	elif l1l111lll11_ll_==11: import l1ll1l1ll11_ll_ 	; results = l1ll1l1ll11_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==12: import l1ll111lll_ll_ 		; results = l1ll111lll_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==13: import l1ll11111_ll_	; results = l1ll11111_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==14: import l1l1lll11ll_ll_ 		; results = l1l1lll11ll_ll_.l111l1l_ll_(mode,url,text,type,page)
	elif l1l111lll11_ll_==15: import l1l111ll111_ll_ 	; results = l1l111ll111_ll_.l111l1l_ll_(mode,text)
	elif l1l111lll11_ll_==16: import l1ll1ll11l1_ll_	 	; results = l1ll1ll11l1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==17: import l1l111ll111_ll_ 	; results = l1l111ll111_ll_.l111l1l_ll_(mode,text)
	elif l1l111lll11_ll_==18: import l11ll1ll1ll_ll_	; results = l11ll1ll1ll_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==19: import l1l111ll111_ll_ 	; results = l1l111ll111_ll_.l111l1l_ll_(mode,text)
	elif l1l111lll11_ll_==20: import l11llll1l_ll_		; results = l11llll1l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==21: import l1lll11ll11_ll_ ; results = l1lll11ll11_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==22: import l1l1l1111l_ll_ 	; results = l1l1l1111l_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==23: import l1111lllll_ll_ 		; results = l1111lllll_ll_.l111l1l_ll_(mode,url,text,type)
	elif l1l111lll11_ll_==24: import l1l1lll_ll_ 		; results = l1l1lll_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==25: import l1l111l11_ll_ 	; results = l1l111l11_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==26: import l11l1l1ll1l_ll_ 		; results = l11l1l1ll1l_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==27: import l11llllll1_ll_ 	; results = l11llllll1_ll_.l111l1l_ll_(mode,context)
	elif l1l111lll11_ll_==28: import l1111lllll_ll_ 		; results = l1111lllll_ll_.l111l1l_ll_(mode,url,text,type)
	elif l1l111lll11_ll_==29: import l1l11lll1l1_ll_	; results = l1l11lll1l1_ll_.l111l1l_ll_(mode,url,page,text)
	elif l1l111lll11_ll_==30: import l11l111ll_ll_		; results = l11l111ll_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==31: import l11ll11llll_ll_	; results = l11ll11llll_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==32: import l1lll1ll111_ll_	; results = l1lll1ll111_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==33: import l1lll1llll_ll_		; results = l1lll1llll_ll_.l111l1l_ll_(mode,url,context)
	elif l1l111lll11_ll_==34: import l1l111ll111_ll_ 	; results = l1l111ll111_ll_.l111l1l_ll_(mode,text)
	elif l1l111lll11_ll_==35: import l1l1lll1_ll_		; results = l1l1lll1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==36: import l1l11l111l1_ll_		; results = l1l11l111l1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==37: import l11l1l1l1_ll_		; results = l11l1l1l1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==38: import l11l1ll11l1_ll_ 		; results = l11l1ll11l1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==39: import l1l11l1ll1_ll_	; results = l1l11l1ll1_ll_.l111l1l_ll_(mode,url,text)
	elif l1l111lll11_ll_==40: import l111l1111_ll_	; results = l111l1111_ll_.l111l1l_ll_(mode,url,text,type,page)
	elif l1l111lll11_ll_==41: import l111l1111_ll_	; results = l111l1111_ll_.l111l1l_ll_(mode,url,text,type,page)
	return results
def l1l1l11_ll_(l1ll_ll_,label,mode,path):
	id = l111lll_ll_ (u"ࠫࠎࡡࠠࠨ⇺")+l11ll11l111_ll_.upper()+l111lll_ll_ (u"ࠬ࠳ࠧ⇻")+l11l1lll11l_ll_+l111lll_ll_ (u"࠭࠭ࠨ⇼")+l1ll_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⇽")
	message = id+l111lll_ll_ (u"ࠨࠋࡏࡥࡧ࡫࡬࠻ࠢ࡞ࠤࠬ⇾")+label+l111lll_ll_ (u"ࠩࠣࡡࠎࡓ࡯ࡥࡧ࠽ࠤࡠࠦࠧ⇿")+str(mode)+l111lll_ll_ (u"ࠪࠤࡢࠏࡐࡢࡶ࡫࠾ࠥࡡࠠࠨ∀")+path+l111lll_ll_ (u"ࠫࠥࡣࠧ∁")
	xbmc.log(message, level=xbmc.LOGNOTICE)
	return
def l1111l1l_ll_(level,message):
	#xbmc.log(l111lll_ll_ (u"ࠬࡋࡍࡂࡆࠣ࠵࠶࠷ࠧ∂")+message+l111lll_ll_ (u"࠭ࡅࡎࡃࡇࠤ࠷࠸࠲ࠨ∃"), level=xbmc.LOGNOTICE)
	message = message.replace(l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌ࠰࠱࡟ࠪ∄"),l111lll_ll_ (u"ࠨࠩ∅")).replace(l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ∆"),l111lll_ll_ (u"ࠪࠫ∇"))
	message = message.replace(l111lll_ll_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭∈"),l111lll_ll_ (u"ࠬ࠭∉"))
	if level==l111lll_ll_ (u"࠭ࠧ∊"): level = l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ∋")
	if level==l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭∌"):
		l11l11l111l_ll_ = xbmc.LOGERROR
		lines = message.strip(l111lll_ll_ (u"ࠩ࠱ࠤࠥࠦࠧ∍")).split(l111lll_ll_ (u"ࠪࠤࠥࠦࠧ∎"))
	elif level==l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ∏"):
		try: l11l11l111l_ll_ = xbmc.LOGNOTICE
		except: l11l11l111l_ll_ = xbmc.LOGINFO
		lines = message.strip(l111lll_ll_ (u"ࠬ࠴ࠠࠡࠢࠪ∐")).split(l111lll_ll_ (u"࠭ࠠࠡࠢࠪ∑"))
	elif level==l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ−"):
		try: l11l11l111l_ll_ = xbmc.LOGNOTICE
		except: l11l11l111l_ll_ = xbmc.LOGINFO
		lines = message.split(l111lll_ll_ (u"ࠨࠢࠣࠤࠥ࠭∓"))
	#message = message.replace(l111lll_ll_ (u"ࠩࠣࠤࠥ࠭∔"),l111lll_ll_ (u"ࠪࡠࡹ࠭∕"))
	tab = l111lll_ll_ (u"ࠫࠥࠦࠠࠡࠩ∖")
	tabs = tab+tab+tab
	shift = tabs+tab+l111lll_ll_ (u"ࠬࠦࠠࠨ∗")
	if l1ll1l111l1_ll_>17.999: shift = shift+l111lll_ll_ (u"࠭ࠠࠡࠢࠣࠤࠥࠦࠠࠡࠢࠣࠫ∘")
	#l1ll1l_ll_(str(l1ll1l111l1_ll_),l111lll_ll_ (u"ࠧࠨ∙"))
	#l1l1llllll1_ll_ = lines[0] + l111lll_ll_ (u"ࠨ࡞ࡵࠫ√")
	l1l1llllll1_ll_ = lines[0]
	for line in lines[1:]:
		if l111lll_ll_ (u"ࠩ࡟ࡲࠬ∛") in line: line = line.replace(l111lll_ll_ (u"ࠪࡠࡳ࠭∜"),l111lll_ll_ (u"ࠫࡡࡴࠧ∝")+tabs)
		#if l111lll_ll_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠳࠼ࠪ∞") in line or l111lll_ll_ (u"࠭ࡒࡦࡵࡲࡰࡻ࡫ࡲࠡ࠵࠽ࠫ∟") in line:
		#	line = line.replace(l111lll_ll_ (u"ࠧ࡝ࡰࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠧ∠"),l111lll_ll_ (u"ࠨ࡞ࡱࠫ∡")+tabs+l111lll_ll_ (u"ࠩࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠷ࡀࠧ∢"))
		#	line = line.replace(l111lll_ll_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠪ∣"),l111lll_ll_ (u"ࠫࡡࡴࠧ∤")+tabs+l111lll_ll_ (u"ࠬࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠴࠼ࠪ∥"))
		tabs = tabs+tab
		l1l1llllll1_ll_ += l111lll_ll_ (u"࠭࡜ࡳࠩ∦")+shift+tabs+line
	l1l1llllll1_ll_ += l111lll_ll_ (u"ࠧࡠࠩ∧")
	if l111lll_ll_ (u"ࠨࠧࠪ∨") in l1l1llllll1_ll_: l1l1llllll1_ll_ = l1111_ll_(l1l1llllll1_ll_)
	xbmc.log(l1l1llllll1_ll_,level=l11l11l111l_ll_)
	return
def l111111l_ll_(l1ll_ll_):
	l11llllll11_ll_ = sys._getframe(1).f_code.co_name
	#l1ll1l_ll_(str(l11llllll11_ll_),l111lll_ll_ (u"ࠩࠪ∩"))
	#if l11llllll11_ll_==l111lll_ll_ (u"ࠪࡀࡲࡵࡤࡶ࡮ࡨࡂࠬ∪"): return l111lll_ll_ (u"ࠫ࠳ࠦࠠ࡜ࠢࠣࠫ∫")+l1ll_ll_+l111lll_ll_ (u"ࠬ࠳ࠧ∬")+l11llllll11_ll_+l111lll_ll_ (u"࠭ࠠ࡞ࠩ∭")
	#l11llllll11_ll_ = l111lll_ll_ (u"ࠧࡎࡃࡌࡒࠬ∮")
	if l1ll_ll_==l111lll_ll_ (u"ࠨࡏࡄࡍࡓ࠭∯") and l11llllll11_ll_==l111lll_ll_ (u"ࠩࡐࡅࡎࡔࠧ∰"):
		return l111lll_ll_ (u"ࠪ࡟ࠥ࠭∱")+l11ll11l111_ll_.upper()+l111lll_ll_ (u"ࠫ࠲࠭∲")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠬ࠳ࠧ∳")+l1ll_ll_+l111lll_ll_ (u"࠭࠭ࠨ∴")+l11llllll11_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪ∵")
	return l111lll_ll_ (u"ࠨ࠰ࠣࠤࠥ࠭∶")+l11llllll11_ll_
class l1l11ll11l1_ll_(xbmc.Player):
	def __init__(self,*args,**kwargs):
		self.status = l111lll_ll_ (u"ࠩࠪ∷")
	def onPlayBackStopped(self):
		self.status=l111lll_ll_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ∸")
	def onPlayBackStarted(self):
		if l11llll1l1l_ll_(l111lll_ll_ (u"ࠫࡈ࡚ࡅ࠺ࡆࡖ࠵࠾࡜ࡕ࠱ࡘࡖ࡜ࠬ∹")):
			self.stop()
			self.status=l111lll_ll_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ∺")
		else: self.status=l111lll_ll_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ∻")
		time.sleep(1)
	def onPlayBackError(self):
		self.status=l111lll_ll_ (u"ࠧࡧࡣ࡬ࡰࡪࡪࠧ∼")
	def onPlayBackEnded(self):
		self.status=l111lll_ll_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ∽")
class l11ll11lll_ll_():
	def __init__(self,l1111l1l11_ll_=False,l1l11l1ll1l_ll_=True):
		self.l1111l1l11_ll_ = l1111l1l11_ll_
		self.l1l11l1ll1l_ll_ = l1l11l1ll1l_ll_
		self.l11lll11l1l_ll_,self.l1lll111l11_ll_ = [],[]
		self.l1l1111111l_ll_,self.l11ll11111_ll_ = {},{}
		self.l1l1l1lll11_ll_,self.l11l11ll1l1_ll_,self.l1ll11l1l11_ll_ = {},{},{}
	def start_new_thread(self,id,func,*args):
		id = str(id)
		self.l1l1111111l_ll_[id] = l111lll_ll_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ∾")
		if self.l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠪࠫ∿"),id)
		# l1ll1l11111_ll_ 2
		# thread.start_new_thread(self.run,(id,func,args))
		# l1ll1l11111_ll_ 2 & 3
		import threading
		l1ll1l1l1l1_ll_ = threading.Thread(target=self.run, args=(id,func,args))
		l1ll1l1l1l1_ll_.start()
	def run(self,id,func,args):
		id = str(id)
		self.l1l1l1lll11_ll_[id] = time.time()
		#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ≀"),l111lll_ll_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥࡹࡴࡢࡴࡷࡩࡩࠦࡩࡥ࠼ࠣࠫ≁")+id)
		try:
			#l1111l1l_ll_(l111lll_ll_ (u"࠭ࠧ≂"),l111lll_ll_ (u"ࠧࡆࡏࡄࡈ࠿ࡀࠠࠨ≃")+str(func))
			self.l11ll11111_ll_[id] = func(*args)
			if l111lll_ll_ (u"ࠨࡑࡓࡉࡓ࡛ࡒࡍࠩ≄") in str(func) and not self.l11ll11111_ll_[id].succeeded:
				raise SystemError(l111lll_ll_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡈࡶࡷࡵࡲࠨ≅"))
			self.l11lll11l1l_ll_.append(id)
			self.l1l1111111l_ll_[id] = l111lll_ll_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࠬ≆")
			#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ≇"),l111lll_ll_ (u"ࠬࡺࡨࡳࡧࡤࡨࠥ࡬ࡩ࡯࡫ࡶ࡬ࡪࡪࠠࡪࡦ࠽ࠤࠬ≈")+id)
		except Exception as err:
			#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭≉"),l111lll_ll_ (u"ࠧࡵࡪࡵࡩࡦࡪࠠࡧࡣ࡬ࡰࡪࡪࠠࡪࡦ࠽ࠤࠬ≊")+id)
			if self.l1l11l1ll1l_ll_:
				l1l11l1lll1_ll_ = traceback.format_exc()
				sys.stderr.write(l1l11l1lll1_ll_)
				#traceback.print_exc(file=sys.stderr)
			self.l1lll111l11_ll_.append(id)
			self.l1l1111111l_ll_[id] = l111lll_ll_ (u"ࠨࡨࡤ࡭ࡱ࡫ࡤࠨ≋")
		self.l11l11ll1l1_ll_[id] = time.time()
		self.l1ll11l1l11_ll_[id] = self.l11l11ll1l1_ll_[id] - self.l1l1l1lll11_ll_[id]
	def l11ll11ll1_ll_(self):
		while l111lll_ll_ (u"ࠩࡵࡹࡳࡴࡩ࡯ࡩࠪ≌") in self.l1l1111111l_ll_.values(): time.sleep(1.000)
def l1ll11lllll_ll_(code,reason,source,l1111l1l11_ll_):
	if l111lll_ll_ (u"ࠪ࠱ࠬ≍") in source: site = source.split(l111lll_ll_ (u"ࠫ࠲࠭≎"),1)[0]
	else: site = source
	#if code==104: l1ll1l_ll_(l111lll_ll_ (u"๊ࠬฯ๋ๅࠣา฼ษࠠศีหหอํࠠไอํีฮ࠭≏"),l111lll_ll_ (u"๊࠭าฮ์ࠤ๊์ใࠡษ็ฮํอีๅ่ࠢ฽ࠥอไๆสิ้ัูࠦ็ฺࠢี๏่่ࠠาสࠤฬ๊ัศสฺࠫ≐"),l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡩ࡬ࡸ࡭ࡻࡢ࠯ࡥࡲࡱ࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠰ࡍࡒࡈࡎ࠵ࡩࡴࡵࡸࡩࡸ࠭≑"))
	l11l111l1l1_ll_ = (code in [7,11001,11002,10054])
	l1l11ll1l1l_ll_ = (code in [0,104,10061,111])
	l1ll11111ll_ll_ = (l111lll_ll_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡉ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ≒") in reason)
	l1ll11111l1_ll_ = (l111lll_ll_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦ࠵ࠡࡵࡨࡧࡴࡴࡤࡴࠢࡥࡶࡴࡽࡳࡦࡴࠣࡧ࡭࡫ࡣ࡬ࠩ≓") in reason)
	l1ll111111l_ll_ = (l111lll_ll_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡈࡱࡲ࡫ࡱ࡫ࠠࡳࡧࡆࡅࡕ࡚ࡃࡉࡃࠪ≔") in reason)
	l1ll111llll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠫࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ≕"))
	l1l11lllll1_ll_ = settings.getSetting(l111lll_ll_ (u"ࠬࡪ࡮ࡴ࠰ࡶࡸࡦࡺࡵࡴࠩ≖"))
	if l1ll111llll_ll_==l111lll_ll_ (u"࠭ࡁࡔࡍࡌࡒࡌ࠭≗") or l1l11lllll1_ll_==l111lll_ll_ (u"ࠧࡂࡕࡎࡍࡓࡍࠧ≘"):
		l11lll11ll1_ll_ = l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠ๋้ࠦสา์าࠤศ์๋ࠠฯส์้ࠦวๅสิ๊ฬ๋ฬࠡวุ่ฬำࠠศๆุ่่๊ษࠡม࡞࠳ࡈࡕࡌࡐࡔࡠࠫ≙")
	else: l11lll11ll1_ll_ = l111lll_ll_ (u"ࠩࠪ≚")
	l11lll11ll1_ll_ += l111lll_ll_ (u"ࠪࠤๆฺไࠡสึัอࠦวๅืไัฮ࠭≛")
	l1ll1lll1l1_ll_ = l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴࠣࠫ≜")+str(code)+l111lll_ll_ (u"ࠬࡀࠠࠨ≝")+reason
	if l1l11ll1l1l_ll_ or l1ll11111ll_ll_ or l1ll11111l1_ll_ or l1ll111111l_ll_:
		l11lll11ll1_ll_ += l111lll_ll_ (u"࠭ࠠ࠯ࠢส่๊๎โฺࠢไ๎์ࠦออสฺࠣิࠦใ้ัํࠤ๊฻ฯา้ࠣห้ษๆหำ้๎ฯࠦวๅะสูࠥฮใࠡล๋ࠤออไๆ๊ๅ฽ࠬ≞")
	if l11l111l1l1_ll_:
		l11lll11ll1_ll_ += l111lll_ll_ (u"ࠧࠡ࠰่ࠣิ๐ใࠡะฺวࠥࡊࡎࡔ๋้ࠢ฾์ว่ࠢอ฽ีืࠠหำฯ้ฮࠦวิ็ࠣห้๋่ใ฻ࠣษ้๏ࠠาไ่๋ࠬ≟")
	l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭≠"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ≡")+str(code)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ≢")+reason+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭≣")+source+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠽ࠤࡠࠦࠧ≤")+l11lll11ll1_ll_+l111lll_ll_ (u"࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ≥")+l1ll1lll1l1_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪ≦"))
	#l1ll1l_ll_(l1ll111llll_ll_,l1l11lllll1_ll_)
	if l1ll111llll_ll_==l111lll_ll_ (u"ࠨࡃࡖࡏࡎࡔࡇࠨ≧") or l1l11lllll1_ll_==l111lll_ll_ (u"ࠩࡄࡗࡐࡏࡎࡈࠩ≨"):
		l1l11llll1l_ll_ = l1llll1111_ll_(site+l111lll_ll_ (u"ࠪࠤࠥࠦࠧ≩")+l1l1ll1l111_ll_(site),l11lll11ll1_ll_,l1ll1lll1l1_ll_,l111lll_ll_ (u"ࠫࠬ≪"),l111lll_ll_ (u"้ࠬไศࠩ≫"),l111lll_ll_ (u"࠭ๆฺ็ࠪ≬"))
	else:
		l1l11llll1l_ll_ = False
		if l1111l1l11_ll_: l1ll1l_ll_(site+l111lll_ll_ (u"ࠧࠡࠢࠣࠫ≭")+l1l1ll1l111_ll_(site),l11lll11ll1_ll_,l1ll1lll1l1_ll_)
	return l1l11llll1l_ll_
	l111lll_ll_ (u"ࠣࠤࠥࠎࠎ࡯ࡦࠡࡦࡱࡷࠥࡵࡲࠡࡤ࡯ࡳࡨࡱࡥࡥ࠳ࠣࡳࡷࠦࡢ࡭ࡱࡦ࡯ࡪࡪ࠲ࠡࡱࡵࠤࡧࡲ࡯ࡤ࡭ࡨࡨ࠸ࡀࠊࠊࠋࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣࡁࠥ࠭ๆ้฻้๋ࠣࠦวๅฯฯฬࠥ฼ฯࠡๅ๋ำ๏ࠦๅึัิ๋ࠥอไฤ่อี๋๐สࠡษ็าฬ฻ࠠษๅ࠱ࠫࠏࠏࠉࡪࡨࠣࡷ࡭ࡵࡷࡅ࡫ࡤࡰࡴ࡭ࡳ࠻ࠢࡥࡰࡴࡩ࡫ࡠ࡯ࡨࡩࡸࡹࡡࡨࡧࠣ࠯ࡂ้ࠦࠧࠡ็ࠤฯื๊ะࠢอๅฬ฻๊ๅࠢส็ะืࠠภࠩࠍࠍࠎ࡯ࡦࠡࡦࡱࡷ࠿ࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄࠢࡀࠤ๊ࠬฯ๋ๅࠣา฼ษࠠࡅࡐࡖࠤํู๋็ษ๊ࠤฯ฿ะาࠢอีั๋ษࠡษึ้ࠥอไๆ๊ๅ฽ࠥหไ๊ࠢิๆ๊ํࠧࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡆࡘࡁࡃࡋࡆࠤ࠰ࡃࠠࠨ๋ࠢหู้ศษࠢๅำࠥ๐ใ้่ࠣࠫ࠰ࡨ࡬ࡰࡥ࡮ࡣࡲ࡫ࡥࡴࡵࡤ࡫ࡪࠐࠉࠊࡧ࡯ࡷࡪࡀࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉࠠ࠾๋ࠢࠪีอࠠศๆ่์็฿ࠠโ์๊ࠤࠬ࠱ࡢ࡭ࡱࡦ࡯ࡤࡳࡥࡦࡵࡶࡥ࡬࡫ࠊࠊࠋࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ࠰ࡑࡕࡇࡈࡋࡑࡋ࠭ࡹࡣࡳ࡫ࡳࡸࡤࡴࡡ࡮ࡧࠬ࠯ࠬࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡰࡷࡵࡧࡪ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠ࡮ࡧࡶࡷࡦ࡭ࡥࡂࡔࡄࡆࡎࡉ࠺ࠡ࡝ࠣࠫ࠰ࡳࡥࡴࡵࡤ࡫ࡪࡇࡒࡂࡄࡌࡇ࠰࠭ࠠ࡞࡟ࠣࠤࠥࡳࡥࡴࡵࡤ࡫ࡪࡋࡎࡈࡎࡌࡗࡍࡀࠠ࡜ࠢࠪ࠯ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠰࠭ࠠ࡞ࠩࠬࠎࠎࠏࡩࡧࠢࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹ࠺ࠋࠋࠌࠍࡾ࡫ࡳࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢ࡝ࡊ࡙ࡎࡐࠪࡶ࡭ࡹ࡫ࠫࠨࠢࠣࠤࠬ࠱ࡔࡓࡃࡑࡗࡑࡇࡔࡆࠪࡶ࡭ࡹ࡫ࠩ࠭࡯ࡨࡷࡸࡧࡧࡦࡃࡕࡅࡇࡏࡃ࠭࡯ࡨࡷࡸࡧࡧࡦࡇࡑࡋࡑࡏࡓࡉ࠮ࠪࠫ࠱࠭ใๅษࠪ࠰ࠬ์ูๆࠩࠬࠎࠎࠏࠉࡪࡨࠣࡽࡪࡹ࠽࠾࠳࠽ࠤ࡮ࡳࡰࡰࡴࡷࠤࡘࡋࡒࡗࡋࡆࡉࡘࠦ࠻ࠡࡕࡈࡖ࡛ࡏࡃࡆࡕ࠱ࡑࡆࡏࡎࠩ࠳࠼࠹࠮ࠐࠉࡦ࡮࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠽ࠎࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡁࡓࡃࡅࡍࡈ࠸ࠠ࠾ࠢࡰࡩࡸࡹࡡࡨࡧࡄࡖࡆࡈࡉࡄ࠭ࠪࠤ࠳ࠦ็ๅࠢอี๏ีࠠๆ฻ิๅฮࠦวๅลึฬฬฮ้ࠠษ็ั้๎ไࠡมࠪࠎࠎࠏࡹࡦࡵࠣࡁࠥࡊࡉࡂࡎࡒࡋࡤ࡟ࡅࡔࡐࡒࠬࡸ࡯ࡴࡦ࠭ࠪࠤࠥࠦࠧࠬࡖࡕࡅࡓ࡙ࡌࡂࡖࡈࠬࡸ࡯ࡴࡦࠫ࠯ࡱࡪࡹࡳࡢࡩࡨࡅࡗࡇࡂࡊࡅ࠵࠰ࡲ࡫ࡳࡴࡣࡪࡩࡊࡔࡇࡍࡋࡖࡌ࠱࠭ࠧ࠭ࠩๆ่ฬ࠭ࠬࠨ่฼้ࠬ࠯ࠊࠊࠋ࡬ࡪࠥࡿࡥࡴ࠿ࡀ࠵࠿ࠐࠉࠊࠋࡰࡩࡸࡹࡡࡨࡧࡇࡉ࡙ࡇࡉࡍࡕࠣࡁࠥ࠭โะࠢํ็ํ์่่ࠠส็ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฾์ฯไࠩࠍࠍࠎࠏ࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠠࠬ࠿ࠣࠫࡡࡴࠧࠬࠩฦ์ࠥอไฤ่อี๋๐สࠡ฻้ำ่ࠦๅโื๋่ฮ࠭ࠊࠊࠋࠌࡱࡪࡹࡳࡢࡩࡨࡈࡊ࡚ࡁࡊࡎࡖࠤ࠰ࡃࠠࠨ࡞ࡱࠫ࠰࠭ร้ࠢส่ึฮืࠡษ็ู้็ัࠡๆสࠤ๏฿ๅๅࠢ฼๊ิ้ࠧࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣห้๋่ใ฻ࠣห้ษีๅ์ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠศๆ่์็฿ࠠศๆฦู้๐ࠠ฻์ิࠤ์ึ็ࠡษ็ูๆำษ๊ࠡส่๊ฮัๆฮ่ࠣฬฺ๊ࠦๆ่ࠫࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯࡞ࡱࠫ࠰࠭ฬาสุ้ࠣำࠠศๆๆหูࠦࠨๆ่ࠣๆฬฬๅสࠢัำ๊อสࠡษ็ฬึ์วๆฮࠬࠫࠏࠏࠉࠊ࡯ࡨࡷࡸࡧࡧࡦࡆࡈࡘࡆࡏࡌࡔࠢ࠮ࡁࠥ࠭࡜࡯ࠩ࠮ࠫศ๎ࠠฤำึู่ࠥฬๅࠢส่ศิืศรࠣ์ฬ๊วิฬัำฬ๋ࠠฦๆ์ࠤฬ๊ๅษำ่ะࠥ࠮ๅ็ࠢๅหห๋ษࠡะา้ฬะࠠศๆหี๋อๅอࠫࠪࠎࠎࠏࠉ࡮ࡧࡶࡷࡦ࡭ࡥࡅࡇࡗࡅࡎࡒࡓࠡ࠭ࡀࠤࠬࡢ࡮ࠨ࠭ࠪวํࠦฬาสࠣ฻ึ่ࠠาใ฼ࠤฬ๊ออส๊ࠣࠬัไศ࡙ࠢࡔࡓࠦࠬࠡࡒࡵࡳࡽࡿࠠ࠭ࠢࡇࡒࡘ࠯ࠧࠋࠋࠌࠍࡲ࡫ࡳࡴࡣࡪࡩࡉࡋࡔࡂࡋࡏࡗࠥ࠱࠽ࠡࠩ࡟ࡲࠬ࠱ࠧฤ๊ࠣะึฮุࠠๆหࠤ์ึวࠡษ็้ํู่ࠡๆสั็อࠧࠋࠋࠌࠍࡉࡏࡁࡍࡑࡊࡣ࡙ࡋࡘࡕࡘࡌࡉ࡜ࡋࡒࠩࠩไุ้ࠦแ๋ࠢึัอࠦวๅืไัฮࠦๅ็ࠢส่ศ์สา่ํฮࠬ࠲࡭ࡦࡵࡶࡥ࡬࡫ࡄࡆࡖࡄࡍࡑ࡙ࠩࠋࠋࠥࠦࠧ≮")
l11ll111l11_ll_ = [ l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡔࡗࡕࡘ࡚ࡡࡗࡉࡘ࡚࠭࠲ࡵࡷࠫ≯")
				,l111lll_ll_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡎࡔࡕࡒࡖࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ≰")
				,l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡕࡐࡆࡐࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞ࡉࡆࡕ࠰࠵ࡸࡺࠧ≱")
				,l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠷ࡴࡤࠨ≲")
				,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡐࡒࡈࡒ࡚ࡘࡌࡠ࡙ࡈࡆࡕࡘࡏ࡙࡛ࡗࡓ࠲࠷ࡳࡵࠩ≳")
				,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡑࡓࡉࡓ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚࡜ࡘࡔ࠳࠲࡯ࡦࠪ≴")
				,l111lll_ll_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡒࡔࡊࡔࡕࡓࡎࡢࡏࡕࡘࡏ࡙࡛ࡆࡓࡒ࠳࠱ࡴࡶࠪ≵")
				,l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡓࡕࡋࡎࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠳ࡰࡧࠫ≶")
				,l111lll_ll_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡔࡖࡅࡏࡗࡕࡐࡤࡑࡐࡓࡑ࡛࡝ࡈࡕࡍ࠮࠵ࡵࡨࠬ≷")
				,l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡉࡈࡆࡅࡎࡣࡍ࡚ࡔࡑࡕࡢࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ≸")
				,l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡅ࡙ࡖࡕࡅࡈ࡚࡟ࡎ࠵ࡘ࠼࠲࠷ࡳࡵࠩ≹")
				,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡔࡇࡑࡈࡤࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡇ࡙ࡉࡓ࡚࠭࠲ࡵࡷࠫ≺")
				,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡊࡗࡘࡕ࡙࠭࠲ࡵࡷࠫ≻")
				,l111lll_ll_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘ࠲࠷ࡳࡵࠩ≼")
				,l111lll_ll_ (u"ࠩࡖࡉࡗ࡜ࡉࡄࡇࡖ࠱࡙ࡋࡓࡕࡡࡄࡐࡑࡥࡗࡆࡄࡖࡍ࡙ࡋࡓ࠮࠳ࡶࡸࠬ≽")
				,l111lll_ll_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲࡚ࡅࡔࡖࡢࡅࡑࡒ࡟ࡘࡇࡅࡗࡎ࡚ࡅࡔ࠯࠵ࡲࡩ࠭≾")
				,l111lll_ll_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡇࡆࡖࡢࡐࡆ࡚ࡅࡔࡖࡢ࡚ࡊࡘࡓࡊࡑࡑࡣࡓ࡛ࡍࡃࡇࡕࡗ࠲࠷ࡳࡵࠩ≿")
				,l111lll_ll_ (u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧ⊀")
				,l111lll_ll_ (u"࠭ࡅࡈ࡛ࡅࡉࡘ࡚ࡖࡊࡒ࠰ࡔࡑࡇ࡙࠮࠴ࡱࡨࠬ⊁")
				,l111lll_ll_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࡗࡋࡓ࠱ࡕࡒࡁ࡚࠯࠶ࡶࡩ࠭⊂")
				,l111lll_ll_ (u"ࠨࡊࡈࡐࡆࡒ࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ⊃")
				,l111lll_ll_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡖࡆࡔࡄࡐࡏࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙࠳࠱ࡴࡶࠪ⊄")
				,l111lll_ll_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡇࡎࡂࡎ࡜ࡘࡎࡉࡓࡠࡔࡈࡔࡔࡘࡔ࠮࠳ࡶࡸࠬ⊅")
				,l111lll_ll_ (u"ࠫࡉࡇࡉࡍ࡛ࡐࡓ࡙ࡏࡏࡏ࠯ࡆࡌࡆࡔࡎࡆࡎࡖࡣࡘ࡛ࡂࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ⊆")
				,l111lll_ll_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠶ࡳࡪࠧ⊇")
				,l111lll_ll_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨ⊈")
				]
def l11l1llll11_ll_(source,code,reason,l1111l1l11_ll_,l1l1l11l1l1_ll_,l11lll1l11l_ll_):
	# l1ll11ll1ll_ll_ force exit l1l1111llll_ll_
	# l11l1llll11_ll_(l111lll_ll_ (u"ࠧࠨ⊉"),l111lll_ll_ (u"ࠨࠩ⊊"),l111lll_ll_ (u"ࠩࠪ⊋"),l111lll_ll_ (u"ࠪࠫ⊌"))
	if source not in l11ll111l11_ll_ and code!=200:
		l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⊍"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡈࡲࡶࡨ࡫ࡤࠡࡇࡻ࡭ࡹࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ⊎")+str(code)+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ⊏")+reason+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ⊐")+source+l111lll_ll_ (u"ࠨࠢࡠࠫ⊑"))
		raise SystemError(l111lll_ll_ (u"ࠩࡉࡳࡷࡩࡥࡥࠢࡈࡼ࡮ࡺࠧ⊒"))
		#sys.exit(l111lll_ll_ (u"ࠪࡊࡴࡸࡣࡦࡦࠣࡉࡽ࡯ࡴࠨ⊓"))
	return
	#l1l11l11l1l_ll_ = source not in l11ll111l11_ll_ and l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ⊔") not in source and l111lll_ll_ (u"ࠬࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ⊕") not in source
	#l1l11l11ll1_ll_ = l111lll_ll_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣࡇࡱࡵࡵࡥࡨ࡯ࡥࡷ࡫ࠧ⊖") in reason
	#l1l111111ll_ll_ = l111lll_ll_ (u"ࠧࡃ࡮ࡲࡧࡰ࡫ࡤࠡࡤࡼࠤ࠺ࠦࡳࡦࡥࡲࡲࡩࡹࠠࡣࡴࡲࡻࡸ࡫ࡲࠡࡥ࡫ࡩࡨࡱࠧ⊗") in reason
def l11111llll_ll_(l11llll1111_ll_=[]):
	l1l1ll111l1_ll_ = [l1l11l11lll_ll_,l11llll1l1_ll_,l1llllll1ll_ll_,l1111l111l_ll_,l11l1l1llll_ll_]
	l11l111ll11_ll_ = l11llll1111_ll_+l1l1ll111l1_ll_
	#delete = l1llll1111_ll_(l111lll_ll_ (u"ࠨ็ึั๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไใัํ้ฮ࠭⊘"),l111lll_ll_ (u"ࠩึ์ๆ๊ࠦห็ࠣห๏฼วࠡ็ึั๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไใัํ้ฮࠦวๅฬํࠤฬ์สࠡษ้ึ้ะ็ศࠢหหุะฮะษ่ࠤ์ึวࠡษ็ฬึ์วๆฮࠣ࠲ࠥํไࠡฬิ๎ิࠦๅิฯ๊หࠥอๅࠡๆสࠤฤ࠭⊙"),l111lll_ll_ (u"ࠪࠫ⊚"),l111lll_ll_ (u"ࠫࠬ⊛"),l111lll_ll_ (u"้ࠬไศࠩ⊜"),l111lll_ll_ (u"࠭ๆฺ็ࠪ⊝"))
	for filename in os.listdir(l1lll11ll1_ll_):
		#if not delete and l111lll_ll_ (u"ࠧࡧ࡫࡯ࡩࡤ࠭⊞") in filename: continue
		if l111lll_ll_ (u"ࠨࡨ࡬ࡰࡪࡥࠧ⊟") in filename: continue
		l1ll1l1lll1_ll_ = os.path.join(l1lll11ll1_ll_,filename)
		if l1ll1l1lll1_ll_ not in l11l111ll11_ll_:
			try: os.remove(l1ll1l1lll1_ll_)
			except: pass
	return
l1l11ll111l_ll_ = {}
l11l11lll_ll_ = []
def l111_ll_(type,name,url,mode=l111lll_ll_ (u"ࠩࠪ⊠"),image=l111lll_ll_ (u"ࠪࠫ⊡"),page=l111lll_ll_ (u"ࠫࠬ⊢"),text=l111lll_ll_ (u"ࠬ࠭⊣"),context=l111lll_ll_ (u"࠭ࠧ⊤")):
	name = name.replace(l111lll_ll_ (u"ࠧ࡝ࡴࠪ⊥"),l111lll_ll_ (u"ࠨࠩ⊦")).replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬ⊧"),l111lll_ll_ (u"ࠪࠫ⊨")).replace(l111lll_ll_ (u"ࠫࡡࡺࠧ⊩"),l111lll_ll_ (u"ࠬ࠭⊪"))
	url = url.replace(l111lll_ll_ (u"࠭࡜ࡳࠩ⊫"),l111lll_ll_ (u"ࠧࠨ⊬")).replace(l111lll_ll_ (u"ࠨ࡞ࡱࠫ⊭"),l111lll_ll_ (u"ࠩࠪ⊮")).replace(l111lll_ll_ (u"ࠪࡠࡹ࠭⊯"),l111lll_ll_ (u"ࠫࠬ⊰"))
	if l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ⊱") in name: l1111l_ll_,name = name.split(l111lll_ll_ (u"࠭࡟ࡠࡡࠪ⊲"),1)
	else: l1111l_ll_,name = l111lll_ll_ (u"ࠧࠨ⊳"),name
	if type==l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⊴") and l1111l_ll_!=l111lll_ll_ (u"ࠩࠪ⊵"):
		l11l1111l11_ll_ = name
		if l11l1111l11_ll_==l111lll_ll_ (u"ࠪࠫ⊶"): l11l1111l11_ll_ = l111lll_ll_ (u"ࠫ࠳࠴࠮࠯ࠩ⊷")
		elif l11l1111l11_ll_.count(l111lll_ll_ (u"ࠬࡥࠧ⊸"))>1: l11l1111l11_ll_ = l11l1111l11_ll_.split(l111lll_ll_ (u"࠭࡟ࠨ⊹"),2)[2]
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠧแࠩ⊺"),l111lll_ll_ (u"ࠨࠩ⊻")).replace(l111lll_ll_ (u"ࠩࠣࠤࠬ⊼"),l111lll_ll_ (u"ࠪࠤࠬ⊽")).replace(l111lll_ll_ (u"ࠫฮ࠭⊾"),l111lll_ll_ (u"ࠬํࠧ⊿")).replace(l111lll_ll_ (u"่࠭ࠡࠩ⋀"),l111lll_ll_ (u"้ࠧࠩ⋁"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠨลࠪ⋂"),l111lll_ll_ (u"ࠩสࠫ⋃")).replace(l111lll_ll_ (u"ࠪษࠬ⋄"),l111lll_ll_ (u"ࠫฬ࠭⋅")).replace(l111lll_ll_ (u"ࠬศࠧ⋆"),l111lll_ll_ (u"࠭วࠨ⋇"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠧๅลࠪ⋈"),l111lll_ll_ (u"ࠨๆสࠫ⋉")).replace(l111lll_ll_ (u"ࠩ็ษࠬ⋊"),l111lll_ll_ (u"่ࠪฬ࠭⋋")).replace(l111lll_ll_ (u"้ࠫศࠧ⋌"),l111lll_ll_ (u"๊ࠬวࠨ⋍"))
		l11l1ll1111_ll_ = [l111lll_ll_ (u"࠭วๅ฻สฬࠬ⋎"),l111lll_ll_ (u"ࠧฯ์ส่ࠬ⋏"),l111lll_ll_ (u"ࠨษ็ฬํ๋ࠧ⋐"),l111lll_ll_ (u"ࠩส่ฬ์ࠧ⋑"),l111lll_ll_ (u"ࠪห฼็วๅࠩ⋒"),l111lll_ll_ (u"ࠫาอไ๋้ࠪ⋓"),l111lll_ll_ (u"ࠬอไ฻ษีࠫ⋔"),l111lll_ll_ (u"࠭ีศๆะࠫ⋕"),l111lll_ll_ (u"ࠧศๆา๎๋࠭⋖"),l111lll_ll_ (u"ࠨ็๋ห้๐ฯࠨ⋗")]
		if not any(value in l11l1111l11_ll_ for value in l11l1ll1111_ll_): l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠩส่ࠬ⋘"),l111lll_ll_ (u"ࠪࠫ⋙"))
		l11l1111l11_ll_ = l11l1111l11_ll_.strip(l111lll_ll_ (u"ࠫࠥ࠭⋚"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠬอฮา์ࠪ⋛"),l111lll_ll_ (u"࠭วฯำ์ࠫ⋜")).replace(l111lll_ll_ (u"ࠧศฮ้ฬ๎࠭⋝"),l111lll_ll_ (u"ࠨษฯ๊อ๐ࠧ⋞")).replace(l111lll_ll_ (u"ࠩ฼หห๊๊่ࠩ⋟"),l111lll_ll_ (u"ࠪ฽ฬฬไ๋ࠩ⋠"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠫฬาๆษ์๊ࠫ⋡"),l111lll_ll_ (u"ࠬอฬ็สํࠫ⋢")).replace(l111lll_ll_ (u"ู࠭าสํ๋ࠬ⋣"),l111lll_ll_ (u"ฺࠧำห๎ࠬ⋤")).replace(l111lll_ll_ (u"ࠨำ๋้ฬ์ำ๋้ࠪ⋥"),l111lll_ll_ (u"ࠩิ์๊อๆิ์ࠪ⋦"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠪࠤࢁࠦวโๆส้ࠥอ่็ࠢ็ห๏์ࠧ⋧"),l111lll_ll_ (u"ࠫࠬ⋨")).replace(l111lll_ll_ (u"ࠬอๆ๋็ํุ๋࠭⋩"),l111lll_ll_ (u"࠭ว็็ํุ๋࠭⋪")).replace(l111lll_ll_ (u"ࠧ฻ำห๎์࠭⋫"),l111lll_ll_ (u"ࠨ฼ิฬ๏࠭⋬"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠩอหึ๐ฮ๋ࠩ⋭"),l111lll_ll_ (u"ࠪฮฬื๊ฯࠩ⋮")).replace(l111lll_ll_ (u"ࠫำ๐วๅࠢ฼่๊๐ࠧ⋯"),l111lll_ll_ (u"ࠬิ๊ศๆࠪ⋰")).replace(l111lll_ll_ (u"࠭ๅ้ีํๆ๏ํࠧ⋱"),l111lll_ll_ (u"ࠧๆ๊ึ๎็๏ࠧ⋲"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠨ้้ำ๎࠭⋳"),l111lll_ll_ (u"๊๊ࠩิ๐ࠧ⋴")).replace(l111lll_ll_ (u"๋๋ࠪี๊่ࠩ⋵"),l111lll_ll_ (u"ࠫ์์ฯ๋ࠩ⋶")).replace(l111lll_ll_ (u"ࠬ๎หศศๅ๎์࠭⋷"),l111lll_ll_ (u"่࠭ฬษษๆ๏࠭⋸"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠧหๆํๅื๐่็์๊ࠫ⋹"),l111lll_ll_ (u"ࠨฬ็ๅื๐่็ࠩ⋺")).replace(l111lll_ll_ (u"ࠩอ่ๆุ๊้่ํ๋ࠬ⋻"),l111lll_ll_ (u"ࠪฮ้็า๋๊้ࠫ⋼"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠫฬ๊อศๆํ๋ࠬ⋽"),l111lll_ll_ (u"ࠬำวๅ์๊ࠫ⋾")).replace(l111lll_ll_ (u"࠭ๅ้ี໏ๆ໑࠭⋿"),l111lll_ll_ (u"ࠧๆ๊ึ๎็๏ࠧ⌀")).replace(l111lll_ll_ (u"ࠨษ็ห๋๋๊ࠨ⌁"),l111lll_ll_ (u"ࠩส๊๊๐ࠧ⌂"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠪห้๋ำๅี็หฯ࠭⌃"),l111lll_ll_ (u"ู๊ࠫไิๆสฮࠬ⌄")).replace(l111lll_ll_ (u"ࠬอไษำส้ั࠭⌅"),l111lll_ll_ (u"࠭ศาษ่ะࠬ⌆"))
		l11l1111l11_ll_ = l11l1111l11_ll_.replace(l111lll_ll_ (u"ࠧฮำ๋ฬࠬ⌇"),l111lll_ll_ (u"ࠨฯิฬࠬ⌈")).replace(l111lll_ll_ (u"ࠩส่ฬ์วี์าࠫ⌉"),l111lll_ll_ (u"ࠪห๋อิ๋ัࠪ⌊"))
		l1111l_ll_ = l1l1ll1l111_ll_(l1111l_ll_)
		if l11l1111l11_ll_ not in l1l11ll111l_ll_.keys(): l1l11ll111l_ll_[l11l1111l11_ll_] = {}
		l1l11ll111l_ll_[l11l1111l11_ll_][l1111l_ll_] = [type,name,url,mode,image,page,text,context]
	l11l11lll_ll_.append([type,name,url,mode,image,page,text,context])
	return
def l1ll1ll1lll_ll_(l11lll1l11_ll_):
	type,name,url,mode,image,l11lll1l1l1_ll_,l11lll1ll1l_ll_,context = l11lll1l11_ll_
	if type==l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⌋"): l1l1l1ll1ll_ll_,l1l1l1lll1l_ll_ = l111lll_ll_ (u"ࠬࡁࠧ⌌"),l111lll_ll_ (u"࠭ࠬࠨ⌍")
	else: l1l1l1ll1ll_ll_,l1l1l1lll1l_ll_ = l1l1l11ll_ll_(l111lll_ll_ (u"ࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧ⌎")),l111lll_ll_ (u"ࠨࠢࠪ⌏")
	l11l11ll11_ll_ = re.findall(l111lll_ll_ (u"ࠩࠩࠪࡤ࠮࡜ࡅ࡞ࡇࡠࡼ࠯࡟ࡠࡏࡒࡈࡤ࠮࠮ࠫࡁࠬࠪࠫ࠭⌐"),l111lll_ll_ (u"ࠪࠪࠫ࠭⌑")+name+l111lll_ll_ (u"ࠫࠫࠬࠧ⌒"),re.DOTALL)
	if l11l11ll11_ll_: name = l1l1l1ll1ll_ll_+l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࠨ⌓")+l11l11ll11_ll_[0][0]+l111lll_ll_ (u"࠭ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⌔")+l11l11ll11_ll_[0][1]
	l11l11ll11_ll_ = re.findall(l111lll_ll_ (u"ࠧࠧࠨࡢࠬࡡࡊ࡜ࡅ࡞ࡺ࠭ࡤ࠮࠮ࠫࡁࠬࠪࠫ࠭⌕"),l111lll_ll_ (u"ࠨࠨࠩࠫ⌖")+name+l111lll_ll_ (u"ࠩࠩࠪࠬ⌗"),re.DOTALL)
	if l11l11ll11_ll_: name = l1l1l1lll1l_ll_+l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭⌘")+l11l11ll11_ll_[0][0]+l111lll_ll_ (u"࡛ࠫࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⌙")+l11l11ll11_ll_[0][1]
	path = l111lll_ll_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࠨ⌚")+l1ll11lll11_ll_+l111lll_ll_ (u"࠭࠯ࡀࡶࡼࡴࡪࡃࠧ⌛")+type.strip(l111lll_ll_ (u"ࠧࠡࠩ⌜"))
	path = path+l111lll_ll_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ⌝")+str(mode).strip(l111lll_ll_ (u"ࠩࠣࠫ⌞"))
	if type==l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⌟") and l11lll1l1l1_ll_!=l111lll_ll_ (u"ࠫࠬ⌠"): path = path+l111lll_ll_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬ⌡")+l1lll111_ll_(l11lll1l1l1_ll_.strip(l111lll_ll_ (u"࠭ࠠࠨ⌢")))
	if context!=l111lll_ll_ (u"ࠧࠨ⌣"): path = path+l111lll_ll_ (u"ࠨࠨࡦࡳࡳࡺࡥࡹࡶࡀࠫ⌤")+context.strip(l111lll_ll_ (u"ࠩࠣࠫ⌥"))
	if name!=l111lll_ll_ (u"ࠪࠫ⌦"): path = path+l111lll_ll_ (u"ࠫࠫࡴࡡ࡮ࡧࡀࠫ⌧")+l1lll111_ll_(name)#.strip(l111lll_ll_ (u"ࠬࠦࠧ⌨")))
	if l11lll1ll1l_ll_!=l111lll_ll_ (u"࠭ࠧ〈"): path = path+l111lll_ll_ (u"ࠧࠧࡶࡨࡼࡹࡃࠧ〉")+l1lll111_ll_(l11lll1ll1l_ll_.strip(l111lll_ll_ (u"ࠨࠢࠪ⌫")))
	listitem = xbmcgui.ListItem(name)
	if image!=l111lll_ll_ (u"ࠩࠪ⌬"):
		listitem.setArt({l111lll_ll_ (u"ࠪ࡭ࡨࡵ࡮ࠨ⌭"):image,l111lll_ll_ (u"ࠫࡹ࡮ࡵ࡮ࡤࠪ⌮"):image,l111lll_ll_ (u"ࠬ࡬ࡡ࡯ࡣࡵࡸࠬ⌯"):l111lll_ll_ (u"࠭ࠧ⌰"),})
		path = path+l111lll_ll_ (u"ࠧࠧ࡫ࡰࡥ࡬࡫࠽ࠨ⌱")+l1lll111_ll_(image.strip(l111lll_ll_ (u"ࠨࠢࠪ⌲")))
	else:
		listitem.setArt({l111lll_ll_ (u"ࠩ࡬ࡧࡴࡴࠧ⌳"):l1ll1l11lll_ll_,l111lll_ll_ (u"ࠪࡸ࡭ࡻ࡭ࡣࠩ⌴"):l11l1l1l1ll_ll_,l111lll_ll_ (u"ࠫ࡫ࡧ࡮ࡢࡴࡷࠫ⌵"):l111lll_ll_ (u"ࠬ࠭⌶"),})
	#listitem.setInfo(type=l111lll_ll_ (u"ࠨࡶࡪࡦࡨࡳࠧ⌷"),infoLabels={l111lll_ll_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ⌸"):name})
	if url!=l111lll_ll_ (u"ࠨࠩ⌹"): path = path+l111lll_ll_ (u"ࠩࠩࡹࡷࡲ࠽ࠨ⌺")+l1lll111_ll_(url.strip(l111lll_ll_ (u"ࠪࠤࠬ⌻")))
	l1l11l111ll_ll_ = []
	if mode in [235,238] and type==l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ⌼") and l111lll_ll_ (u"ࠬࡋࡐࡈࠩ⌽") in context:
		l11l1111lll_ll_ = l111lll_ll_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࠩ⌾")+l1ll11lll11_ll_+l111lll_ll_ (u"ࠧࡀ࡯ࡲࡨࡪࡃ࠲࠴࠺ࠩࡸࡪࡾࡴ࠾ࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠪࡺࡸ࡬࠾ࠩ⌿")+url
		l11ll1111l1_ll_ = l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠห้ฮัศ็ฯࠤฬ๊โศั่อࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⍀")
		l1l1l1llll1_ll_ = (l11ll1111l1_ll_,l111lll_ll_ (u"࡛ࠩࡆࡒࡉ࠮ࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࠫ⍁")+l11l1111lll_ll_+l111lll_ll_ (u"ࠪ࠭ࠬ⍂"))
		l1l11l111ll_ll_.append(l1l1l1llll1_ll_)
	elif mode in [265]:
		import l11l1l1ll1l_ll_
		length = l11l1l1ll1l_ll_.l1ll11lll1l_ll_(l11lll1ll1l_ll_,True)
		if length>0:
			l11l1111lll_ll_ = l111lll_ll_ (u"ࠫࡵࡲࡵࡨ࡫ࡱ࠾࠴࠵ࠧ⍃")+l1ll11lll11_ll_+l111lll_ll_ (u"ࠬࡅ࡭ࡰࡦࡨࡁ࠷࠼࠶ࠧࡶࡨࡼࡹࡃࠧ⍄")+l11lll1ll1l_ll_
			l11ll1111l1_ll_ = l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞็ึั่ࠥวว็ฬࠤวิัࠡ࠷࠳ࠤࠬ⍅")+l1l1ll1l111_ll_(l11lll1ll1l_ll_)+l111lll_ll_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⍆")
			l1l1l1llll1_ll_ = (l11ll1111l1_ll_,l111lll_ll_ (u"ࠨ࡚ࡅࡑࡈ࠴ࡒࡶࡰࡓࡰࡺ࡭ࡩ࡯ࠪࠪ⍇")+l11l1111lll_ll_+l111lll_ll_ (u"ࠩࠬࠫ⍈"))
			l1l11l111ll_ll_.append(l1l1l1llll1_ll_)
	import l11llllll1_ll_
	#l1ll1l_ll_(path,l1l111l1l1_ll_)
	l1l11l111ll_ll_ += l11llllll1_ll_.l1l1111l11_ll_(path)
	if type==l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⍉") and mode!=331:
		l11l1111lll_ll_ = path+l111lll_ll_ (u"ࠫࠫࡩ࡯࡯ࡶࡨࡼࡹࡃ࠶ࠨ⍊")
		l11ll1111l1_ll_ = l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡇࡈࡉࡊ࠵࠶࡝หฯ่๎้ࠦๅๅใࠣห้็๊ะ์๋࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⍋")
		l1l1l1llll1_ll_ = (l11ll1111l1_ll_,l111lll_ll_ (u"࠭ࡘࡃࡏࡆ࠲ࡗࡻ࡮ࡑ࡮ࡸ࡫࡮ࡴࠨࠨ⍌")+l11l1111lll_ll_+l111lll_ll_ (u"ࠧࠪࠩ⍍"))
		l1l11l111ll_ll_.append(l1l1l1llll1_ll_)
	if mode==331:
		l1l11l111ll_ll_.append((l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡊࡋࡌࡆ࠱࠲ࡠัี็ࠠๆๆไࠤฬ๊แ๋ัํ์ࡠ࠵ࡃࡐࡎࡒࡖࡢࠦࠧ⍎"),l111lll_ll_ (u"࡛ࠩࡆࡒࡉ࠮ࡓࡷࡱࡔࡱࡻࡧࡪࡰࠫࠫ⍏")+path+l111lll_ll_ (u"ࠪࠪࡨࡵ࡮ࡵࡧࡻࡸࡂ࠼࡟ࡓࡇࡐࡓ࡛ࡋࠧ⍐")+l111lll_ll_ (u"ࠫ࠮࠭⍑")))
	listitem.addContextMenuItems(l1l11l111ll_ll_)
	if type in [l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ⍒"),l111lll_ll_ (u"࠭࡬ࡪࡸࡨࠫ⍓")]: isFolder = False
	elif type==l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⍔"):
		isFolder = False
		listitem.setInfo(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⍕"),{l111lll_ll_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ⍖"):l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⍗")})
		if l11lll1l1l1_ll_!=l111lll_ll_ (u"ࠫࠬ⍘"):
			duration = l111lll_ll_ (u"ࠬ࠶࠺࠱࠼࠳࠾࠵ࡀ࠰࠻ࠩ⍙")+l11lll1l1l1_ll_
			dummy,days,hours,minutes,seconds = duration.rsplit(l111lll_ll_ (u"࠭࠺ࠨ⍚"),4)
			l1l1l1ll111_ll_ = int(days)*24*l11111ll11_ll_+int(hours)*l11111ll11_ll_+int(minutes)*60+int(seconds)
			listitem.setInfo(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭⍛"),{l111lll_ll_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ⍜"):l1l1l1ll111_ll_})
		listitem.setProperty(l111lll_ll_ (u"ࠩࡌࡷࡕࡲࡡࡺࡣࡥࡰࡪ࠭⍝"),l111lll_ll_ (u"ࠪࡸࡷࡻࡥࠨ⍞"))
		xbmcplugin.setContent(l1l1l11l1ll_ll_,l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࡶࠫ⍟"))
	elif type==l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⍠"):
		isFolder = True
	#listitem.setInfo(type=l111lll_ll_ (u"ࠨࡶࡪࡦࡨࡳࠧ⍡"),infoLabels={l111lll_ll_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ⍢"):name})
	#xbmcplugin.addDirectoryItem(handle=l1l1l11l1ll_ll_,url=path,listitem=listitem,isFolder=isFolder)
	return (path,listitem,isFolder)
def l11lllllll_ll_(path=l111lll_ll_ (u"ࠨࠩ⍣")):
	l1ll1lllll1_ll_ = {l111lll_ll_ (u"ࠩࡷࡽࡵ࡫ࠧ⍤"):l111lll_ll_ (u"ࠪࠫ⍥"),l111lll_ll_ (u"ࠫࡲࡵࡤࡦࠩ⍦"):l111lll_ll_ (u"ࠬ࠭⍧"),l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪ⍨"):l111lll_ll_ (u"ࠧࠨ⍩"),l111lll_ll_ (u"ࠨࡶࡨࡼࡹ࠭⍪"):l111lll_ll_ (u"ࠩࠪ⍫"),l111lll_ll_ (u"ࠪࡴࡦ࡭ࡥࠨ⍬"):l111lll_ll_ (u"ࠫࠬ⍭"),l111lll_ll_ (u"ࠬࡴࡡ࡮ࡧࠪ⍮"):l111lll_ll_ (u"࠭ࠧ⍯"),l111lll_ll_ (u"ࠧࡪ࡯ࡤ࡫ࡪ࠭⍰"):l111lll_ll_ (u"ࠨࠩ⍱"),l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ⍲"):l111lll_ll_ (u"ࠪࠫ⍳")}
	if path==l111lll_ll_ (u"ࠫࠬ⍴"): path = l11ll11ll11_ll_
	if l111lll_ll_ (u"ࠬࡅࠧ⍵") in path: path = path.split(l111lll_ll_ (u"࠭࠿ࠨ⍶"),1)[1]
	l1ll111_ll_,l1ll1llll1l_ll_ = l1l11l1111l_ll_(path)
	args = dict(l1ll1lllll1_ll_.items()+l1ll1llll1l_ll_.items())
	mode = args[l111lll_ll_ (u"ࠧ࡮ࡱࡧࡩࠬ⍷")]
	url = l1111_ll_(args[l111lll_ll_ (u"ࠨࡷࡵࡰࠬ⍸")])
	text = l1111_ll_(args[l111lll_ll_ (u"ࠩࡷࡩࡽࡺࠧ⍹")])
	page = l1111_ll_(args[l111lll_ll_ (u"ࠪࡴࡦ࡭ࡥࠨ⍺")])
	type = l1111_ll_(args[l111lll_ll_ (u"ࠫࡹࡿࡰࡦࠩ⍻")])
	name = l1111_ll_(args[l111lll_ll_ (u"ࠬࡴࡡ࡮ࡧࠪ⍼")])
	image = l1111_ll_(args[l111lll_ll_ (u"࠭ࡩ࡮ࡣࡪࡩࠬ⍽")])
	context = args[l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨ⍾")]
	#name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ⍿"))
	#image = xbmc.getInfoLabel(l111lll_ll_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩ⎀"))
	if mode==l111lll_ll_ (u"ࠪࠫ⎁"): type = l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⎂") ; mode = l111lll_ll_ (u"ࠬ࠸࠶࠱ࠩ⎃")
	return type,name,url,mode,image,page,text,context
def l111111_ll_(l1l11lll1ll_ll_,method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_=True,l11lll1l11l_ll_=True):
	#l1l1l11lll1_ll_(url,headers,data)
	#response = l11lll11111_ll_(method,url,data,headers,allow_redirects,l1111l1l11_ll_,source)
	if l1l11lll1ll_ll_==l1l11lll_ll_: return l1l11ll11ll_ll_(method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	response = l1llll11l1l_ll_(l111lll_ll_ (u"࠭ࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࠩ⎄"),[method,url,data,headers,allow_redirects,l1111l1l11_ll_,source])
	if response:
		l1l1l11lll1_ll_(url,headers,data)
		return response
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡴࡶࡤࡶࡹ࠭⎅"),url)
	response = l1l11ll11ll_ll_(method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࡨ࡬ࡲ࡮ࡹࡨࠨ⎆"),url)
	code = response.code
	reason = response.reason
	if response.succeeded:
		l1111l1lll_ll_(l111lll_ll_ (u"ࠩࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࠬ⎇"),[method,url,data,headers,allow_redirects,l1111l1l11_ll_,source],response,l1l11lll1ll_ll_)
	return response
def l1l11llllll_ll_(proxy,method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_=True,l11lll1l11l_ll_=True):
	l1ll1ll1l11_ll_,proxy_port = proxy.split(l111lll_ll_ (u"ࠪ࠾ࠬ⎈"))
	#l1ll11l_ll_(l111lll_ll_ (u"ฺ๊ࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ⎉"),l111lll_ll_ (u"ูࠬรอำหࠤࠬ⎊")+name,time=2000)
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⎋"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡘࡷࡿࡩ࡯ࡩࠣࠫ⎌")+name+l111lll_ll_ (u"ࠨࠢࡶࡩࡷࡼࡥࡳࠢࠣࠤࡕࡸ࡯ࡹࡻ࠽ࠤࡠࠦࠧ⎍")+proxy+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⎎")+url+l111lll_ll_ (u"ࠪࠤࡢ࠭⎏"))
	url = url+l111lll_ll_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀࠫ⎐")+proxy
	response = l111111_ll_(l1l11lll_ll_,method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	if url in response.content: response.succeeded = False
	if not response.succeeded:
		#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⎑"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡉࡥ࡮ࡲࡥࡥࠢࠪ⎒")+name+l111lll_ll_ (u"ࠧࠡࡵࡨࡶࡻ࡫ࡲࠡࠢࠣࡔࡷࡵࡸࡺ࠼ࠣ࡟ࠥ࠭⎓")+proxy+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⎔")+url+l111lll_ll_ (u"ࠩࠣࡡࠬ⎕"))
		raise SystemError(l111lll_ll_ (u"ࠪࡌ࡙࡚ࡐࠡࡔࡨࡵࡺ࡫ࡳࡵࠢࡉࡥ࡮ࡲࡵࡳࡧࠪ⎖"))
	#else: l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⎗"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡕࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ⎘")+proxy+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⎙")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⎚"))
	return response
def l1l1l1111ll_ll_(url):
	#url = url.decode(l111lll_ll_ (u"ࠨࡤࡤࡷࡪ࠼࠴ࠨ⎛"))
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࡊࡉ࡙ࡥࡐࡓࡑ࡛ࡍࡊ࡙࡟ࡍࡋࡖࡘࠬ⎜"))
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ⎝"),url,l111lll_ll_ (u"ࠫࠬ⎞"),l111lll_ll_ (u"ࠬ࠭⎟"),True,False,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡈࡇࡗࡣࡕࡘࡏ࡙ࡋࡈࡗࡤࡒࡉࡔࡖ࠰࠵ࡸࡺࠧ⎠"),True,False)
	l1l1l1ll11l_ll_ = []
	if response.succeeded:
		html = response.content
		proxies = html.replace(l111lll_ll_ (u"ࠧ࡝ࡴࠪ⎡"),l111lll_ll_ (u"ࠨࠩ⎢")).strip(l111lll_ll_ (u"ࠩ࡟ࡲࠬ⎣")).split(l111lll_ll_ (u"ࠪࡠࡳ࠭⎤"))
		l1l1l1ll11l_ll_ = []
		for proxy in proxies:
			if proxy.count(l111lll_ll_ (u"ࠫ࠳࠭⎥"))==3: l1l1l1ll11l_ll_.append(proxy)
	return l1l1l1ll11l_ll_
def l11lll11111_ll_(*args):
	l1l1l11l111_ll_ = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠺࠵࠯࠵࠶࠲࠶࠽࠮࠲࠴࠺࠳ࡦࡶࡩ࠰ࡲࡵࡳࡽࡿ࠿ࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡷࡵ࡫ࡥࡥ࠿࠴࠴ࠫࡲࡡࡴࡶࡢࡧ࡭࡫ࡣ࡬࠿࠴࠴ࠫ࡮ࡴࡵࡲࡶࡁࡹࡸࡵࡦࠨࡳࡳࡸࡺ࠽ࡵࡴࡸࡩࠫ࡬࡯ࡳ࡯ࡤࡸࡂࡺࡸࡵࠨ࡯࡭ࡲ࡯ࡴ࠾࠳࠳ࠪࡨࡵࡵ࡯ࡶࡵࡽࡂࡔࡌ࠭ࡄࡈ࠰ࡉࡋࠬࡇࡔ࠯ࡋࡇ࠲ࡔࡓࠩ⎦")
	l1ll11ll11l_ll_ = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡲ࡬࠲ࡵࡸ࡯ࡹࡻࡶࡧࡷࡧࡰࡦ࠰ࡦࡳࡲ࠵࠿ࡳࡧࡴࡹࡪࡹࡴ࠾ࡦ࡬ࡷࡵࡲࡡࡺࡲࡵࡳࡽ࡯ࡥࡴࠨࡳࡶࡴࡾࡹࡵࡻࡳࡩࡂ࡮ࡴࡵࡲࠩࡸ࡮ࡳࡥࡰࡷࡷࡁ࠶࠶࠰࠱࠲ࠩࡷࡸࡲ࠽ࡺࡧࡶࠪࡱ࡯࡭ࡪࡶࡀ࠵࠵ࠬࡣࡰࡷࡱࡸࡷࡿ࠽ࡏࡎ࠯ࡆࡊ࠲ࡄࡆ࠮ࡉࡖ࠱ࡍࡂ࠭ࡖࡕࠫ⎧")
	l1l1l1ll1l1_ll_ = l1l1l1111ll_ll_(l1l1l11l111_ll_)
	l1l1l1ll11l_ll_ = l1l1l1111ll_ll_(l1ll11ll11l_ll_)
	l1ll1l1llll_ll_ = l1l1l1ll1l1_ll_+l1l1l1ll11l_ll_
	l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭⎨"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡌࡵࡴࠡࡲࡵࡳࡽ࡯ࡥࡴࠢ࡯࡭ࡸࡺࠠࠡࠢ࠴ࡷࡹ࠱࠲࡯ࡦ࠽ࠤࡠࠦࠧ⎩")+str(len(l1l1l1ll1l1_ll_))+l111lll_ll_ (u"ࠩ࠮ࠫ⎪")+str(len(l1l1l1ll11l_ll_))+l111lll_ll_ (u"ࠪࠤࡢ࠭⎫"))
	proxy = settings.getSetting(l111lll_ll_ (u"ࠫࡵࡸ࡯ࡹࡻ࠱ࡰࡦࡹࡴࠨ⎬"))
	response = l1l1ll1l1ll_ll_()
	response.succeeded = False
	settings.setSetting(l111lll_ll_ (u"ࠬࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ⎭"),l111lll_ll_ (u"࠭ࠧ⎮"))
	if proxy!=l111lll_ll_ (u"ࠧࠨ⎯") or l1ll1l1llll_ll_:
		id,timeout = 0,10
		l1ll1111111_ll_ = len(l1ll1l1llll_ll_)
		l1ll111ll11_ll_ = timeout
		if l1ll1111111_ll_>l1ll111ll11_ll_: counts = l1ll111ll11_ll_
		else: counts = l1ll1111111_ll_
		l11lll1l1ll_ll_ = random.sample(l1ll1l1llll_ll_,counts)
		if proxy!=l111lll_ll_ (u"ࠨࠩ⎰"): l11lll1l1ll_ll_ = [proxy]+l11lll1l1ll_ll_
		threads = l11ll11lll_ll_(False,False)
		t1 = time.time()
		while time.time()-t1<=timeout and not threads.l11lll11l1l_ll_:
			if id<counts:
				proxy = l11lll1l1ll_ll_[id]
				threads.start_new_thread(id,l1l11llllll_ll_,proxy,*args)
			time.sleep(1)
			id += 1
			#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⎱"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡔࡳࡻ࡬ࡲ࡬ࡀࠠࠡࠢࡓࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ⎲")+proxy+l111lll_ll_ (u"ࠫࠥࡣࠧ⎳"))
		l11lll11l1l_ll_ = threads.l11lll11l1l_ll_
		if l11lll11l1l_ll_:
			l11ll11111_ll_ = threads.l11ll11111_ll_
			l11ll111l1l_ll_ = l11lll11l1l_ll_[0]
			response = l11ll11111_ll_[l11ll111l1l_ll_]
			proxy = l11lll1l1ll_ll_[int(l11ll111l1l_ll_)]
			settings.setSetting(l111lll_ll_ (u"ࠬࡶࡲࡰࡺࡼ࠲ࡱࡧࡳࡵࠩ⎴"),proxy)
			if l11ll111l1l_ll_!=0: l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊࡥࡌࡊࡐࡈࡗࠬ⎵"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡗࡺࡩࡣࡦࡵࡶ࠾ࠥࠦࠠࡑࡴࡲࡼࡾࡀࠠ࡜ࠢࠪ⎶")+proxy+l111lll_ll_ (u"ࠨࠢࡠࠫ⎷"))
			else: l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ⎸"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡸࡹ࠺ࠡࠢࠣࡗࡦࡼࡥࡥࠢࡳࡶࡴࡾࡹ࠻ࠢ࡞ࠤࠬ⎹")+proxy+l111lll_ll_ (u"ࠫࠥࡣࠧ⎺"))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⎻"),l111lll_ll_ (u"࠭ࡰࡳࡱࡻ࡭ࡪࡹࡌࡊࡕࡗ࠶ࠥࡀ࠺ࠡࠩ⎼")+str(l11lll1l1ll_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ⎽"),l111lll_ll_ (u"ࠨࡲࡵࡳࡽ࡯ࡥࡴࡎࡌࡗ࡙ࠦ࠺࠻ࠢࠪ⎾")+str(l1ll1l1llll_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⎿"),l111lll_ll_ (u"ࠪࡪ࡮ࡴࡩࡴࡪࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭⏀")+str(threads.l11lll11l1l_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⏁"),l111lll_ll_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࡑࡏࡓࡕࠢ࠽࠾ࠥ࠭⏂")+str(threads.l1lll111l11_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⏃"),l111lll_ll_ (u"ࠧࡳࡧࡶࡹࡱࡺࡳࡅࡋࡆࡘࠥࡀ࠺ࠡࠩ⏄")+str(threads.l11ll11111_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⏅"),l111lll_ll_ (u"ࠩࡨࡰࡵࡧࡳࡦࡦࡷ࡭ࡲ࡫ࡄࡊࡅࡗࠤ࠿ࡀࠠࠨ⏆")+str(threads.l1ll11l1l11_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⏇"),l111lll_ll_ (u"ࠫࡸࡵࡲࡵࡧࡧࡐࡎ࡙ࡔࠡ࠼࠽ࠤࠬ⏈")+str(l11ll1lll11_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⏉"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࠪ⏊")+l1l1ll1l11l_ll_+l111lll_ll_ (u"ࠧࠡࠢࠣࠫ⏋")+str(l11ll1lll11_ll_))
	return response
def l111ll1_ll_(l1l11lll1ll_ll_,url,data,headers,l1111l1l11_ll_,source):
	if data==l111lll_ll_ (u"ࠨࠩ⏌") or l111lll_ll_ (u"ࠩࡧ࡭ࡨࡺࠧ⏍") in str(type(data)): method = l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ⏎")
	else:
		method = l111lll_ll_ (u"ࠫࡕࡕࡓࡕࠩ⏏")
		data = l1111_ll_(data)
		dummy,data = l1l11l1111l_ll_(data)
	response = l111111_ll_(l1l11lll1ll_ll_,method,url,data,headers,True,l1111l1l11_ll_,source)
	html = str(response.content)
	return html
l111lll_ll_ (u"ࠧࠨࠢࠋࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠡ࠳࠴࠵ࠬ࠲ࠧࠨࠫࠍࠍ࡮࡬ࠠࡦࡺࡳ࡭ࡷࡿ࠽࠾ࡐࡒࡣࡈࡇࡃࡉࡇ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࡔࡖࡅࡏࡗࡕࡐ࠭ࡻࡲ࡭࠮ࡧࡥࡹࡧࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸ࠲ࡳࡰࡷࡵࡧࡪ࠯ࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡔࡈࡅࡉࡥࡆࡓࡑࡐࡣࡘࡗࡌ࠴ࠪࠪࡓࡕࡋࡎࡖࡔࡏࠫ࠱ࡡࡵࡳ࡮࠯ࡨࡦࡺࡡ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡶ࡬ࡴࡽࡄࡪࡣ࡯ࡳ࡬ࡹࠬࡴࡱࡸࡶࡨ࡫࡝ࠪࠌࠌ࡭࡫ࠦࡨࡵ࡯࡯࠾ࠥࡸࡥࡵࡷࡵࡲࠥ࡮ࡴ࡮࡮ࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐ࠭ࡻࡲ࡭࠮ࡧࡥࡹࡧࠬࡩࡧࡤࡨࡪࡸࡳ࠭ࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸ࠲ࡳࡰࡷࡵࡧࡪ࠯ࠊࠊ࡫ࡩࠤࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪࠤࡳࡵࡴࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠍࠍࠎ࡝ࡒࡊࡖࡈࡣ࡙ࡕ࡟ࡔࡓࡏ࠷࠭࠭ࡏࡑࡇࡑ࡙ࡗࡒࠧ࠭࡝ࡸࡶࡱ࠲ࡤࡢࡶࡤ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱ࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠯ࡷࡴࡻࡲࡤࡧࡠ࠰࡭ࡺ࡭࡭࠮ࡨࡼࡵ࡯ࡲࡺࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤ࡭ࡺ࡭࡭ࠌࠍࡨࡪ࡬ࠠࡐࡒࡈࡒ࡚ࡘࡌࠩࡷࡵࡰ࠱ࡪࡡࡵࡣ࠯࡬ࡪࡧࡤࡦࡴࡶ࠰ࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠮ࡶࡳࡺࡸࡣࡦࠫ࠽ࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࡶࡸࡷ࠮ࡴࡺࡲࡨࠬࡩࡧࡴࡢࠫࠬ࠰ࡸࡺࡲࠩࡦࡤࡸࡦ࠯ࠩࠋࠋ࡬ࡪࠥࡪࡡࡵࡣࡀࡁࠬ࠭ࠠࡰࡴࠣࠫࡩ࡯ࡣࡵࠩࠣ࡭ࡳࠦࡳࡵࡴࠫࡸࡾࡶࡥࠩࡦࡤࡸࡦ࠯ࠩ࠻ࠢࡰࡩࡹ࡮࡯ࡥࠢࡀࠤࠬࡍࡅࡕࠩࠍࠍࡪࡲࡳࡦ࠼ࠍࠍࠎࡳࡥࡵࡪࡲࡨࠥࡃࠠࠨࡒࡒࡗ࡙࠭ࠊࠊࠋࡧࡥࡹࡧࠠ࠾ࠢࡘࡒࡖ࡛ࡏࡕࡇࠫࡨࡦࡺࡡࠪࠌࠌࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡪࡡࡵࡣ࠱ࡷࡵࡲࡩࡵࠪࠪࠪࠬ࠯ࠊࠊࠋࡧࡥࡹࡧࠠ࠾ࠢࡾࢁࠏࠏࠉࡧࡱࡵࠤ࡮ࡺࡥ࡮ࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊ࡭ࡨࡽ࠱ࡼࡡ࡭ࡷࡨࠤࡂࠦࡩࡵࡧࡰ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡂ࠭ࠬ࠲ࠫࠍࠍࠎࠏࡤࡢࡶࡤ࡟ࡰ࡫ࡹ࡞ࠢࡀࠤࡻࡧ࡬ࡶࡧࠍࠍࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡࡑࡓࡉࡓ࡛ࡒࡍࡡࡕࡉࡖ࡛ࡅࡔࡖࡖࠬࡲ࡫ࡴࡩࡱࡧ࠰ࡺࡸ࡬࠭ࡦࡤࡸࡦ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࡕࡴࡸࡩ࠱ࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵ࠯ࡷࡴࡻࡲࡤࡧࠬࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡹࡴࡳࠪࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡨࡵ࡮ࡵࡧࡱࡸ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠠࡩࡶࡰࡰࠏࠨࠢࠣ⏐")
class l1l1ll1l1ll_ll_(): pass
def l1l111l1ll1_ll_(connection,l11lll11l11_ll_):
	#l1ll1l_ll_(l11lll11l11_ll_,l111lll_ll_ (u"࠭ࠧ⏑"))
	l11l1l111ll_ll_ = connection.create_connection
	def l1lll11l11l_ll_(address,*args,**kwargs):
		host,port = address
		ip = l11l111l111_ll_(host,l11lll11l11_ll_)
		if ip: host = ip[0]
		else:
			l11ll1111ll_ll_.remove(l11lll11l11_ll_)
			if l11ll1111ll_ll_:
				l1ll1l11l11_ll_ = l11ll1111ll_ll_[0]
				#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ⏒"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࡛ࠡࠢࠣ࡮ࡲ࡬ࠡࡶࡵࡽࠥࡺࡨࡦࠢࡲࡸ࡭࡫ࡲࠡࡆࡑࡗ࠿ࡡࠠࠨ⏓")+l1ll1l11l11_ll_+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡉࡱࡶࡸ࠿ࡡࠠࠨ⏔")+str(host)+l111lll_ll_ (u"ࠪࠤࡢ࠭⏕"))
				ip = l11l111l111_ll_(host,l1ll1l11l11_ll_)
				if ip: host = ip[0]
		#l1ll1l_ll_(str(host),str(ip))
		address = (host,port)
		return l11l1l111ll_ll_(address,*args,**kwargs)
	connection.create_connection = l1lll11l11l_ll_
	return l11l1l111ll_ll_
def l1l1l11lll1_ll_(url,headers,data):
	l1ll11l1l_ll_ = str(headers)[0:250].replace(l111lll_ll_ (u"ࠫࡡࡴࠧ⏖"),l111lll_ll_ (u"ࠬࡢ࡜࡯ࠩ⏗")).replace(l111lll_ll_ (u"࠭࡜ࡳࠩ⏘"),l111lll_ll_ (u"ࠧ࡝࡞ࡵࠫ⏙")).replace(l111lll_ll_ (u"ࠨࠢࠣࠤࠥ࠭⏚"),l111lll_ll_ (u"ࠩࠣࠫ⏛")).replace(l111lll_ll_ (u"ࠪࠤࠥࠦࠧ⏜"),l111lll_ll_ (u"ࠫࠥ࠭⏝"))
	if len(str(headers))>250: l1ll11l1l_ll_ = l1ll11l1l_ll_+l111lll_ll_ (u"ࠬࠦ࠮࠯࠰ࠪ⏞")
	data2 = str(data)[0:250].replace(l111lll_ll_ (u"࠭࡜࡯ࠩ⏟"),l111lll_ll_ (u"ࠧ࡝࡞ࡱࠫ⏠")).replace(l111lll_ll_ (u"ࠨ࡞ࡵࠫ⏡"),l111lll_ll_ (u"ࠩ࡟ࡠࡷ࠭⏢")).replace(l111lll_ll_ (u"ࠪࠤࠥࠦࠠࠨ⏣"),l111lll_ll_ (u"ࠫࠥ࠭⏤")).replace(l111lll_ll_ (u"ࠬࠦࠠࠡࠩ⏥"),l111lll_ll_ (u"࠭ࠠࠨ⏦"))
	if len(str(data))>250: data2 = data2+l111lll_ll_ (u"ࠧࠡ࠰࠱࠲ࠬ⏧")
	l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⏨"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭⏩")+url+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡊࡨࡥࡩ࡫ࡲࡴ࠼ࠣ࡟ࠥ࠭⏪")+str(l1ll11l1l_ll_)+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡇࡥࡹࡧ࠺ࠡ࡝ࠣࠫ⏫")+data2+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⏬"))
	return
def l1l11ll11ll_ll_(method,url,data,headers,allow_redirects,l1111l1l11_ll_,source,l1l1l11l1l1_ll_=True,l11lll1l11l_ll_=True):
	l1l1l11lll1_ll_(url,headers,data)
	#l1ll1l_ll_(source,str(l1l1l11l1l1_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠩ⏭")+str(l11lll1l11l_ll_))
	if data==l111lll_ll_ (u"ࠧࠨ⏮"): data = {}
	if headers==l111lll_ll_ (u"ࠨࠩ⏯"): headers = {l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⏰"):None}
	if l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ⏱") not in headers.keys(): headers[l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⏲")] = None
	if allow_redirects==l111lll_ll_ (u"ࠬ࠭⏳"): allow_redirects = True
	if l1111l1l11_ll_==l111lll_ll_ (u"࠭ࠧ⏴"): l1111l1l11_ll_ = True
	#url = url + l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳ࠾࠴࠵࠱࠹࠺࠱࠵࠻࠼࠮࠶࠻࠱࠵࠼ࡀ࠸࠲࠳࠻ࠫ⏵")
	import requests
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1ll1ll111l_ll_(url)
	l11lll11l11_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ⏶"))
	l1l11lllll1_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩࡧࡲࡸ࠴ࡳࡵࡣࡷࡹࡸ࠭⏷"))
	l1ll111llll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠪࡴࡷࡵࡸࡺ࠰ࡶࡸࡦࡺࡵࡴࠩ⏸"))
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊ࡫ࡩࠤࠬ࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳࠨࠢ࡬ࡲࠥࡻࡲ࡭࠴࠽ࠎࠎࠏࡳࡩࡱࡺࡈ࡮ࡧ࡬ࡰࡩࡶࠤࡂࠦࡆࡢ࡮ࡶࡩࠏࠏࠉࠤࡦࡱࡷࡤࡹࡥࡳࡸࡨࡶࠥࡃࠠࡅࡐࡖࡣࡘࡋࡒࡗࡇࡕࡗࡠ࠶࡝ࠋࠋࠌࠧࡵࡸ࡯ࡹࡻࡢࡷࡹࡧࡴࡶࡵࠣࡁࠥ࠭ࡁࡖࡖࡒࠫࠏࠏࠉࠤࡦࡱࡷࡤࡹࡴࡢࡶࡸࡷࠥࡃࠠࠨࡃࡘࡘࡔ࠭ࠊࠊࠋࠦࡥࡱࡲ࡯ࡸࡡࡧࡲࡸࡥࡦࡪࡺࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࠎࠩࡡ࡭࡮ࡲࡻࡤࡶࡲࡰࡺࡼࡣ࡫࡯ࡸࠡ࠿ࠣࡘࡷࡻࡥࠋࠋࠥࠦࠧ⏹")
	if l11lll11l11_ll_==l111lll_ll_ (u"ࠬ࠭⏺") and l1l11lllll1_ll_ in [l111lll_ll_ (u"࠭ࠧ⏻"),l111lll_ll_ (u"ࠧࡂࡗࡗࡓࠬ⏼")]:
		l11lll11l11_ll_ = l11ll1111ll_ll_[0]
		settings.setSetting(l111lll_ll_ (u"ࠨࡦࡱࡷ࠳ࡹࡥࡳࡸࡨࡶࠬ⏽"),l11lll11l11_ll_)
	elif l1l11lllll1_ll_ in [l111lll_ll_ (u"ࠩࠪ⏾"),l111lll_ll_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ⏿"),l111lll_ll_ (u"ࠫࡆ࡙ࡋࠨ␀")]:
		l1l11lllll1_ll_ = l111lll_ll_ (u"ࠬࡇࡕࡕࡑࠪ␁")
		l11lll11l11_ll_ = l11ll1111ll_ll_[0]
		settings.setSetting(l111lll_ll_ (u"࠭ࡤ࡯ࡵ࠱ࡷࡹࡧࡴࡶࡵࠪ␂"),l1l11lllll1_ll_)
		settings.setSetting(l111lll_ll_ (u"ࠧࡥࡰࡶ࠲ࡸ࡫ࡲࡷࡧࡵࠫ␃"),l11lll11l11_ll_)
	if l1ll111llll_ll_ in [l111lll_ll_ (u"ࠨࠩ␄"),l111lll_ll_ (u"ࠩࡈࡒࡆࡈࡌࡆࡆࠪ␅"),l111lll_ll_ (u"ࠪࡈࡎ࡙ࡁࡃࡎࡈࡈࠬ␆"),l111lll_ll_ (u"ࠫࡆ࡙ࡋࠨ␇")]:
		l1ll111llll_ll_ = l111lll_ll_ (u"ࠬࡇࡕࡕࡑࠪ␈")
		settings.setSetting(l111lll_ll_ (u"࠭ࡰࡳࡱࡻࡽ࠳ࡹࡴࡢࡶࡸࡷࠬ␉"),l1ll111llll_ll_)
	if l11lll1llll_ll_==l111lll_ll_ (u"ࠧࠨ␊"): l11lll1llll_ll_ = l11lll11l11_ll_
	if l11lll1llll_ll_==None and l1l11lllll1_ll_==l111lll_ll_ (u"ࠨࡃࡏ࡛ࡆ࡟ࡓࠨ␋") and l1l1l11l1l1_ll_: l11lll1llll_ll_ = l11lll11l11_ll_
	if l111lll_ll_ (u"ࠩࡌࡊࡎࡒࡍࠨ␌") in source: timeout = 20
	elif l111lll_ll_ (u"ࠪࡅࡐ࡝ࡁࡎࠩ␍") in source: timeout = 20
	elif l111lll_ll_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ␎") in source: timeout = 10
	elif l111lll_ll_ (u"ࠬ࡭ࡩࡵࡧࡨࠫ␏") in l1ll111_ll_: timeout = 10
	elif l11ll1ll11l_ll_!=None: timeout = 10
	else: timeout = 5
	if l11ll1ll11l_ll_!=None:
		proxies = {l111lll_ll_ (u"ࠨࡨࡵࡶࡳࠦ␐"):l11ll1ll11l_ll_,l111lll_ll_ (u"ࠢࡩࡶࡷࡴࡸࠨ␑"):l11ll1ll11l_ll_}
		l11l1l11ll1_ll_ = l11ll1ll11l_ll_
	else: proxies,l11l1l11ll1_ll_ = {},l111lll_ll_ (u"ࠨࠩ␒")
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ␓"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡐࡳࡱࡻࡽ࠿ࡡࠠࠨ␔")+l1ll111llll_ll_+l111lll_ll_ (u"ࠫࡂ࠭␕")+l11l1l11ll1_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡈࡓ࡙࠺࡜ࠢࠪ␖")+l1l11lllll1_ll_+l111lll_ll_ (u"࠭࠽ࠨ␗")+l11lll11l11_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥࡓࡍ࠼࡞ࠤࠬ␘")+str(l11l1llll1l_ll_!=None)+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡓࡰࡷࡵࡧࡪࡀࠠ࡜ࠢࠪ␙")+source+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ␚")+url+l111lll_ll_ (u"ࠪࠤࡢ࠭␛"))
	#if l11l1llll1l_ll_!=None and l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠫฯ็ู๋ๆࠣฮู็๊าࠢࡖࡗࡑ࠭␜"),l111lll_ll_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ␝"),time=2000)
	if l11lll1llll_ll_!=None and l1l11lllll1_ll_!=l111lll_ll_ (u"࠭ࡓࡕࡑࡓࠫ␞"):
		import urllib3.util.connection as connection
		l11l1l111ll_ll_ = l1l111l1ll1_ll_(connection,l11lll11l11_ll_)
		#if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠧหใ฼๎้ࠦࡄࡏࡕࠣี็๋࠺ࠡࠩ␟")+l11lll1llll_ll_,l111lll_ll_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ␠"),time=2000)
		#l1ll1l_ll_(str(type(l11lll11l11_ll_)),str(l11lll11l11_ll_))
	if l11l1llll1l_ll_!=None: verify = True
	else: verify = False
	l111lll_ll_ (u"ࠤࠥࠦࠏࠏࡩࡧࠢࠪࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨࠫࠥ࡯࡮ࠡࡷࡵࡰ࠷ࡀࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌࡷࡴࡩ࡫࠳࠴ࠣࡁࠥࡹ࡯ࡤ࡭ࡨࡸ࠳ࡹ࡯ࡤ࡭ࡨࡸ࠭ࡹ࡯ࡤ࡭ࡨࡸ࠳ࡇࡆࡠࡋࡑࡉ࡙࠲ࠠࡴࡱࡦ࡯ࡪࡺ࠮ࡔࡑࡆࡏࡤ࡙ࡔࡓࡇࡄࡑ࠮ࠐࠉࠊࠋࡵࡩࡸࡻ࡬ࡵ࠴࠵ࠤࡂࠦࡳࡰࡥ࡮࠶࠷࠴ࡣࡰࡰࡱࡩࡨࡺ࡟ࡦࡺࠫࠬࠬ࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠭ࠬ࠹࠲ࠬ࠭ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠋࠋࠥࠦࠧ␡")
	try:
		if method==l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨ␢") and allow_redirects==True:
			l11ll1_ll_ = l1ll111_ll_
			for i in range(10):
				#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠫ࠶࠷࠱࠲࠳ࠪ␣"))
				response = requests.request(method,l11ll1_ll_,data=data,headers=headers,verify=verify,allow_redirects=False,timeout=timeout,proxies=proxies)
				#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠬ࠸࠲࠳࠴࠵ࠫ␤"))
				if response.status_code<300 or response.status_code>399: break
				l11ll1_ll_ = response.headers[l111lll_ll_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ␥")]
		else: response = requests.request(method,l1ll111_ll_,data=data,headers=headers,verify=verify,allow_redirects=allow_redirects,timeout=timeout,proxies=proxies)
		code,reason = response.status_code,response.reason
		response.raise_for_status()
		succeeded = True
	except requests.exceptions.HTTPError as err:
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠧ࠵࠶࠷࠸࠹࠭␦"))
		# it l1l11lll111_ll_ l1ll1ll1_ll_ if response.raise_for_status() is l1lll1111l1_ll_
		# code,reason = re.findall(l111lll_ll_ (u"ࠨࠪ࡟ࡨ࠰࠯࠮ࠫࡁ࠽ࠤ࠭࠴ࠪࡀࠫ࠽ࠫ␧"),err.message)[0]
		succeeded = False
	except requests.exceptions.Timeout as err:
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠩ࠸࠹࠺࠻࠵ࠨ␨"))
		reason,code = str(err.message).split(l111lll_ll_ (u"ࠪ࠾ࠥ࠭␩"))[1],-1
		succeeded = False
	except requests.exceptions.ConnectionError as err:
		#l1ll1l_ll_(str(err.message),str(err.message[0]))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ␪"),str(err.message))
		reason,code = l111lll_ll_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳࠦࡅࡳࡴࡲࡶࠬ␫"),-1
		try:
			error = err.message[0]
			reason,code = error,-1
			if l111lll_ll_ (u"࠭ࡅࡳࡴࡱࡳࠬ␬") in error: code,reason = re.findall(l111lll_ll_ (u"ࠢ࡝࡝ࡈࡶࡷࡴ࡯ࠡࠪ࡟ࡨ࠰࠯࡜࡞ࠢࠫ࠲࠯ࡅࠩࠨࠤ␭"),error)[0]
			elif l111lll_ll_ (u"ࠨ࠮ࠣࡩࡷࡸ࡯ࡳࠪࠪ␮") in error: code,reason = re.findall(l111lll_ll_ (u"ࠤ࠯ࠤࡪࡸࡲࡰࡴ࡟ࠬ࠭ࡢࡤࠬࠫ࠯ࠤࠬ࠮࠮ࠫࡁࠬࠫࠧ␯"),error)[0]
			elif error.count(l111lll_ll_ (u"ࠪ࠾ࠬ␰"))>=2: reason,code = re.findall(l111lll_ll_ (u"ࠫ࠿ࠦࠨ࠯ࠬࡂ࠭࠿࠴ࠪࡀࠪ࡟ࡨ࠰࠯ࠧ␱"),error)[0]
			#l1ll1l_ll_(str(code),reason)
		except: pass
		succeeded = False
	except requests.exceptions.RequestException as err:
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠬ࠽࠷࠸࠹࠺ࠫ␲"))
		reason,code = err.message,-1
		succeeded = False
	except:
		#l11l1lll1l1_ll_ = sys.exc_info()[0]
		#l1l1l111l11_ll_ = sys.exc_info()[1]
		#l11l1l1l111_ll_ = sys.exc_info()[2]
		# to find the code & reason from any class
		#print dir(err)
		#for i in dir(err):
		#    print i+l111lll_ll_ (u"࠭ࠠ࠾࠿ࡀࡂࡃࠦࠧ␳")+str(eval(l111lll_ll_ (u"ࠧࡦࡴࡵ࠲ࠬ␴")+i))
		reason,code = l111lll_ll_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡈࡶࡷࡵࡲࠨ␵"),-1
		succeeded = False
	if l11lll1llll_ll_!=None and l1l11lllll1_ll_!=l111lll_ll_ (u"ࠩࡖࡘࡔࡖࠧ␶"): connection.create_connection = l11l1l111ll_ll_
	if l1l11lllll1_ll_==l111lll_ll_ (u"ࠪࡅࡑ࡝ࡁ࡚ࡕࠪ␷") and l1l1l11l1l1_ll_: l11lll1llll_ll_ = None
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ␸"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡ࠶࠷࠸࠹࠺࠴࠵࠶࠷࠸࠹࠺࠴࠵࠶࠷࠸࠹࠺ࠧ␹"))
	#l1ll1l_ll_(l111lll_ll_ (u"࠭࠱࠲࠳࠴ࠫ␺"),l111lll_ll_ (u"ࠧࠨ␻"))
	if not succeeded and l11ll1ll11l_ll_==None and l111lll_ll_ (u"ࠨࡩࡲࡳ࡬ࡲࡥ࠮ࡣࡱࡥࡱࡿࡴࡪࡥࡶࠫ␼") not in l1ll111_ll_:
		l1l11l1lll1_ll_ = traceback.format_exc()
		sys.stderr.write(l1l11l1lll1_ll_)
	else:
		#code = l111lll_ll_ (u"ࠩ࠰࠵ࠬ␽")
		#reason = l111lll_ll_ (u"ࠪࡗࡾࡹࡴࡦ࡯ࠣࡩࡳࡩ࡯ࡥ࡫ࡱ࡫ࠥࡨࡵࡨࠩ␾")
		pass
	try: response.close()
	except: pass
	code = int(code)
	l1ll1lll11l_ll_ = l1l1ll1l1ll_ll_()
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡔࡖࡅࡏࡗࡕࡐࡤࡘࡅࡒࡗࡈࡗ࡙࡙ࠧ␿"),str(response.content))
	if succeeded:
		l1ll1lll11l_ll_.headers = response.headers
		l1ll1lll11l_ll_.cookies = response.cookies
		l1ll1lll11l_ll_.url     = response.url
		l1ll1lll11l_ll_.content = response.content
		l1ll1lll11l_ll_.code    = code
		l1ll1lll11l_ll_.reason  = reason
		l1ll1lll11l_ll_.succeeded = True
	else:
		l1ll1lll11l_ll_.headers = {}
		l1ll1lll11l_ll_.cookies = {}
		l1ll1lll11l_ll_.url     = l111lll_ll_ (u"ࠬ࠭⑀")
		l1ll1lll11l_ll_.content = l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢ࠾ࠬ⑁")+str(code)+l111lll_ll_ (u"ࠧ࠻ࠩ⑂")+reason
		l1ll1lll11l_ll_.code = code
		l1ll1lll11l_ll_.reason = reason
		l1ll1lll11l_ll_.succeeded = False
	l1ll1l1l111_ll_ = (l11ll1ll11l_ll_==None and l11lll1llll_ll_==None and l11l1llll1l_ll_==None)
	try: html = response.content
	except: html = l1ll1lll11l_ll_.content
	l1l1l111lll_ll_ = html.lower()
	l1111l1111_ll_ = (l111lll_ll_ (u"ࠨࡥ࡯ࡳࡺࡪࡦ࡭ࡣࡵࡩࠬ⑃") in l1l1l111lll_ll_ and l111lll_ll_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ⑄") in l1l1l111lll_ll_)
	if code==200 and l1111l1111_ll_: l1ll1lll11l_ll_.succeeded = False
	if not l1ll1lll11l_ll_.succeeded and l1ll1l1l111_ll_:# and l111lll_ll_ (u"ࠪ࡫ࡴࡵࡧ࡭ࡧ࠰ࡥࡳࡧ࡬ࡺࡶ࡬ࡧࡸ࠭⑅") not in l1ll111_ll_:
		l111l1llll_ll_ = (l111lll_ll_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ⑆") in l1l1l111lll_ll_ and l111lll_ll_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ⑇") in l1l1l111lll_ll_)
		l1l1111ll1l_ll_ = (l111lll_ll_ (u"࠭࠵ࠡࡵࡨࡧࠬ⑈") in l1l1l111lll_ll_ and l111lll_ll_ (u"ࠧࡣࡴࡲࡻࡸ࡫ࡲࠨ⑉") in l1l1l111lll_ll_)
		l1l1llll1ll_ll_ = (code in [104,111] or l111lll_ll_ (u"ࠨࡏࡤࡼࠥࡸࡥࡵࡴ࡬ࡩࡸࠦࡥࡹࡥࡨࡩࡩ࡫ࡤࠨ⑊") in reason)
		if   l1111l1111_ll_: l11llll11ll_ll_ = l111lll_ll_ (u"ࠩࡅࡰࡴࡩ࡫ࡦࡦࠣࡦࡾࠦࡇࡰࡱࡪࡰࡪࠦࡲࡦࡅࡄࡔ࡙ࡉࡈࡂࠩ⑋")
		elif l111l1llll_ll_: l11llll11ll_ll_ = l111lll_ll_ (u"ࠪࡆࡱࡵࡣ࡬ࡧࡧࠤࡧࡿࠠࡄ࡮ࡲࡹࡩ࡬࡬ࡢࡴࡨࠫ⑌")
		elif l1l1111ll1l_ll_: l11llll11ll_ll_ = l111lll_ll_ (u"ࠫࡇࡲ࡯ࡤ࡭ࡨࡨࠥࡨࡹࠡ࠷ࠣࡷࡪࡩ࡯࡯ࡦࡶࠤࡧࡸ࡯ࡸࡵࡨࡶࠥࡩࡨࡦࡥ࡮ࠫ⑍")
		elif l1l1llll1ll_ll_: l11llll11ll_ll_ = l111lll_ll_ (u"ࠬࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡢࡺࠢࡼࡳࡺࡸࠠ࡯ࡧࡷࡻࡴࡸ࡫ࠡࡲࡵࡳࡻ࡯ࡤࡦࡴࠪ⑎")
		if l1111l1111_ll_ or l111l1llll_ll_ or l1l1111ll1l_ll_ or l1l1llll1ll_ll_:
			reason = l11llll11ll_ll_+l111lll_ll_ (u"࠭ࠠࠩࠢࠪ⑏")+reason+l111lll_ll_ (u"ࠧࠡࠫࠪ⑐")
			l1ll1lll11l_ll_.content = l111lll_ll_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤࡀࠧ⑑")+str(code)+l111lll_ll_ (u"ࠩ࠽ࠫ⑒")+reason
		l1111l1l_ll_(l111lll_ll_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ⑓"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡅ࡫ࡵࡩࡨࡺࠠࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࠤ࡫ࡧࡩ࡭ࡧࡧࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ⑔")+str(code)+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ⑕")+reason+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ⑖")+source+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭⑗")+url+l111lll_ll_ (u"ࠨࠢࡠࠫ⑘"))
		if l1l11lllll1_ll_==l111lll_ll_ (u"ࠩࡄࡗࡐࡏࡎࡈࠩ⑙") or l1ll111llll_ll_==l111lll_ll_ (u"ࠪࡅࡘࡑࡉࡏࡉࠪ⑚"):
			l111111l1_ll_ = l1ll11lllll_ll_(code,reason,source,True)
			if l111111l1_ll_ and l1l11lllll1_ll_==l111lll_ll_ (u"ࠫࡆ࡙ࡋࡊࡐࡊࠫ⑛"): l1l11lllll1_ll_ = l111lll_ll_ (u"ࠬࡇࡃࡄࡇࡓࡘࡊࡊࠧ⑜")
			else: l1l11lllll1_ll_ = l111lll_ll_ (u"࠭ࡒࡆࡌࡈࡇ࡙ࡋࡄࠨ⑝")
			if l111111l1_ll_ and l1ll111llll_ll_==l111lll_ll_ (u"ࠧࡂࡕࡎࡍࡓࡍࠧ⑞"): l1ll111llll_ll_ = l111lll_ll_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ⑟")
			else: l1ll111llll_ll_ = l111lll_ll_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ①")
			settings.setSetting(l111lll_ll_ (u"ࠪࡨࡳࡹ࠮ࡴࡶࡤࡸࡺࡹࠧ②"),l1l11lllll1_ll_)
			settings.setSetting(l111lll_ll_ (u"ࠫࡵࡸ࡯ࡹࡻ࠱ࡷࡹࡧࡴࡶࡵࠪ③"),l1ll111llll_ll_)
		else: l111111l1_ll_ = True
		if l111111l1_ll_:
			l11lllll1ll_ll_ = True
			if code==8 and l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶࠫ④") in l1ll111_ll_ and l11lllll1ll_ll_:
				if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"࠭สโ฻ํ่ࠥ็อึࠢื๋ฬีษࠡษ็ฮู็๊าࠢࡖࡗࡑ࠭⑤"),l111lll_ll_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ⑥"),time=2000)
				l11ll1_ll_ = l1ll111_ll_+l111lll_ll_ (u"ࠨࡾࡿࡑࡾ࡙ࡓࡍࡗࡵࡰࡂ࠭⑦")
				l1l111l11l1_ll_ = l1l11ll11ll_ll_(method,l11ll1_ll_,data,headers,allow_redirects,l1111l1l11_ll_,source)
				if l1l111l11l1_ll_.succeeded:
					l1ll1lll11l_ll_ = l1l111l11l1_ll_
					l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࡡࡏࡍࡓࡋࡓࠨ⑧"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࠢࡸࡷ࡮ࡴࡧࠡࡕࡖࡐ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ⑨")+source+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ⑩")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⑪"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"࠭ๆอษะࠤออำหะาห๊ࠦࡓࡔࡎࠪ⑫"),l111lll_ll_ (u"ࠧๅวุ่ฬำࠠๆึๆ่ฮࠦวๅว้ฮึ์๊หࠩ⑬"),time=2000)
				else:
					l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭⑭"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡻࡳࡪࡰࡪࠤࡘ࡙ࡌ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ⑮")+source+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⑯")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ⑰"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠬ็ิๅࠢหหุะฮะษ่ࠤࡘ࡙ࡌࠨ⑱"),l111lll_ll_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ⑲"),time=2000)
			if not l1ll1lll11l_ll_.succeeded and l1ll111llll_ll_ in [l111lll_ll_ (u"ࠧࡂࡅࡆࡉࡕ࡚ࡅࡅࠩ⑳"),l111lll_ll_ (u"ࠨࡃࡘࡘࡔ࠭⑴")] and l11lll1l11l_ll_:
				if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠩอๅ฾๐ไࠡีํีๆืวหࠢหีํ้ำ๋ࠩ⑵"),l111lll_ll_ (u"่ࠪส฻ไศฯู้้ࠣไสࠢส่ส์สา่ํฮࠬ⑶"),time=2000)
				l1l111l11l1_ll_ = l11lll11111_ll_(method,l1ll111_ll_,data,headers,allow_redirects,l1111l1l11_ll_,source)
				if l1l111l11l1_ll_.succeeded:
					l1ll1lll11l_ll_ = l1l111l11l1_ll_
					l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࡣࡑࡏࡎࡆࡕࠪ⑷"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡒࡵࡳࡽ࡯ࡥࡴࠢࡶࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠡࡕࡲࡹࡷࡩࡥ࠻ࠢ࡞ࠤࠬ⑸")+source+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⑹")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⑺"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠨ่ฯหาࠦำษำไีฬะࠠษำ๋็ุ๐ࠧ⑻"),l111lll_ll_ (u"ࠩ็ษฺ๊วฮุ่่๊ࠢษࠡษ็ษ๋ะั็์อࠫ⑼"),time=2000)
				else:
					l1111l1l_ll_(l111lll_ll_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ⑽"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡑࡴࡲࡼ࡮࡫ࡳࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ⑾")+source+l111lll_ll_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ⑿")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠩ⒀"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠧโึ็ࠤุฮัโำสฮࠥฮั้ๅึ๎ࠬ⒁"),l111lll_ll_ (u"ࠨๆศู้ออࠡ็ื็้ฯࠠศๆศ๊ฯืๆ๋ฬࠪ⒂"),time=2000)
			if not l1ll1lll11l_ll_.succeeded and l1l11lllll1_ll_ in [l111lll_ll_ (u"ࠩࡄࡇࡈࡋࡐࡕࡇࡇࠫ⒃"),l111lll_ll_ (u"ࠪࡅ࡚࡚ࡏࠨ⒄")] and l1l1l11l1l1_ll_:
				if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠫฯ็ู๋ๆࠣื๏ืแาࠢࡇࡒࡘ࠭⒅"),l111lll_ll_ (u"๊ࠬลึๆสั๋ࠥิไๆฬࠤฬ๊ล็ฬิ๊๏ะࠧ⒆"),time=2000)
				l11ll1_ll_ = l1ll111_ll_+l111lll_ll_ (u"࠭ࡼࡽࡏࡼࡈࡓ࡙ࡕࡳ࡮ࡀࠫ⒇")
				l1l111l11l1_ll_ = l1l11ll11ll_ll_(method,l11ll1_ll_,data,headers,allow_redirects,l1111l1l11_ll_,source)
				if l1l111l11l1_ll_.succeeded:
					l1ll1lll11l_ll_ = l1l111l11l1_ll_
					l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋ࡟ࡍࡋࡑࡉࡘ࠭⒈"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡵࡸࡧࡨ࡫ࡥࡥࡧࡧ࠾ࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ⒉")+l11lll11l11_ll_+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ⒊")+source+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⒋")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ⒌"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠬ์ฬศฯࠣือืแาࠢࡇࡒࡘ࠭⒍"),l111lll_ll_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ⒎"),time=2000)
				else:
					l1111l1l_ll_(l111lll_ll_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ⒏"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࠻ࠢࠣࠤࡉࡔࡓ࠻ࠢ࡞ࠤࠬ⒐")+l11lll11l11_ll_+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ⒑")+source+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⒒")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ⒓"))
					if l1111l1l11_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠬ็ิๅࠢึ๎ึ็ัࠡࡆࡑࡗࠬ⒔"),l111lll_ll_ (u"࠭ไฦื็หาࠦๅีๅ็อࠥอไฦ่อี๋๐สࠨ⒕"),time=2000)
			l111lll_ll_ (u"ࠢࠣࠤࠍࠍࠎࠏࡩࡧࠢࡦࡳࡩ࡫ࠠࡪࡰࠣ࡟࠲࠷ࠬ࠸࠮࠴࠵࠵࠶࠱࠭࠳࠴࠴࠵࠸ࠬ࠲࠲࠳࠹࠹ࡣ࠺ࠋࠋࠌࠍࠎࡒࡏࡈࡡࡗࡌࡎ࡙ࠨࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ࠬࡍࡑࡊࡋࡎࡔࡇࠩࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠯ࠫࠨࠢࠣࠤࡉࡔࡓࠡࡨࡤ࡭ࡱ࡫ࡤ࡛ࠡࠢࠣ࡮ࡲ࡬ࠡࡷࡶࡩࠥࡺࡨࡪࡵࠣࡈࡓ࡙ࠠࡴࡧࡵࡺࡪࡸࠠࠣࠩ࠮ࡨࡳࡹ࡟ࡴࡧࡵࡺࡪࡸࠫࠨࠤࠣࡸࡴࠦࡦࡪࡺࠣࡸ࡭࡯ࡳࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ࠱ࡳࡵࡴࠫࡧࡴࡪࡥࠪ࠭ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ࠱ࡲࡦࡣࡶࡳࡳ࠱ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ࠮ࡷࡴࡻࡲࡤࡧ࠮ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ࠯ࡺࡸ࡬ࠬࠩࠣࡡࠬ࠯ࠊࠊࠋࠌࠍࡉࡏࡁࡍࡑࡊࡣࡓࡕࡔࡊࡈࡌࡇࡆ࡚ࡉࡐࡐฺ๊ࠫࠫใๅหࠣษ๋ะั็์อࠤ࠳ࠦำฤฯส์้ࠦลึๆสั์อࠧ࠭ࠩึวัืศࠡࡆࡑࡗࠥืโๆࠢࠣࠫ࠰ࡪ࡮ࡴࡡࡶࡩࡷࡼࡥࡳ࠮ࡷ࡭ࡲ࡫࠽࠳࠲࠳࠴࠮ࠐࠉࠊࠋࠌࡹࡷࡲ࠳ࠡ࠿ࠣࡹࡷࡲࠫࠨࡾࡿࡑࡾࡊࡎࡔࡗࡵࡰࡂ࠭ࠊࠊࠋࠌࠍࡷ࡫ࡳࡱࡱࡱࡷࡪ࠹ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗ࠭ࡳࡥࡵࡪࡲࡨ࠱ࡻࡲ࡭࠵࠯ࡨࡦࡺࡡ࠭ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡤࡰࡱࡵࡷࡠࡴࡨࡨ࡮ࡸࡥࡤࡶࡶ࠰ࡸ࡮࡯ࡸࡆ࡬ࡥࡱࡵࡧࡴ࠮ࡶࡳࡺࡸࡣࡦࠫࠍࠍࠎࠏࠉࡪࡨࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠸࠴ࡳࡶࡥࡦࡩࡪࡪࡥࡥ࠼ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠷ࠦ࠽ࠡࡴࡨࡷࡵࡵ࡮ࡴࡧ࠶ࠎࠎࠏࠉࠊࡧ࡯ࡷࡪࡀࠠࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ࠮ࡏࡓࡌࡍࡉࡏࡉࠫࡷࡨࡸࡩࡱࡶࡢࡲࡦࡳࡥࠪ࠭ࠪࠤࠥࠦࡄࡏࡕࠣࡹࡸ࡫ࡤࠡࡤࡸࡸࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡅࡐࡖ࠾ࠥࡡࠠࠨ࠭ࡧࡲࡸࡥࡳࡦࡴࡹࡩࡷ࠱ࠧࠡ࡟ࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧࠬࡵࡷࡶ࠭ࡩ࡯ࡥࡧࠬ࠯ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧࠬࡴࡨࡥࡸࡵ࡮ࠬࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ࠰ࡹ࡯ࡶࡴࡦࡩ࠰࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ࠱ࡵࡳ࡮࠮ࠫࠥࡣࠧࠪࠌࠌࠍࠎࠨࠢࠣ⒖")
		if l1l11lllll1_ll_ in [l111lll_ll_ (u"ࠨࡃࡆࡇࡊࡖࡔࡆࡆࠪ⒗"),l111lll_ll_ (u"ࠩࡕࡉࡏࡋࡃࡕࡇࡇࠫ⒘")] or l1ll111llll_ll_ in [l111lll_ll_ (u"ࠪࡅࡈࡉࡅࡑࡖࡈࡈࠬ⒙"),l111lll_ll_ (u"ࠫࡗࡋࡊࡆࡅࡗࡉࡉ࠭⒚")]:
			l1111l1l11_ll_ = False
		#l1ll1l_ll_(source,str(l1111l1l11_ll_))
		if not l1ll1lll11l_ll_.succeeded:
			if l1111l1l11_ll_:# and (l1l1l11l1l1_ll_ or l11lll1l11l_ll_):
				l1ll11lllll_ll_(code,reason,source,l1111l1l11_ll_)
			l11l1llll11_ll_(source,code,reason,l1111l1l11_ll_,l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	elif l1ll1l1l111_ll_ and not l1ll1lll11l_ll_.succeeded and l111lll_ll_ (u"ࠬ࡭࡯ࡰࡩ࡯ࡩ࠲ࡧ࡮ࡢ࡮ࡼࡸ࡮ࡩࡳࠨ⒛") in l1ll111_ll_:
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ⒜"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡷࡪࡴࡤࡪࡰࡪࠤࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹࠠࡦࡸࡨࡲࡹࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⒝")+l1ll111_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫ⒞"))
	if l1ll1l1l111_ll_ and l1ll1lll11l_ll_.succeeded and l111lll_ll_ (u"ࠩࡳࡽࡹ࡮࡯࡯ࡣࡱࡽࡼ࡮ࡥࡳࡧࠪ⒟") in l1ll111_ll_:
		#l1ll1l_ll_(str(l1111l1l11_ll_),str(l1l1l11l1l1_ll_)+l111lll_ll_ (u"ࠪࠤࠥ࠭⒠")+str(l11lll1l11l_ll_))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⒡"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡕࡨࡲࡩ࡯࡮ࡨࠢࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠥ࡫ࡶࡦࡰࡷࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⒢")+l1ll111_ll_+l111lll_ll_ (u"࠭ࠠ࡞ࠩ⒣"))
		l1l111l11l1_ll_ = l1ll1ll1l1l_ll_(l111lll_ll_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ⒤"),l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⒥"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡌࡩ࡯࡫ࡶ࡬ࡪࡪࠠࠡࠢࡖࡹࡨࡩࡥࡴࡵ࠽ࠤࡠࠦࠧ⒦")+str(l1ll1lll11l_ll_.succeeded)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⒧")+l1ll111_ll_+l111lll_ll_ (u"ࠫࠥࡣࠧ⒨"))
	return l1ll1lll11l_ll_
def l1ll1ll1l1l_ll_(l1ll_ll_,l1l1l11l1l1_ll_=True,l11lll1l11l_ll_=True):
	#l1ll1l_ll_(l111lll_ll_ (u"࡙ࠬࡅࡏࡆࡢࡅࡓࡇࡌ࡚ࡖࡌࡇࡘࡥࡅࡗࡇࡑࡘࠬ⒩"),str(l1l1l11l1l1_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠩ⒪")+str(l11lll1l11l_ll_))
	l11ll1l11ll_ll_ = str(random.randrange(111111111111,999999999999))
	url = l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡹࡺ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠱ࡦࡴࡡ࡭ࡻࡷ࡭ࡨࡹ࠮ࡤࡱࡰ࠳ࡨࡵ࡬࡭ࡧࡦࡸࡄࡼ࠽࠲ࠨࡷ࡭ࡩࡃࡕࡂ࠯࠴࠶࠼࠶࠴࠶࠳࠳࠸࠲࠻ࠦࡤ࡫ࡧࡁࠬ⒫")+l11l1lll1ll_ll_(32)+l111lll_ll_ (u"ࠨࠨࡷࡁࡪࡼࡥ࡯ࡶࠩࡷࡨࡃࡥ࡯ࡦࠩࡩࡨࡃࠧ⒬")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠩࠩࡥࡻࡃࠧ⒭")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠪࠪࡦࡴ࠽ࡂࡔࡄࡆࡎࡉ࡟ࡗࡋࡇࡉࡔ࡙ࠦࡦࡣࡀࠫ⒮")+l1ll_ll_+l111lll_ll_ (u"ࠫࠫ࡫࡬࠾ࠩ⒯")+str(l1ll1l111l1_ll_)+l111lll_ll_ (u"ࠬࠬࡺ࠾ࠩ⒰")+l11ll1l11ll_ll_
	response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ⒱"),url,l111lll_ll_ (u"ࠧࠨ⒲"),l111lll_ll_ (u"ࠨࠩ⒳"),l111lll_ll_ (u"ࠩࠪ⒴"),False,l111lll_ll_ (u"ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡘࡋࡎࡅࡡࡄࡒࡆࡒ࡙ࡕࡋࡆࡗࡤࡋࡖࡆࡐࡗ࠱࠶ࡹࡴࠨ⒵"),l1l1l11l1l1_ll_,l11lll1l11l_ll_)
	#html = response.content
	#l1ll1l_ll_(url,response.content)
	return response
def l1ll1ll111l_ll_(url):
	l1l1ll1l1l1_ll_ = url.split(l111lll_ll_ (u"ࠫࢁࢂࠧⒶ"))
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1l1ll1l1l1_ll_[0],None,None,None
	for item in l1l1ll1l1l1_ll_:
		if l111lll_ll_ (u"ࠬࡓࡹࡑࡴࡲࡼࡾ࡛ࡲ࡭࠿ࠪⒷ") in item: l11ll1ll11l_ll_ = item.split(l111lll_ll_ (u"࠭࠽ࠨⒸ"))[1]
		elif l111lll_ll_ (u"ࠧࡎࡻࡇࡒࡘ࡛ࡲ࡭࠿ࠪⒹ") in item: l11lll1llll_ll_ = item.split(l111lll_ll_ (u"ࠨ࠿ࠪⒺ"))[1]
		elif l111lll_ll_ (u"ࠩࡐࡽࡘ࡙ࡌࡖࡴ࡯ࡁࠬⒻ") in item: l11l1llll1l_ll_ = item.split(l111lll_ll_ (u"ࠪࡁࠬⒼ"))[1]
	#if l111lll_ll_ (u"ࠫࡦࡱ࡯ࡢ࡯࠱ࠫⒽ") in l1ll111_ll_:
	#	l1ll1l1l_ll_ = l1ll111_ll_.split(l111lll_ll_ (u"ࠬࡀࠧⒾ"))[0]
	#	l11ll1ll11l_ll_ = l1ll1l1l_ll_+l111lll_ll_ (u"࠭࠺࠰࠱࠴࠹࠾࠴࠲࠱࠵࠱࠼࠼࠴࠱࠴࠲࠽࠷࠶࠸࠸ࠨⒿ")
	return l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_
def l1l1l111l_ll_(title,link):
	l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡜ࡣ࠰ࡾࡆ࠳࡚࠮࡟࠮ࠫⓀ"),title,re.DOTALL)
	if l11ll111_ll_: title = l11ll111_ll_[0]
	else: title = title+l111lll_ll_ (u"ࠨࠢࠪⓁ")+l1l11l1lll_ll_(link,False)
	title = title.replace(l111lll_ll_ (u"ࠩ฼ีอࠦำ๋ัࠪⓂ"),l111lll_ll_ (u"ࠪࠫⓃ")).replace(l111lll_ll_ (u"๊ࠫฮวีำࠪⓄ"),l111lll_ll_ (u"ࠬ࠭Ⓟ"))
	title = title.replace(l111lll_ll_ (u"࠭ࠠࠡࠩⓆ"),l111lll_ll_ (u"ࠧࠡࠩⓇ"))
	return title
def l1ll1l111_ll_(url):
	return l111lll_ll_ (u"ࠨ࠱ࠪⓈ").join(url.split(l111lll_ll_ (u"ࠩ࠲ࠫⓉ"))[:3])
def l1l11l1lll_ll_(url,full=True):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫⓊ"))
	url = l111lll_ll_ (u"ࠫ࠴࠭Ⓥ")+url+l111lll_ll_ (u"ࠬ࠵ࠧⓌ")
	if url==l111lll_ll_ (u"࠭࠯࠰ࠩⓍ"): host = l111lll_ll_ (u"ࠧࠨⓎ")
	elif l111lll_ll_ (u"ࠨ࠱࠲ࠫⓏ") in url: host = url.split(l111lll_ll_ (u"ࠩ࠲ࠫⓐ"))[3].split(l111lll_ll_ (u"ࠪ࠾ࠬⓑ"))[0]
	else: host = url.split(l111lll_ll_ (u"ࠫ࠴࠭ⓒ"))[1]
	host = host.strip(l111lll_ll_ (u"ࠬ࠵ࠧⓓ"))
	if not full and l111lll_ll_ (u"࠭࠮ࠨⓔ") in host:
		l1ll1l1l1ll_ll_ = host.split(l111lll_ll_ (u"ࠧ࠯ࠩⓕ"))
		length = len(l1ll1l1l1ll_ll_)
		if length<=2 or l111lll_ll_ (u"ࠨࡦࡤ࡭ࡱࡿ࡭ࡰࡶ࡬ࡳࡳ࠭ⓖ") in host: l1ll1l1l1ll_ll_ = l1ll1l1l1ll_ll_[0]
		elif length>=3: l1ll1l1l1ll_ll_ = l1ll1l1l1ll_ll_[1]
		l1ll1l1l1ll_ll_ = l1ll1l1l1ll_ll_.strip(l111lll_ll_ (u"ࠩ࠲ࠫⓗ"))
		if len(l1ll1l1l1ll_ll_)>1: host = l1ll1l1l1ll_ll_
	return host
	l111lll_ll_ (u"ࠥࠦࠧࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࠨ࠱ࠪ࠯ࡺࡸ࡬࠳࠭ࠪ࠳ࠬࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡰࡨࡸ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡥࡲࡱ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡱࡵ࡫࠴࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࡵࡳ࡮࠵ࠤࡂࠦࡵࡳ࡮࠵࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮࡭࡫ࡹࡩ࠴࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡶࡹ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡸࡵ࠲ࠫ࠱࠭࠯ࠨࠫࠍࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠳ࡺ࡯࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡲ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡴ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠯ࡴࡸ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡤࡣࡰ࠳ࠬ࠲ࠧ࠰ࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯ࠊࠊࡷࡵࡰ࠷ࠦ࠽ࠡࡷࡵࡰ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ࠰࡯࡭ࡻ࡫࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱ࡧࡱࡻࡢ࠰ࠩ࠯ࠫ࠴࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡱ࡯ࡦࡦ࠱ࠪ࠰ࠬ࠵ࠧࠪࠌࠌࡹࡷࡲ࠲ࠡ࠿ࠣࡹࡷࡲ࠲࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪ࠲ࡲࡾ࠯ࠨ࠮ࠪ࠳ࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠱࡭ࡳ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࡶࡴ࡯࠶ࠥࡃࠠࡶࡴ࡯࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰ࡹࡺࡻ࠳࠭ࠬࠨ࠱ࠪ࠭࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ࠰࡯࠱ࠫ࠱࠭࠯ࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ࠵ࡥ࡮ࡤࡨࡨ࠳࠭ࠬࠨ࠱ࠪ࠭ࠏࠏࠢࠣࠤⓘ")
def l1ll111l1ll_ll_(l11l1ll11ll_ll_):
	l11l1ll1l11_ll_ = repr(l11l1ll11ll_ll_.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩⓙ"))).replace(l111lll_ll_ (u"ࠧ࠭ࠢⓚ"),l111lll_ll_ (u"࠭ࠧⓛ"))
	return l11l1ll1l11_ll_
def unescapeHTML(l1l111l111l_ll_):
	if l111lll_ll_ (u"ࠧࠧࠩⓜ") in l1l111l111l_ll_ and l111lll_ll_ (u"ࠨ࠽ࠪⓝ") in l1l111l111l_ll_:
		l1l111l111l_ll_ = l1l111l111l_ll_.decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧⓞ"))
		import HTMLParser
		l1l111l111l_ll_ = HTMLParser.HTMLParser().unescape(l1l111l111l_ll_)
		l1l111l111l_ll_ = l1l111l111l_ll_.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨⓟ"))
	return l1l111l111l_ll_
def l1l1l11ll11_ll_(string):
	l1l111l111l_ll_ = l111lll_ll_ (u"ࠫࠬⓠ").join(x for x in string if x.isalnum())
	return l1l111l111l_ll_
def l1lllllll1_ll_(filename):
	l11ll111lll_ll_ = l111lll_ll_ (u"ࠬ࠭ⓡ").join(i for i in filename if i not in l111lll_ll_ (u"࠭࡜࠰ࠤ࠽࠮ࡄࡂ࠾ࡽࠩⓢ")+l1l1l11ll_ll_(l111lll_ll_ (u"ࠧ࡝ࡷ࠳࠶ࡩ࠷ࠧⓣ")))
	return l11ll111lll_ll_
def l1l1l11ll_ll_(l1l111l111l_ll_):
	if l111lll_ll_ (u"ࠨ࡞࡟ࡹࠬⓤ") in l1l111l111l_ll_:
		l1l111l111l_ll_ = l1l111l111l_ll_.decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪⓥ"))
		l1l111l111l_ll_ = l1l111l111l_ll_.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨⓦ"))
	return l1l111l111l_ll_
def l1lll1l1lll_ll_(l1l111l111l_ll_):
	import unicodedata
	#if l111lll_ll_ (u"ࠫࡡࡻࠧⓧ") in l1l111l111l_ll_:
	#	l1l111l111l_ll_ = l1l111l111l_ll_.decode(l111lll_ll_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ⓨ"))
	#	l11l1111l1l_ll_=re.findall(l111lll_ll_ (u"ࡸࠧ࡝ࡷ࡞࠴࠲࠿ࡁ࠮ࡈࡠࠫⓩ"),l1l111l111l_ll_)
	#	for unicode in l11l1111l1l_ll_
	#		char = l1l1llll1l1_ll_(
	#		replace(    , char)
	l1l111l111l_ll_ = l1l111l111l_ll_.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬ⓪"))
	l1l1ll1lll1_ll_ = l111lll_ll_ (u"ࠨࠩ⓫")
	for letter in l1l111l111l_ll_:
		#l1ll1l_ll_(unicodedata.decomposition(letter),hex(ord(letter)))
		if ord(letter) < 256: l11l111llll_ll_ = l111lll_ll_ (u"ࠩ࡟ࡠࡺ࠶࠰ࠨ⓬")+hex(ord(letter)).replace(l111lll_ll_ (u"ࠪ࠴ࡽ࠭⓭"),l111lll_ll_ (u"ࠫࠬ⓮"))
		elif ord(letter) < 4096: l11l111llll_ll_ = l111lll_ll_ (u"ࠬࡢ࡜ࡶ࠲ࠪ⓯")+hex(ord(letter)).replace(l111lll_ll_ (u"࠭࠰ࡹࠩ⓰"),l111lll_ll_ (u"ࠧࠨ⓱"))
		else: l11l111llll_ll_ = l111lll_ll_ (u"ࠨ࡞࡟ࡹࠬ⓲")+unicodedata.decomposition(letter).split(l111lll_ll_ (u"ࠩࠣࠫ⓳"))[1]
		l1l1ll1lll1_ll_ += l11l111llll_ll_
	l1l1ll1lll1_ll_ = l1l1ll1lll1_ll_.replace(l111lll_ll_ (u"ࠪࡠࡺ࠶࠶ࡄࡅࠪ⓴"),l111lll_ll_ (u"ࠫࡡࡻ࠰࠷࠶࠼ࠫ⓵"))
	l1l1ll1lll1_ll_ = l1l1ll1lll1_ll_.decode(l111lll_ll_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭⓶"))
	l1l1ll1lll1_ll_ = l1l1ll1lll1_ll_.encode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠰࠼ࠬ⓷"))
	return l1l1ll1lll1_ll_
def l1ll1_ll_(header=l111lll_ll_ (u"ࠧๅ๊ะอࠥอไๆใสฮ๏ำࠧ⓸"),default=l111lll_ll_ (u"ࠨࠩ⓹"),l1ll1llllll_ll_=False):
	#text = l111lll_ll_ (u"ࠩࠪ⓺")
	#l11l11l11ll_ll_ = xbmc.Keyboard(default,header)
	#l1lll1l11l1_ll_.setDefault(default)
	#l1lll1l11l1_ll_.setHeading(header)
	#l11l11l11ll_ll_.doModal()
	#if l11l11l11ll_ll_.isConfirmed(): text = l11l11l11ll_ll_.getText()
	#l1l11l1ll11_ll_ = xbmcgui.WindowXMLDialog(l111lll_ll_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡎࡩࡾࡨ࡯ࡢࡴࡧ࠶࠷࠴ࡸ࡮࡮ࠪ⓻"),l1l1l1111l1_ll_,l111lll_ll_ (u"ࠫࡩ࡫ࡦࡢࡷ࡯ࡸࠬ⓼"),l111lll_ll_ (u"ࠬ࠽࠲࠱ࡲࠪ⓽"))
	#l1l11l1ll11_ll_.show()
	#l1l11l1ll11_ll_.doModal()
	#l1l11l1ll11_ll_.getControl(99991).setPosition(0,0)
	#l1l11l1ll11_ll_.getControl(311).setLabel(text)
	#l1l11l1ll11_ll_.getControl(5).setText(l1l1lllll1l_ll_)
	#width = xbmcgui.getScreenWidth()
	#height = xbmcgui.getScreenHeight()
	#resolution = (0.0+width)/height
	#l1l11l1ll11_ll_.getControl(5).setWidth(width-180)
	#l1l11l1ll11_ll_.getControl(5).setHeight(height-180)
	#text = l1l11l1ll11_ll_.getControl(312).getLabel()
	#del l1l11l1ll11_ll_
	text = l11ll111111_ll_(header,default,type=xbmcgui.INPUT_ALPHANUM)
	text = text.replace(l111lll_ll_ (u"࠭ࠠࠡࠩ⓾"),l111lll_ll_ (u"ࠧࠡࠩ⓿")).replace(l111lll_ll_ (u"ࠨࠢࠣࠫ─"),l111lll_ll_ (u"ࠩࠣࠫ━")).replace(l111lll_ll_ (u"ࠪࠤࠥ࠭│"),l111lll_ll_ (u"ࠫࠥ࠭┃"))
	if text==l111lll_ll_ (u"ࠬ࠭┄") and not l1ll1llllll_ll_:
		l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ┅"),l111lll_ll_ (u"ࠧห็ࠣษ้เวยࠢส่สีฮศๆࠪ┆"))
		return l111lll_ll_ (u"ࠨࠩ┇")
	if text not in [l111lll_ll_ (u"ࠩࠪ┈"),l111lll_ll_ (u"ࠪࠤࠬ┉")]:
		text = text.strip(l111lll_ll_ (u"ࠫࠥ࠭┊"))
		text = l1lll1l1lll_ll_(text)
	return text
def l1l1l11llll_ll_():
	#l11ll1l1l1l_ll_ = [12,24,33,43,53,63,74,82,92,112,123,134,143,182,202,212,223,235,243,252]
	#l1l11111111_ll_ = [235,105]
	#if int(mode)in l11ll1l1l1l_ll_: filename = l1l1l111l1l_ll_
	#elif int(mode)in l1l11111111_ll_: filename = l1l1ll11lll_ll_
	#else: filename = l111lll_ll_ (u"ࠬ࠭┋")
	type,name,l1lll11111l_ll_,l11l11l1l1l_ll_,l11lllll1l1_ll_,l1l11l11111_ll_,l11l1ll1lll_ll_,context = l11lllllll_ll_()
	l1l111l111_ll_ = (type,name,l1lll11111l_ll_,l11l11l1l1l_ll_,l11lllll1l1_ll_,l1l11l11111_ll_,l11l1ll1lll_ll_)
	if os.path.exists(l1l11l11lll_ll_):
		with open(l1l11l11lll_ll_,l111lll_ll_ (u"࠭ࡲࠨ┌")) as f: l11lll1l1l_ll_ = f.read()
		#l11lll1l1l_ll_ = l11lll1l1l_ll_.replace(l111lll_ll_ (u"ࠧࡶ࡞ࠪࠫ┍"),l111lll_ll_ (u"ࠨ࡞ࠪࠫ┎"))
		l11lll1l1l_ll_ = eval(l11lll1l1l_ll_)
	else: l11lll1l1l_ll_ = {}
	l1l1111l1l_ll_ = {}
	for l1111ll1l1_ll_ in l11lll1l1l_ll_.keys():
		if l1111ll1l1_ll_!=type: l1l1111l1l_ll_[l1111ll1l1_ll_] = l11lll1l1l_ll_[l1111ll1l1_ll_]
		else:
			if name!=l111lll_ll_ (u"ࠩ࠱࠲ࠬ┏") and name!=l111lll_ll_ (u"ࠪࠫ┐"):
				l1l11111l1_ll_ = l11lll1l1l_ll_[l1111ll1l1_ll_]
				if l1l111l111_ll_ in l1l11111l1_ll_:
					index = l1l11111l1_ll_.index(l1l111l111_ll_)
					del l1l11111l1_ll_[index]
				l1l1l111l1_ll_ = [l1l111l111_ll_]+l1l11111l1_ll_
				l1l1l111l1_ll_ = l1l1l111l1_ll_[:50]
				l1l1111l1l_ll_[l1111ll1l1_ll_] = l1l1l111l1_ll_
			else: l1l1111l1l_ll_[l1111ll1l1_ll_] = l11lll1l1l_ll_[l1111ll1l1_ll_]
	if type not in l1l1111l1l_ll_.keys(): l1l1111l1l_ll_[type] = [l1l111l111_ll_]
	l1l1111l1l_ll_ = str(l1l1111l1l_ll_)
	with open(l1l11l11lll_ll_,l111lll_ll_ (u"ࠫࡼ࠭┑")) as f: f.write(l1l1111l1l_ll_)
	return
def l11l1l1l_ll_(l1ll111_ll_,headers={}):
	if l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ┒") not in headers.keys(): headers[l111lll_ll_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ┓")] = l111lll_ll_ (u"ࠧࠨ└")
	#l11l11l1lll_ll_ = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ┕") : l111lll_ll_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣ࠲࠹࠳࠶࡙ࠠࠩ࡬ࡲࡩࡵࡷࡴࠢࡑࡘࠥ࠷࠰࠯࠲࠾ࠤ࡜࡯࡮࠷࠶࠾ࠤࡽ࠼࠴ࠪࠢࡄࡴࡵࡲࡥࡘࡧࡥࡏ࡮ࡺ࠯࠶࠵࠺࠲࠸࠼ࠠࠩࡍࡋࡘࡒࡒࠬࠡ࡮࡬࡯ࡪࠦࡇࡦࡥ࡮ࡳ࠮ࠦࡃࡩࡴࡲࡱࡪ࠵࠷࠶࠰࠳࠲࠸࠽࠷࠱࠰࠴࠸࠷ࠦࡓࡢࡨࡤࡶ࡮࠵࠵࠴࠹࠱࠷࠻࠭┖") }
	#url = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡻࡪ࠸࠵࠰ࡰࡽࡨࡪ࡮࠯࡯ࡨ࠳ࡻ࡯ࡤࡦࡱ࠱ࡱ࠸ࡻ࠸ࠨ┗")
	#with open(l111lll_ll_ (u"ࠫࡘࡀ࡜࡝ࡶࡨࡷࡹ࠸࠮࡮࠵ࡸ࠼ࠬ┘"), l111lll_ll_ (u"ࠬࡸࠧ┙")) as f: html = f.read()
	url,params = l1ll111_ll_,l111lll_ll_ (u"࠭ࠧ┚")
	if l111lll_ll_ (u"ࠧࡽࠩ┛") in l1ll111_ll_:
		url,params = l1ll111_ll_.split(l111lll_ll_ (u"ࠨࡾࠪ├"),1)
		if l111lll_ll_ (u"ࠩࡀࠫ┝") not in params: url,params = l1ll111_ll_,l111lll_ll_ (u"ࠪࠫ┞")
	html = l111ll1_ll_(l1l1l11ll1l_ll_,url,l111lll_ll_ (u"ࠫࠬ┟"),headers,l111lll_ll_ (u"ࠬ࠭┠"),l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡆ࡚ࡗࡖࡆࡉࡔࡠࡏ࠶࡙࠽࠳࠱ࡴࡶࠪ┡"))
	if l111lll_ll_ (u"ࠧࡕ࡛ࡓࡉࡂࡇࡕࡅࡋࡒࠫ┢") in html: return [l111lll_ll_ (u"ࠨ࠯࠴ࠫ┣")],[url]
	if l111lll_ll_ (u"ࠩࡗ࡝ࡕࡋ࠽ࡗࡋࡇࡉࡔ࠭┤") in html: return [l111lll_ll_ (u"ࠪ࠱࠶࠭┥")],[url]
	#l1ll1l_ll_(str(l1ll111_ll_),html)
	#if l111lll_ll_ (u"࡙ࠫ࡟ࡐࡆ࠿ࡖ࡙ࡇ࡚ࡉࡕࡎࡈࡗࠬ┦") in html: return [l111lll_ll_ (u"ࠬ࠳࠱ࠨ┧")],[url]
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࠧ┨"),html)
	l1111ll_ll_,l1l111l_ll_,l1l1llll111_ll_,l1ll1ll11ll_ll_ = [],[],[],[]
	lines = re.findall(l111lll_ll_ (u"ࠧ࡝ࠥࡈ࡜࡙࠳ࡘ࠮ࡕࡗࡖࡊࡇࡍ࠮ࡋࡑࡊ࠿࠮࠮ࠫࡁࠬ࡟ࡡࡴ࡜ࡳ࡟ࠫ࠲࠯ࡅࠩ࡜࡞ࡱࡠࡷࡣࠧ┩"),html+l111lll_ll_ (u"ࠨ࡞ࡱࡠࡷ࠭┪"),re.DOTALL)
	if not lines: return [l111lll_ll_ (u"ࠩ࠰࠵ࠬ┫")],[url]
	for line,link in lines:
		l1l11111ll1_ll_,bitrate,quality = {},-1,-1
		l1lll11l1l_ll_ = re.findall(l111lll_ll_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡺࡳࡽ࡞࠱ࡱࡵ࠺ࡼ࡝࠰ࡰ࠷ࡺࢂ࡜࠯࡯࠶ࡹ࠽ࢂ࡜࠯࡯ࡳࡨࢁࡢ࠮࡮࡭ࡹࢀࡡ࠴ࡦ࡭ࡸࡿࡠ࠳ࡳࡰ࠴ࠫࠫࢀࡡࡅ࠮ࠫࡁࡿ࠳ࡡࡅ࠮ࠫࡁࡿࡠࢁ࠴ࠪࡀࠫࠩࠪࠬ┬"),link.lower()+l111lll_ll_ (u"ࠫࠫࠬࠧ┭"),re.DOTALL|re.IGNORECASE)
		if l1lll11l1l_ll_: title = l1lll11l1l_ll_[0][0][1:]+l111lll_ll_ (u"ࠬࠦࠠࠨ┮")
		else: title = l111lll_ll_ (u"࠭ࠧ┯")
		hostname = l1l11l1lll_ll_(link,False)
		title = title+l111lll_ll_ (u"ࠧࠡࠢࠪ┰")+hostname+l111lll_ll_ (u"ࠨࠢࠣࠫ┱")
		#line = line.lower()
		items = line.split(l111lll_ll_ (u"ࠩ࠯ࠫ┲"))
		for item in items:
			#l1ll1l_ll_(item,l111lll_ll_ (u"ࠪࠫ┳"))
			#if l111lll_ll_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭┴") in item: l1l11111ll1_ll_[key] = value
			if l111lll_ll_ (u"ࠬࡃࠧ┵") in item:
				key,value = item.split(l111lll_ll_ (u"࠭࠽ࠨ┶"),1)
				l1l11111ll1_ll_[key.lower()] = value
		if l111lll_ll_ (u"ࠧࡢࡸࡨࡶࡦ࡭ࡥ࠮ࡤࡤࡲࡩࡽࡩࡥࡶ࡫ࠫ┷") in line.lower():
			bitrate = int(l1l11111ll1_ll_[l111lll_ll_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦ࠯ࡥࡥࡳࡪࡷࡪࡦࡷ࡬ࠬ┸")])/1024
			#title += l111lll_ll_ (u"ࠩࡄࡺ࡬ࡈࡗ࠻ࠢࠪ┹")+str(bitrate)+l111lll_ll_ (u"ࠪ࡯ࡧࡶࡳࠡࠢࠪ┺")
			title += str(bitrate)+l111lll_ll_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ┻")
		elif l111lll_ll_ (u"ࠬࡨࡡ࡯ࡦࡺ࡭ࡩࡺࡨࠨ┼") in line.lower():
			bitrate = int(l1l11111ll1_ll_[l111lll_ll_ (u"࠭ࡢࡢࡰࡧࡻ࡮ࡪࡴࡩࠩ┽")])/1024
			#title += l111lll_ll_ (u"ࠧࡃ࡙࠽ࠤࠬ┾")+str(bitrate)+l111lll_ll_ (u"ࠨ࡭ࡥࡴࡸࠦࠠࠨ┿")
			title += str(bitrate)+l111lll_ll_ (u"ࠩ࡮ࡦࡵࡹࠠࠡࠩ╀")
		if l111lll_ll_ (u"ࠪࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠧ╁") in line.lower():
			quality = int(l1l11111ll1_ll_[l111lll_ll_ (u"ࠫࡷ࡫ࡳࡰ࡮ࡸࡸ࡮ࡵ࡮ࠨ╂")].split(l111lll_ll_ (u"ࠬࡾࠧ╃"))[1])
			#title += l111lll_ll_ (u"࠭ࡒࡦࡵ࠽ࠤࠬ╄")+str(quality)+l111lll_ll_ (u"ࠧࠡࠢࠪ╅")
			title += str(quality)+l111lll_ll_ (u"ࠨࠢࠣࠫ╆")
		title = title.strip(l111lll_ll_ (u"ࠩࠣࠤࠬ╇"))
		if title==l111lll_ll_ (u"ࠪࠫ╈"): title = l111lll_ll_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ╉")
		if l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪ╊") not in link: link = url.rsplit(l111lll_ll_ (u"࠭࠯ࠨ╋"),1)[0]+l111lll_ll_ (u"ࠧ࠰ࠩ╌")+link
		if params!=l111lll_ll_ (u"ࠨࠩ╍"): link = link+l111lll_ll_ (u"ࠩࡿࠫ╎")+params
		if l111lll_ll_ (u"ࠪࡴࡷࡵࡧࡳࡧࡶࡷ࡮ࡼࡥ࠮ࡷࡵ࡭ࠬ╏") in l1l11111ll1_ll_.keys():
			l11ll1ll_ll_ = l1l11111ll1_ll_[l111lll_ll_ (u"ࠫࡵࡸ࡯ࡨࡴࡨࡷࡸ࡯ࡶࡦ࠯ࡸࡶ࡮࠭═")]
			l11ll1ll_ll_ = link.replace(l111lll_ll_ (u"ࠬࠨࠧ║"),l111lll_ll_ (u"࠭ࠧ╒")).replace(l111lll_ll_ (u"ࠢࠨࠤ╓"),l111lll_ll_ (u"ࠨࠩ╔")).split(l111lll_ll_ (u"ࠩࠦࠫ╕"))[0]
			#l1111l1l_ll_(l111lll_ll_ (u"ࠪࠫ╖"),link)
			l1111ll_ll_.append(title+l111lll_ll_ (u"ࠫࠥ࠮ࡰࡳࡱࡪࡶࡪࡹࡳࡪࡸࡨ࠭ࠬ╗"))
			l1l111l_ll_.append(l11ll1ll_ll_)
			l1l1llll111_ll_.append(quality)
			l1ll1ll11ll_ll_.append(bitrate)
		l1111ll_ll_.append(title)
		l1l111l_ll_.append(link)
		l1l1llll111_ll_.append(quality)
		l1ll1ll11ll_ll_.append(bitrate)
	z = zip(l1111ll_ll_,l1l111l_ll_,l1l1llll111_ll_,l1ll1ll11ll_ll_)
	#z = set(z)
	z = sorted(z, reverse=True, key=lambda key: key[3])
	l1111ll_ll_,l1l111l_ll_,l1l1llll111_ll_,l1ll1ll11ll_ll_ = zip(*z)
	l1111ll_ll_,l1l111l_ll_ = list(l1111ll_ll_),list(l1l111l_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠿࠹ࠨ╘"),l111lll_ll_ (u"࠭ࠧ╙"))
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠧࠨ╚"), l1111ll_ll_)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠨࠩ╛"), l1l111l_ll_)
	return l1111ll_ll_,l1l111l_ll_
def l11l1lll1ll_ll_(length):
	#import uuid
	#l11l111l1ll_ll_ = hex(uuid.getnode())		# l11ll11l1l1_ll_
	#mac = l111lll_ll_ (u"ࠩ࠰ࠫ╜").join(l1l1lll1l11_ll_[i:i+2].upper() for i in range(0,11,2))		# l1l1l1l1111_ll_:l1l11l1l1l1_ll_:l1l1lllll11_ll_:l1l1l1l11ll_ll_:l1l1ll11l1l_ll_:5E
	try:
		import platform
		hostname = platform.node()			# l1ll111lll1_ll_/l11l1l1lll1_ll_
		l1l1lllllll_ll_ = platform.system()			# Windows/l11l1111ll1_ll_
		os_version = platform.release()		# 10.0/3.14.22
		l1ll1ll1111_ll_ = platform.machine()		# l1lll11l1l1_ll_/l1l1111ll11_ll_
		#processor = platform.processor()	# l11lll1ll11_ll_ l11lll111l1_ll_ 9 l11l11ll111_ll_ 68 l11ll1ll111_ll_ 16, l11lllllll1_ll_/l111lll_ll_ (u"ࠪࠫ╝")
	except: hostname,l1l1lllllll_ll_,os_version,l1ll1ll1111_ll_,processor = l111lll_ll_ (u"ࠫࠬ╞"),l111lll_ll_ (u"ࠬ࠭╟"),l111lll_ll_ (u"࠭ࠧ╠"),l111lll_ll_ (u"ࠧࠨ╡"),l111lll_ll_ (u"ࠨࠩ╢")
	l11ll1llll1_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩࡱࡳࡩ࡫ࠧ╣"))
	if l11ll1llll1_ll_==l111lll_ll_ (u"ࠪࠫ╤"):
		import uuid
		node = str(uuid.getnode())		# 326509845772831
		settings.setSetting(l111lll_ll_ (u"ࠫࡳࡵࡤࡦࠩ╥"),node)
	else:
		node = l11ll1llll1_ll_
	l1l1ll1ll1l_ll_ = node+l111lll_ll_ (u"ࠬࡀࠧ╦")+hostname+l111lll_ll_ (u"࠭࠺ࠨ╧")+l1l1lllllll_ll_+l111lll_ll_ (u"ࠧ࠻ࠩ╨")+os_version+l111lll_ll_ (u"ࠨ࠼ࠪ╩")+l1ll1ll1111_ll_
	import hashlib
	l11lll111ll_ll_ = hashlib.md5(l1l1ll1ll1l_ll_).hexdigest()
	md5 = l11lll111ll_ll_[0:length]
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ╪"),l111lll_ll_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࠣࡉࡒࡇࡄࠡࡇࡐࡅࡉࠦࠧ╫")+node+l111lll_ll_ (u"ࠫࠥ࠭╬")+hostname+l111lll_ll_ (u"ࠬࠦࠧ╭")+l1l1lllllll_ll_+l111lll_ll_ (u"࠭ࠠࠨ╮")+os_version+l111lll_ll_ (u"ࠧࠡࠩ╯")+l1ll1ll1111_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ╰"),l111lll_ll_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠢࡈࡑࡆࡊࠠࡆࡏࡄࡈࠥ࠭╱")+md5+l111lll_ll_ (u"ࠪࠤࠬ╲")+str(platform.platform()))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ╳"),md5)
	return md5
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋࠦࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡹࡸ࡫ࡲ࠯ࡪࡤࡷ࡭࠭ࠬࠨࠩࠬࠎࠎࠩࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡵࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡵࡴࡧࡵ࠲࡭ࡧࡳࡩ࠴ࠪ࠰ࠬ࠭ࠩࠋࠋࠦࡷࡪࡺࡴࡪࡰࡪࡷ࠳ࡹࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࠪࠪࡹࡸ࡫ࡲ࠯ࡪࡤࡷ࡭࠹ࠧ࠭ࠩࠪ࠭ࠏࠏࠣࡴࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡶࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࠮ࠧࡶࡵࡨࡶ࠳࡮ࡡࡴࡪ࠷ࠫ࠱࠭ࠧࠪࠌࠌࠧࡪࡲࡳࡦ࠼ࠣࡪ࡮ࡲࡥࠡ࠿ࠣࠫࡸࡧࡶࡦࡴࡨࡥࡱ࡮ࡡࡴࡪ࠷ࠫࠏࠏࠣࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡤࡺࡪ࡯࡮ࡱࡷࡷࠫࠏࠏࠣࡪࡰࡳࡹࡹࠦ࠽ࠡ࡯ࡧ࠹࡫ࡻ࡬࡭ࠢ࠮ࠤࠬࠦࠠࡠࡡࡢࠤࠥࡌ࡯ࡶࡰࡧࠤࡦࡺ࠺ࠨࠢ࠮ࠤࡸࡺࡲࠩ࡫ࠬࠤ࠰ࠦࠧࠡࠢࡢࡣࡤࠦࠠࠨࠢ࠮ࠤ࡭ࡧࡳࡩࡅࡲࡱࡵࡵ࡮ࡦࡰࡷࡷࠏࠏࠣࠊࠥࡳࡥࡾࡲ࡯ࡢࡦࠣࡁࠥࢁࠠࠨࡨ࡬ࡰࡪ࠭ࠠ࠻ࠢࡩ࡭ࡱ࡫ࠠ࠭ࠢࠪ࡭ࡳࡶࡵࡵࠩࠣ࠾ࠥ࡯࡮ࡱࡷࡷࠤࢂࠐࠉࠤࠋࠦࡨࡦࡺࡡࠡ࠿࡙ࠣࡗࡒࡅࡏࡅࡒࡈࡊ࠮ࡰࡢࡻ࡯ࡳࡦࡪࠩࠋࠋࠦࠍࠨ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡎࡐࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱ࡪࡡࡵࡣ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࡐࡎࡈࡒࡂࡔ࡜࠱ࡉ࡛ࡍࡎ࡛ࡆࡐࡎࡋࡎࡕࡋࡇ࠱࠶ࡹࡴࠨࠫࠍࠍࠨ࡮ࡥࡢࡦࡨࡶࡸࠦ࠽ࠡࡽࠣࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ࠾ࠥ࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬࠦࡽࠋࠋࠦࡴࡦࡿ࡬ࡰࡣࡧࠤࡂࠦࠢࡧ࡫࡯ࡩࡂࠨࠫࡧ࡫࡯ࡩ࠰ࠨࠦࡪࡰࡳࡹࡹࡃࠢࠬ࡫ࡱࡴࡺࡺࠊࠊࠥ࡬ࡱࡵࡵࡲࡵࠢࡵࡩࡶࡻࡥࡴࡶࡶࠎࠎࠩࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡶࡪࡷࡵࡦࡵࡷࡷ࠳ࡸࡥࡲࡷࡨࡷࡹ࠮ࠢࡑࡑࡖࡘࠧ࠲ࠠࡶࡴ࡯࠰ࠥࡪࡡࡵࡣࡀࡴࡦࡿ࡬ࡰࡣࡧ࠰ࠥ࡮ࡥࡢࡦࡨࡶࡸࡃࡨࡦࡣࡧࡩࡷࡹࠩࠋࠋࠦࠍࠨ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࠦࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࡪࡷࡱࡱ࠲ࡨࡵ࡯࡯࠭ࠏࠏࠣࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴ࠿࠵࠯ࡦ࡯ࡤࡨࡲࡧࡨࡥ࡫࠱ࡴࡾࡺࡨࡰࡰࡤࡲࡾࡽࡨࡦࡴࡨ࠲ࡨࡵ࡭࠰ࡵࡤࡺࡪ࡯࡮ࡱࡷࡷࠫࠏࠏࠣࡱࡣࡼࡰࡴࡧࡤࠡ࠿ࠣࡿࠥ࠭ࡦࡪ࡮ࡨࠫࠥࡀࠠࠨࡵࡤࡺࡪ࡮ࡡࡴࡪࠪࠤ࠱ࠦࠧࡪࡰࡳࡹࡹ࠭ࠠ࠻ࠢࡰࡨ࠺࡬ࡵ࡭࡮ࠣ࠯ࠥ࠭ࠠࠡࡡࡢࡣࠥࠦࠧࠡ࠭ࠣ࡬ࡦࡹࡨࡄࡱࡰࡴࡴࡴࡥ࡯ࡶࡶࠤࢂࠐࠉࠤࡦࡤࡸࡦࠦ࠽ࠡࡗࡕࡐࡊࡔࡃࡐࡆࡈࠬࡵࡧࡹ࡭ࡱࡤࡨ࠮ࠐࠉࠤࡴࡨࡸࡺࡸ࡮ࠡࠩࠪࠎࠎࠨࠢࠣ╴")
def l11l111l111_ll_(url,l11lll11l11_ll_):
	if url.replace(l111lll_ll_ (u"࠭࠮ࠨ╵"),l111lll_ll_ (u"ࠧࠨ╶")).isdigit(): return [url]
	try:
		packet = struct.pack(l111lll_ll_ (u"ࠣࡀࡋࠦ╷"), 12049)
		packet += struct.pack(l111lll_ll_ (u"ࠤࡁࡌࠧ╸"), 256)
		packet += struct.pack(l111lll_ll_ (u"ࠥࡂࡍࠨ╹"), 1)
		packet += struct.pack(l111lll_ll_ (u"ࠦࡃࡎࠢ╺"), 0)
		packet += struct.pack(l111lll_ll_ (u"ࠧࡄࡈࠣ╻"), 0)
		packet += struct.pack(l111lll_ll_ (u"ࠨ࠾ࡉࠤ╼"), 0)
		l1lll111lll_ll_ = url.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠱࠽࠭╽")).split(l111lll_ll_ (u"ࠣ࠰ࠥ╾"))
		for part in l1lll111lll_ll_:
			parts = part.encode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ╿"))
			packet += struct.pack(l111lll_ll_ (u"ࠥࡆࠧ▀"), len(part))
			for l1l11llll11_ll_ in part:
				packet += struct.pack(l111lll_ll_ (u"ࠦࡨࠨ▁"), l1l11llll11_ll_.encode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠯࠻ࠫ▂")))
		packet += struct.pack(l111lll_ll_ (u"ࠨࡂࠣ▃"), 0)
		packet += struct.pack(l111lll_ll_ (u"ࠢ࠿ࡊࠥ▄"), 1)
		packet += struct.pack(l111lll_ll_ (u"ࠣࡀࡋࠦ▅"), 1)
		sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		sock.sendto(bytes(packet), (l11lll11l11_ll_, 53))
		data, addr = sock.recvfrom(1024)
		sock.close()
		l11lllll111_ll_ = struct.unpack_from(l111lll_ll_ (u"ࠤࡁࡌࡍࡎࡈࡉࡊࠥ▆"), data, 0)
		l1ll11l11l1_ll_ = l11lllll111_ll_[3]
		offset = len(url)+18
		answer = []
		for _ in range(l1ll11l11l1_ll_):
			l1l1lll1ll1_ll_ = offset
			l1l1l1l11l1_ll_ = 1
			l1l1ll1llll_ll_ = False
			while True:
				l1l11llll11_ll_ = struct.unpack_from(l111lll_ll_ (u"ࠥࡂࡇࠨ▇"), data, l1l1lll1ll1_ll_)[0]
				if l1l11llll11_ll_ == 0:
					l1l1lll1ll1_ll_ += 1
					break
				# l11l111111l_ll_ the field l1l111l1111_ll_ the first l1l1111l111_ll_ bits equal to 1, l1ll1llll11_ll_ a pointer
				if l1l11llll11_ll_ >= 192:
					l1l11l1l11l_ll_ = struct.unpack_from(l111lll_ll_ (u"ࠦࡃࡈࠢ█"), data, l1l1lll1ll1_ll_ + 1)[0]
					# l11l1lllll1_ll_ the pointer
					l1l1lll1ll1_ll_ = ((l1l11llll11_ll_ << 8) + l1l11l1l11l_ll_ - 0xc000) - 1
					l1l1ll1llll_ll_ = True
				l1l1lll1ll1_ll_ += 1
				if l1l1ll1llll_ll_ == False: l1l1l1l11l1_ll_ += 1
			if l1l1ll1llll_ll_ == True: l1l1l1l11l1_ll_ += 1
			offset = offset + l1l1l1l11l1_ll_
			l1ll1l1l11l_ll_ = struct.unpack_from(l111lll_ll_ (u"ࠧࡄࡈࡉࡋࡋࠦ▉"), data, offset)
			offset = offset + 10
			l1l1111l1ll_ll_ = l1ll1l1l11l_ll_[0]
			l11lll1l111_ll_ = l1ll1l1l11l_ll_[3]
			if l1l1111l1ll_ll_ == 1: # A type
				l1l111lllll_ll_ = struct.unpack_from(l111lll_ll_ (u"ࠨ࠾ࠣ▊")+l111lll_ll_ (u"ࠢࡃࠤ▋")*l11lll1l111_ll_, data, offset)
				ip = l111lll_ll_ (u"ࠨࠩ▌")
				for l1l11llll11_ll_ in l1l111lllll_ll_: ip += str(l1l11llll11_ll_) + l111lll_ll_ (u"ࠩ࠱ࠫ▍")
				ip = ip[0:-1]
				answer.append(ip)
			if l1l1111l1ll_ll_ in [1,2,5,6,15,28]: offset = offset + l11lll1l111_ll_
	except: answer = []
	if not answer: l1111l1l_ll_(l111lll_ll_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ▎"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗࠦࡦࡢ࡫࡯ࡩࡩࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ▏")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ▐"))
	return answer
def l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_,l11111l11l_ll_=True):
	if l1llll_ll_:
		if l1ll_ll_==l111lll_ll_ (u"࠭ࡂࡐࡍࡕࡅࠬ░"): l11llll111l_ll_ = [l111lll_ll_ (u"ࠧไสสีࠬ▒")]
		else:
			l11llll111l_ll_ = [l111lll_ll_ (u"ࠨ࠳࠹ࠫ▓"),l111lll_ll_ (u"ࠩ࠴࠻ࠬ▔"),l111lll_ll_ (u"ࠪ࠵࠽࠭▕"),l111lll_ll_ (u"ࠫ࠶࠿ࠧ▖"),l111lll_ll_ (u"ࠬ࠸࠰ࠨ▗"),l111lll_ll_ (u"࠭࠲࠲ࠩ▘"),l111lll_ll_ (u"ࠧ࠳࠴ࠪ▙")]
			l11llll111l_ll_ += [l111lll_ll_ (u"ࠨࡴ࠽ࠫ▚"),l111lll_ll_ (u"ࠩࡵࠤࠬ▛"),l111lll_ll_ (u"ࠪࡶ࠲࠭▜"),l111lll_ll_ (u"ࠫ࠲ࡸࠧ▝"),l111lll_ll_ (u"ࠬ࠳࡭ࡢࠩ▞"),l111lll_ll_ (u"࠭ใษษิࠫ▟"),l111lll_ll_ (u"ࠧษษ็฾ࠬ■"),l111lll_ll_ (u"ࠨࡣࡧࡹࡱࡺࠧ□")]
		for rating in l1llll_ll_:
			rating = rating.lower().decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ▢")).encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ▣"))
			if l111lll_ll_ (u"ࠫࡳࡵࡴࠡࡴࡤࡸࡪࡪࠧ▤") in rating: continue
			if l111lll_ll_ (u"ࠬࡻ࡮ࡳࡣࡷࡩࡩ࠭▥") in rating: continue
			if l111lll_ll_ (u"ฺ๋࠭ำฺ้ࠣ์แࠨ▦") in rating: continue
			if l11llll1l1l_ll_(l111lll_ll_ (u"ࠧࡃࡖࡈࡼࡕ࡜࠱࠺ࡕࡕ࡚ࡓ࡛ࡕ࡭ࡘࡇ࡚ࡊ࡜ࡅ࡙ࠩ▧")): continue
			if rating==l111lll_ll_ (u"ࠨࡴࠪ▨") or any(value in rating for value in l11llll111l_ll_):
				l1111l1l_ll_(l111lll_ll_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ▩"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡢࡦࡸࡰࡹࡹࠠࡷ࡫ࡧࡩࡴࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ▪")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ▫"))
				if l11111l11l_ll_: l1ll11l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ▬"),l111lll_ll_ (u"࠭วๅใํำ๏๎ࠠๅๆๆฬฬืࠠโไฺࠤํษๆศ่๊ࠢ฾ะ็ࠨ▭"))
				return True
	return False
	l111lll_ll_ (u"ࠢࠣࠤࠍࠍࠎ࡬࡯ࡶࡰࡧࠤࡂࠦࡆࡢ࡮ࡶࡩࠏࠏࠉࡧࡱࡵࠤࡷࡧࡴࡪࡰࡪࠤ࡮ࡴࠠࡳࡣࡷ࡭ࡳ࡭ࡌࡊࡕࡗ࠾ࠏࠏࠉࠊࡴࡤࡸ࡮ࡴࡧࠡ࠿ࠣࡶࡦࡺࡩ࡯ࡩ࠱ࡰࡴࡽࡥࡳࠪࠬ࠲ࡩ࡫ࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭࠳࡫࡮ࡤࡱࡧࡩ࠭࠭ࡵࡵࡨ࠻ࠫ࠮ࠐࠉࠊࠋࠦࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࠧࠨ࠮ࡵࡥࡹ࡯࡮ࡨࠫࠍࠍࠎࠏࡦࡰࡴࠣࡦࡱࡵࡣ࡬ࡧࡧࠤ࡮ࡴࠠࡣ࡮ࡲࡧࡰ࡫ࡤࡍࡋࡖࡘ࠿ࠐࠉࠊࠋࠌ࡭࡫ࠦ࡬ࡦࡰࠫࡦࡱࡵࡣ࡬ࡧࡧ࠭ࡁࡃ࠲࠻ࠢࡥࡰࡴࡩ࡫ࡦࡦࠣࡁࠥ࠭࡟ࠨ࠭ࡥࡰࡴࡩ࡫ࡦࡦ࠮ࠫࡤ࠭ࠊࠊࠋࠌࠍ࡫ࡵࡵ࡯ࡦࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡟ࠥ࠳࠺ࡠ࠿࡟ࠫࡡࠨ࡜ࡽ࡟ࠪ࠯ࡧࡲ࡯ࡤ࡭ࡨࡨ࠰࡛࠭ࠡ࠯࠽ࡣࡂࡢࠧ࡝ࠤ࡟ࢀࡢ࠭ࠬࡳࡣࡷ࡭ࡳ࡭ࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࠉࠊࠥࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭ࡸࡡࡵ࡫ࡱ࡫࠱ࡹࡴࡳࠪࡩࡳࡺࡴࡤࠪࠫࠍࠍࠎࠏࠉࡪࡨࠣࡪࡴࡻ࡮ࡥ࠼ࠣࡦࡷ࡫ࡡ࡬ࠌࠌࠍࠎ࡯ࡦࠡࡨࡲࡹࡳࡪ࠺ࠡࡤࡵࡩࡦࡱࠊࠊ࡫ࡩࠤ࡫ࡵࡵ࡯ࡦ࠽ࠎࠎࠏࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ࠭ࡎࡒࡋࡌࡏࡎࡈࠪࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠩࠬࠩࠣࠤࠥࡈ࡬ࡰࡥ࡮ࡩࡩࠦࡡࡥࡷ࡯ࡸࡸࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ࠭ࡸࡶࡱ࠱ࠧࠡ࡟ࠪ࠭ࠏࠏࠉࡅࡋࡄࡐࡔࡍ࡟ࡏࡑࡗࡍࡋࡏࡃࡂࡖࡌࡓࡓ࠮ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ࠰ࠬอไโ์า๎ํࠦไๅๅหหึࠦแใูࠣ์ศ์วࠡ็้฽ฯํࠧࠪࠌࠌࠍࡷ࡫ࡴࡶࡴࡱࠤ࡙ࡸࡵࡦࠌࠌࡶࡪࡺࡵࡳࡰࠣࡊࡦࡲࡳࡦࠌࠌࠦࠧࠨ▮")
l111lll_ll_ (u"ࠣࠤࠥࠎࠨ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠿ࠏ࡭ࡱࡦ࠯ࠤ࡭ࡲࡳ࠭ࠢ࡬ࡷࡲࠐࠣࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲ࠽ࠍࠎࡸࡴ࡮ࡲࠍࠧࡽࡨ࡭ࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࡥࡹ࡮ࡲࡴࡪࡰࠫࠫࡎࡴࡳࡵࡣ࡯ࡰࡆࡪࡤࡰࡰࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠯ࠧ࠭ࡹࡤ࡭ࡹࡃࡔࡳࡷࡨ࠭ࠏࠐࡩ࡮ࡲࡲࡶࡹࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࡬ࡪࡲࡰࡦࡴࠍ࡬ࡪࡲࡰࡦࡴࠣࡁࠥ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࡫ࡩࡱࡶࡥࡳ࠰ࡋࡩࡱࡶࡥࡳࠪࠪ࡬ࡱࡹࠧࠪࠌ࡬ࡲࡸࡺࡡ࡭࡮ࡨࡨࠥࡃࠠࡩࡧ࡯ࡴࡪࡸ࠮ࡤࡪࡨࡧࡰࡥࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠬ࠮ࠐࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪ࡭ࡸࠦࡩ࡯ࡵࡷࡥࡱࡲࡥࡥࠩ࠯ࡷࡹࡸࠨࡪࡰࡶࡸࡦࡲ࡬ࡦࡦࠬ࠭ࠏ࡯ࡦࠡࡰࡲࡸࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤ࠻ࠌࠌࡽࡪࡹࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡ࡜ࡉࡘࡔࡏࠩࠩࡄࡨࡩࡵ࡮ࠡࡰࡲࡸࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠨ࠮ࠪ࡭ࡳࡹࡴࡢ࡮࡯ࠤࡳࡵࡷࠡࡁࠪ࠰ࠬ࠭ࠬࠨࠩ࠯่๊ࠫวࠨ࠮๊ࠪ฾๋ࠧࠪࠌࠌ࡭࡫ࠦࡹࡦࡵ࠽ࠤ࡭࡫࡬ࡱࡧࡵ࠲ࡤ࡯࡮ࡴࡶࡤࡰࡱࡥࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰࠬ࠮ࠐࠢࠣࠤ▯")
def l11llllllll_ll_(l1111l1l11_ll_=True):
	if l1111l1l11_ll_==l111lll_ll_ (u"ࠩࠪ▰"): l1111l1l11_ll_ = True
	enabled = xbmc.getCondVisibility(l111lll_ll_ (u"ࠪࡗࡾࡹࡴࡦ࡯࠱ࡌࡦࡹࡁࡥࡦࡲࡲ࠭࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡥࡩࡧࡰࡵ࡫ࡹࡩ࠮࠭▱"))
	if enabled and l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ▲"),l111lll_ll_ (u"ࠬ็อึࠢสฺฬ็ษࠡ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡡࡥࡣࡳࡸ࡮ࡼࡥࠡ࡞ࡱࡠࡷࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไ่ࠢ์ั๎ฯส๋้ࠢๆ฿ไส๋ࠢะฬําสࠢ็่ฬูสฯัส้ࠬ△"))
	elif not enabled:
		l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ▴"),l111lll_ll_ (u"ࠧࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡧࡤࡢࡲࡷ࡭ࡻ࡫ࠠ࡝ࡰ࡟ࡶࠥํะ่ࠢฦ่ส฼วโหࠣ฽๋ีใࠡ฼ํี๋ࠥแฺๆฬࠤศ๎ࠠ฻์ิࠤ๊๎ฬ้ัฬࠤ࠳๊ࠦอสࠣฮ๋฻๊ษ้สࠤํะแฺ์็๋ฬࠦไไ์ࠣฮ฾๋ไࠡ฻้ำ่ࠦแ๋ัํ์์อส่๋ࠡ฽ࠥࡳࡰࡥࠢ࡫ࡰࡸࠦࡩࡴ࡯ࠣࠤ࠳ࠦ็ๅࠢอี๏ีࠠหุ่๎อ่ࠦหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤฬ๊ย็ࠢยࠫ▵"),l111lll_ll_ (u"ࠨࠩ▶"),l111lll_ll_ (u"ࠩࠪ▷"),l111lll_ll_ (u"ࠪ็้อࠧ▸"),l111lll_ll_ (u"๋ࠫ฿ๅࠨ▹"))
		if l111111l1_ll_:
			xbmc.executebuiltin(l111lll_ll_ (u"ࠬࡏ࡮ࡴࡶࡤࡰࡱࡇࡤࡥࡱࡱࠬ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮࠰ࡤࡨࡦࡶࡴࡪࡸࡨ࠭ࠬ►"))
			time.sleep(1)
			xbmc.executebuiltin(l111lll_ll_ (u"࠭ࡓࡦࡰࡧࡇࡱ࡯ࡣ࡬ࠪ࠴࠵࠮࠭▻"))
			time.sleep(1)
			while xbmc.getCondVisibility(l111lll_ll_ (u"ࠧࡘ࡫ࡱࡨࡴࡽ࠮ࡊࡵࡄࡧࡹ࡯ࡶࡦࠪࡳࡶࡴ࡭ࡲࡦࡵࡶࡨ࡮ࡧ࡬ࡰࡩࠬࠫ▼")): time.sleep(1)
			result = xbmc.executeJSONRPC(l111lll_ll_ (u"ࠨࡽࠥ࡮ࡸࡵ࡮ࡳࡲࡦࠦ࠿ࠨ࠲࠯࠲ࠥ࠰ࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡂࡦࡧࡳࡳࡹ࠮ࡔࡧࡷࡅࡩࡪ࡯࡯ࡇࡱࡥࡧࡲࡥࡥࠤ࠯ࠦ࡮ࡪࠢ࠻࠳࠯ࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡢࡦࡧࡳࡳ࡯ࡤࠣ࠼ࠥ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧࠥ࠰ࠧ࡫࡮ࡢࡤ࡯ࡩࡩࠨ࠺ࡵࡴࡸࡩࢂࢃࠧ▽"))
			if l111lll_ll_ (u"ࠩࡒࡏࠬ▾") in result and l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭▿"),l111lll_ll_ (u"ࠫฯ๋ࠠศๆอฺ๊๐ศ๊ࠡส่ฯ็ู๋ๆࠣ์์ึ็ࠡษ็ษ฻อแสࠢ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠢฯห์ุษࠡๆ็หุะฮะษ่ࠫ◀"))
			elif l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ◁"),l111lll_ll_ (u"࠭แีๆࠣๅ๏ࠦวๅฬู้๏ฮࠠฤ๊ࠣห้ะแฺ์็ࠤ࠳ࠦวๅสิ๊ฬ๋ฬࠡ฼ํี่ࠥวะำࠣ฽้๏ࠠหุ่๎อࠦร้ࠢอๅ฾๐ไ้ࠡำ๋ࠥอไฦุสๅฮࠦ࠮๊ࠡส่า๊่๊ࠠࠣฮ๋฻๊ษ้สࠤํะแฺ์็๋ฬࠦๅ็ࠢัหึาࠠศๆหี๋อๅอࠩ◂"))
	return
def l1ll11llll1_ll_(l1111l1l11_ll_=True):
	if l1111l1l11_ll_==l111lll_ll_ (u"ࠧࠨ◃"): l1111l1l11_ll_ = True
	enabled = xbmc.getCondVisibility(l111lll_ll_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡊࡤࡷࡆࡪࡤࡰࡰࠫ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡴࡷࡱࡵ࠯ࠧ◄"))
	if enabled and l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ◅"),l111lll_ll_ (u"ࠪๅา฻ࠠศุสๅฮࠦࡩ࡯ࡲࡸࡸࡸࡺࡲࡦࡣࡰ࠲ࡷࡺ࡭ࡱࠢ࡟ࡲࡡࡸ่ࠠา๊ࠤศ๊ลืษไอࠥ฿ๆะๅ้ࠣํา่ะหࠣ์๊็ูๅหࠣ์ัอ็ำห่้ࠣอำหะาห๊࠭◆"))
	elif not enabled:
		l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ◇"),l111lll_ll_ (u"ࠬ࡯࡮ࡱࡷࡷࡷࡹࡸࡥࡢ࡯࠱ࡶࡹࡳࡰࠡ࡞ࡱࡠࡷࠦ็ั้ࠣว้หึศใฬࠤ฾์ฯไࠢ฽๎ึࠦๅโ฻็อࠥษ่ࠡ฼ํี๋่ࠥอ๊าอࠥ࠴๋ࠠฮหࠤฯ์ี๋ส๊หࠥ๎สโ฻ํ่์อࠠๅๅํࠤฯ฿ๅๅࠢ฼๊ิ้ࠠโ์า๎ํํวห้ࠢ์฾ࠦࡲࡵ࡯ࡳࠤࠥ࠴่ࠠๆࠣฮึ๐ฯࠡฬู้๏ฮ้ࠠฬไ฽๏๊่ࠠา๊ࠤฬ๊ลืษไอࠥอไร่ࠣรࠬ◈"),l111lll_ll_ (u"࠭ࠧ◉"),l111lll_ll_ (u"ࠧࠨ◊"),l111lll_ll_ (u"ࠨๅ็หࠬ○"),l111lll_ll_ (u"้ࠩ฽๊࠭◌"))
		if l111111l1_ll_:
			xbmc.executebuiltin(l111lll_ll_ (u"ࠪࡍࡳࡹࡴࡢ࡮࡯ࡅࡩࡪ࡯࡯ࠪ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡳࡶࡰࡴ࠮࠭◍"))
			time.sleep(1)
			xbmc.executebuiltin(l111lll_ll_ (u"ࠫࡘ࡫࡮ࡥࡅ࡯࡭ࡨࡱࠨ࠲࠳ࠬࠫ◎"))
			time.sleep(1)
			while xbmc.getCondVisibility(l111lll_ll_ (u"ࠬ࡝ࡩ࡯ࡦࡲࡻ࠳ࡏࡳࡂࡥࡷ࡭ࡻ࡫ࠨࡱࡴࡲ࡫ࡷ࡫ࡳࡴࡦ࡬ࡥࡱࡵࡧࠪࠩ●")): time.sleep(1)
			result = xbmc.executeJSONRPC(l111lll_ll_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡇࡤࡥࡱࡱࡷ࠳࡙ࡥࡵࡃࡧࡨࡴࡴࡅ࡯ࡣࡥࡰࡪࡪࠢ࠭ࠤ࡬ࡨࠧࡀ࠱࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡧࡤࡥࡱࡱ࡭ࡩࠨ࠺ࠣ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲ࠴ࡲࡵ࡯ࡳࠦ࠱ࠨࡥ࡯ࡣࡥࡰࡪࡪࠢ࠻ࡶࡵࡹࡪࢃࡽࠨ◐"))
			if l111lll_ll_ (u"ࠧࡐࡍࠪ◑") in result and l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ◒"),l111lll_ll_ (u"ࠩอ้ࠥอไหุ่๎อ่ࠦศๆอๅ฾๐ไ๊๊ࠡิ์ࠦวๅวูหๆฯࠠࡪࡰࡳࡹࡹࡹࡴࡳࡧࡤࡱ࠳ࡸࡴ࡮ࡲࠣะฬําสࠢ็่ฬูสฯัส้ࠬ◓"))
			elif l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭◔"),l111lll_ll_ (u"ࠫๆฺไࠡใํࠤฬ๊ส็ืํฬࠥษ่ࠡษ็ฮๆ฿๊ๅࠢ࠱ࠤฬ๊ศา่ส้ัฺ๋ࠦำࠣๆฬีัࠡ฻็ํࠥะๆึ์หࠤศ๎ࠠหใ฼๎้ࠦ็ั้ࠣห้หึศใฬࠤ࠳่ࠦศๆะ่ࠥํ่ࠡฬู้๏ฮ็ศ๋ࠢฮๆ฿๊ๅ้สࠤ๊์ࠠฯษิะࠥอไษำ้ห๊าࠧ◕"))
	return
def l1111l1lll_ll_(table,column,data,l1l11lll1ll_ll_):
	status = settings.getSetting(l111lll_ll_ (u"ࠬࡩࡡࡤࡪࡨ࠲ࡸࡺࡡࡵࡷࡶࠫ◖"))
	if l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࠫ◗") not in table and table not in [l111lll_ll_ (u"ࠧࡎࡋࡖࡇࠬ◘")]:
		if status==l111lll_ll_ (u"ࠨࡕࡗࡓࡕ࠭◙"): return
		elif status==l111lll_ll_ (u"ࠩࡖࡌࡔࡘࡔࠨ◚") and l1l11lll1ll_ll_>l11l1lll111_ll_: l1l11lll1ll_ll_ = l11l1lll111_ll_
	if l1l11lll1ll_ll_==l1l11lll_ll_: return
	l11llll1l11_ll_ = str(type(data))
	#size = 1
	#if   l111lll_ll_ (u"ࠪࡷࡹࡸࠧ◛") in l11llll1l11_ll_: size = len(data)
	#elif l111lll_ll_ (u"ࠫࡱ࡯ࡳࡵࠩ◜") in l11llll1l11_ll_: size = len(data)
	#elif l111lll_ll_ (u"ࠬࡪࡩࡤࡶࠪ◝") in l11llll1l11_ll_: size = len(data.values())
	#else:
	#if size==None: return
	try:
		html = data.content
		if l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ◞") in html or html==l111lll_ll_ (u"ࠧࠨ◟"): return
	except: pass
	l1l11lll1ll_ll_ = l1l11lll1ll_ll_+now
	import sqlite3
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	c = conn.cursor()
	conn.text_factory = str
	c.execute(l111lll_ll_ (u"ࠨࡅࡕࡉࡆ࡚ࡅࠡࡖࡄࡆࡑࡋࠠࡊࡈࠣࡒࡔ࡚ࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠨ◠")+table+l111lll_ll_ (u"ࠩࠣࠬࡪࡾࡰࡪࡴࡼ࠰ࡨࡵ࡬ࡶ࡯ࡱ࠰ࡩࡧࡴࡢࠫࠪ◡"))
	text = pickle.dumps(data)
	compressed = zlib.compress(text)
	t = (l1l11lll1ll_ll_,str(column),compressed)
	c.execute(l111lll_ll_ (u"ࠪࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࠩ◢")+table+l111lll_ll_ (u"ࠫࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠮࠭◣"),t)
	conn.commit()
	conn.close()
	return
def l1llll11l1l_ll_(table,column):
	#l1ll1l_ll_(table,l111lll_ll_ (u"ࠬࡘࡅࡂࡆࡢࡊࡗࡕࡍࡠࡕࡔࡐ࠸࠭◤"))
	if l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣࡌࡘࡏࡖࡒࡖࠫ◥") in table or l111lll_ll_ (u"ࠧࡊࡒࡗ࡚ࡤࡏࡔࡆࡏࡖࠫ◦") in table: data = []
	elif l111lll_ll_ (u"ࠨࡋࡓࡘ࡛ࡥࡓࡕࡔࡈࡅࡒ࡙ࠧ◧") in table or table in [l111lll_ll_ (u"ࠩࡐࡍࡘࡉࠧ◨")]: data = {}
	elif table in [l111lll_ll_ (u"ࠪࡓࡕࡋࡎࡖࡔࡏࠫ◩")]: data = l111lll_ll_ (u"ࠫࠬ◪")
	#elif table in [l111lll_ll_ (u"ࠬࡕࡐࡆࡐࡘࡖࡑࡥࡒࡆࡓࡘࡉࡘ࡚ࡓࠨ◫")]: data = l1l1ll1l1ll_ll_()
	#elif table in [l111lll_ll_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ◬")]: data = ((l111lll_ll_ (u"ࠧࠨ◭"),l111lll_ll_ (u"ࠨࠩ◮")))
	else: data = None
	status = settings.getSetting(l111lll_ll_ (u"ࠩࡦࡥࡨ࡮ࡥ࠯ࡵࡷࡥࡹࡻࡳࠨ◯"))
	SHORT = 0
	if l111lll_ll_ (u"ࠪࡍࡕ࡚ࡖࠨ◰") not in table and table not in [l111lll_ll_ (u"ࠫࡒࡏࡓࡄࠩ◱")]:
		if status==l111lll_ll_ (u"࡙ࠬࡔࡐࡒࠪ◲"): return data
		elif status==l111lll_ll_ (u"࠭ࡓࡉࡑࡕࡘࠬ◳"): SHORT = l11l1lll111_ll_
		#elif status==l111lll_ll_ (u"ࠧࡔࡊࡒࡖ࡙࠭◴") and l1l11lll1ll_ll_>l11l1lll111_ll_: l1l11lll1ll_ll_ = l11l1lll111_ll_
	import sqlite3
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	c = conn.cursor()
	conn.text_factory = str
	t = (str(column),)
	try:
		if SHORT!=0: c.execute(l111lll_ll_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧ◵")+table+l111lll_ll_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡨࡼࡵ࡯ࡲࡺࡀࠪ◶")+str(now+SHORT))
		c.execute(l111lll_ll_ (u"ࠪࡈࡊࡒࡅࡕࡇࠣࡊࡗࡕࡍࠡࠩ◷")+table+l111lll_ll_ (u"ࠫࠥ࡝ࡈࡆࡔࡈࠤࡪࡾࡰࡪࡴࡼࡀࠬ◸")+str(now))
		c.execute(l111lll_ll_ (u"࡙ࠬࡅࡍࡇࡆࡘࠥࡪࡡࡵࡣࠣࡊࡗࡕࡍࠡࠩ◹")+table+l111lll_ll_ (u"࠭ࠠࡘࡊࡈࡖࡊࠦࡣࡰ࡮ࡸࡱࡳࡃ࠿ࠨ◺"),t)
	except: pass
	rows = c.fetchall()
	conn.commit()
	conn.close()
	if rows:
		text = zlib.decompress(rows[0][0])
		try: data = pickle.loads(text)
		except: l11111l1ll_ll_(table,column)
	return data
def l11111l1ll_ll_(table,column=None):
	import sqlite3
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	c = conn.cursor()
	conn.text_factory = str
	if column==None: c.execute(l111lll_ll_ (u"ࠧࡅࡔࡒࡔ࡚ࠥࡁࡃࡎࡈࠤࡎࡌࠠࡆ࡚ࡌࡗ࡙࡙ࠠࠨ◻")+table)
	else:
		t = (str(column),)
		try: c.execute(l111lll_ll_ (u"ࠨࡆࡈࡐࡊ࡚ࡅࠡࡈࡕࡓࡒࠦࠧ◼")+table+l111lll_ll_ (u"࡛ࠩࠣࡍࡋࡒࡆࠢࡦࡳࡱࡻ࡭࡯࠿ࡂࠫ◽"),t)
		except: pass
	conn.commit()
	conn.close()
	return
def l1lll11ll_ll_(data):
	import urllib
	return urllib.urlencode(data)
def l1l11l1111l_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"࡙ࠪࡗࡒࡄࡆࡅࡒࡈࡊ࠭◾"))
	if l111lll_ll_ (u"ࠫࡂ࠭◿") in url:
		if l111lll_ll_ (u"ࠬࡅࠧ☀") in url: l1ll111_ll_,filters = url.split(l111lll_ll_ (u"࠭࠿ࠨ☁"))
		else: l1ll111_ll_,filters = l111lll_ll_ (u"ࠧࠨ☂"),url
		filters = filters.split(l111lll_ll_ (u"ࠨࠨࠪ☃"))
		data2 = {}
		for filter in filters:
			#l1ll1l_ll_(filter,str(filters))
			key,value = filter.split(l111lll_ll_ (u"ࠩࡀࠫ☄"))
			data2[key] = value
	else: l1ll111_ll_,data2 = url,{}
	return l1ll111_ll_,data2
def l111ll1lll_ll_(html):
	html = html.replace(l111lll_ll_ (u"ࠪࡲࡺࡲ࡬ࠨ★"),l111lll_ll_ (u"ࠫࡓࡵ࡮ࡦࠩ☆")).replace(l111lll_ll_ (u"ࠬࡻ࡜ࠨࠩ☇"),l111lll_ll_ (u"࠭࡜ࠨࠩ☈"))
	html = html.replace(l111lll_ll_ (u"ࠧࡵࡴࡸࡩࠬ☉"),l111lll_ll_ (u"ࠨࡖࡵࡹࡪ࠭☊")).replace(l111lll_ll_ (u"ࠩࡩࡥࡱࡹࡥࠨ☋"),l111lll_ll_ (u"ࠪࡊࡦࡲࡳࡦࠩ☌"))
	return eval(html)
def l1l1ll1l111_ll_(text):
	dict = {
	l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ☍")		:l111lll_ll_ (u"๋ࠬฬๅัࠪ☎")
	,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ☏")		:l111lll_ll_ (u"ࠧโ์า๎ํ࠭☐")
	,l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭☑")			:l111lll_ll_ (u"ࠩๅ๊ฬฯࠧ☒")
	,l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎࠩ☓")		:l111lll_ll_ (u"๊ࠫ๎โฺࠢฦ็ํอๅࠡษ็ๆิ๐ๅࠨ☔")
	,l111lll_ll_ (u"ࠬࡇࡋࡘࡃࡐࠫ☕")		:l111lll_ll_ (u"࠭ๅ้ไ฼ࠤศ้่ศ็ࠣห้าฯ๋ัࠪ☖")
	,l111lll_ll_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎࠩ☗")		:l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦรไ๊ส้้ࠥวๆࠩ☘")
	,l111lll_ll_ (u"ࠩࡄࡐࡆࡘࡁࡃࠩ☙")		:l111lll_ll_ (u"้ࠪํู่ࠡๅ็ࠤฬู๊าสࠪ☚")
	,l111lll_ll_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭☛")		:l111lll_ll_ (u"๋่ࠬใ฻ࠣห้๋ๆษำࠣห้็วุ็ํࠫ☜")
	,l111lll_ll_ (u"࠭ࡁࡍࡍࡄ࡛࡙ࡎࡁࡓࠩ☝")	:l111lll_ll_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣห้้่ฬำࠪ☞")
	,l111lll_ll_ (u"ࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ☟")		:l111lll_ll_ (u"่ࠩ์็฿ࠠใ่สอࠥอไๆ฻สีๆ࠭☠")
	,l111lll_ll_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞ࠬ☡")	:l111lll_ll_ (u"๊ࠫ๎โฺࠢ฼ีอࠦไ๋๊้ึࠬ☢")
	,l111lll_ll_ (u"ࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩ☣")	:l111lll_ll_ (u"࠭ๅ้ไ฼ࠤฬ๐ฬ๋ࠢห๎ุะࠠࡷ࡫ࡳࠫ☤")
	,l111lll_ll_ (u"ࠧࡉࡇࡏࡅࡑ࠭☥")		:l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦ็ๅษ็ࠤ๏๎ส๋๊หࠫ☦")
	,l111lll_ll_ (u"ࠩࡌࡊࡎࡒࡍࠨ☧")		:l111lll_ll_ (u"้ࠪํู่ࠡไ้หฮࠦว๋ࠢไ๎้๋ࠧ☨")
	,l111lll_ll_ (u"ࠫࡎࡌࡉࡍࡏࡢࡅࡗࡇࡂࡊࡅࠪ☩")	:l111lll_ll_ (u"๋่ࠬใ฻ࠣๆ๋อษࠡษํࠤๆ๐ไๆࠢส่฾ืศ๋ࠩ☪")
	,l111lll_ll_ (u"࠭ࡉࡇࡋࡏࡑࡤࡋࡎࡈࡎࡌࡗࡍ࠭☫"):l111lll_ll_ (u"ࠧๆ๊ๅ฽่ࠥๆศหࠣห๏ࠦแ๋ๆ่ࠤฬ์ใๅ์ี๎ࠬ☬")
	,l111lll_ll_ (u"ࠨࡒࡄࡒࡊ࡚ࠧ☭")		:l111lll_ll_ (u"่ࠩ์็฿ࠠษษ้๎ฯ࠭☮")
	,l111lll_ll_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙ࠬ☯")		:l111lll_ll_ (u"๊ࠫ๎โฺࠢืห์ีࠠโ๊ิ๎ํ࠭☰")
	,l111lll_ll_ (u"࡙ࠬࡈࡐࡑࡉࡑࡆ࡞ࠧ☱")		:l111lll_ll_ (u"࠭ๅ้ไ฼ࠤู๎แࠡ็ส็ุ࠭☲")
	,l111lll_ll_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩ☳")		:l111lll_ll_ (u"ࠨ็๋ๆ฾ูࠦาสࠣื๏๐ฯࠨ☴")
	,l111lll_ll_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ☵")		:l111lll_ll_ (u"้ࠪํู่ࠡ์๋ฮ๏๎ศࠨ☶")
	,l111lll_ll_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛ࠬ☷")		:l111lll_ll_ (u"๋่ࠬใ฻ࠣื๏๋ว่ࠡส์ࠬ☸")
	,l111lll_ll_ (u"࠭ࡓࡉࡋࡄ࡚ࡔࡏࡃࡆࠩ☹")	:l111lll_ll_ (u"ࠧๆ๊ๅ฽ࠥ฻่หࠢสู่๐ูสࠩ☺")
	,l111lll_ll_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙ࠫ☻")	:l111lll_ll_ (u"่ࠩ์็฿ࠠใ่สอ้ࠥัษๆสลࠬ☼")
	,l111lll_ll_ (u"ࠪ࡝࡙ࡈ࡟ࡄࡊࡄࡒࡓࡋࡌࡔࠩ☽")	:l111lll_ll_ (u"๊ࠫ๎วใ฻ࠣ๎ํะ๊้สࠪ☾")
	,l111lll_ll_ (u"ࠬࡓ࡙ࡄࡋࡐࡅࠬ☿")		:l111lll_ll_ (u"࠭ๅ้ไ฼ࠤ๊อ๊ࠡีํ้ฬ࠭♀")
	,l111lll_ll_ (u"ࠧࡃࡑࡎࡖࡆ࠭♁")		:l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦศไำสࠫ♂")
	,l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋࡔࡗࠩ♃")		:l111lll_ll_ (u"้้ࠪ็ࠧ♄")
	,l111lll_ll_ (u"ࠫࡎࡖࡔࡗࠩ♅")			:l111lll_ll_ (u"๋ࠬไโࠩ♆")
	,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟ࠧ♇")		:l111lll_ll_ (u"ࠧๆๆไࠫ♈")
	,l111lll_ll_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕࠨ♉")		:l111lll_ll_ (u"่ࠩ์็฿ࠠๆ๊ไึࠥ็่า์๋ࠫ♊")
	,l111lll_ll_ (u"ࠪࡊࡆࡐࡅࡓࡕࡋࡓ࡜࠭♋")	:l111lll_ll_ (u"๊ࠫ๎โฺࠢไะึࠦิ้ࠩ♌")
	,l111lll_ll_ (u"ࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ♍")	:l111lll_ll_ (u"࠭ๅ้ไ฼ࠤิอ๊ๅ์้ࠣํฺๆࠨ♎")
	,l111lll_ll_ (u"ࠧࡆࡉ࡜ࡆࡊ࡙ࡔࠨ♏")		:l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦว๋ฮํࠤอ๐ำหࠩ♐")
	#,l111lll_ll_ (u"ࠩࡈࡋ࡞࠺ࡂࡆࡕࡗࠫ♑")	:l111lll_ll_ (u"ࠪࠫ♒")
	#,l111lll_ll_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠭♓")	:l111lll_ll_ (u"ࠬ࠭♔")
	#,l111lll_ll_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅࠩ♕")	:l111lll_ll_ (u"ࠧࠨ♖")
	#,l111lll_ll_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ♗"):l111lll_ll_ (u"ࠩࠪ♘")
	}
	if text in dict.keys(): return dict[text]
	return l111lll_ll_ (u"ࠪࠫ♙")
def l111lll1_ll_(l11ll1_ll_,l1111l_ll_=l111lll_ll_ (u"ࠫࠬ♚"),type=l111lll_ll_ (u"ࠬ࠭♛")):
	if type==l111lll_ll_ (u"࠭ࠧ♜"): type = l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭♝")
	result,l1l11111lll_ll_,httpd = l111lll_ll_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦ࠳ࠫ♞"),l111lll_ll_ (u"ࠩࠪ♟"),l111lll_ll_ (u"ࠪࠫ♠")
	if len(l11ll1_ll_)==3:
		url,subtitle,httpd = l11ll1_ll_
		if subtitle!=l111lll_ll_ (u"ࠫࠬ♡"): l1l11111lll_ll_ = l111lll_ll_ (u"ࠬࠦࠠࠡࡕࡸࡦࡹ࡯ࡴ࡭ࡧ࠽ࠤࡠࠦࠧ♢")+subtitle+l111lll_ll_ (u"࠭ࠠ࡞ࠩ♣")
	else: url,subtitle,httpd = l11ll1_ll_,l111lll_ll_ (u"ࠧࠨ♤"),l111lll_ll_ (u"ࠨࠩ♥")
	url = l1111_ll_(url)
	l1lll11l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩࠫࡠ࠳ࡧࡶࡪࡾ࡟࠲ࡹࡹࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠨࠩࠫ♦"),url.lower()+l111lll_ll_ (u"ࠪࠪࠫ࠭♧"),re.DOTALL|re.IGNORECASE)
	if l1lll11l1l_ll_: l1lll11l1l_ll_ = l1lll11l1l_ll_[0][0]
	else: l1lll11l1l_ll_ = l111lll_ll_ (u"ࠫࠬ♨")
	if l1111l_ll_ not in [l111lll_ll_ (u"ࠬࡊࡏࡘࡐࡏࡓࡆࡊࠧ♩"),l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࠫ♪")]:
		if l1111l_ll_!=l111lll_ll_ (u"ࠧࡅࡑ࡚ࡒࡑࡕࡁࡅࠩ♫"): url = url.replace(l111lll_ll_ (u"ࠨࠢࠪ♬"),l111lll_ll_ (u"ࠩࠨ࠶࠵࠭♭"))
		l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ♮"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡑࡴࡨࡴࡦࡸࡩ࡯ࡩࠣࡸࡴࠦࡰ࡭ࡣࡼ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩࠦࡶࡪࡦࡨࡳࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ♯")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ♰")+l1l11111lll_ll_)
		if l1lll11l1l_ll_==l111lll_ll_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ♱") and l1111l_ll_ not in [l111lll_ll_ (u"ࠧࡊࡒࡗ࡚ࠬ♲"),l111lll_ll_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ♳")]:
			headers = {l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭♴"):l111lll_ll_ (u"ࠪࠫ♵")}
			l1111ll_ll_,l1l111l_ll_ = l11l1l1l_ll_(url,headers)
			count = len(l1l111l_ll_)
			if count>1:
				selection = l1l1111_ll_(l111lll_ll_ (u"ࠫฬิสาࠢส่๊๊แࠡษ็้๋อำษ࠼ࠣࠬࠬ♶")+str(count)+l111lll_ll_ (u"ࠬࠦๅๅใࠬࠫ♷"), l1111ll_ll_)
				if selection == -1:
					l1ll11l_ll_(l111lll_ll_ (u"࠭สๆࠢศ่฿อมࠡษ็ฮูเ๊ๅࠩ♸"),l111lll_ll_ (u"ࠧࠨ♹"))
					return result
			else: selection = 0
			url = l1l111l_ll_[selection]
			if l1111ll_ll_[0]!=l111lll_ll_ (u"ࠨ࠯࠴ࠫ♺"):
				l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ♻"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳ࡙ࠥࡥ࡭ࡧࡦࡸࡪࡪࠠࠡࠢࡖࡩࡱ࡫ࡣࡵ࡫ࡲࡲ࠿࡛ࠦࠡࠩ♼")+l1111ll_ll_[selection]+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ♽")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ♾"))
		if l111lll_ll_ (u"࠭ࡨࡵࡶࡳࠫ♿") in url.lower() and l111lll_ll_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ⚀") not in url and l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡰࡴࡩ࠭⚁") not in url:
			if l111lll_ll_ (u"ࠩࡹࡩࡷ࡯ࡦࡺࡲࡨࡩࡷࡃࠧ⚂") not in url and l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࠬ⚃") in url.lower():
				if l111lll_ll_ (u"ࠫࢁ࠭⚄") not in url: url = url+l111lll_ll_ (u"ࠬࢂࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡪࡦࡲࡳࡦࠩ⚅")
				else: url = url+l111lll_ll_ (u"࠭ࠦࡷࡧࡵ࡭࡫ࡿࡰࡦࡧࡵࡁ࡫ࡧ࡬ࡴࡧࠪ⚆")
			if l111lll_ll_ (u"ࠧࡶࡵࡨࡶ࠲ࡧࡧࡦࡰࡷࠫ⚇") not in url.lower() and l1111l_ll_!=l111lll_ll_ (u"ࠨࡋࡓࡘ࡛࠭⚈"):
				if l111lll_ll_ (u"ࠩࡿࠫ⚉") not in url: url = url+l111lll_ll_ (u"ࠪࢀ࡚ࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴ࠾ࠨࠪ⚊")
				else: url = url+l111lll_ll_ (u"࡛ࠫࠫࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠩࠫ⚋")
	l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࡤࡒࡉࡏࡇࡖࠫ⚌"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡊࡳࡹࠦࡦࡪࡰࡤࡰࠥࡻࡲ࡭ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⚍")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⚎"))
	l1l111ll11l_ll_ = xbmcgui.ListItem()
	#l1l111ll11l_ll_ = xbmcgui.ListItem(l111lll_ll_ (u"ࠨࡶࡨࡷࡹ࠭⚏"))
	l1l1l111ll1_ll_,name,l1lll11111l_ll_,l11l11l1l1l_ll_,image,l1l11l11111_ll_,l11l1ll1lll_ll_,context = l11lllllll_ll_()
	if l1111l_ll_ not in [l111lll_ll_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ⚐"),l111lll_ll_ (u"ࠪࡍࡕ࡚ࡖࠨ⚑")]:
		#l1l111ll11l_ll_ = xbmcgui.ListItem(path=url)
		l1l111ll11l_ll_.setProperty(l111lll_ll_ (u"ࠫ࡮ࡴࡰࡶࡶࡶࡸࡷ࡫ࡡ࡮ࡣࡧࡨࡴࡴࠧ⚒"), l111lll_ll_ (u"ࠬ࠭⚓"))
		l1l111ll11l_ll_.setMimeType(l111lll_ll_ (u"࠭࡭ࡪ࡯ࡨ࠳ࡽ࠳ࡴࡺࡲࡨࠫ⚔"))
		l1l111ll11l_ll_.setInfo(l111lll_ll_ (u"ࠧࡗ࡫ࡧࡩࡴ࠭⚕"), {l111lll_ll_ (u"ࠨ࡯ࡨࡨ࡮ࡧࡴࡺࡲࡨࠫ⚖"): l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⚗")})
		#img = xbmc.getInfoLabel(l111lll_ll_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳࡯ࡣࡰࡰࠪ⚘"))
		l1l111ll11l_ll_.setArt({l111lll_ll_ (u"ࠫ࡮ࡩ࡯࡯ࠩ⚙"):image,l111lll_ll_ (u"ࠬࡺࡨࡶ࡯ࡥࠫ⚚"):image,l111lll_ll_ (u"࠭ࡦࡢࡰࡤࡶࡹ࠭⚛"):l1lll111111_ll_})
		l1l111ll11l_ll_.setInfo( l111lll_ll_ (u"ࠢࡗ࡫ࡧࡩࡴࠨ⚜"),{l111lll_ll_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧ⚝"):name})
		#name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡑࡧࡢࡦ࡮ࠪ⚞"))
		#name = name.strip(l111lll_ll_ (u"ࠪࠤࠬ⚟"))
		if l1lll11l1l_ll_ in [l111lll_ll_ (u"ࠫ࠳ࡧࡶࡪࠩ⚠"),l111lll_ll_ (u"ࠬ࠴ࡴࡴࠩ⚡"),l111lll_ll_ (u"࠭࠮࡮࡭ࡹࠫ⚢"),l111lll_ll_ (u"ࠧ࠯࡯ࡳ࠸ࠬ⚣"),l111lll_ll_ (u"ࠨ࠰ࡰࡴ࠸࠭⚤"),l111lll_ll_ (u"ࠩ࠱ࡪࡱࡼࠧ⚥")]:
			#when set to l111lll_ll_ (u"ࠥࡊࡦࡲࡳࡦࠤ⚦") it l11l11l1111_ll_ l11l111lll1_ll_ l11l11lllll_ll_ and l11l11111l1_ll_ l11l11l1l11_ll_ l11llllll1l_ll_ l1l111ll1l1_ll_
			l1l111ll11l_ll_.setContentLookup(False)
		#if l1lll11l1l_ll_ in [l111lll_ll_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ⚧")]: l1l111ll11l_ll_.setContentLookup(False)
		if l111lll_ll_ (u"ࠬࡸࡴ࡮ࡲࠪ⚨") in url: enabled = l1ll11llll1_ll_(False)
		if l1lll11l1l_ll_==l111lll_ll_ (u"࠭࠮࡮ࡲࡧࠫ⚩") or l111lll_ll_ (u"ࠧ࠰ࡦࡤࡷ࡭࠵ࠧ⚪") in url:
			enabled = l11llllllll_ll_(False)
			l1l111ll11l_ll_.setProperty(l111lll_ll_ (u"ࠨ࡫ࡱࡴࡺࡺࡳࡵࡴࡨࡥࡲࡧࡤࡥࡱࡱࠫ⚫"),l111lll_ll_ (u"ࠩ࡬ࡲࡵࡻࡴࡴࡶࡵࡩࡦࡳ࠮ࡢࡦࡤࡴࡹ࡯ࡶࡦࠩ⚬"))
			l1l111ll11l_ll_.setProperty(l111lll_ll_ (u"ࠪ࡭ࡳࡶࡵࡵࡵࡷࡶࡪࡧ࡭࠯ࡣࡧࡥࡵࡺࡩࡷࡧ࠱ࡱࡦࡴࡩࡧࡧࡶࡸࡤࡺࡹࡱࡧࠪ⚭"),l111lll_ll_ (u"ࠫࡲࡶࡤࠨ⚮"))
		if subtitle!=l111lll_ll_ (u"ࠬ࠭⚯"):
			l1l111ll11l_ll_.setSubtitles([subtitle])
			#xbmc.log(l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࠣࠤࠥࡇࡤࡥࡧࡧࠤࡸࡻࡢࡵ࡫ࡷࡰࡪࠦࡴࡰࠢࡹ࡭ࡩ࡫࡯ࠡࠢࠣࡗࡺࡨࡴࡪࡶ࡯ࡩ࠿ࡡࠧ⚰")+subtitle+l111lll_ll_ (u"ࠧ࡞ࠩ⚱"), level=xbmc.LOGNOTICE)
	if type==l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⚲") and l1111l_ll_==l111lll_ll_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇࠫ⚳"):
		result = l111lll_ll_ (u"ࠪࡴࡱࡧࡹࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⚴")
		l1111l_ll_ = l111lll_ll_ (u"ࠫࡕࡒࡁ࡚ࡡࡇࡐࡤࡌࡉࡍࡇࡖࠫ⚵")
	elif type==l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ⚶") and context.startswith(l111lll_ll_ (u"࠭࠶ࠨ⚷")):
		result = l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ⚸")
		l1111l_ll_ = l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡇࡐࠬ⚹")
	# l11l1l1111l_ll_ l1l11111l1l_ll_
	#	l11l11ll1ll_ll_ = l1l11ll11l1_ll_() is needed for both setResolvedUrl() and Player()
	#	and should be l1l1lll111l_ll_ with xbmc.sleep(step*1000)
	l11l11ll1ll_ll_ = l1l11ll11l1_ll_()
	if type==l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ⚺") and not context.startswith(l111lll_ll_ (u"ࠪ࠺ࠬ⚻")):
		#title = xbmc.getInfoLabel(l111lll_ll_ (u"ࠫࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡔࡪࡶ࡯ࡩࠬ⚼"))
		#l1l111ll11l_ll_.setInfo(l111lll_ll_ (u"ࠬ࡜ࡩࡥࡧࡲࠫ⚽"), {l111lll_ll_ (u"࠭ࡤࡶࡴࡤࡸ࡮ࡵ࡮ࠨ⚾"): 3600})
		#xbmcplugin.setContent(l1l1l11l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴࡹࠧ⚿"))
		#l1l111ll11l_ll_.setInfo(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⛀"),{l111lll_ll_ (u"ࠩࡰࡩࡩ࡯ࡡࡵࡻࡳࡩࠬ⛁"):l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⛂")})
		#l1l111ll11l_ll_.setProperty(l111lll_ll_ (u"ࠫࡎࡹࡐ࡭ࡣࡼࡥࡧࡲࡥࠨ⛃"),l111lll_ll_ (u"ࠬࡺࡲࡶࡧࠪ⛄"))
		#l1l111ll11l_ll_.setInfo(type=l111lll_ll_ (u"࠭ࡖࡪࡦࡨࡳࠬ⛅"),infoLabels={l111lll_ll_ (u"ࠢࡕ࡫ࡷࡰࡪࠨ⛆"):l111lll_ll_ (u"ࠨࡖ࡬ࡸࡱ࡫ࠧ⛇")})
		l1l111ll11l_ll_.setPath(url)
		l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⛈"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࡺࡹࡩ࡯ࡩࠣࡷࡪࡺࡒࡦࡵࡲࡰࡻ࡫ࡤࡖࡴ࡯ࠬ࠮ࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⛉")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ⛊"))
		xbmcplugin.setResolvedUrl(l1l1l11l1ll_ll_,True,l1l111ll11l_ll_)
	elif type==l111lll_ll_ (u"ࠬࡲࡩࡷࡧࠪ⛋"):
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⛌"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡔࡱࡧࡹࡪࡰࡪࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡷࡶ࡭ࡳ࡭ࠠࡱ࡮ࡤࡽ࠭࠯ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ⛍")+url+l111lll_ll_ (u"ࠨࠢࡠࠫ⛎"))
		l11l11ll1ll_ll_.play(url,l1l111ll11l_ll_)
		#xbmc.Player().play(url,l1l111ll11l_ll_)
		#l1ll1l_ll_(url,type)
	l1l1l11llll_ll_()
	#l1ll1111lll_ll_ = xbmc.translatePath(l111lll_ll_ (u"ࠩࡶࡴࡪࡩࡩࡢ࡮࠽࠳࠴ࡲ࡯ࡨࡲࡤࡸ࡭࠭⛏"))+l111lll_ll_ (u"ࠪ࡯ࡴࡪࡩ࠯࡮ࡲ࡫ࠬ⛐")
	if result!=l111lll_ll_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭⛑"):
		timeout,step,result = 60,1,l111lll_ll_ (u"ࠬࡺࡲࡪࡧࡧࠫ⛒")
		for i in range(0,timeout,step):
			# l11l1l1111l_ll_ l1l11111l1l_ll_
			#	if l1ll11l1l1l_ll_ time.sleep() l11l1l1ll11_ll_ of xbmc.sleep() l1ll1l11l1l_ll_ the player status
			#	l111lll_ll_ (u"ࠨ࡭ࡺࡲ࡯ࡥࡾ࡫ࡲ࠯ࡵࡷࡥࡹࡻࡳࠣ⛓") will stop working for both setResolvedUrl() and Player()
			xbmc.sleep(step*1000)
			result = l11l11ll1ll_ll_.status
			if result==l111lll_ll_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ⛔"):
				l1ll11l_ll_(l111lll_ll_ (u"ࠨษ็ๅ๏ี๊้ࠢํ฽๊๊ࠧ⛕"),l111lll_ll_ (u"ࠩࠪ⛖"),time=1000)
				l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࡢࡐࡎࡔࡅࡔࠩ⛗"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡔࡷࡦࡧࡪࡹࡳ࠻ࠢࡹ࡭ࡩ࡫࡯ࠡ࡫ࡶࠤࡵࡲࡡࡺ࡫ࡱ࡫ࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨ⛘")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⛙")+l1l11111lll_ll_)
				break
			elif result==l111lll_ll_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭⛚"):
				l1111l1l_ll_(l111lll_ll_ (u"ࠧࡆࡔࡕࡓࡗࡥࡌࡊࡐࡈࡗࠬ⛛"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡋࡧࡩ࡭ࡧࡧࠤࡵࡲࡡࡺ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⛜")+url+l111lll_ll_ (u"ࠩࠣࡡࠬ⛝")+l1l11111lll_ll_)
				l1ll11l_ll_(l111lll_ll_ (u"ࠪห้็๊ะ์๋ࠤ้๋๋ࠠ฻่่ࠬ⛞"),l111lll_ll_ (u"ࠫࠬ⛟"),time=1000)
				break
			l1ll11l_ll_(l111lll_ll_ (u"ࠬาวา์ࠣฮูเ๊ๅࠢส่ๆ๐ฯ๋๊ࠪ⛠"),l111lll_ll_ (u"࠭ศศไํࠤࠬ⛡")+str(timeout-i)+l111lll_ll_ (u"ࠧࠡอส๊๏ฯࠧ⛢"))
		else:
			result = l111lll_ll_ (u"ࠨࡶ࡬ࡱࡪࡵࡵࡵࠩ⛣")
			l11l11ll1ll_ll_.stop()
			l1ll11l_ll_(l111lll_ll_ (u"ࠩส่ๆ๐ฯฺ๋๊่๊๊ࠣࠦ็็ࠫ⛤"),l111lll_ll_ (u"ࠪࠫ⛥"))
			l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⛦"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡖ࡬ࡱࡪࡵࡵࡵࠢࡸࡲࡰࡴ࡯ࡸࡰࠣࡴࡷࡵࡢ࡭ࡧࡰࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⛧")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠩ⛨")+l1l11111lll_ll_)
	l1111l1111_ll_ = result in [l111lll_ll_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ⛩"),l111lll_ll_ (u"ࠨࡲ࡯ࡥࡾࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⛪")]
	l111l1llll_ll_ = result==l111lll_ll_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ⛫") and l1lll11l1l_ll_ in [l111lll_ll_ (u"ࠪ࠲ࡹࡹࠧ⛬"),l111lll_ll_ (u"ࠫ࠳ࡳ࡫ࡷࠩ⛭"),l111lll_ll_ (u"ࠬ࠴࡭ࡱ࠶ࠪ⛮"),l111lll_ll_ (u"࠭࠮࡮ࡲ࠶ࠫ⛯"),l111lll_ll_ (u"ࠧ࠯ࡨ࡯ࡺࠬ⛰"),l111lll_ll_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ⛱"),l111lll_ll_ (u"ࠩࡤࡺ࡮࠭⛲")]
	if l1111l1111_ll_ or l111l1llll_ll_:
		#l11l1lll11l_ll_ = xbmc.getInfoLabel( l111lll_ll_ (u"ࠥࡗࡾࡹࡴࡦ࡯࠱ࡅࡩࡪ࡯࡯ࡘࡨࡶࡸ࡯࡯࡯ࠪࠥ⛳")+l1ll11lll11_ll_+l111lll_ll_ (u"ࠦ࠮ࠨ⛴") )
		response = l1ll1ll1l1l_ll_(l1111l_ll_)
		#html = response.content
	if httpd!=l111lll_ll_ (u"ࠬ࠭⛵"):
		#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡣ࡭࡫ࡦ࡯ࠥࡵ࡫ࠡࡶࡲࠤࡸ࡮ࡵࡵࡦࡲࡻࡳࠦࡴࡩࡧࠣ࡬ࡹࡺࡰࠡࡵࡨࡶࡻ࡫ࡲࠨ⛶"),l111lll_ll_ (u"ࠧࠨ⛷"))
		#html = l111ll1_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡮ࡲࡧࡦࡲࡨࡰࡵࡷ࠾࠺࠻࠰࠶࠷࠲ࡷ࡭ࡻࡴࡥࡱࡺࡲࠬ⛸"),l111lll_ll_ (u"ࠩࠪ⛹"),l111lll_ll_ (u"ࠪࠫ⛺"),l111lll_ll_ (u"ࠫࠬ⛻"),l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡐࡍࡃ࡜ࡣ࡛ࡏࡄࡆࡑ࠰࠶ࡳࡪࠧ⛼"))
		time.sleep(1)
		httpd.shutdown()
		#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡨࡵࡶࡳࠤࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡹࠠࡥࡱࡺࡲࠬ⛽"),l111lll_ll_ (u"ࠧࠨ⛾"))
	if result==l111lll_ll_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ⛿"):
		import l1lll1llll_ll_
		l1lll1llll_ll_.l1llll11ll_ll_(url,l1lll11l1l_ll_)
	#if result in [l111lll_ll_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ✀"),l111lll_ll_ (u"ࠪࡸࡷ࡯ࡥࡥࠩ✁"),l111lll_ll_ (u"ࠫ࡫ࡧࡩ࡭ࡧࡧࠫ✂"),l111lll_ll_ (u"ࠬࡺࡩ࡮ࡧࡲࡹࡹ࠭✃"),l111lll_ll_ (u"࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧ✄")]: l1l111l1l11_ll_(l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡒࡏࡅ࡞ࡥࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ✅"),False)
	#l1l111l1l11_ll_(l111lll_ll_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡓࡐࡆ࡟࡟ࡗࡋࡇࡉࡔ࠳࠳ࡳࡦࠪ✆"))
	#if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࠫ✇") in url and result in [l111lll_ll_ (u"ࠪࡪࡦ࡯࡬ࡦࡦࠪ✈"),l111lll_ll_ (u"ࠫࡹ࡯࡭ࡦࡱࡸࡸࠬ✉")]:
	#	working = HTTPS(False)
	#	if not working:
	#		l1ll1l_ll_(l111lll_ll_ (u"ࠬอไศฬุห้ࠦๅีใิࠫ✊"),l111lll_ll_ (u"࠭ๅีๅ็อࠥ࠴࠮࠯๊ࠢิฬࠦวๅใํำ๏๎๋ࠠฯอหัࠦวๅ๋ࠣหฯ฻วๅุ่ࠢๆืࠠࠩำห฻๋ࠥิโำࠬࠤํ๊ใ็ࠢ็่ศูแࠡษ็หฯ฻วๅࠢสฺ่๊แาࠢ็หࠥ๐ูๆๆࠣ฽้๏ࠠอ้สึ่࠭✋"))
	#		return l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸ࠭✌")
	#sys.exit()
	return result
def l1lll11_ll_(search):
	options,l1ll11_ll_ = l111lll_ll_ (u"ࠨࠩ✍"),True
	if search.count(l111lll_ll_ (u"ࠩࡢࠫ✎"))>=2:
		search,options = search.split(l111lll_ll_ (u"ࠪࡣࠬ✏"),1)
		options = l111lll_ll_ (u"ࠫࡤ࠭✐")+options
		if l111lll_ll_ (u"ࠬࡥࡎࡐࡆࡌࡅࡑࡕࡇࡔࡡࠪ✑") in options: l1ll11_ll_ = False
		else: l1ll11_ll_ = True
	#l1ll1l_ll_(search,options)
	return search,options,l1ll11_ll_
def l1ll1l_ll_(*args,**kwargs):
	return xbmcgui.Dialog().ok(*args,**kwargs)
def l1llll1111_ll_(*args,**kwargs):
	return xbmcgui.Dialog().yesno(*args,**kwargs)
def l1l1111_ll_(*args,**kwargs):
	return xbmcgui.Dialog().select(*args,**kwargs)
def l1ll11l_ll_(*args,**kwargs):
	return xbmcgui.Dialog().notification(sound=False,*args,**kwargs)
def l11l1l1ll_ll_(*args,**kwargs):
	#return xbmcgui.Dialog().textviewer(*args,**kwargs)
	return l1111l11l_ll_(args[0],args[1],l111lll_ll_ (u"࠭ࡢࡪࡩࠪ✒"),l111lll_ll_ (u"ࠧ࡭ࡧࡩࡸࠬ✓"))
def l1111ll11l_ll_(*args,**kwargs):
	return xbmcgui.Dialog().contextmenu(*args,**kwargs)
def l1lllll111_ll_(*args,**kwargs):
	return xbmcgui.Dialog().browseSingle(*args,**kwargs)
def l11ll111111_ll_(*args,**kwargs):
	return xbmcgui.Dialog().input(*args,**kwargs)
def l11111l11_ll_(*args,**kwargs):
	return xbmcgui.DialogProgress(*args,**kwargs)
def l1ll1ll11_ll_(l1l1l11111l_ll_):
	if l1ll1l111l1_ll_>17.999: l1l11l1ll11_ll_ = l111lll_ll_ (u"ࠨࡤࡸࡷࡾࡪࡩࡢ࡮ࡲ࡫ࡳࡵࡣࡢࡰࡦࡩࡱ࠭✔")
	else: l1l11l1ll11_ll_ = l111lll_ll_ (u"ࠩࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠭✕")
	if l1l1l11111l_ll_==l111lll_ll_ (u"ࠪࡷࡹࡧࡲࡵࠩ✖"): xbmc.executebuiltin(l111lll_ll_ (u"ࠫࡆࡩࡴࡪࡸࡤࡸࡪ࡝ࡩ࡯ࡦࡲࡻ࠭࠭✗")+l1l11l1ll11_ll_+l111lll_ll_ (u"ࠬ࠯ࠧ✘"))
	elif l1l1l11111l_ll_==l111lll_ll_ (u"࠭ࡳࡵࡱࡳࠫ✙"): xbmc.executebuiltin(l111lll_ll_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭࠮ࡄ࡮ࡲࡷࡪ࠮ࠧ✚")+l1l11l1ll11_ll_+l111lll_ll_ (u"ࠨࠫࠪ✛"))
	return
def l1lll11l1ll_ll_(header,text,l1l1l1l1l1l_ll_=l111lll_ll_ (u"ࠩࠪ✜"),l1ll1l111ll_ll_=l111lll_ll_ (u"ࠪࠫ✝"),l1ll1111l11_ll_=l111lll_ll_ (u"ࠫࠬ✞"),l1l1ll11111_ll_=-1):
	# l11ll1l1l11_ll_:
	# choice = l1lll11l1ll_ll_(l111lll_ll_ (u"ࠬ࡮ࡥࡢࡦࠪ✟"),l111lll_ll_ (u"࠭ࡴࡦࡺࡷࠫ✠"),l111lll_ll_ (u"ࠧࡣ࠲ࠪ✡"),l111lll_ll_ (u"ࠨࡤ࠴ࠫ✢"),l111lll_ll_ (u"ࠩࡥ࠶ࠬ✣"),10)
	class l1l111l1lll_ll_(xbmcgui.WindowXMLDialog):
		def __init__(self,*args,**kwargs): self.controlId = -1
		def onClick(self,controlId):
			self.controlId = controlId
			self.close()
	l1l11l1ll11_ll_ = l1l111l1lll_ll_(l111lll_ll_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩࡆࡳࡳ࡬ࡩࡳ࡯ࡗ࡬ࡷ࡫ࡥࡃࡷࡷࡸࡴࡴࡳ࠯ࡺࡰࡰࠬ✤"),l1l1l1111l1_ll_,l111lll_ll_ (u"ࠫࡉ࡫ࡦࡢࡷ࡯ࡸࠬ✥"),l111lll_ll_ (u"ࠬ࠽࠲࠱ࡲࠪ✦"))
	l1l11l1ll11_ll_.show()
	l1l11l1ll11_ll_.getControl(9).setText(text)
	l1l11l1ll11_ll_.getControl(10).setLabel(l1l1l1l1l1l_ll_)
	l1l11l1ll11_ll_.getControl(11).setLabel(l1ll1l111ll_ll_)
	l1l11l1ll11_ll_.getControl(12).setLabel(l1ll1111l11_ll_)
	l1l11l1ll11_ll_.getControl(1).setLabel(header)
	if l1l1ll11111_ll_==-1: l1l11l1ll11_ll_.getControl(20).setVisible(False)
	else:
		l1l11l1ll11_ll_.getControl(20).setVisible(True)
		def l1ll11l1ll1_ll_(l1l111l1l1l_ll_):
			for i in range(1,l1l1ll11111_ll_+1):
				time.sleep(1)
				l1l1l1lllll_ll_ = time.strftime(l111lll_ll_ (u"ࠨࠥࡎ࠼ࠨࡗࠧ✧"),time.gmtime(l1l1ll11111_ll_-i))
				header = l111lll_ll_ (u"ࠧษษๅ๎๋ࠥๆࠡษ็ึ๊์ࠠࠡࠩ✨")+l1l1l1lllll_ll_+l111lll_ll_ (u"ࠨࠢࠣำ็๐โสࠩ✩")
				l1l111l1l1l_ll_.getControl(1).setLabel(header)
				percent = int(100*i/l1l1ll11111_ll_)
				l1l111l1l1l_ll_.getControl(20).setPercent(percent)
				if l1l111l1l1l_ll_.controlId>=0: break
			else: l1l111l1l1l_ll_.close()
			return
		import threading
		l1ll1l1l1l1_ll_ = threading.Thread(target=l1ll11l1ll1_ll_, args=(l1l11l1ll11_ll_,))
		l1ll1l1l1l1_ll_.start()
	l1l11l1ll11_ll_.doModal()
	if l1l11l1ll11_ll_.controlId>=10: choice = l1l11l1ll11_ll_.controlId-10
	else: choice = -1
	del l1l11l1ll11_ll_
	#l1ll1l_ll_(str(choice),l111lll_ll_ (u"ࠩࠪ✪"))
	return choice
	l111lll_ll_ (u"ࠥࠦࠧࠐࠉࡤ࡮ࡤࡷࡸࠦࡍࡺࡅ࡯ࡥࡸࡹࠨࡹࡤࡰࡧ࡬ࡻࡩ࠯࡙࡬ࡲࡩࡵࡷ࡙ࡏࡏࡈ࡮ࡧ࡬ࡰࡩࠬ࠾ࠏࠏࠉࡥࡧࡩࠤࡤࡥࡩ࡯࡫ࡷࡣࡤ࠮ࡳࡦ࡮ࡩ࠰࠯ࡧࡲࡨࡵ࠯࠮࠯ࡱࡷࡢࡴࡪࡷ࠮ࡀࠠࡴࡧ࡯ࡪ࠳ࡩ࡯࡯ࡶࡵࡳࡱࡏࡤࠡ࠿ࠣ࠱࠶ࠐࠉࠊࡦࡨࡪࠥࡵ࡮ࡄ࡮࡬ࡧࡰ࠮ࡳࡦ࡮ࡩ࠰ࡨࡵ࡮ࡵࡴࡲࡰࡎࡪࠩ࠻ࠢࡶࡩࡱ࡬࠮ࡤࡱࡱࡸࡷࡵ࡬ࡊࡦࠣࡁࠥࡩ࡯࡯ࡶࡵࡳࡱࡏࡤࠋࠋࡧ࡭ࡦࡲ࡯ࡨࠢࡀࠤࡒࡿࡃ࡭ࡣࡶࡷ࠭࠭ࡄࡪࡣ࡯ࡳ࡬ࡉ࡯࡯ࡨ࡬ࡶࡲ࡚ࡨࡳࡧࡨࡆࡺࡺࡴࡰࡰࡶ࠲ࡽࡳ࡬ࠨ࠮ࡤࡨࡩࡵ࡮ࡧࡱ࡯ࡨࡪࡸࠬࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ࠯ࠫ࠼࠸࠰ࡱࠩࠬࠎࠎࡪࡩࡢ࡮ࡲ࡫࠳ࡹࡨࡰࡹࠫ࠭ࠏࠏࡤࡪࡣ࡯ࡳ࡬࠴ࡧࡦࡶࡆࡳࡳࡺࡲࡰ࡮ࠫ࠵࠮࠴ࡳࡦࡶࡏࡥࡧ࡫࡬ࠩࡪࡨࡥࡩ࡫ࡲࠪࠌࠌࡨ࡮ࡧ࡬ࡰࡩ࠱࡫ࡪࡺࡃࡰࡰࡷࡶࡴࡲࠨ࠺ࠫ࠱ࡷࡪࡺࡔࡦࡺࡷࠬࡹ࡫ࡸࡵࠫࠍࠍࡩ࡯ࡡ࡭ࡱࡪ࠲࡬࡫ࡴࡄࡱࡱࡸࡷࡵ࡬ࠩ࠳࠳࠭࠳ࡹࡥࡵࡎࡤࡦࡪࡲࠨࡣࡷࡷࡸࡴࡴ࠰ࠪࠌࠌࡨ࡮ࡧ࡬ࡰࡩ࠱࡫ࡪࡺࡃࡰࡰࡷࡶࡴࡲࠨ࠲࠳ࠬ࠲ࡸ࡫ࡴࡍࡣࡥࡩࡱ࠮ࡢࡶࡶࡷࡳࡳ࠷ࠩࠋࠋࡧ࡭ࡦࡲ࡯ࡨ࠰ࡪࡩࡹࡉ࡯࡯ࡶࡵࡳࡱ࠮࠱࠳ࠫ࠱ࡷࡪࡺࡌࡢࡤࡨࡰ࠭ࡨࡵࡵࡶࡲࡲ࠷࠯ࠊࠊ࡫ࡩࠤࡺࡶࡤࡢࡶࡨࡂࡂ࠶࠺ࠋࠋࠌࡨ࡮ࡧ࡬ࡰࡩ࠱࡫ࡪࡺࡃࡰࡰࡷࡶࡴࡲࠨ࠳࠲ࠬ࠲ࡸ࡫ࡴࡗ࡫ࡶ࡭ࡧࡲࡥࠩࡖࡵࡹࡪ࠯ࠊࠊࠋࡧ࡭ࡦࡲ࡯ࡨ࠰ࡪࡩࡹࡉ࡯࡯ࡶࡵࡳࡱ࠮࠲࠱ࠫ࠱ࡷࡪࡺࡐࡦࡴࡦࡩࡳࡺࠨࡶࡲࡧࡥࡹ࡫ࠩࠋࠋࡨࡰࡸ࡫࠺ࠡࡦ࡬ࡥࡱࡵࡧ࠯ࡩࡨࡸࡈࡵ࡮ࡵࡴࡲࡰ࠭࠸࠰ࠪ࠰ࡶࡩࡹ࡜ࡩࡴ࡫ࡥࡰࡪ࠮ࡆࡢ࡮ࡶࡩ࠮ࠐࠉࡥ࡫ࡤࡰࡴ࡭࠮ࡥࡱࡐࡳࡩࡧ࡬ࠩࠫࠍࠍࡨ࡮࡯ࡪࡥࡨࠤࡂࠦࡤࡪࡣ࡯ࡳ࡬࠴ࡣࡰࡰࡷࡶࡴࡲࡉࡥ࠯࠴࠴ࠏࠏࠣࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࡷࡹࡸࠨࡤࡪࡲ࡭ࡨ࡫ࠩ࠭ࠩࠪ࠭ࠏࠏࡤࡦ࡮ࠣࡨ࡮ࡧ࡬ࡰࡩࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡨ࡮࡯ࡪࡥࡨࠎࠎࠨࠢࠣ✫")
def l1111l11l_ll_(header,text,size=l111lll_ll_ (u"ࠫࡸࡳࡡ࡭࡮ࠪ✬"),direction=l111lll_ll_ (u"ࠬࡲࡥࡧࡶࠪ✭")):
	#return
	#l1l11l1ll11_ll_ = xbmcgui.WindowXML(l111lll_ll_ (u"࠭ࡆࡰࡰࡷ࠶࠷࠴ࡸ࡮࡮ࠪ✮"),l1l1l1111l1_ll_)
	#l1l11l1ll11_ll_.show()
	l1l11l1ll11_ll_ = xbmcgui.WindowXMLDialog(l111lll_ll_ (u"ࠧࡅ࡫ࡤࡰࡴ࡭ࡔࡦࡺࡷ࡚࡮࡫ࡷࡦࡴࡉࡹࡱࡲࡓࡤࡴࡨࡩࡳ࠴ࡸ࡮࡮ࠪ✯"),l1l1l1111l1_ll_,l111lll_ll_ (u"ࠨࡆࡨࡪࡦࡻ࡬ࡵࠩ✰"),l111lll_ll_ (u"ࠩ࠺࠶࠵ࡶࠧ✱"))
	l1l11l1ll11_ll_.show()
	#l1l11l1ll11_ll_.getControl(99991).setPosition(0,0)
	l1l11l1ll11_ll_.getControl(1).setLabel(header)
	if size==l111lll_ll_ (u"ࠪࡦ࡮࡭ࠧ✲") and direction==l111lll_ll_ (u"ࠫࡨ࡫࡮ࡵࡧࡵࠫ✳"):
		l1l11l1ll11_ll_.getControl(51).setVisible(False)
		l1l11l1ll11_ll_.getControl(52).setVisible(False)
		l1l11l1ll11_ll_.getControl(53).setVisible(False)
		l1l11l1ll11_ll_.getControl(54).setText(text)
	elif size==l111lll_ll_ (u"ࠬࡹ࡭ࡢ࡮࡯ࠫ✴") and direction==l111lll_ll_ (u"࠭࡬ࡦࡨࡷࠫ✵"):
		l1l11l1ll11_ll_.getControl(51).setVisible(False)
		l1l11l1ll11_ll_.getControl(52).setVisible(False)
		l1l11l1ll11_ll_.getControl(53).setText(text)
		l1l11l1ll11_ll_.getControl(54).setVisible(False)
	elif size==l111lll_ll_ (u"ࠧࡣ࡫ࡪࠫ✶") and direction==l111lll_ll_ (u"ࠨࡴ࡬࡫࡭ࡺࠧ✷"):
		l1l11l1ll11_ll_.getControl(51).setVisible(False)
		l1l11l1ll11_ll_.getControl(52).setText(text)
		l1l11l1ll11_ll_.getControl(53).setVisible(False)
		l1l11l1ll11_ll_.getControl(54).setVisible(False)
	elif size==l111lll_ll_ (u"ࠩࡥ࡭࡬࠭✸") and direction==l111lll_ll_ (u"ࠪࡰࡪ࡬ࡴࠨ✹"):
		l1l11l1ll11_ll_.getControl(51).setText(text)
		l1l11l1ll11_ll_.getControl(52).setVisible(False)
		l1l11l1ll11_ll_.getControl(53).setVisible(False)
		l1l11l1ll11_ll_.getControl(54).setVisible(False)
	#width = xbmcgui.getScreenWidth()
	#height = xbmcgui.getScreenHeight()
	#resolution = (0.0+width)/height
	#l1l11l1ll11_ll_.getControl(5).setWidth(width-180)
	#l1l11l1ll11_ll_.getControl(5).setHeight(height-180)
	result = l1l11l1ll11_ll_.doModal()
	del l1l11l1ll11_ll_
	return result
def l1ll11lll_ll_():
	results = l1llll11l1l_ll_(l111lll_ll_ (u"ࠫࡒࡏࡓࡄࠩ✺"),l111lll_ll_ (u"࡛ࠬࡓࡆࡔࡄࡋࡊࡔࡔࠨ✻"))
	#l1ll1l_ll_(results,l111lll_ll_ (u"࠭ࠧ✼"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ✽"),l111lll_ll_ (u"ࠨࡇࡐࡅࡉࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠡࡷࡶࡩࡷࡧࡧࡦࡰࡷ࠾ࠥ࠭✾")+results)
	if results: l1ll11l11_ll_ = results ; return l1ll11l11_ll_
	# l11lll11lll_ll_ and l11ll1l11l1_ll_ common user l1l111ll1ll_ll_ (l1ll111l11l_ll_ updated)
	url = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡸࡪࡩࡨࡣ࡮ࡲ࡫࠳ࡽࡩ࡭࡮ࡶ࡬ࡴࡻࡳࡦ࠰ࡦࡳࡲ࠵࠲࠱࠳࠵࠳࠵࠷࠯࠱࠵࠲ࡱࡴࡹࡴ࠮ࡥࡲࡱࡲࡵ࡮࠮ࡷࡶࡩࡷ࠳ࡡࡨࡧࡱࡸࡸ࠵ࠧ✿")
	headers = {l111lll_ll_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ❀"):url}
	response = l111111_ll_(l11ll11l1ll_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ❁"),url,l111lll_ll_ (u"ࠬ࠭❂"),headers,l111lll_ll_ (u"࠭ࠧ❃"),l111lll_ll_ (u"ࠧࠨ❄"),l111lll_ll_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆ࠯ࡕࡅࡓࡊࡏࡎࡡࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠲࠷ࡳࡵࠩ❅"))
	html = response.content
	count = html.count(l111lll_ll_ (u"ࠩࡐࡳࡿ࡯࡬࡭ࡣࠪ❆"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ❇"),html)
	#l1ll1l_ll_(str(count),html)
	if l111lll_ll_ (u"ࠫࡤࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࡠࠩ❈") in html or count<100:
		with open(l1ll11ll1l1_ll_,l111lll_ll_ (u"ࠬࡸࠧ❉")) as f: text = f.read()
	else:
		text = re.findall(l111lll_ll_ (u"࠭ࡧࡦࡶ࠰ࡸ࡭࡫࠭࡭࡫ࡶࡸ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ❊"),html,re.DOTALL)
		text = text[0]
	l11l111ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠧࠩࡏࡲࡾ࡮ࡲ࡬ࡢ࠰࠭ࡃ࠮ࡢ࡮ࠨ❋"),text,re.DOTALL)
	l1l1l11l11l_ll_ = []
	for line in l11l111ll1l_ll_:
		if l111lll_ll_ (u"ࠨࡣࡱࡨࡷࡵࡩࡥࠢ࠷ࠫ❌") in line.lower(): continue
		l1l1l11l11l_ll_.append(line)
	l1ll11l11_ll_ = random.sample(l1l1l11l11l_ll_,1)
	l1ll11l11_ll_ = l1ll11l11_ll_[0]
	#l1ll1l_ll_(l1ll11l11_ll_,str(len(a)))
	l1111l1lll_ll_(l111lll_ll_ (u"ࠩࡐࡍࡘࡉࠧ❍"),l111lll_ll_ (u"࡙ࠪࡘࡋࡒࡂࡉࡈࡒ࡙࠭❎"),l1ll11l11_ll_,l11111l1_ll_)
	return l1ll11l11_ll_
def l1l111llll1_ll_(error):
	if str(error) not in [l111lll_ll_ (u"ࠫࡋࡵࡲࡤࡧࡧࠤࡊࡾࡩࡵࠩ❏")]:
		l1l11l1lll1_ll_ = traceback.format_exc()
		sys.stderr.write(l1l11l1lll1_ll_)
		lines = l1l11l1lll1_ll_.splitlines()
		l1l1l1l1lll_ll_ = lines[-1]
		l11l11111ll_ll_ = lines[-3].replace(l111lll_ll_ (u"ࠬ࠴ࡰࡺࠩ❐"),l111lll_ll_ (u"࠭ࠧ❑"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ❒"),l11l11111ll_ll_))
		if l111lll_ll_ (u"ࠨ࡞࡟ࠫ❓") in l11l11111ll_ll_: l11l11111ll_ll_ = l11l11111ll_ll_.rsplit(l111lll_ll_ (u"ࠩ࡟ࡠࠬ❔"),1)[1]
		elif l111lll_ll_ (u"ࠪ࠳ࠬ❕") in l11l11111ll_ll_: l11l11111ll_ll_ = l11l11111ll_ll_.rsplit(l111lll_ll_ (u"ࠫ࠴࠭❖"),1)[1]
		l1l11ll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠮࠮ࠫࡁࠬࠦ࠱ࠦ࡬ࡪࡰࡨࠤ࠭ࡢࡤࠬࠫ࠯ࠤ࡮ࡴࠠࠩ࠰࠭ࡃ࠮ࠬࠦࠨ❗"),l11l11111ll_ll_+l111lll_ll_ (u"࠭ࠦࠧࠩ❘"),re.DOTALL)
		if l1l11ll1lll_ll_: file,lineno,function = l1l11ll1lll_ll_[0]
		else: file,lineno,function = l111lll_ll_ (u"ࠧๆฮ๊์้࠭❙"),l111lll_ll_ (u"ࠨ็ฯ๋ํ๊ࠧ❚"),l111lll_ll_ (u"่ࠩะ์๎ไࠨ❛")
		l1ll11l_ll_(l111lll_ll_ (u"ࠪา฼ษࠠࠨ❜")+function+l111lll_ll_ (u"ࠫࠥ࠭❝")+lineno+l111lll_ll_ (u"ࠬࠦࠧ❞")+file,l1l1l1l1lll_ll_,time=2000)
	return
def l11llll1l1l_ll_(l1ll1lll1ll_ll_):
	l11l11lll1l_ll_ = settings.getSetting(l111lll_ll_ (u"࠭ࡵࡴࡧࡵ࠲ࡵࡸࡩࡷࡵࠪ❟"))
	#l1ll1lll1ll_ll_ = l1ll1lll1ll_ll_.encode(l111lll_ll_ (u"ࠧࡣࡣࡶࡩ࠻࠺ࠧ❠")).replace(l111lll_ll_ (u"ࠨ࡞ࡱࠫ❡"),l111lll_ll_ (u"ࠩࠪ❢"))
	user = l11l1lll1ll_ll_(32)
	import hashlib
	md5 = hashlib.md5(l111lll_ll_ (u"ࠪ࡜࠶࠿ࠧ❣")+l1ll1lll1ll_ll_+l111lll_ll_ (u"ࠫ࠶࠾࠽ࠨ❤")+user).hexdigest()[0:32]
	if md5 in l11l11lll1l_ll_: return True
	return False
def l1l1l1111_ll_(data):
	with open(l111lll_ll_ (u"ࠬࡹ࠺࡝࡞࠳࠴࠵࠶ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ❥"),l111lll_ll_ (u"࠭ࡷࠨ❦")) as f: f.write(data)
	return
def l11l11l1ll1_ll_():
	url = l11l11l_ll_[l111lll_ll_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ❧")][4]
	payload = {l111lll_ll_ (u"ࠨࡷࡶࡩࡷ࠭❨"):l11l1lll1ll_ll_(32)}
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡓࡓࡘ࡚ࠧ❩"),url,payload,l111lll_ll_ (u"ࠪࠫ❪"),l111lll_ll_ (u"ࠫࠬ❫"),True,l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳ࡇࡆࡐࡈࡖࡎࡉ࡟ࡊࡕࡏࡅࡒࡏࡃࡠࡏࡈࡗࡘࡇࡇࡆࡕ࠰࠵ࡸࡺࠧ❬"),True,True)
	if not response.succeeded: return
	messages = response.content
	messages = l111ll1lll_ll_(messages)
	messages = list(messages)
	return messages
def l111lllll1_ll_(filename,data):
	filepath = os.path.join(l1lll11ll1_ll_,filename)
	data = str(data)
	data = zlib.compress(data)
	with open(filepath,l111lll_ll_ (u"࠭ࡷࡣࠩ❭")) as f: f.write(data)
	return
def l1111llll1_ll_(filename):
	filepath = os.path.join(l1lll11ll1_ll_,filename)
	with open(filepath,l111lll_ll_ (u"ࠧࡳࡤࠪ❮")) as f: data = f.read()
	data = zlib.decompress(data)
	data = eval(data)
	return data
def l1lll1ll1ll_ll_(filename):
	filepath = os.path.join(l1lll11ll1_ll_,filename)
	if os.path.exists(filepath): os.remove(filepath)
	return
l111lll_ll_ (u"ࠣࠤࠥࠎࡩ࡫ࡦࠡ࡭ࡲࡨ࡮ࡐࡳࡰࡰࡕࡩࡶࡻࡥࡴࡶࠫࡴࡦࡸࡡ࡮ࡵࠬ࠾ࠏࠏࡩ࡮ࡲࡲࡶࡹࠦࡪࡴࡱࡱࠎࠎࡪࡡࡵࡣࠣࡁࠥࡰࡳࡰࡰ࠱ࡨࡺࡳࡰࡴࠪࡳࡥࡷࡧ࡭ࡴࠫࠍࠍࡷ࡫ࡱࡶࡧࡶࡸࠥࡃࠠࡹࡤࡰࡧ࠳࡫ࡸࡦࡥࡸࡸࡪࡐࡓࡐࡐࡕࡔࡈ࠮ࡤࡢࡶࡤ࠭ࠏࠏࡴࡳࡻ࠽ࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࠦ࠽ࠡ࡬ࡶࡳࡳ࠴࡬ࡰࡣࡧࡷ࠭ࡸࡥࡲࡷࡨࡷࡹ࠯ࠊࠊࡧࡻࡧࡪࡶࡴࠡࡗࡱ࡭ࡨࡵࡤࡦࡆࡨࡧࡴࡪࡥࡆࡴࡵࡳࡷࡀࠠࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤ࡯ࡹ࡯࡯࠰࡯ࡳࡦࡪࡳࠩࡴࡨࡵࡺ࡫ࡳࡵ࠰ࡧࡩࡨࡵࡤࡦࠪࠪࡹࡹ࡬࠭࠹ࠩ࠯ࠤࠬ࡯ࡧ࡯ࡱࡵࡩࠬ࠯ࠩࠋࠋࡷࡶࡾࡀࠊࠊࠋ࡬ࡪࠥ࠭ࡲࡦࡵࡸࡰࡹ࠭ࠠࡪࡰࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠿ࠦࡲࡦࡶࡸࡶࡳࠦࡲࡦࡵࡳࡳࡳࡹࡥ࡜ࠩࡵࡩࡸࡻ࡬ࡵࠩࡠࠎࠎ࡫ࡸࡤࡧࡳࡸࠥࡑࡥࡺࡇࡵࡶࡴࡸ࠺ࠋࠋࠌࠧࡱࡵࡧࡨࡧࡵ࠲ࡼࡧࡲ࡯ࠪࠥ࡟ࠪࡹ࡝ࠡࠧࡶࠦࠥࠫࠠࠩࡲࡤࡶࡦࡳࡳ࡜ࠩࡰࡩࡹ࡮࡯ࡥࠩࡠ࠰ࠥࡸࡥࡴࡲࡲࡲࡸ࡫࡛ࠨࡧࡵࡶࡴࡸࠧ࡞࡝ࠪࡱࡪࡹࡳࡢࡩࡨࠫࡢ࠯ࠩࠋࠋࠌࡴࡦࡹࡳࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࡑࡳࡳ࡫ࠊࠋࠥࡨࡼ࡮ࡹࡴࡪࡰࡪࡣࡵࡸ࡯ࡹࡻࠣࡁࠥ࡭ࡥࡵࡅࡲࡲ࡫࡯ࡧࡶࡴࡨࡨࡕࡸ࡯ࡹࡻࠫ࠭ࠏࠩ࡮ࡦࡹࡢࡴࡷࡵࡸࡺࠢࡀࠤࡵࡸ࡯ࡹࡻ࡬ࡴ࠰࠭࠺ࠨ࠭ࡳࡳࡷࡺࠫࠨ࠼࠳ࠫࠎࠏࠣࠡ࠼࠳ࠤࡲ࡫ࡡ࡯ࡵࠣࡌ࡙࡚ࡐࠡࡲࡵࡳࡽࡿࠠ࡯ࡱࡷࠤࡸࡵࡣ࡬ࡵࠣࡴࡷࡵࡸࡺࠌࠦࡷࡪࡺࡋࡰࡦ࡬ࡔࡷࡵࡸࡺࠪࡱࡩࡼࡥࡰࡳࡱࡻࡽ࠮ࠐࠣࡴࡧࡷࡏࡴࡪࡩࡑࡴࡲࡼࡾ࠮ࡥࡹ࡫ࡶࡸ࡮ࡴࡧࡠࡲࡵࡳࡽࡿࠩࠋࡦࡨࡪࠥࡹࡥࡵࡍࡲࡨ࡮ࡖࡲࡰࡺࡼࠬࡵࡸ࡯ࡹࡻࡶࡩࡹࡺࡩ࡯ࡩࡶࡁࡓࡵ࡮ࡦࠫ࠽ࠎࠎ࡯ࡦࠡࡲࡵࡳࡽࡿࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠾࠿ࡑࡳࡳ࡫࠺ࠋࠋࠌࠧࡵࡸࡩ࡯ࡶࠣࠫࡵࡸ࡯ࡹࡻࠣࡷࡪࡺࠠࡵࡱࠣࡲࡴࡺࡨࡪࡰࡪࠫࠏࠏࠉࡹࡤࡰࡧ࠳࡫ࡸࡦࡥࡸࡸࡪࡐࡓࡐࡐࡕࡔࡈ࠮ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡖࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡮ࡦࡶࡺࡳࡷࡱ࠮ࡶࡵࡨ࡬ࡹࡺࡰࡱࡴࡲࡼࡾࠨࠬࠡࠤࡹࡥࡱࡻࡥࠣ࠼ࡩࡥࡱࡹࡥࡾ࠮ࠣࠦ࡮ࡪࠢ࠻࠳ࢀࠫ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠊࡲࡶࠤࡂࠦࡰࡳࡱࡻࡽࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠺ࠨࠫࠍࠍࠎࡶࡲࡰࡺࡼ࡙ࡗࡒࠠ࠾ࠢࡳࡷࡠ࠶࡝ࠋࠋࠌࡴࡷࡵࡸࡺࡒࡲࡶࡹࠦ࠽ࠡࡲࡶ࡟࠶ࡣࠊࠊࠋࡳࡶࡴࡾࡹࡕࡻࡳࡩࠥࡃࠠࡱࡵ࡞࠶ࡢࠐࠉࠊࡲࡵࡳࡽࡿࡕࡴࡧࡵࡲࡦࡳࡥࠡ࠿ࠣࡒࡴࡴࡥࠋࠋࠌࡴࡷࡵࡸࡺࡒࡤࡷࡸࡽ࡯ࡳࡦࠣࡁࠥࡔ࡯࡯ࡧࠍࠍࠎ࡯ࡦࠡ࡮ࡨࡲ࠭ࡶࡳࠪࡀ࠶ࠤࡦࡴࡤࠡࠩࡃࠫࠥ࡯࡮ࠡࡲࡵࡳࡽࡿࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠻ࠌࠌࠍࠎࡶࡲࡰࡺࡼ࡙ࡸ࡫ࡲ࡯ࡣࡰࡩࠥࡃࠠࡱࡵ࡞࠷ࡢࠐࠉࠊࠋࡳࡶࡴࡾࡹࡑࡣࡶࡷࡼࡵࡲࡥࠢࡀࠤࡵࡸ࡯ࡹࡻࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡅ࠭ࠩ࡜࠯࠴ࡡࠏࠏࠉࠤࡲࡵ࡭ࡳࡺࠠࠨࡲࡵࡳࡽࡿࠠࡴࡧࡷࠤࡹࡵࠧ࠭ࠢࡳࡶࡴࡾࡹࡕࡻࡳࡩ࠱ࠦࡰࡳࡱࡻࡽ࡚ࡘࡌ࠭ࡲࡵࡳࡽࡿࡐࡰࡴࡷࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡪࡾࡥࡤࡷࡷࡩࡏ࡙ࡏࡏࡔࡓࡇ࠭࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡴࡥࡵࡹࡲࡶࡰ࠴ࡵࡴࡧ࡫ࡸࡹࡶࡰࡳࡱࡻࡽࠧ࠲ࠠࠣࡸࡤࡰࡺ࡫ࠢ࠻ࡶࡵࡹࡪࢃࠬࠡࠤ࡬ࡨࠧࡀ࠱ࡾࠩࠬࠎࠎࠏࡸࡣ࡯ࡦ࠲ࡪࡾࡥࡤࡷࡷࡩࡏ࡙ࡏࡏࡔࡓࡇ࠭࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡕࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡴࡥࡵࡹࡲࡶࡰ࠴ࡨࡵࡶࡳࡴࡷࡵࡸࡺࡶࡼࡴࡪࠨࠬࠡࠤࡹࡥࡱࡻࡥࠣ࠼ࠪࠤ࠰ࠦࡳࡵࡴࠫࡴࡷࡵࡸࡺࡖࡼࡴࡪ࠯ࠠࠬࠩࢀ࠰ࠥࠨࡩࡥࠤ࠽࠵ࢂ࠭ࠩࠋࠋࠌࡼࡧࡳࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࡌࡖࡓࡓࡘࡐࡄࠪࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡱࡩࡹࡽ࡯ࡳ࡭࠱࡬ࡹࡺࡰࡱࡴࡲࡼࡾࡹࡥࡳࡸࡨࡶࠧ࠲ࠠࠣࡸࡤࡰࡺ࡫ࠢ࠻ࠤࠪࠤ࠰ࠦࡳࡵࡴࠫࡴࡷࡵࡸࡺࡗࡕࡐ࠮ࠦࠫࠨࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽࠵ࢂ࠭ࠩࠋࠋࠌࡼࡧࡳࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࡌࡖࡓࡓࡘࡐࡄࠪࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡱࡩࡹࡽ࡯ࡳ࡭࠱࡬ࡹࡺࡰࡱࡴࡲࡼࡾࡶ࡯ࡳࡶࠥ࠰ࠥࠨࡶࡢ࡮ࡸࡩࠧࡀࠧࠡ࠭ࠣࡷࡹࡸࠨࡱࡴࡲࡼࡾࡖ࡯ࡳࡶࠬࠤ࠰࠭ࡽ࠭ࠢࠥ࡭ࡩࠨ࠺࠲ࡿࠪ࠭ࠏࠏࠉࡪࡨࠣࡲࡴࡺࠠࡱࡴࡲࡼࡾ࡛ࡳࡦࡴࡱࡥࡲ࡫࠽࠾ࡐࡲࡲࡪࡀࠊࠊࠋࠌࡼࡧࡳࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࡌࡖࡓࡓࡘࡐࡄࠪࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠣ࠴࠱࠴ࠧ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳࡙ࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡱࡩࡹࡽ࡯ࡳ࡭࠱࡬ࡹࡺࡰࡱࡴࡲࡼࡾࡻࡳࡦࡴࡱࡥࡲ࡫ࠢ࠭ࠢࠥࡺࡦࡲࡵࡦࠤ࠽ࠦࠬࠦࠫࠡࡵࡷࡶ࠭ࡶࡲࡰࡺࡼ࡙ࡸ࡫ࡲ࡯ࡣࡰࡩ࠮ࠦࠫࠨࠤࢀ࠰ࠥࠨࡩࡥࠤ࠽࠵ࢂ࠭ࠩࠋࠋࠌࠍࡽࡨ࡭ࡤ࠰ࡨࡼࡪࡩࡵࡵࡧࡍࡗࡔࡔࡒࡑࡅࠫࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡓࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡲࡪࡺࡷࡰࡴ࡮࠲࡭ࡺࡴࡱࡲࡵࡳࡽࡿࡰࡢࡵࡶࡻࡴࡸࡤࠣ࠮ࠣࠦࡻࡧ࡬ࡶࡧࠥ࠾ࠧ࠭ࠠࠬࠢࡶࡸࡷ࠮ࡰࡳࡱࡻࡽࡕࡧࡳࡴࡹࡲࡶࡩ࠯ࠠࠬࠩࠥࢁ࠱ࠦࠢࡪࡦࠥ࠾࠶ࢃࠧࠪࠌࠌࡶࡪࡺࡵࡳࡰࠍࠎࡩ࡫ࡦࠡࡩࡨࡸࡈࡵ࡮ࡧ࡫ࡪࡹࡷ࡫ࡤࡑࡴࡲࡼࡾ࠮ࠩ࠻ࠌࠌࡴࡷࡵࡸࡺࡃࡦࡸ࡮ࡼࡥࠡ࠿ࠣ࡯ࡴࡪࡩࡋࡵࡲࡲࡗ࡫ࡱࡶࡧࡶࡸ࠭ࢁࠧ࡫ࡵࡲࡲࡷࡶࡣࠨ࠼ࠣࠫ࠷࠴࠰ࠨ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡴࡥࡵࡹࡲࡶࡰ࠴ࡵࡴࡧ࡫ࡸࡹࡶࡰࡳࡱࡻࡽࠧࢃࠬࠡࠩ࡬ࡨࠬࡀࠠ࠲ࡿࠬ࡟ࠬࡼࡡ࡭ࡷࡨࠫࡢࠐࠉࠤࡲࡵ࡭ࡳࡺࠠࠨࡲࡵࡳࡽࡿࡁࡤࡶ࡬ࡺࡪ࠭ࠬࡱࡴࡲࡼࡾࡇࡣࡵ࡫ࡹࡩࠏࠏࡰࡳࡱࡻࡽ࡙ࡿࡰࡦࠢࡀࠤࡰࡵࡤࡪࡌࡶࡳࡳࡘࡥࡲࡷࡨࡷࡹ࠮ࡻࠨ࡬ࡶࡳࡳࡸࡰࡤࠩ࠽ࠤࠬ࠸࠮࠱ࠩ࠯ࠤࠧࡳࡥࡵࡪࡲࡨࠧࡀࠢࡔࡧࡷࡸ࡮ࡴࡧࡴ࠰ࡊࡩࡹ࡙ࡥࡵࡶ࡬ࡲ࡬࡜ࡡ࡭ࡷࡨࠦ࠱ࠦࠢࡱࡣࡵࡥࡲࡹࠢ࠻ࡽࠥࡷࡪࡺࡴࡪࡰࡪࠦ࠿ࠨ࡮ࡦࡶࡺࡳࡷࡱ࠮ࡩࡶࡷࡴࡵࡸ࡯ࡹࡻࡷࡽࡵ࡫ࠢࡾ࠮ࠣࠫ࡮ࡪࠧ࠻ࠢ࠴ࢁ࠮ࡡࠧࡷࡣ࡯ࡹࡪ࠭࡝ࠋࠋ࡬ࡪࠥࡶࡲࡰࡺࡼࡅࡨࡺࡩࡷࡧ࠽ࠤࠨࠦࡐࡓࡑ࡛࡝ࡤࡎࡔࡕࡒࠍࠍࠎࡶࡲࡰࡺࡼ࡙ࡗࡒࠠ࠾ࠢ࡮ࡳࡩ࡯ࡊࡴࡱࡱࡖࡪࡷࡵࡦࡵࡷࠬࢀ࠭ࡪࡴࡱࡱࡶࡵࡩࠧ࠻ࠢࠪ࠶࠳࠶ࠧ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡳ࡫ࡴࡸࡱࡵ࡯࠳࡮ࡴࡵࡲࡳࡶࡴࡾࡹࡴࡧࡵࡺࡪࡸࠢࡾ࠮ࠣࠫ࡮ࡪࠧ࠻ࠢ࠴ࢁ࠮ࡡࠧࡷࡣ࡯ࡹࡪ࠭࡝ࠋࠋࠌࠧࡵࡸ࡯ࡹࡻࡓࡳࡷࡺࠠ࠾ࠢࡸࡲ࡮ࡩ࡯ࡥࡧࠫ࡯ࡴࡪࡩࡋࡵࡲࡲࡗ࡫ࡱࡶࡧࡶࡸ࠭ࢁࠧ࡫ࡵࡲࡲࡷࡶࡣࠨ࠼ࠣࠫ࠷࠴࠰ࠨ࠮ࠣࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡓࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡉࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࡛ࡧ࡬ࡶࡧࠥ࠰ࠥࠨࡰࡢࡴࡤࡱࡸࠨ࠺ࡼࠤࡶࡩࡹࡺࡩ࡯ࡩࠥ࠾ࠧࡴࡥࡵࡹࡲࡶࡰ࠴ࡨࡵࡶࡳࡴࡷࡵࡸࡺࡲࡲࡶࡹࠨࡽ࠭ࠢࠪ࡭ࡩ࠭࠺ࠡ࠳ࢀ࠭ࡠ࠭ࡶࡢ࡮ࡸࡩࠬࡣࠩࠋࠋࠌࡴࡷࡵࡸࡺࡒࡲࡶࡹࠦ࠽ࠡ࡭ࡲࡨ࡮ࡐࡳࡰࡰࡕࡩࡶࡻࡥࡴࡶࠫࡿࠬࡰࡳࡰࡰࡵࡴࡨ࠭࠺ࠡࠩ࠵࠲࠵࠭ࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠦࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡇࡦࡶࡖࡩࡹࡺࡩ࡯ࡩ࡙ࡥࡱࡻࡥࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࢁࠢࡴࡧࡷࡸ࡮ࡴࡧࠣ࠼ࠥࡲࡪࡺࡷࡰࡴ࡮࠲࡭ࡺࡴࡱࡲࡵࡳࡽࡿࡰࡰࡴࡷࠦࢂ࠲ࠠࠨ࡫ࡧࠫ࠿ࠦ࠱ࡾࠫ࡞ࠫࡻࡧ࡬ࡶࡧࠪࡡࠏࠏࠉࡱࡴࡲࡼࡾ࡛ࡳࡦࡴࡱࡥࡲ࡫ࠠ࠾ࠢ࡮ࡳࡩ࡯ࡊࡴࡱࡱࡖࡪࡷࡵࡦࡵࡷࠬࢀ࠭ࡪࡴࡱࡱࡶࡵࡩࠧ࠻ࠢࠪ࠶࠳࠶ࠧ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾࡙ࠧࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡈࡧࡷࡗࡪࡺࡴࡪࡰࡪ࡚ࡦࡲࡵࡦࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࡻࠣࡵࡨࡸࡹ࡯࡮ࡨࠤ࠽ࠦࡳ࡫ࡴࡸࡱࡵ࡯࠳࡮ࡴࡵࡲࡳࡶࡴࡾࡹࡶࡵࡨࡶࡳࡧ࡭ࡦࠤࢀ࠰ࠥ࠭ࡩࡥࠩ࠽ࠤ࠶ࢃࠩ࡜ࠩࡹࡥࡱࡻࡥࠨ࡟ࠍࠍࠎࡶࡲࡰࡺࡼࡔࡦࡹࡳࡸࡱࡵࡨࠥࡃࠠ࡬ࡱࡧ࡭ࡏࡹ࡯࡯ࡔࡨࡵࡺ࡫ࡳࡵࠪࡾࠫ࡯ࡹ࡯࡯ࡴࡳࡧࠬࡀࠠࠨ࠴࠱࠴ࠬ࠲ࠠࠣ࡯ࡨࡸ࡭ࡵࡤࠣ࠼ࠥࡗࡪࡺࡴࡪࡰࡪࡷ࠳ࡍࡥࡵࡕࡨࡸࡹ࡯࡮ࡨࡘࡤࡰࡺ࡫ࠢ࠭ࠢࠥࡴࡦࡸࡡ࡮ࡵࠥ࠾ࢀࠨࡳࡦࡶࡷ࡭ࡳ࡭ࠢ࠻ࠤࡱࡩࡹࡽ࡯ࡳ࡭࠱࡬ࡹࡺࡰࡱࡴࡲࡼࡾࡶࡡࡴࡵࡺࡳࡷࡪࠢࡾ࠮ࠣࠫ࡮ࡪࠧ࠻ࠢ࠴ࢁ࠮ࡡࠧࡷࡣ࡯ࡹࡪ࠭࡝ࠋࠋࠌ࡭࡫ࠦࡰࡳࡱࡻࡽ࡚ࡹࡥࡳࡰࡤࡱࡪࠦࡡ࡯ࡦࠣࡴࡷࡵࡸࡺࡒࡤࡷࡸࡽ࡯ࡳࡦࠣࡥࡳࡪࠠࡱࡴࡲࡼࡾ࡛ࡒࡍࠢࡤࡲࡩࠦࡰࡳࡱࡻࡽࡕࡵࡲࡵ࠼ࠍࠍࠎࠏࡲࡦࡶࡸࡶࡳࠦࡰࡳࡱࡻࡽ࡚ࡘࡌࠡ࠭ࠣࠫ࠿࠭ࠠࠬࠢࡶࡸࡷ࠮ࡰࡳࡱࡻࡽࡕࡵࡲࡵࠫ࠮ࠫ࠿࠭ࠫࡴࡶࡵࠬࡵࡸ࡯ࡹࡻࡗࡽࡵ࡫ࠩࠡ࠭ࠣࠫ࠿࠭ࠠࠬࠢࡳࡶࡴࡾࡹࡖࡵࡨࡶࡳࡧ࡭ࡦࠢ࠮ࠤࠬࡆࠧࠡ࠭ࠣࡴࡷࡵࡸࡺࡒࡤࡷࡸࡽ࡯ࡳࡦࠍࠍࠎ࡫࡬ࡪࡨࠣࡴࡷࡵࡸࡺࡗࡕࡐࠥࡧ࡮ࡥࠢࡳࡶࡴࡾࡹࡑࡱࡵࡸ࠿ࠐࠉࠊࠋࡵࡩࡹࡻࡲ࡯ࠢࡳࡶࡴࡾࡹࡖࡔࡏࠤ࠰ࠦࠧ࠻ࠩࠣ࠯ࠥࡹࡴࡳࠪࡳࡶࡴࡾࡹࡑࡱࡵࡸ࠮࠱ࠧ࠻ࠩ࠮ࡷࡹࡸࠨࡱࡴࡲࡼࡾ࡚ࡹࡱࡧࠬࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡷ࡫ࡴࡶࡴࡱࠤࡓࡵ࡮ࡦࠌࠌࡶࡪࡺࡵࡳࡰࠍࠦࠧࠨ❯")