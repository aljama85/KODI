# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠪࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭Έ")
l1l1l1l_ll_ = l111lll_ll_ (u"ࠫࡤࡑࡒࡃࡡࠪῊ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
headers = {l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩΉ"):l111lll_ll_ (u"࠭ࠧῌ")}
def l111l1l_ll_(mode,url,text):
	if   mode==320: results = l11l1ll_ll_(url)
	elif mode==321: results = l1l11l1_ll_(url)
	elif mode==322: results = l11_ll_(url)
	elif mode==329: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠧࠨ῍")):
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ῎"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ῏"),l111lll_ll_ (u"ࠪࠫῐ"),329,l111lll_ll_ (u"ࠫࠬῑ"),l111lll_ll_ (u"ࠬ࠭ῒ"),l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪΐ"))
	if l1111l_ll_==l111lll_ll_ (u"ࠧࠨ῔"): l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭῕"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬῖ"),l111lll_ll_ (u"ࠪࠫῗ"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨῘ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡶࡪࡦࡨࡳ࠳ࡶࡨࡱࠩῙ"),l111lll_ll_ (u"࠭ࠧῚ"),headers,l111lll_ll_ (u"ࠧࠨΊ"),l111lll_ll_ (u"ࠨࠩ῜"),l111lll_ll_ (u"ࠩࡎࡅࡗࡈࡁࡍࡃࡗ࡚࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ῝"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡨࡵ࡮ࡰ࠯ࡳࡰࡺࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࠫ῞"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ῟"),block,re.DOTALL)
	for link,title in items:
		if title==l111lll_ll_ (u"ࠬอไๆๅอฬฮࠦวๅ็ิส๏ฯࠧῠ"): continue
		link = l1ll1l1_ll_+link
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ῡ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫῢ")+l1l1l1l_ll_+title,link,321)
	return html
def l1l11l1_ll_(url):
	#l1ll1l_ll_(url,html)
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬΰ"),url,l111lll_ll_ (u"ࠩࠪῤ"),headers,l111lll_ll_ (u"ࠪࠫῥ"),l111lll_ll_ (u"ࠫࠬῦ"),l111lll_ll_ (u"ࠬࡑࡁࡓࡄࡄࡐࡆ࡚ࡖ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬῧ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧῨ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡳࡨ࠺ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࡬࠸࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪῩ"),block,re.DOTALL)
	if not items: items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡴ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨῪ"),block,re.DOTALL)
	for link,img,count,title in items:
		count = count.replace(l111lll_ll_ (u"ࠩ฼ำิࠦࠧΎ"),l111lll_ll_ (u"ࠪࠫῬ")).replace(l111lll_ll_ (u"ࠫࠥ࠭῭"),l111lll_ll_ (u"ࠬ࠭΅"))
		link = link.replace(l111lll_ll_ (u"࠭࠯ࠨ`"),l111lll_ll_ (u"ࠧࠨ῰"))
		img = img.replace(l111lll_ll_ (u"ࠣࠩࠥ῱"),l111lll_ll_ (u"ࠩࠪῲ"))
		if l111lll_ll_ (u"ࠪ࠲ࡵ࡮ࡰࠨῳ") not in link: link = l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱ࠱ࡴ࡭ࡶࠧῴ")+link
		link = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࠧ῵")+link
		img = l1ll1l1_ll_+img
		title = title.strip(l111lll_ll_ (u"࠭ࠠࠨῶ"))
		title = title+l111lll_ll_ (u"ࠧࠡࠪࠪῷ")+count+l111lll_ll_ (u"ࠨࠫࠪῸ")
		if l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬΌ") in link: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪῺ"),l1l1l1l_ll_+title,link,321,img)
		elif l111lll_ll_ (u"ࠫࡼࡧࡴࡤࡪ࠱ࡴ࡭ࡶࠧΏ") in link: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫῼ"),l1l1l1l_ll_+title,link,322,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡧࡱࡲࡸࡪࡸࠧ´"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭῾"),block,re.DOTALL)
		for link,title in items:
			link = l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯࠯ࡲ࡫ࡴࠬ῿")+link
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ "),l1l1l1l_ll_+l111lll_ll_ (u"ูࠪๆำษࠡࠩ ")+title,link,321)
	return
def l11_ll_(url):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ "),url,l111lll_ll_ (u"ࠬ࠭ "),headers,l111lll_ll_ (u"࠭ࠧ "),l111lll_ll_ (u"ࠧࠨ "),l111lll_ll_ (u"ࠨࡍࡄࡖࡇࡇࡌࡂࡖ࡙࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ "))
	html = response.content
	#link = re.findall(l111lll_ll_ (u"ࠩ࠿ࡥࡺࡪࡩࡰ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ "),html,re.DOTALL)
	#if not link:
	link = re.findall(l111lll_ll_ (u"ࠪࡀࡻ࡯ࡤࡦࡱ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ "),html,re.DOTALL)
	link = l1ll1l1_ll_+link[0]#+l111lll_ll_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪ ")+l1ll11lll_ll_()+l111lll_ll_ (u"ࠬࠬࡶࡦࡴ࡬ࡪࡾࡶࡥࡦࡴࡀࡸࡷࡻࡥࠨ ")
	l111lll1_ll_(link,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ​"))
	return
def l1lll1_ll_(search):
	#search = l111lll_ll_ (u"ࠧๆะอหึ࠭‌")
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠨࠩ‍"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠩࠪ‎"): return
	search = search.replace(l111lll_ll_ (u"ࠪࠤࠬ‏"),l111lll_ll_ (u"ࠫ࠰࠭‐"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡵࡧ࡭࠴ࡰࡩࡲࡂࡵࡂ࠭‑")+search
	l1l11l1_ll_(url)
	return