# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ࣗ") : l111lll_ll_ (u"ࠪࠫࣘ") }
l1ll_ll_=l111lll_ll_ (u"ࠫࡆࡑࡏࡂࡏࡆࡅࡒ࠭ࣙ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡥࡁࡌࡅࡢࠫࣚ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
#l1l11_ll_ = [l111lll_ll_ (u"࠭แ๋ๆ่ࠫࣛ"),l111lll_ll_ (u"ࠧไๆํฬࠬࣜ"),l111lll_ll_ (u"ࠨษ็฽ึ฼ࠠศๆสือ๎ู๋ࠩࣝ"),l111lll_ll_ (u"่ࠩืึำ๊สࠩࣞ"),l111lll_ll_ (u"ุ้ࠪือ๋้ࠪࣟ"),l111lll_ll_ (u"ࠫฬเๆ๋หࠪ࣠"),l111lll_ll_ (u"ࠬอูๅษ้ࠫ࣡"),l111lll_ll_ (u"࠭ไใษฤࠫ࣢")]
#proxy = l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯࠲࠷࠼࠲࠷࠶࠳࠯࠺࠺࠲࠶࠹࠰࠻࠵࠴࠶࠽ࣣ࠭")
#proxy = l111lll_ll_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨࣤ")+l11llll1_ll_[6][1]
#l11lll1_ll_ = [l111lll_ll_ (u"ࠩหีฬ๋ฬࠨࣥ"),l111lll_ll_ (u"ࠪว้฿วษࣦࠩ"),l111lll_ll_ (u"ࠫฬ๊ๅึษิ฽ฮࠦวๅฯิอࠬࣧ"),l111lll_ll_ (u"ࠬอไฤฮ๊ึฮࠦวๅๆ๋ั๏ฯࠧࣨ"),l111lll_ll_ (u"࠭วๅๅ๋ีุอสࠡษ็ฮ฾๊๊ๆ์ฬࣩࠫ"),l111lll_ll_ (u"ࠧษำส้ัࠦวๅฬุ้๏๋ࠧ࣪"),l111lll_ll_ (u"ࠨษ็฽ฬฮࠠใฬส่ࠬ࣫"),l111lll_ll_ (u"ࠩส่฾อศࠡษ็็๊ฮ๊้ฬิࠤࡕࡉࠧ࣬"),l111lll_ll_ (u"ࠪห้ฮัศ็ฯ࣭ࠫ")]
l11lll1_ll_ = [l111lll_ll_ (u"๊ࠫ฻วา฻ฬ࣮ࠫ")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==350: results = l11l1ll_ll_(url)
	elif mode==351: results = l1l11l1_ll_(url,text)
	elif mode==352: results = l1l11ll_ll_(url)
	elif mode==353: results = l11_ll_(url)
	elif mode==354: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘࡥ࡟ࡠ࣯ࠩ")+text)
	elif mode==355: results = l1111l1_ll_(url,l111lll_ll_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤࣰ࠭")+text)
	elif mode==356: results = l1ll1lll_ll_(url)
	elif mode==357: results = l11lll1l_ll_(url)
	elif mode==359: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠧࠨࣱ")):
	if l1111l_ll_==l111lll_ll_ (u"ࠨࣲࠩ"):
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࣳ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪࣴ"),l111lll_ll_ (u"ࠫࠬࣵ"),359,l111lll_ll_ (u"ࣶࠬ࠭"),l111lll_ll_ (u"࠭ࠧࣷ"),l111lll_ll_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫࣸ"))
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨࣹ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤࣺ࠭")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪๅ้ะัࠡ็ะำิ࠭ࣻ"),l1ll1l1_ll_,356)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࣼ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩࣽ")+l1l1l1l_ll_+l111lll_ll_ (u"࠭แๅฬิࠤ่อๅๅࠩࣾ"),l1ll1l1_ll_,357)
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬࣿ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫऀ"),l111lll_ll_ (u"ࠩࠪँ"),9999)
	#l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪं"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨः")+l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไๆิํำࠬऄ"),l1ll1l1_ll_,352,l111lll_ll_ (u"࠭ࠧअ"),l111lll_ll_ (u"ࠧࠨआ"),l111lll_ll_ (u"ࠨ࡯ࡲࡶࡪ࠭इ"))
	#l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩई"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧउ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊วฯสสีࠬऊ"),l1ll1l1_ll_,352,l111lll_ll_ (u"ࠬ࠭ऋ"),l111lll_ll_ (u"࠭ࠧऌ"),l111lll_ll_ (u"ࠧ࡯ࡧࡺࡷࠬऍ"))
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠨࠩऎ"),headers,l111lll_ll_ (u"ࠩࠪए"),l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧऐ"))
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡰࡾ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪऑ"),html,re.DOTALL)
	if l1ll111_ll_: l1ll111_ll_ = l1ll111_ll_[0]
	else: l1ll111_ll_ = l1ll1l1_ll_
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬऒ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪओ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศุํๅࠥำฯ๋อสࠫऔ"),l1ll111_ll_,351)
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠨࡂ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧक"),html,re.DOTALL)
	if l1ll111_ll_: l1ll111_ll_ = l1ll111_ll_[0]
	else: l1ll111_ll_ = l1ll1l1_ll_
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩख"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧग")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ๅๆ์ีอࠬघ"),l1ll111_ll_,351,l111lll_ll_ (u"ࠬ࠭ङ"),l111lll_ll_ (u"࠭ࠧच"),l111lll_ll_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩछ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡢࡶࡨ࡫ࡴࡸࡩࡦࡵ࠰ࡰ࡮ࡹࡴࠩ࠰࠭ࡃ࠮ࡳࡡࡪࡰ࠰ࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹ࠭࡭࡫ࡶࡸࠬज"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡪࡴࡴࡴ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫझ"),block,re.DOTALL)
		for link,title in items:
			if title not in l11lll1_ll_: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪञ"),l1l1l1l_ll_+title,link,351)
		if l1111l_ll_==l111lll_ll_ (u"ࠫࠬट"): l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪठ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩड"),l111lll_ll_ (u"ࠧࠨढ"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡤࡸࡪ࡭࡯ࡳ࡫ࡨࡷ࠲ࡨ࡯ࡹࠪ࠱࠮ࡄ࠯࠼ࡧࡱࡲࡸࡪࡸࠧण"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀࠬत"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			if title not in l11lll1_ll_: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪथ"),l1l1l1l_ll_+title,link,351)
	return html
def l1ll1lll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠫࠬद")):
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠬ࠭ध"),headers,l111lll_ll_ (u"࠭ࠧन"),l111lll_ll_ (u"ࠧࡂࡍࡒࡅࡒࡉࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫऩ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠮࠮ࠫࡁࠬࡀࡳࡧࡶࠨप"),html,re.DOTALL)
	#l1ll1l_ll_(link,l1lll_ll_][0])
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸࡪࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩफ"),block,re.DOTALL)
		for link,title in items:
			#l1ll1l_ll_(link,title)
			if title not in l11lll1_ll_:
				title = title+l111lll_ll_ (u"ࠪࠤ๊฻ๆโหࠪब")
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫभ"),l1l1l1l_ll_+title,link,355)
		if l1111l_ll_==l111lll_ll_ (u"ࠬ࠭म"): l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫय"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪर"),l111lll_ll_ (u"ࠨࠩऱ"),9999)
	return html
def l11lll1l_ll_(l1111l_ll_=l111lll_ll_ (u"ࠩࠪल")):
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫळ"),headers,l111lll_ll_ (u"ࠫࠬऴ"),l111lll_ll_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩव"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨ࡭ࡦࡰࡸࠬ࠳࠰࠿ࠪ࠾ࡱࡥࡻ࠭श"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶࡨࡼࡹࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧष"),block,re.DOTALL)
		for link,title in items:
			if title not in l11lll1_ll_:
				title = title+l111lll_ll_ (u"ࠨ่ࠢๅ้ะัสࠩस")
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩह"),l1l1l1l_ll_+title,link,354)
		if l1111l_ll_==l111lll_ll_ (u"ࠪࠫऺ"): l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩऻ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ़"),l111lll_ll_ (u"࠭ࠧऽ"),9999)
	return html
def l1l11l1_ll_(url,type=l111lll_ll_ (u"ࠧࠨा")):
	#l1ll1l_ll_(url,type)
	html = l111ll1_ll_(l1l11lll_ll_,url,l111lll_ll_ (u"ࠨࠩि"),headers,True,l111lll_ll_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨी"))
	if type==l111lll_ll_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࠬु"): l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡸࡽࡩࡱࡧࡵ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠨ࠯ࠬࡂ࠭ࡸࡽࡩࡱࡧࡵ࠱ࡧࡻࡴࡵࡱࡱ࠱ࡵࡸࡥࡷࠩू"),html,re.DOTALL)
	else: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠣࠪ࠱࠮ࡄ࠯࡭ࡢ࡫ࡱ࠱࡫ࡵ࡯ࡵࡧࡵࠫृ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡸ࡭࡫ࡱ࡯࠿࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵࡧࡻࡸ࠲ࡽࡨࡪࡶࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬॄ"),block,re.DOTALL)
		#l1ll1l_ll_(str(len(block)),url)
		l1ll11ll_ll_ = []
		for img,link,title in items:
			title = unescapeHTML(title)
			if l111lll_ll_ (u"ࠧศๆะ่็ฯࠧॅ") in title or l111lll_ll_ (u"ࠨษ็ั้่็ࠨॆ") in title:
				episode = re.findall(l111lll_ll_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧे"),title,re.DOTALL)
				if episode:
					title = l111lll_ll_ (u"ࠪࡣࡒࡕࡄࡠࠩै") + episode[0][0]
					if title not in l1ll11ll_ll_:
						l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫॉ"),l1l1l1l_ll_+title,link,352,img)
						l1ll11ll_ll_.append(title)
			elif l111lll_ll_ (u"๋ࠬำๅี็ࠫॊ") in title:
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ो"),l1l1l1l_ll_+title,link,352,img)
			else: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ौ"),l1l1l1l_ll_+title,link,353,img)
			#if l111lll_ll_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱्ࠪ") in link or l111lll_ll_ (u"ࠩ࠲ࡷ࡭ࡵࡷࡴ࠱ࠪॎ") in link:
			#	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪॏ"),l1l1l1l_ll_+title,link,352,img)
			#elif l111lll_ll_ (u"ࠫ࠴ࡶࡲࡰࡩࡵࡥࡲࡹ࠯ࠨॐ") not in link and l111lll_ll_ (u"ࠬ࠵ࡧࡢ࡯ࡨࡷ࠴࠭॑") not in link:
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ॒ࠧ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࠳࠰࠿ࠪ࡝ࠥࡠࠬࡣ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ॓"),block,re.DOTALL)
		for link,title in items:
			#if l111lll_ll_ (u"ࠨࠨ࡯ࡷࡦࡷࡵࡰ࠽ࠪ॔") in title: title = l111lll_ll_ (u"ุࠩๅาฯࠠิษหๆฮ࠭ॕ")
			#if l111lll_ll_ (u"ࠪࠪࡷࡹࡡࡲࡷࡲ࠿ࠬॖ") in title: title = l111lll_ll_ (u"ฺࠫ็อสࠢ็หา่ษࠨॗ")
			#if l111lll_ll_ (u"ࠬࠬ࡬ࡢࡳࡸࡳࠬक़") in title: title = l111lll_ll_ (u"࠭วๅืไัฮࠦวๅฬส่๏ฯࠧख़")
			#if l111lll_ll_ (u"ࠧึใะอࠬग़") not in title: title = l111lll_ll_ (u"ࠨืไัฮࠦࠧज़")+title
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩड़"),l1l1l1l_ll_+l111lll_ll_ (u"ูࠪๆำษࠡࠩढ़")+title,link,351)
	return
def l1lll1_ll_(search):
	# l1ll1l1l_ll_://l11lllll_ll_.net/search?q=%l1l11111_ll_%l1ll11l1_ll_%l1l11111_ll_%l1lll1ll_ll_%l1l11111_ll_%l1ll1111_ll_
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠫࠬफ़"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠬ࠭य़"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"࠭ࠠࠨॠ"),l111lll_ll_ (u"ࠧࠬࠩॡ"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠨ࠱ࡂࡷࡂ࠭ॢ")+l1llll1_ll_
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࡖࡉࡆࡘࡃࡉࡡࡄࡏࡔࡇࡍࠨॣ"))
	results = l1l11l1_ll_(url)
	return
def l1l11ll_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࡉࡕࡏࡓࡐࡆࡈࡗࡤࡇࡋࡘࡃࡐࠫ।"))
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬ॥"),headers,True,l111lll_ll_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭०"))
	#if l111lll_ll_ (u"࠭࠭ࡦࡲ࡬ࡷࡴࡪࡥࡴࠩ१") not in html:
	#	img = xbmc.getInfoLabel(l111lll_ll_ (u"ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡌࡧࡴࡴࠧ२"))
	#	l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ३"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩิหอ฽ࠠศๆอุ฿๐ไࠨ४"),url,353,img)
	#else:
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡸࡪࡾࡴ࠮ࡹ࡫࡭ࡹ࡫ࠢ࠿ษ็ั้่วหࠪ࠱࠮ࡄ࠯࠼ࡩࡧࡤࡨࡪࡸࠧ५"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		episodes = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡤࡰࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ६"),block,re.DOTALL)
		for link,img,title in episodes:
			if l111lll_ll_ (u"ࠬอไฮๆๅอࠬ७") in title or l111lll_ll_ (u"࠭วๅฯ็ๆ์࠭८") in title: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭९"),l1l1l1l_ll_+title,link,353,img)
			#else: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ॰"),l1l1l1l_ll_+title,link,352,img)
	else:
		img = xbmc.getInfoLabel(l111lll_ll_ (u"ࠩࡏ࡭ࡸࡺࡉࡵࡧࡰ࠲ࡎࡩ࡯࡯ࠩॱ"))
		if html.count(l111lll_ll_ (u"ࠪࡀࡹ࡯ࡴ࡭ࡧࡁࠫॲ"))>1: title = re.findall(l111lll_ll_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫॳ"),html,re.DOTALL)[1]
		else: title = l111lll_ll_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫॴ")
		l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬॵ"),l1l1l1l_ll_+title,url,353,img)
	return
def l11_ll_(url):
	l1l111l_ll_,l1111ll_ll_ = [],[]
	l1llllll_ll_ = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫॶ"),url,l111lll_ll_ (u"ࠨࠩॷ"),l111lll_ll_ (u"ࠩࠪॸ"),l111lll_ll_ (u"ࠪࠫॹ"),l111lll_ll_ (u"ࠫࠬॺ"),l111lll_ll_ (u"ࠬࡇࡋࡐࡃࡐࡇࡆࡓ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩॻ"))
	html = l1llllll_ll_.content
	l1l111ll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠨࠧॼ"),html,re.DOTALL)
	if l1l111ll_ll_:
		l1l111ll_ll_ = l1l111ll_ll_[0]
		headers = {l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫॽ"):l111lll_ll_ (u"ࠨࠩॾ"),l111lll_ll_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨॿ"):l111lll_ll_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩঀ")}
		data = {l111lll_ll_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬঁ"):l1l111ll_ll_}
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡥ࡫ࡲࡡ࡮࠺࡮࡯ࡰ࠵ࡉ࡯ࡥ࠲ࡅ࡯ࡧࡸ࠰ࡕ࡬ࡲ࡬ࡲࡥ࠰࡙ࡤࡸࡨ࡮࠮ࡱࡪࡳࠫং")
		l1l1l11l_ll_ = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫঃ"),l1ll111_ll_,data,headers,l111lll_ll_ (u"ࠧࠨ঄"),l111lll_ll_ (u"ࠨࠩঅ"),l111lll_ll_ (u"ࠩࡄࡏࡔࡇࡍࡄࡃࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭আ"))
		l1l111l1_ll_ = l1l1l11l_ll_.content
		items = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡵࡨࡶࡻ࡫ࡲ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡨࡲࡡࡴࡵࡀࠦࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪই"),l1l111l1_ll_,re.DOTALL)
		for l1l11l1l_ll_,name in items:
			#data = {l111lll_ll_ (u"ࠫࡵࡵࡳࡵࡡ࡬ࡨࠬঈ"):l1l111ll_ll_,l111lll_ll_ (u"ࠬࡹࡥࡳࡸࡨࡶࠬউ"):l1l11l1l_ll_}
			link = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸ࠰ࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡤࡪࡱࡧ࡭࠹࡭࡮࡯࠴ࡏ࡮ࡤ࠱ࡄ࡮ࡦࡾ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡔࡧࡵࡺࡪࡸ࠮ࡱࡪࡳࠫঊ")
			link = link+l111lll_ll_ (u"ࠧࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩঋ")+l1l111ll_ll_+l111lll_ll_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬঌ")+l1l11l1l_ll_+l111lll_ll_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪ঍")+name+l111lll_ll_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫ঎")
			l1l111l_ll_.append(link)
			l1111ll_ll_.append(name)
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡽࡰ࠮ࡥࡲࡲࡹ࡫࡮ࡵ࠱ࡷ࡬ࡪࡳࡥࡴ࠱ࡤࡪࡱࡧ࡭࠹࡭࡮࡯࠴ࡏ࡮ࡤ࠱ࡄ࡮ࡦࡾ࠯ࡔ࡫ࡱ࡫ࡱ࡫࠯ࡅࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵ࠭এ")
		l1l1l11l_ll_ = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠬࡖࡏࡔࡖࠪঐ"),l1ll111_ll_,data,headers,l111lll_ll_ (u"࠭ࠧ঑"),l111lll_ll_ (u"ࠧࠨ঒"),l111lll_ll_ (u"ࠨࡃࡎࡓࡆࡓࡃࡂࡏ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬও"))
		l1l111l1_ll_ = l1l1l11l_ll_.content
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡸࡪࡾࡴࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩঔ"),l1l111l1_ll_,re.DOTALL)
		for link,title in items:
			#l1ll1l_ll_(link,title)
			link = link.strip(l111lll_ll_ (u"ࠪࠤࠬক"))
			link = link+l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬখ")+title+l111lll_ll_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩগ")
			l1l111l_ll_.append(link)
			l1111ll_ll_.append(title)
	#l1l1111_ll_(l111lll_ll_ (u"࠭ࠧঘ"),l1l111l_ll_)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪঙ"),l111lll_ll_ (u"ࠨษ็ีฬฮืࠡๆํืࠥ็๊่ࠢไ๎ิ๐่ࠨচ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨছ"))
	return
def l1111l1_ll_(url,filter):
	filter = filter.replace(l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬজ"),l111lll_ll_ (u"ࠫࠬঝ"))
	#l1ll1l_ll_(filter,url)
	l1l1ll1l_ll_ = [l111lll_ll_ (u"ࠬࡩࡡࡵࠩঞ"),l111lll_ll_ (u"࠭ࡧࡦࡰࡵࡩࠬট"),l111lll_ll_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ঠ"),l111lll_ll_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩড"),l111lll_ll_ (u"ࠩࡲࡶࡩ࡫ࡲࡣࡻࠪঢ")]
	if l111lll_ll_ (u"ࠪࡃࠬণ") in url: url = url.split(l111lll_ll_ (u"ࠫࡄ࠭ত"))[0]
	type,filter = filter.split(l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩথ"),1)
	if filter==l111lll_ll_ (u"࠭ࠧদ"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"ࠧࠨধ"),l111lll_ll_ (u"ࠨࠩন")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"ࠩࡢࡣࡤ࠭঩"))
	if type==l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧপ"):
		if l1l1ll1l_ll_[0]+l111lll_ll_ (u"ࠫࡂ࠭ফ") not in l1l1l1ll_ll_: category = l1l1ll1l_ll_[0]
		for i in range(len(l1l1ll1l_ll_[0:-1])):
			if l1l1ll1l_ll_[i]+l111lll_ll_ (u"ࠬࡃࠧব") in l1l1l1ll_ll_: category = l1l1ll1l_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"࠭ࠦࠨভ")+category+l111lll_ll_ (u"ࠧ࠾࠲ࠪম")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠨࠨࠪয")+category+l111lll_ll_ (u"ࠩࡀ࠴ࠬর")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"ࠪࠪࠬ঱"))+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨল")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠬࠬࠧ঳"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"࠭ࡡ࡭࡮ࠪ঴"))
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠧࡀࠩ঵")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩশ"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫষ"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"ࠪࠫস"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠫࡦࡲ࡬ࠨহ"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠬ࠭঺"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"࠭࠿ࠨ঻")+l1l1l1l1_ll_
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ়ࠧ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠪঽ"),l1ll111_ll_,351,l111lll_ll_ (u"ࠩࠪা"),l111lll_ll_ (u"ࠪ࠵ࠬি"))
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫী"),l1l1l1l_ll_+l111lll_ll_ (u"࡛ࠬࠦ࡜ࠢࠣࠤࠬু")+l1l1111l_ll_+l111lll_ll_ (u"࠭ࠠࠡࠢࡠࡡࠬূ"),l1ll111_ll_,351,l111lll_ll_ (u"ࠧࠨৃ"),l111lll_ll_ (u"ࠨ࠳ࠪৄ"))
		l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ৅"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭৆"),l111lll_ll_ (u"ࠫࠬে"),9999)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠬ࠭ৈ"),headers,True,l111lll_ll_ (u"࠭ࡁࡌࡑࡄࡑࡈࡇࡍ࠮ࡈࡌࡐ࡙ࡋࡒࡔࡡࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ৉"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࠽ࡨࡲࡶࡲࠦࡩࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡨࡲࡶࡲࡄࠧ৊"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l11111l_ll_ = re.findall(l111lll_ll_ (u"ࠨ࠾ࡶࡩࡱ࡫ࡣࡵ࠰࠭ࡃࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡦ࡮ࡨࡧࡹࡄࠧো"),block,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪৌ"),str(l11111l_ll_))
	dict = {}
	for l1lllll1_ll_,name,block in l11111l_ll_:
		#name = name.replace(l111lll_ll_ (u"ࠪ࠱࠲্࠭"),l111lll_ll_ (u"ࠫࠬৎ"))
		items = re.findall(l111lll_ll_ (u"ࠬࡂ࡯ࡱࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡂ࠭࠴ࠪࡀࠫ࠿ࠫ৏"),block,re.DOTALL)
		if l111lll_ll_ (u"࠭࠽ࠨ৐") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫ৑"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ৒")+l1l1llll_ll_)
				return
			else:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ৓"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้าๅ๋฻ࠪ৔"),l1ll111_ll_,351,l111lll_ll_ (u"ࠫࠬ৕"),l111lll_ll_ (u"ࠬ࠷ࠧ৖"))
				else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ৗ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆฯ้๏฿ࠧ৘"),l1ll111_ll_,355,l111lll_ll_ (u"ࠨࠩ৙"),l111lll_ll_ (u"ࠩࠪ৚"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫ৛"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠫࠫ࠭ড়")+l1lllll1_ll_+l111lll_ll_ (u"ࠬࡃ࠰ࠨঢ়")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"࠭ࠦࠨ৞")+l1lllll1_ll_+l111lll_ll_ (u"ࠧ࠾࠲ࠪয়")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬৠ")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩৡ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠥ࠭ৢ")+name,l1ll111_ll_,354,l111lll_ll_ (u"ࠫࠬৣ"),l111lll_ll_ (u"ࠬ࠭৤"),l1l1llll_ll_+l111lll_ll_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ৥"))
		dict[l1lllll1_ll_] = {}
		for value,option in items:
			if option in l11lll1_ll_: continue
			if l111lll_ll_ (u"ࠧࡷࡣ࡯ࡹࡪ࠭০") not in value: value = option
			else: value = re.findall(l111lll_ll_ (u"ࠨࠤࠫ࠲࠯ࡅࠩࠣࠩ১"),value,re.DOTALL)[0]
			dict[l1lllll1_ll_][value] = option
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠩࠩࠫ২")+l1lllll1_ll_+l111lll_ll_ (u"ࠪࡁࠬ৩")+option
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠫࠫ࠭৪")+l1lllll1_ll_+l111lll_ll_ (u"ࠬࡃࠧ৫")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ৬")+l1ll1l11_ll_
			title = option+l111lll_ll_ (u"ࠧࠡ࠼ࠣࠫ৭")#+dict[l1lllll1_ll_][l111lll_ll_ (u"ࠨ࠲ࠪ৮")]
			title = option+l111lll_ll_ (u"ࠩࠣ࠾ࠥ࠭৯")+name
			if type==l111lll_ll_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫৰ"): l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫৱ"),l1l1l1l_ll_+title,url,354,l111lll_ll_ (u"ࠬ࠭৲"),l111lll_ll_ (u"࠭ࠧ৳"),l1llll1l_ll_+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ৴"))
			elif type==l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ৵") and l1l1ll1l_ll_[-2]+l111lll_ll_ (u"ࠩࡀࠫ৶") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠪࡥࡱࡲࠧ৷"))
				l11ll1_ll_ = url+l111lll_ll_ (u"ࠫࡄ࠭৸")+l1l11ll1_ll_
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ৹"),l1l1l1l_ll_+title,l11ll1_ll_,351,l111lll_ll_ (u"࠭ࠧ৺"),l111lll_ll_ (u"ࠧ࠲ࠩ৻"))
			else: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨৼ"),l1l1l1l_ll_+title,url,355,l111lll_ll_ (u"ࠩࠪ৽"),l111lll_ll_ (u"ࠪࠫ৾"),l1llll1l_ll_)
	return
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬ৿"))
	# mode==l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧ਀")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩਁ")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"ࠧࡢ࡮࡯ࠫਂ")					all filters (l1l11l11_ll_ empty filter)
	#filters = filters.replace(l111lll_ll_ (u"ࠨ࠿ࠩࠫਃ"),l111lll_ll_ (u"ࠩࡀ࠴ࠫ࠭਄"))
	filters = filters.strip(l111lll_ll_ (u"ࠪࠪࠬਅ"))
	l1l1ll11_ll_ = {}
	if l111lll_ll_ (u"ࠫࡂ࠭ਆ") in filters:
		items = filters.split(l111lll_ll_ (u"ࠬࠬࠧਇ"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"࠭࠽ࠨਈ"))
			l1l1ll11_ll_[var] = value
	l1llll11_ll_ = l111lll_ll_ (u"ࠧࠨਉ")
	l1lll1l1_ll_ = [l111lll_ll_ (u"ࠨࡥࡤࡸࠬਊ"),l111lll_ll_ (u"ࠩࡪࡩࡳࡸࡥࠨ਋"),l111lll_ll_ (u"ࠪࡶࡪࡲࡥࡢࡵࡨ࠱ࡾ࡫ࡡࡳࠩ਌"),l111lll_ll_ (u"ࠫࡶࡻࡡ࡭࡫ࡷࡽࠬ਍"),l111lll_ll_ (u"ࠬࡵࡲࡥࡧࡵࡦࡾ࠭਎")]
	for key in l1lll1l1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"࠭࠰ࠨਏ")
		#if l111lll_ll_ (u"ࠧࠦࠩਐ") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ਑") and value!=l111lll_ll_ (u"ࠩ࠳ࠫ਒"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠪࠤ࠰ࠦࠧਓ")+value
		elif mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧਔ") and value!=l111lll_ll_ (u"ࠬ࠶ࠧਕ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"࠭ࠦࠨਖ")+key+l111lll_ll_ (u"ࠧ࠾ࠩਗ")+value
		elif mode==l111lll_ll_ (u"ࠨࡣ࡯ࡰࠬਘ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠩࠩࠫਙ")+key+l111lll_ll_ (u"ࠪࡁࠬਚ")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠫࠥ࠱ࠠࠨਛ"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠬࠬࠧਜ"))
	#l1llll11_ll_ = l1llll11_ll_.replace(l111lll_ll_ (u"࠭࠽࠱ࠩਝ"),l111lll_ll_ (u"ࠧ࠾ࠩਞ"))
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠲࠳ࠩਟ"))
	return l1llll11_ll_