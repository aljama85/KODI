﻿# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#import unicodedata,simplejson
def l111l1l_ll_(mode,l1lll1l11l1_ll_):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if l1lll1l11l1_ll_==l111lll_ll_ (u"࠭ࠧ‒"): return
	if mode==1:
		l1lll1l1ll1_ll_ = xbmcgui.getCurrentWindowDialogId()
		l1lll1l1l1l_ll_ = xbmcgui.Window(l1lll1l1ll1_ll_)
		l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
		l1lll1l1l1l_ll_.getControl(311).setLabel(l1lll1l11l1_ll_)
	if mode==0:
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠧࡶࡰ࡬ࡧࡴࡪࡥࡠࡧࡶࡧࡦࡶࡥࠨ–"))
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠨࡴࡤࡻࡤࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭—"))
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠳࠸ࠨ―"))
		l1lll1l1111_ll_=l111lll_ll_ (u"ࠪ࡜ࠬ‖")
		check=isinstance(l1lll1l11l1_ll_, unicode)
		if check==True: l1lll1l1111_ll_=l111lll_ll_ (u"࡚ࠫ࠭‗")
		l1lll11llll_ll_=str(type(l1lll1l11l1_ll_))+l111lll_ll_ (u"ࠬࠦࠧ‘")+l1lll1l11l1_ll_+l111lll_ll_ (u"࠭ࠠࠨ’")+l1lll1l1111_ll_+l111lll_ll_ (u"ࠧࠡࠩ‚")
		for i in range(0,len(l1lll1l11l1_ll_),1):
			l1lll11llll_ll_ += hex(ord(l1lll1l11l1_ll_[i])).replace(l111lll_ll_ (u"ࠨ࠲ࡻࠫ‛"),l111lll_ll_ (u"ࠩࠪ“"))+l111lll_ll_ (u"ࠪࠤࠬ”")
		l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠮࠺ࠪ„"))
		l1lll1l1111_ll_=l111lll_ll_ (u"ࠬ࡞ࠧ‟")
		check=isinstance(l1lll1l11l1_ll_, unicode)
		if check==True: l1lll1l1111_ll_=l111lll_ll_ (u"࠭ࡕࠨ†")
		l1lll1l111l_ll_=str(type(l1lll1l11l1_ll_))+l111lll_ll_ (u"ࠧࠡࠩ‡")+l1lll1l11l1_ll_+l111lll_ll_ (u"ࠨࠢࠪ•")+l1lll1l1111_ll_+l111lll_ll_ (u"ࠩࠣࠫ‣")
		for i in range(0,len(l1lll1l11l1_ll_),1):
			l1lll1l111l_ll_ += hex(ord(l1lll1l11l1_ll_[i])).replace(l111lll_ll_ (u"ࠪ࠴ࡽ࠭․"),l111lll_ll_ (u"ࠫࠬ‥"))+l111lll_ll_ (u"ࠬࠦࠧ…")
		#l1ll1l_ll_(l1lll11llll_ll_,l1lll1l111l_ll_)
	return
	#for i in range(0,len(l1lll1l11l1_ll_)-2,3):
	#	string=hex(ord(l1lll1l11l1_ll_[i+0]))+l111lll_ll_ (u"࠭ࠠࠡࠩ‧")+hex(ord(l1lll1l11l1_ll_[i+1]))+l111lll_ll_ (u"ࠧࠡࠢࠪ ")+hex(ord(l1lll1l11l1_ll_[i+2]))
	#	l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩ "),string)
	#return
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ‪"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫ‫"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ‬"))
	#l1lll1l11l1_ll_ = unicodedata.normalize(l111lll_ll_ (u"ࠬࡔࡆࡌࡆࠪ‭"),l1lll1l11l1_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧ‮"),   hex(  unicodedata.combining(l1lll1l11l1_ll_[0])  )   )
	#l1ll1l_ll_(l1lll1l11l1_ll_,   hex(ord(  l1lll1l11l1_ll_[0]  ))   )
	#new = l111lll_ll_ (u"ࠧࠨ ")
	#for letter in l1lll1l11l1_ll_:
	#	l1ll1l_ll_(l111lll_ll_ (u"ࠨࡏࡲࡨࡪࠦ࠰ࠨ‰"),unicodedata.decomposition(letter) )
	#	new += l111lll_ll_ (u"ࠩ࡟ࡹ࠵࠭‱") + hex(ord(letter)).replace(l111lll_ll_ (u"ࠪ࠴ࡽ࠭′"),l111lll_ll_ (u"ࠫࠬ″"))
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭‴"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"࠭ࠧ‵")
	#for i in range(len(l1lll1l11l1_ll_)-6,-5,-6):
	#	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ‶"),str(i))
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1] + l1lll1l11l1_ll_[i+2] + l1lll1l11l1_ll_[i+3] + l1lll1l11l1_ll_[i+4] + l1lll1l11l1_ll_[i+5]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩ‷"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ‸"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫ‹"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ›"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭※"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l111lll_ll_ (u"࠭ࡥ࡮ࡣࡧࠫ‼")
	#l1lll1l11ll_ll_ = xbmc.executeJSONRPC(l111lll_ll_ (u"ࠧࡼࠤ࡭ࡷࡴࡴࡲࡱࡥࠥ࠾ࠧ࠸࠮࠱ࠤ࠯ࠦࡲ࡫ࡴࡩࡱࡧࠦ࠿ࠨࡉ࡯ࡲࡸࡸ࠳࡙ࡥ࡯ࡦࡗࡩࡽࡺࠢ࠭ࠤࡳࡥࡷࡧ࡭ࡴࠤ࠽ࡿࠧࡺࡥࡹࡶࠥ࠾ࠧ࠭‽")+l1lll1l11l1_ll_+l111lll_ll_ (u"ࠨࠤ࠯ࠦࡩࡵ࡮ࡦࠤ࠽ࡪࡦࡲࡳࡦࡿ࠯ࠦ࡮ࡪࠢ࠻࠳ࢀࠫ‾"))
	#simplejson.loads(l1lll1l11ll_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ‿"))
	#new = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ⁀"))
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ⁁"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭⁂"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"࠭ࠧ⁃")
	#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ⁄"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭⁅"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ⁆"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"ࠪࠫ⁇")
	#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ⁈"),l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.replace(l111lll_ll_ (u"ࠬࠦࠧ⁉"),l111lll_ll_ (u"࠭ࠧ⁊"))
		#new = l111lll_ll_ (u"ࠧࠨ⁋")
		#for i in range(len(l1lll1l11l1_ll_)-3,-2,-3):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1] + l1lll1l11l1_ll_[i+2]
		#l1lll1l11l1_ll_ = new
		#new = l111lll_ll_ (u"ࠨࠩ⁌")
		#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
		#l1lll1l11l1_ll_ = new
		#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ⁍"),l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.l1lll1l1l11_ll_(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ⁎"))
		#l1ll1l_ll_(str(ord(l1lll1l11l1_ll_[0]))+l111lll_ll_ (u"ࠫࠥ࠭⁏")+str(ord(l1lll1l11l1_ll_[1]))+l111lll_ll_ (u"ࠬࠦࠧ⁐")+str(ord(l1lll1l11l1_ll_[2])),str(len(l1lll1l11l1_ll_)))
		#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡍࡰࡦࡨࠤ࠵ࠦࡌࡦࡶࡷࡩࡷࡹࠧ⁑"),l1lll1l11l1_ll_)
		#new = l111lll_ll_ (u"ࠧࠨ⁒")
		#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
		#l1lll1l11l1_ll_ = new
		#new = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭⁓"))
		#new = new.decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ⁔"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ⁕"),new )
		#l1lll11llll_ll_ = l111lll_ll_ (u"ࠫࠬ⁖")
		#for letter in new:
		#	l1ll1l_ll_(l111lll_ll_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠬ⁗"),unicodedata.decomposition(letter) )
		#	l1lll11llll_ll_ += l111lll_ll_ (u"࠭࡜ࡶࠩ⁘") + hex(ord(letter)).replace(l111lll_ll_ (u"ࠧࡹࠩ⁙"),l111lll_ll_ (u"ࠨࠩ⁚"))
		#l1lll11llll_ll_ = l1lll11llll_ll_.decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪ⁛"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠪࡑࡴࡪࡥࠡ࠲ࠪ⁜"),l1lll11llll_ll_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1lll1l1lll_ll_(new)
		#l1lll1l11l1_ll_ = new.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ⁝"))
		#new = new.decode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪ⁞")) #.decode(l111lll_ll_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ "))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ⁠"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭⁡")))   )
		#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(new)
		#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
		#method=l111lll_ll_ (u"ࠤࡌࡲࡵࡻࡴ࠯ࡕࡨࡲࡩ࡚ࡥࡹࡶࠥ⁢")
		#params=l111lll_ll_ (u"ࠪࡿࠧࡺࡥࡹࡶࠥ࠾ࠧࠫࡳࠣ࠮ࠣࠦࡩࡵ࡮ࡦࠤ࠽ࡪࡦࡲࡳࡦࡿࠪ⁣") % l1lll1l11l1_ll_
		#l1lll1l11ll_ll_ = xbmc.executeJSONRPC(l111lll_ll_ (u"ࠫࢀࠨࡪࡴࡱࡱࡶࡵࡩࠢ࠻ࠢࠥ࠶࠳࠶ࠢ࠭ࠢࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠥࠨࠥࡴࠤ࠯ࠤࠧࡶࡡࡳࡣࡰࡷࠧࡀࠠࠦࡵ࠯ࠤࠧ࡯ࡤࠣ࠼ࠣ࠵ࢂ࠭⁤") % (method, params))