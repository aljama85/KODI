# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"࠭ࡃࡊࡏࡄࡒࡔ࡝ࠧኳ")
headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫኴ") : l111lll_ll_ (u"ࠨࠩኵ") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡇࡒࡔ࡟ࠨ኶")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==300: results = l11l1ll_ll_(url)
	elif mode==301: results = l1l11l1_ll_(url,text)
	elif mode==302: results = l11_ll_(url)
	elif mode==309: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ኷")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬኸ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬኹ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ኺ"),l111lll_ll_ (u"ࠧࠨኻ"),309,l111lll_ll_ (u"ࠨࠩኼ"),l111lll_ll_ (u"ࠩࠪኽ"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧኾ"))
	#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ኿"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็ไหำࠪዀ"),l111lll_ll_ (u"࠭ࠧ዁"),114,l1ll1l1_ll_)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫዂ"),l1ll1l1_ll_,l111lll_ll_ (u"ࠨࠩዃ"),headers,l111lll_ll_ (u"ࠩࠪዄ"),l111lll_ll_ (u"ࠪࠫዅ"),l111lll_ll_ (u"ࠫࡈࡏࡍࡂࡐࡒ࡛࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ዆"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡩ࡭ࡶࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ዇"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"࠭ࡤࡢࡶࡤ࠱࡫࡯࡬ࡵࡧࡵࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽࠱࡬ࡂ࠭࠴ࠪࡀࠫ࠿ࠫወ"),block,re.DOTALL)
	if l1111l_ll_==l111lll_ll_ (u"ࠧࠨዉ"): l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭ዊ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬዋ"),l111lll_ll_ (u"ࠪࠫዌ"),9999)
	for key,title in items:
		title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭ው"))
		url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡷࡱ࠯ࡦࡳࡳࡺࡥ࡯ࡶ࠲ࡸ࡭࡫࡭ࡦࡵ࠲ࡇ࡮ࡳࡡࡏࡱࡺ࠳ࡎࡴࡴࡦࡴࡩࡥࡨ࡫࠯ࡧ࡫࡯ࡸࡪࡸ࠮ࡱࡪࡳࠫዎ")
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ዏ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫዐ")+l1l1l1l_ll_+title,url,301,l111lll_ll_ (u"ࠨࠩዑ"),l111lll_ll_ (u"ࠩࠪዒ"),key)
	if l1111l_ll_==l111lll_ll_ (u"ࠪࠫዓ"): l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩዔ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨዕ"),l111lll_ll_ (u"࠭ࠧዖ"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡣ࡬ࡲࡒ࡫࡮ࡶࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ዗"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧዘ"),block,re.DOTALL)
	l11lll1_ll_ = [l111lll_ll_ (u"ࠩࡇࡑࡈࡇࠧዙ"),l111lll_ll_ (u"ࠪห้ืฦ๋ีํอࠬዚ")]
	#l11ll11l1_ll_ = [l111lll_ll_ (u"ู๊ࠫไิๆสฮࠥ࠭ዛ"),l111lll_ll_ (u"ࠬอแๅษ่ࠤࠬዜ"),l111lll_ll_ (u"࠭ศาษ่ะࠬዝ"),l111lll_ll_ (u"ฺࠧำฺ๋ࠬዞ"),l111lll_ll_ (u"ࠨๅ็๎ออสࠨዟ"),l111lll_ll_ (u"ࠩส฾ฬ์้ࠨዠ")]
	for link,title in items:
		#if any(value in title for value in l11ll11l1_ll_):
		if not any(value in title for value in l11lll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪዡ"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨዢ")+l1l1l1l_ll_+title,link,301)
	return html
def l1l11l1_ll_(url,key=l111lll_ll_ (u"ࠬ࠭ዣ")):
	#l1ll1l_ll_(url,html)
	url = l1111_ll_(url)
	if l111lll_ll_ (u"࠭วๅฯ็ๆฮ࠭ዤ") in url:
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫዥ"),url,l111lll_ll_ (u"ࠨࠩዦ"),l111lll_ll_ (u"ࠩࠪዧ"),l111lll_ll_ (u"ࠪࠫየ"),l111lll_ll_ (u"ࠫࠬዩ"),l111lll_ll_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪዪ"))
		html = response.content
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓࡦࡴ࡬ࡩࡸࡖࡒࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡲࡦ࡮ࡤࡸࡪࡪࠢࠨያ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		links = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ዬ"),block,re.DOTALL)
		url = links[2]
		url = l1111_ll_(url)
		#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࠩይ"))
	if l111lll_ll_ (u"ࠩࡩ࡭ࡱࡺࡥࡳ࠰ࡳ࡬ࡵ࠭ዮ") in url:
		headers = {l111lll_ll_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩዯ"):l111lll_ll_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦ࠾ࠤࡨ࡮ࡡࡳࡵࡨࡸࡂ࡛ࡔࡇ࠯࠻ࠫደ")}
		data = {l111lll_ll_ (u"ࠬࡱࡥࡺࠩዱ"):key}
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫዲ"),url,data,headers,l111lll_ll_ (u"ࠧࠨዳ"),l111lll_ll_ (u"ࠨࠩዴ"),l111lll_ll_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧድ"))
		block = response.content
	else:
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧዶ"),url,l111lll_ll_ (u"ࠫࠬዷ"),l111lll_ll_ (u"ࠬ࠭ዸ"),l111lll_ll_ (u"࠭ࠧዹ"),l111lll_ll_ (u"ࠧࠨዺ"),l111lll_ll_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠶ࡶࡩ࠭ዻ"))
		html = response.content
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡸࡻ࡬ࡵࡵࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣࡨࡲࡳࡹ࡫ࡲ࠮࡯ࡨࡲࡺࠨࠧዼ"),html,re.DOTALL)
		if l1lll_ll_: block = l1lll_ll_[0]
		else:
			new_url = re.findall(l111lll_ll_ (u"ࠪࡀࡸࡶࡡ࡯ࡀ࡞ࡠࡷࡢ࡮࡞࠭࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫዽ"),html,re.DOTALL)
			l1l11l1_ll_(new_url[2])
			return
	items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩ࡬ࡢࡵࡶࡁࠧࡨࡡࡤ࡭ࡪࠦ࠳࠰࠿ࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡂࡰࡺࡖ࡭ࡳ࡭ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨዾ"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for link,img,title in items:
		title = unescapeHTML(title)
		if l111lll_ll_ (u"ࠬ࠵ࡳࡦ࡮ࡤࡶࡾ࠵ࠧዿ") in link: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ጀ"),l1l1l1l_ll_+title,link,301,img)
		elif l111lll_ll_ (u"ࠧ࠰ࡁࡶࡁࠬጁ") in url and l111lll_ll_ (u"ࠨษ็ั้่ษࠨጂ") in title:
			episode = re.findall(l111lll_ll_ (u"ࠩࠫ࠲࠯ࡅࠩࠡษ็ั้่ษࠡ࡞ࡧ࠯ࠬጃ"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠪࡣࡒࡕࡄࡠࠩጄ") + episode[0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫጅ"),l1l1l1l_ll_+title,link,301,img)
					l1ll11ll_ll_.append(title)
		else: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫጆ"),l1l1l1l_ll_+title,link,302,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨጇ"),block,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ገ"),block,re.DOTALL)
		for link,title in items:
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨጉ"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨጊ")+title,link,301)
	return
def l11_ll_(url):
	l1l111l_ll_ = []
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫጋ"))
	#response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨጌ"),url,l111lll_ll_ (u"ࠬ࠭ግ"),l111lll_ll_ (u"࠭ࠧጎ"),l111lll_ll_ (u"ࠧࠨጏ"),l111lll_ll_ (u"ࠨࠩጐ"),l111lll_ll_ (u"ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ጑"))
	#html = response.content
	#l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡶࡪࡪࡩࡳࡧࡦࡸࡂ࠮࠮ࠫࡁࠬࠦࠬጒ"),html,re.DOTALL)
	#if l1ll111_ll_: l1ll111_ll_ = base64.b64decode(l1ll111_ll_[0])
	#else:
	l1ll111_ll_ = url+l111lll_ll_ (u"ࠫࡼࡧࡴࡤࡪࠪጓ")
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩጔ"),l1ll111_ll_,l111lll_ll_ (u"࠭ࠧጕ"),l111lll_ll_ (u"ࠧࠨ጖"),l111lll_ll_ (u"ࠨࠩ጗"),l111lll_ll_ (u"ࠩࠪጘ"),l111lll_ll_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭ጙ"))
	l1l111l1_ll_ = response.content
	# watch links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡼࡧࡴࡤࡪࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡹࡱࡄࠧጚ"),l1l111l1_ll_,re.DOTALL)
	block = l1lll_ll_[0]
	l1l111ll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࠭ࡩࡥࠩ࠽ࠤ࠭࠴ࠪࡀࠫ࠯ࠦጛ"),block,re.DOTALL)[0]
	link = re.findall(l111lll_ll_ (u"࠭ࡵࡳ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬጜ"),block,re.DOTALL)[0]
	items = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡷࡥ࠲ࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩጝ"),block,re.DOTALL)
	for l1l11l1l_ll_,title in items:
		title = title.strip(l111lll_ll_ (u"ࠨࠢࠪጞ"))
		if title==l111lll_ll_ (u"ࠩࡆ࡭ࡲࡧࠠࡏࡱࡺࠫጟ"): title = l111lll_ll_ (u"ࠪࡇ࡮ࡳࡡࡏࡱࡺࠫጠ")
		#l1ll1l_ll_(title,l111lll_ll_ (u"ࠫࠬጡ"))
		l11ll1ll_ll_ = link+l111lll_ll_ (u"ࠬࡅࡰࡰࡵࡷ࡭ࡩࡃࠧጢ")+l1l111ll_ll_+l111lll_ll_ (u"࠭ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠪጣ")+l1l11l1l_ll_+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨጤ")+title+l111lll_ll_ (u"ࠨࡡࡢࡻࡦࡺࡣࡩࠩጥ")
		l1l111l_ll_.append(l11ll1ll_ll_)
	# download links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡺࡲ࠾࠯࠾࠲ࡨ࡮ࡼ࠾ࠨጦ"),l1l111l1_ll_,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩጧ"),block,re.DOTALL)
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭ጨ"))
		quality = re.findall(l111lll_ll_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ጩ"),title,re.DOTALL)
		if quality:
			quality = l111lll_ll_ (u"࠭࡟ࡠࡡࡢࠫጪ")+quality[0]
			title = l111lll_ll_ (u"ࠧࡤ࡫ࡰࡥࡳࡵࡷࠨጫ")
		else: quality = l111lll_ll_ (u"ࠨࠩጬ")
		l11ll1ll_ll_ = link+l111lll_ll_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪጭ")+title+l111lll_ll_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧጮ")+quality
		l1l111l_ll_.append(l11ll1ll_ll_)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩጯ"),l1l111l_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬጰ"),str(l1l111l_ll_))
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩጱ"),l111lll_ll_ (u"ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐็ࠡใํำ๏๎ࠧጲ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧጳ"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠩࠪጴ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠪࠫጵ"): return
	search = search.replace(l111lll_ll_ (u"ࠫࠥ࠭ጶ"),l111lll_ll_ (u"ࠬ࠱ࠧጷ"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"࠭࠯ࡀࡵࡀࠫጸ")+search
	l1l11l1_ll_(url)
	return