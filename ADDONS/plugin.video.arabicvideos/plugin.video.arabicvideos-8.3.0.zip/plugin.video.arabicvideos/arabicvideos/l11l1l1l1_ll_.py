# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠨࡄࡒࡏࡗࡇࠧᆖ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡆࡐࡘ࡟ࠨᆗ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==370: results = l11l1ll_ll_(url)
	elif mode==371: results = l1l11l1_ll_(url,text)
	elif mode==372: results = l11_ll_(url)
	elif mode==379: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫᆘ")):
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨᆙ"),l1ll1l1_ll_,l111lll_ll_ (u"ࠬ࠭ᆚ"),l111lll_ll_ (u"࠭ࠧᆛ"),l111lll_ll_ (u"ࠧࠨᆜ"),l111lll_ll_ (u"ࠨࠩᆝ"),l111lll_ll_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪᆞ"))
	if l1111l_ll_==l111lll_ll_ (u"ࠪࠫᆟ"): l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᆠ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬᆡ"),l111lll_ll_ (u"࠭ࠧᆢ"),379,l111lll_ll_ (u"ࠧࠨᆣ"),l111lll_ll_ (u"ࠨࠩᆤ"),l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭ᆥ"))
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᆦ"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨᆧ")+l1l1l1l_ll_+l111lll_ll_ (u"๋ࠬำๅี็หฯ࠭ᆨ"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡄࡣࡷ࠱࠹࠹࠭࠲ࠩᆩ"),371)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆪ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᆫ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩฦๅ้อๅࠨᆬ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡈࡧࡴ࠮࠶࠵࠱࠶࠭ᆭ"),371)
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬᆮ"): l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪᆯ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᆰ"),l111lll_ll_ (u"ࠧࠨᆱ"),9999)
	html = response.content
	l11lll1_ll_ = [l111lll_ll_ (u"ࠨษไ่ฬ๋ࠠๅๆๆฬฬืࠧᆲ"),l111lll_ll_ (u"ࠩห็ึอࠠࡕࡘࠪᆳ")]
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡶࡴࡽࠠࡤࡣࡷࠤ࡙ࡧࡧࡴࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡱࡺࠤࡨࡧࡴࠡࡼࡲࡲࡪ࠸࠲࠱ࠤࠪᆴ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᆵ"),block,re.DOTALL)
		for link,title in items:
			link = l1ll1l1_ll_+link
			if not any(value in title for value in l11lll1_ll_):
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᆶ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪᆷ")+l1l1l1l_ll_+title,link,371)
		if l1111l_ll_==l111lll_ll_ (u"ࠧࠨᆸ"): l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭ᆹ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᆺ"),l111lll_ll_ (u"ࠪࠫᆻ"),9999)
	global l11l11lll_ll_
	l11l11l1l_ll_ = l11l11lll_ll_[:]
	l11l11lll_ll_[:] = []
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡹࡣࡳ࡫ࡳࡸࠥࡺࡹࡱࡧࡀࠫᆼ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫᆽ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l111lll_ll_ (u"࠭ࠠࠨᆾ"))
			link = l1ll1l1_ll_+link
			if not any(value in title for value in l11lll1_ll_):
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᆿ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᇀ")+l1l1l1l_ll_+title,link,371)
		if l1111l_ll_==l111lll_ll_ (u"ࠩࠪᇁ"): l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨᇂ"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᇃ"),l111lll_ll_ (u"ࠬ࠭ᇄ"),9999)
	l11l1l11l_ll_ = l11l11lll_ll_[:]
	l11l1l111_ll_ = l11l1l11l_ll_[0:6]
	del l11l1l11l_ll_[0:6]
	l11l11ll1_ll_ = l11l11l1l_ll_[4:5]
	del l11l11l1l_ll_[4:5]
	l11l11lll_ll_[:] = l11l11l1l_ll_+l11l1l11l_ll_+l11l1l111_ll_+l11l11ll1_ll_
	return html
def l1l11l1_ll_(url,type=l111lll_ll_ (u"࠭ࠧᇅ")):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠧᇆ"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᇇ"),html)
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭ᇈ"),url,l111lll_ll_ (u"ࠪࠫᇉ"),l111lll_ll_ (u"ࠫࠬᇊ"),l111lll_ll_ (u"ࠬ࠭ᇋ"),l111lll_ll_ (u"࠭ࠧᇌ"),l111lll_ll_ (u"ࠧࡃࡑࡎࡖࡆ࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪᇍ"))
	html = response.content
	if l111lll_ll_ (u"ࠨࡸ࡬ࡨࡵࡧࡧࡦࡡࠪᇎ") in url:
		link = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠲ࡅࡱࡨࡵ࡮࠯࠱࠮ࡄ࠯ࠢࠨᇏ"),html,re.DOTALL)
		if link:
			link = l1ll1l1_ll_+link[0]
			l1l11l1_ll_(link)
			return
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࠤࡸࡻࡢࡤࡣࡷࡷࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡮ࡦ࠰࠷ࠬᇐ"),html,re.DOTALL)
	if type==l111lll_ll_ (u"ࠫࠬᇑ") and l1lll_ll_ and l1lll_ll_[0].count(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࠪᇒ"))>1:
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇓ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆฯ้๏฿ࠧᇔ"),url,371,l111lll_ll_ (u"ࠨࠩᇕ"),l111lll_ll_ (u"ࠩࠪᇖ"),l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࡵࠪᇗ"))
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᇘ"),block,re.DOTALL)
		for link,title in items:
			link = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࠧᇙ")+link
			title = title.strip(l111lll_ll_ (u"࠭ࠠࠨᇚ"))
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇛ"),l1l1l1l_ll_+title,link,371)
	else:
		l1ll11ll_ll_ = []
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡥࡲࡰ࠲ࡳࡤ࠮࠵ࠫ࠲࠯ࡅࠩࡤࡱ࡯࠱ࡽࡹ࠭࠲࠴ࠪᇜ"),html,re.DOTALL)
		if not l1lll_ll_: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡳࡱ࠳ࡳ࡮࠯࠻ࠦ࠭࠴ࠪࡀࠫࡦࡳࡱ࠳ࡸࡴ࠯࠴࠶ࠬᇝ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠴࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᇞ"),block,re.DOTALL)
			l111lll_ll_ (u"ࠦࠧࠨࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴ࠴ࠣࡁࠥࡡ࡝ࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡩ࡮ࡩ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࠋࡷࡶࡾࡀࠠࡤࡱࡸࡲࡹࠦ࠽ࠡ࡫ࡱࡸ࠭ࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪห้ำไใหࠣ࠯࠭ࡢࡤࠬࠫࠪ࠰ࡹ࡯ࡴ࡭ࡧ࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯࡛࠱࡟ࠬࠎࠎࠏࠉࠊࡧࡻࡧࡪࡶࡴ࠻ࠢࡦࡳࡺࡴࡴࠡ࠿ࠣ࠱࠶ࠐࠉࠊࠋࠌ࡭ࡹ࡫࡭ࡴ࠴࠱ࡥࡵࡶࡥ࡯ࡦࠫࠬࡱ࡯࡮࡬࠮࡬ࡱ࡬࠲ࡴࡪࡶ࡯ࡩ࠱ࡩ࡯ࡶࡰࡷ࠭࠮ࠐࠉࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡷࡴࡸࡴࡦࡦࠫ࡭ࡹ࡫࡭ࡴ࠴࠯ࠤࡷ࡫ࡶࡦࡴࡶࡩࡂࡌࡡ࡭ࡵࡨ࠰ࠥࡱࡥࡺ࠿࡯ࡥࡲࡨࡤࡢࠢ࡮ࡩࡾࡀࠠ࡬ࡧࡼ࡟࠸ࡣࠩࠋࠋࠌࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰ࠲ࡩ࡮ࡩ࠯ࡸ࡮ࡺ࡬ࡦ࠮ࡦࡳࡺࡴࡴࠡ࡫ࡱࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠏࠉࠣࠤࠥᇟ")
			for link,img,title in items:
				link = l1ll1l1_ll_+link
				title = title.strip(l111lll_ll_ (u"ࠬࠦࠧᇠ"))
				if l111lll_ll_ (u"࠭࠯ࡢ࡮ࡢࠫᇡ") in link:
					l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᇢ"),l1l1l1l_ll_+title,link,371,img)
				elif l111lll_ll_ (u"ࠨษ็ั้่ษࠨᇣ") in title and (l111lll_ll_ (u"ࠩ࠲ࡇࡦࡺ࠭ࠨᇤ") in url or l111lll_ll_ (u"ࠪ࠳ࡘ࡫ࡡࡳࡥ࡫࠳ࠬᇥ") in url):
					episode = re.findall(l111lll_ll_ (u"ࠫ࠭࠴ࠪࡀࠫࠣ࠱ࠥ࠱วๅฯ็ๆฮࠦࠫ࡝ࡦ࠮ࠫᇦ"),title,re.DOTALL)
					if episode: title = l111lll_ll_ (u"ࠬࡥࡍࡐࡆࡢุ้๊ำๅࠢࠪᇧ")+episode[0]
					if title not in l1ll11ll_ll_:
						l1ll11ll_ll_.append(title)
						l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᇨ"),l1l1l1l_ll_+title,link,371,img)
				else: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᇩ"),l1l1l1l_ll_+title,link,372,img)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᇪ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᇫ"),block,re.DOTALL)
			for link,title in items:
				link = l1ll1l1_ll_+link
				title = l111lll_ll_ (u"ูࠪๆำษࠡࠩᇬ")+unescapeHTML(title)
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᇭ"),l1l1l1l_ll_+title,link,371,l111lll_ll_ (u"ࠬ࠭ᇮ"),l111lll_ll_ (u"࠭ࠧᇯ"),l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪࡹࠧᇰ"))
	return
def l11_ll_(url):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬᇱ"),url,l111lll_ll_ (u"ࠩࠪᇲ"),l111lll_ll_ (u"ࠪࠫᇳ"),l111lll_ll_ (u"ࠫࠬᇴ"),l111lll_ll_ (u"ࠬ࠭ᇵ"),l111lll_ll_ (u"࠭ࡂࡐࡍࡕࡅ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧᇶ"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡭ࡣࡥࡩࡱ࠳ࡳࡶࡥࡦࡩࡸࡹࠠ࡮ࡴࡪ࠱ࡧࡺ࡭࠮࠷ࠣࠦࡃ࠮࠮ࠫࡁࠬࡀࠬᇷ"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	#l1ll111_ll_ = url.replace(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡵࡧࡧࡦࡡࠪᇸ"),l111lll_ll_ (u"ࠩࡓࡰࡦࡿ࠯ࠨᇹ"))
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡺࡦࡸࠠࡶࡴ࡯ࠤࡂࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧᇺ"),html,re.DOTALL)
	l1ll111_ll_ = l1ll1l1_ll_+l1ll111_ll_[0]
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨᇻ"),l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭ᇼ"),l111lll_ll_ (u"࠭ࠧᇽ"),l111lll_ll_ (u"ࠧࠨᇾ"),l111lll_ll_ (u"ࠨࠩᇿ"),l111lll_ll_ (u"ࠩࡅࡓࡐࡘࡁ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪሀ"))
	l1l111l1_ll_ = response.content
	l11ll1_ll_ = re.findall(l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨሁ"),l1l111l1_ll_,re.DOTALL)
	if l11ll1_ll_:
		l11ll1_ll_ = l11ll1_ll_[-1]
		if l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼ࠪሂ") not in l11ll1_ll_: l11ll1_ll_ = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫሃ")+l11ll1_ll_
		if l111lll_ll_ (u"࠭ࡥ࡮ࡤࡨࡨ࠳ࡳࡩ࡯࠰࡭ࡷࠬሄ") in l11ll1_ll_:
			ids = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡷࡥ࠲ࡶࡵࡣ࡮࡬ࡷ࡭࡫ࡲ࠮࡫ࡧࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡪࡡࡵࡣ࠰ࡺ࡮ࡪࡥࡰ࠯࡬ࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ህ"),l1l111l1_ll_,re.DOTALL)
			if ids:
				publisher_id, video_id = ids[0]
				l11ll1_ll_ = l1ll1l111_ll_(l11ll1_ll_)+l111lll_ll_ (u"ࠨ࠱ࡹ࠶࠴࠭ሆ")+publisher_id+l111lll_ll_ (u"ࠩ࠲ࡧࡴࡴࡦࡪࡩ࠲ࠫሇ")+video_id+l111lll_ll_ (u"ࠪ࠲࡯ࡹ࡯࡯ࠩለ")
		import l1_ll_
		l1_ll_.l11_ll_([l11ll1_ll_],l1ll_ll_,l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪሉ"))
	else: l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨሊ"),l111lll_ll_ (u"࠭ไๅลึๅ๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣ฾๏ืࠠๆ๊ฯ์ิࠦแ๋ࠢส่๊๎โฺࠢส่ศ฻ไ๋ࠩላ"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠧࠨሌ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠨࠩል"): return
	search = search.replace(l111lll_ll_ (u"ࠩࠣࠫሎ"),l111lll_ll_ (u"ࠪ࠯ࠬሏ"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴࡙ࡥࡢࡴࡦ࡬࠴࠭ሐ")+search
	l1l11l1_ll_(url)
	return