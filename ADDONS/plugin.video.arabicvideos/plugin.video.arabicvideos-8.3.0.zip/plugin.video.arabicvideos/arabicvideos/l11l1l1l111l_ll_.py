# coding: UTF-8
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
def l11l1l1lll1l_ll_():
	headers = {l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䐘"):l111lll_ll_ (u"ࠪࡑࡴࢀࡩ࡭࡮ࡤ࠳࠺࠴࠰࡚ࠡࠪ࡭ࡳࡪ࡯ࡸࡵࠣࡒ࡙ࠦ࠱࠱࠰࠳࠿ࠥ࠯ࠠࡂࡲࡳࡰࡪ࡝ࡥࡣࡍ࡬ࡸ࠴࠻࠳࠸࠰࠶࠺ࠥ࠮ࡋࡉࡖࡐࡐ࠱ࠦ࡬ࡪ࡭ࡨࠤࡌ࡫ࡣ࡬ࡱࠬࠤࡈ࡮ࡲࡰ࡯ࡨ࠳࠽࠹࠮࠱࠰࠷࠴࠽࠼࠮࠱ࠢࡖࡥ࡫ࡧࡲࡪ࠱࠸࠷࠼࠴࠳࠷ࠩ䐙")}
	url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰ฮหࠧࡵࡳࡁࡊ࡭ࡊࡂࡃࡔࡁࡂ࠭䐚")
	import requests
	response = requests.request(l111lll_ll_ (u"ࠬࡍࡅࡕࠩ䐛"),url=url,headers=headers)
	html = response.content
	a = re.findall(l111lll_ll_ (u"࠭ࡷࡪࡰࡧࡳࡼࡢ࡛ࠣࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠣ࡞ࡠࠤࡂࠦࠨࡼ࠰࠭ࡃࢂ࠯࠻ࠨ䐜"),html,re.DOTALL)
	b = a[0].replace(l111lll_ll_ (u"ࠧࡵࡴࡸࡩࠬ䐝"),l111lll_ll_ (u"ࠨࡖࡵࡹࡪ࠭䐞")).replace(l111lll_ll_ (u"ࠩࡩࡥࡱࡹࡥࠨ䐟"),l111lll_ll_ (u"ࠪࡊࡦࡲࡳࡦࠩ䐠"))
	c = eval(b)
	d = c[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䐡")]
	e = d[l111lll_ll_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡔࡧࡤࡶࡨ࡮ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䐢")][l111lll_ll_ (u"࠭ࡰࡳ࡫ࡰࡥࡷࡿࡃࡰࡰࡷࡩࡳࡺࡳࠨ䐣")][l111lll_ll_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䐤")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ䐥")][0][l111lll_ll_ (u"ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䐦")]
	token = e[l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠪ䐧")][0][l111lll_ll_ (u"ࠫࡳ࡫ࡸࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡄࡢࡶࡤࠫ䐨")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ䐩")].replace(l111lll_ll_ (u"࠭࠽ࠨ䐪"),l111lll_ll_ (u"ࠧࠦ࠴࠸࠷ࡉ࠭䐫"))
	l1ll111_ll_ = url+l111lll_ll_ (u"ࠨࠨࡳࡦ࡯ࡃ࠱ࠧࡥࡷࡳࡰ࡫࡮࠾ࠩ䐬")+token
	l1ll11l1l_ll_ = headers.copy()
	l1ll11l1l_ll_.update({l111lll_ll_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲ࡔࡡ࡮ࡧࠪ䐭"):l111lll_ll_ (u"ࠪ࠵ࠬ䐮"),l111lll_ll_ (u"ࠫ࡝࠳࡙ࡰࡷࡗࡹࡧ࡫࠭ࡄ࡮࡬ࡩࡳࡺ࠭ࡗࡧࡵࡷ࡮ࡵ࡮ࠨ䐯"):l111lll_ll_ (u"ࠬ࠸࠮࠳࠲࠵࠴࠵࠼࠱࠹࠰࠳࠵࠳࠶࠱ࠨ䐰")})
	response = requests.request(l111lll_ll_ (u"࠭ࡇࡆࡖࠪ䐱"),url=l1ll111_ll_,headers=l1ll11l1l_ll_)
	l1l111l1_ll_ = response.content
	#with open(l111lll_ll_ (u"ࠧࡔ࠼࡟ࡠࡾࡵࡵࡵࡷࡥࡩࡤࡴࡥࡸࡡࡓࡅࡌࡋ࡟ࡓࡇࡖ࡙ࡑ࡚ࡓ࠯ࡶࡻࡸࠬ䐲"), l111lll_ll_ (u"ࠨࡹࠪ䐳")) as f: f.write(l1l111l1_ll_)
	l1l11l1_ll_(l1ll111_ll_)
	return
def l11l1l1l11l1_ll_(url):
	html,c = l11l1ll1lll1_ll_(url)
	if l111lll_ll_ (u"ࠩࡦࡸࡴࡱࡥ࡯࠿ࠪ䐴") not in url:
		if l111lll_ll_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࡜ࡩࡥࡧࡲࡷࠧ࠭䐵") in html: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䐶"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็๊ะ์๋๋ฬะࠧ䐷"),url+l111lll_ll_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䐸"),146)
		if l111lll_ll_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭䐹") in html: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䐺"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩๅ์ฬฬๅࠨ䐻"),url+l111lll_ll_ (u"ࠪ࠳ࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ䐼"),146)
		if l111lll_ll_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ䐽") in html: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䐾"),l1l1l1l_ll_+l111lll_ll_ (u"࠭โ็๊สฮࠬ䐿"),url+l111lll_ll_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䑀"),146)
		d = c[l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ䑁")][l111lll_ll_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲࡇࡸ࡯ࡸࡵࡨࡖࡪࡹࡵ࡭ࡶࡶࡖࡪࡴࡤࡦࡴࡨࡶࠬ䑂")][l111lll_ll_ (u"ࠪࡸࡦࡨࡳࠨ䑃")][0][l111lll_ll_ (u"ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩ䑄")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭䑅")][l111lll_ll_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࡌࡪࡵࡷࡖࡪࡴࡤࡦࡴࡨࡶࠬ䑆")]
	else: d = c[1][l111lll_ll_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ䑇")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ䑈")][l111lll_ll_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ䑉")]
	e = d[l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䑊")]
	for i in range(len(e)):
		try:
			item = e[i][l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䑋")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ䑌")][0]
			l11l1l11ll11_ll_(item)
		except: pass
	if l111lll_ll_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡸ࠭䑍") in d.keys():
		token = d[l111lll_ll_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡹࠧ䑎")][0][l111lll_ll_ (u"ࠨࡰࡨࡼࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡈࡦࡺࡡࠨ䑏")][l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䑐")]
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ䑑")+token
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䑒"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣหำื้ࠨ䑓"),l1ll111_ll_,146)
	return
def l11l1l1ll11l_ll_():
	l11lll1l1l1_ll_ = l111lll_ll_ (u"࠭็ัษࠣห้๋่ใ฻ࠣ๎ุะฮะ็ࠣห฻อแสࠢํ์ฯ๐่ษ๋่ࠢฬฺ๊ࠦ็็ࠤอี่็้ࠪ䑔")
	l11lll1ll1l_ll_ = l111lll_ll_ (u"ࠧๅ฻ิฺࠥ็๊ะ๊๊หฯ๊้ࠦฬํ์อࠦสฮฬสะࠥอๆࠡฬอว่ีࠠศ่ࠣฮ฻ฮุ๊ษอࠤํอูะษาฮࠥ๐่ห๊ํฬࠥ฻อ๋ฯฬࠫ䑕")
	#l1ll1l_ll_(l11lll1l1l1_ll_,l11lll1ll1l_ll_)
	xbmc.executebuiltin(l111lll_ll_ (u"ࠨࡃࡧࡨࡴࡴ࠮ࡐࡲࡨࡲࡘ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠮ࡰ࡭ࡷࡪ࡭ࡳ࠴ࡶࡪࡦࡨࡳ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠯ࠧ䑖"), True)
	return
def l11l1l1l1lll_ll_(url,html):
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.youtube.l1lll1l11_ll_/playlist?list=l11l1l11lll1_ll_
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.youtube.l1lll1l11_ll_/watch?v=l11l1l1l1l11_ll_&list=l11l1l11lll1_ll_&index=18
	if l111lll_ll_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ䑗") in url:
		l11l1l1ll1l1_ll_(url)
		return
	l1lll_ll_ = []
	if l111lll_ll_ (u"ࠪࡦࡷࡵࡷࡴࡧࡢࡥ࡯ࡧࡸࠨ䑘") in url:
		#html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬ䑙"),headers,l111lll_ll_ (u"ࠬ࠭䑚"),l111lll_ll_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠭ࡑࡎࡄ࡝ࡑࡏࡓࡕࡡࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ䑛"))
		html = l11l1l11llll_ll_(html)
		l1lll_ll_ = [html]
	elif l111lll_ll_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭䑜") in url and l111lll_ll_ (u"ࠨ࡫ࡱࡨࡪࡾ࠽ࠨ䑝") not in url:
		id = url.split(l111lll_ll_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ䑞"))[1].split(l111lll_ll_ (u"ࠪࠪࠬ䑟"))[0]
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺ࠿࡭࡫ࡶࡸࡂ࠭䑠")+id
		html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭䑡"),headers,l111lll_ll_ (u"࠭ࠧ䑢"),l111lll_ll_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡒࡏࡅ࡞ࡒࡉࡔࡖࡢࡍ࡙ࡋࡍࡔ࠯࠵ࡲࡩ࠭䑣"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲ࡯࠱ࡻ࡯ࡤࡦࡱ࠰ࡸࡦࡨ࡬ࡦࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ䑤"),html,re.DOTALL)
	#l1ll1l_ll_(l1ll111_ll_,id)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩࡧࡥࡹࡧ࠭ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶ࡫ࡹࡲࡨ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡺ࡮ࡪࡥࡰ࠯ࡷ࡭ࡲ࡫ࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡺࡤ࠿࠾࠲ࡸࡷࡄࠧ䑥"),block,re.DOTALL)
		for title,link,img,duration in items:
			if l111lll_ll_ (u"ࠪࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭䑦") in duration: duration = re.findall(l111lll_ll_ (u"ࠫࡹ࡯࡭ࡦࡵࡷࡥࡲࡶ࠮ࠫࡁࡁࡀ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䑧"),duration,re.DOTALL)[0]
			else: duration=l111lll_ll_ (u"ࠬ࠭䑨")
			if l111lll_ll_ (u"࠭࠮ࠨ䑩") in duration: duration = duration.replace(l111lll_ll_ (u"ࠧ࠯ࠩ䑪"),l111lll_ll_ (u"ࠨ࠼ࠪ䑫"))
			title = title.replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬ䑬"),l111lll_ll_ (u"ࠪࠫ䑭"))
			title = unescapeHTML(title)
			link = l1ll1l1_ll_+link
			l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䑮"),l1l1l1l_ll_+title,link,143,img,duration)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡯ࡴࡦ࡯ࡶ࠱ࡱࡵࡡࡥ࠯ࡰࡳࡷ࡫࠭ࡣࡷࡷࡸࡴࡴࠨ࠯ࠬࡂ࠭ࡱࡵࡡࡥ࠯ࡰࡳࡷ࡫࠭࡭ࡱࡤࡨ࡮ࡴࡧࠨ䑯"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䑰"),block,re.DOTALL)
			for link in items:
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䑱"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦวฯำ์ࠫ䑲"),l1ll1l1_ll_+link,142)
	return
def l11l1l1ll1l1_ll_(url):
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.youtube.l1lll1l11_ll_/watch?v=l11l1l1l1l11_ll_&list=l11l1l11lll1_ll_&index=18
	html,c = l11l1ll1lll1_ll_(url)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࠱ࡻ࡯ࡤࡦࡱࡶ࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠨ࠯ࠬࡂ࠭ࡼࡧࡴࡤࡪ࠺࠱ࡨࡵ࡮ࡵࡣ࡬ࡲࡪࡸࠧ䑳"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l1111ll1_ll_ = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡸ࡬ࡨࡪࡵ࠭ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ䑴"),block,re.DOTALL)
	l1llll111_ll_ = re.findall(l111lll_ll_ (u"ࠫࡩࡧࡴࡢ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠲ࡻࡲ࡭࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䑵"),block,re.DOTALL)
	i = 0
	for title,link in l1111ll1_ll_:
		title = title.replace(l111lll_ll_ (u"ࠬࡢ࡮ࠨ䑶"),l111lll_ll_ (u"࠭ࠧ䑷"))
		title = unescapeHTML(title)
		img = l1llll111_ll_[i]
		link = l1ll1l1_ll_+link
		l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䑸"),l1l1l1l_ll_+title,link,143,img)
		i = i+1
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䑹"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠศะิํࠬ䑺"),link,142)
	return
def l11l1ll11l1l_ll_(url,html):
	#l1ll1l_ll_(url,str(c))
	if l111lll_ll_ (u"ࠪࡦࡷࡵࡷࡴࡧࡢࡥ࡯ࡧࡸࠨ䑻") in url:
		html = l11l1l11llll_ll_(html)
		l1lll_ll_ = [html]
	else: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡧࡸࡡ࡯ࡦࡨࡨ࠲ࡶࡡࡨࡧ࠰ࡺ࠷࠳ࡳࡶࡤࡱࡥࡻ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠪ࠱࠮ࡄ࠯ࡦࡰࡱࡷࡩࡷ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ䑼"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠬࡿࡴ࠮࡮ࡲࡧࡰࡻࡰ࠮ࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࡶࡩࡸࡹࡩࡰࡰ࡯࡭ࡳࡱ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠪ࠱࠮ࡄ࠯ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳࠩ䑽"),block,re.DOTALL)
		for link,img,count,title,live in items:
			if l111lll_ll_ (u"࠭࠾ࡍ࡫ࡹࡩࠥࡴ࡯ࡸ࠾ࠪ䑾") in live: live = l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ䑿")
			else: live = l111lll_ll_ (u"ࠨࠩ䒀")
			if l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡶ࡬ࡱࡪ࠭䒁") in count: duration = re.findall(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡷ࡭ࡲ࡫࠮ࠫࡁࡁࡀ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䒂"),count,re.DOTALL)[0]
			else: duration=l111lll_ll_ (u"ࠫࠬ䒃")
			if l111lll_ll_ (u"ࠬ࠴ࠧ䒄") in duration: duration = duration.replace(l111lll_ll_ (u"࠭࠮ࠨ䒅"),l111lll_ll_ (u"ࠧ࠻ࠩ䒆"))
			if l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡤࡱࡸࡲࡹ࠳࡬ࡢࡤࡨࡰࠬ䒇") in count: count = l111lll_ll_ (u"ࠩࠣࠫ䒈")+re.findall(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡦࡳࡺࡴࡴ࠮࡮ࡤࡦࡪࡲ࠮ࠫࡁࠫࡠࡩ࠱ࠩ࠯ࠬࡂࡀ࠴࠭䒉"),count,re.DOTALL)[0]
			else: count=l111lll_ll_ (u"ࠫࠬ䒊")
			title = title.replace(l111lll_ll_ (u"ࠬࡢ࡮ࠨ䒋"),l111lll_ll_ (u"࠭ࠧ䒌"))
			link = l1ll1l1_ll_+link
			title = unescapeHTML(title)
			if l111lll_ll_ (u"ࠧ࡭࡫ࡶࡸࡂ࠭䒍") in link: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䒎"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࡏࡍࡘ࡚ࠧ䒏")+count+l111lll_ll_ (u"ࠪ࠾ࠥࠦࠧ䒐")+title,link,142,img)
			elif l111lll_ll_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱ࠵ࠧ䒑") in link: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒒"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ࡃࡉࡐࡏ࠾ࠥࠦࠧ䒓")+title,link,146,img)
			elif live!=l111lll_ll_ (u"ࠧࠨ䒔"): l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭䒕"),l1l1l1l_ll_+live+title,link,143,img)
			else: l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䒖"),l1l1l1l_ll_+title,link,143,img,duration)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡴ࠯࡯ࡳࡦࡪ࠭࡮ࡱࡵࡩ࠲ࡨࡵࡵࡶࡲࡲ࠭࠴ࠪࡀࠫ࡯ࡳࡦࡪ࠭࡮ࡱࡵࡩ࠲ࡲ࡯ࡢࡦ࡬ࡲ࡬࠭䒗"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䒘"),block,re.DOTALL)
			for link in items:
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䒙"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ีโฯฬࠤฬิั๊ࠩ䒚"),l1ll1l1_ll_+link,146)
	return
def l11l1l1l1ll1_ll_(url,html):
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࠩࡻࡷ࠱ࡱࡵࡣ࡬ࡷࡳ࠱ࡹ࡯࡬ࡦ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠨ䒛"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨࡻࡷ࠱ࡱࡵࡣ࡬ࡷࡳ࠱ࡹ࡯࡬ࡦ࠰࠭ࡃ࠭ࡹࡲࡤࡾࡷ࡬ࡺࡳࡢࠪ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠭䒜"),block,re.DOTALL)
	#l1ll1l_ll_(str(block.count(l111lll_ll_ (u"ࠩࡼࡸ࠲ࡲ࡯ࡤ࡭ࡸࡴ࠲ࡺࡩ࡭ࡧࠪ䒝"))),str(len(items)))
	#with open(l111lll_ll_ (u"ࠪࡗ࠿ࡢࡥ࡮ࡣࡧ࠷࠳࡮ࡴ࡮࡮ࠪ䒞"), l111lll_ll_ (u"ࠫࡼ࠭䒟")) as f: f.write(block)
	for dummy,img,count,link,title,l11l1l1lll11_ll_,l11l1ll1llll_ll_ in items:
		if l111lll_ll_ (u"ࠬ࡝ࡡࡵࡥ࡫ࠤࡱࡧࡴࡦࡴࠪ䒠") in title: continue
		if l111lll_ll_ (u"࠭ࡡࡥࡷࡵࡰࡂ࠭䒡") in link:
			#title = l111lll_ll_ (u"ࠧࡂࡆ࠽ࠤࠥ࠭䒢")+title
			#link = re.findall(l111lll_ll_ (u"ࠨࡣࡧࡹࡷࡲ࠽ࠩ࠰࠭ࡃ࠮ࠬࡡ࡮ࡲ࠾ࠫ䒣"),link+l111lll_ll_ (u"ࠩࠩࡥࡲࡶ࠻ࠨ䒤"),re.DOTALL)
			#link = l1111_ll_(link[0])
			continue
		l1l1l1ll1_ll_ = re.findall(l111lll_ll_ (u"ࠪࡸ࡭ࡻ࡭ࡣ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ䒥"),count,re.DOTALL)
		if l1l1l1ll1_ll_: img = l1l1l1ll1_ll_[0]
		count = l111lll_ll_ (u"ࠫࠬ䒦")
		if l111lll_ll_ (u"ࠬࡢ࡮ࠨ䒧") in l11l1ll1llll_ll_: title = l111lll_ll_ (u"࠭ࠤࠥ࠼ࠣࠤࠬ䒨")+title
		if l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠳ࡴࡪ࡯ࡨࠫ䒩") in count: duration = re.findall(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵ࠭ࡵ࡫ࡰࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䒪"),count,re.DOTALL)[0]
		else: duration = l111lll_ll_ (u"ࠩࠪ䒫")
		if l111lll_ll_ (u"ࠪ࠲ࠬ䒬") in duration: duration = duration.replace(l111lll_ll_ (u"ࠫ࠳࠭䒭"),l111lll_ll_ (u"ࠬࡀࠧ䒮"))
		if l111lll_ll_ (u"࠭࠾ࡍ࡫ࡹࡩࠥࡴ࡯ࡸ࠾ࠪ䒯") in l11l1l1lll11_ll_: live = l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉ࠿ࠦࠠࠨ䒰")
		else: live = l111lll_ll_ (u"ࠨࠩ䒱")
		if l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯࠮ࡥࡲࡹࡳࡺ࠭࡭ࡣࡥࡩࡱ࠭䒲") in count:
			count = re.findall(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡦࡳࡺࡴࡴ࠮࡮ࡤࡦࡪࡲ࠮ࠫࡁࠫࡠࡩ࠱ࠩ࠯ࠬࡂࡀ࠴࠭䒳"),count,re.DOTALL)
			if count: count = l111lll_ll_ (u"ࠫࠥ࠭䒴") + count[0]
		else:
			l11l1l1lll11_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂ࡬ࡪࡀࠫࡠࡩ࠱ࠩࠡࡸ࡬ࡨࡪࡵࠧ䒵"),l11l1l1lll11_ll_,re.DOTALL)
			if l11l1l1lll11_ll_: count = l111lll_ll_ (u"࠭ࠠࠨ䒶") + l11l1l1lll11_ll_[0]
		if l111lll_ll_ (u"ࠧࡩࡶࡷࡴࠬ䒷") not in img: img = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺ࠨ䒸")+img
		if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࠧ䒹") not in link: link = l1ll1l1_ll_+link
		title = title.replace(l111lll_ll_ (u"ࠪࡠࡳ࠭䒺"),l111lll_ll_ (u"ࠫࠬ䒻"))
		title = unescapeHTML(title)
		if l111lll_ll_ (u"ࠬࡲࡩࡴࡶࡀࠫ䒼") in link: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䒽"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧࡍࡋࡖࡘࠬ䒾")+count+l111lll_ll_ (u"ࠨ࠼ࠣࠤࠬ䒿")+title,link,142,img)
		elif l111lll_ll_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯࠳ࠬ䓀") in link: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓁"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫࡈࡎࡎࡍࠩ䓂")+count+l111lll_ll_ (u"ࠬࡀࠠࠡࠩ䓃")+title,link,146,img)
		elif l111lll_ll_ (u"࠭࠯ࡶࡵࡨࡶ࠴࠭䓄") in link: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䓅"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡗࡖࡉࡗ࠭䓆")+count+l111lll_ll_ (u"ࠩ࠽ࠤࠥ࠭䓇")+title,link,146,img)
		elif live!=l111lll_ll_ (u"ࠪࠫ䓈"): l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ䓉"),l1l1l1l_ll_+live+title,link,143,img)
		else: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ䓊"),l1l1l1l_ll_+title,link,143,img,duration)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࡶ࠭࠴ࠪࡀࠫࡩࡳࡴࡺࡥࡳ࠯ࡦࡳࡳࡺࡡࡪࡰࡨࡶࠬ䓋"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		#with open(l111lll_ll_ (u"ࠧࡔ࠼࡟ࡠ࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ䓌"), l111lll_ll_ (u"ࠨࡹࠪ䓍")) as f: f.write(block)
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡺࡺࡴࡰࡰ࠰ࡧࡴࡴࡴࡦࡰࡷࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ䓎"),block,re.DOTALL)
		for link,title in items:
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䓏"),l1l1l1l_ll_+l111lll_ll_ (u"ฺࠫ็อสࠢࠪ䓐")+title,l1ll1l1_ll_+link,141)
	return
def l11l1l11llll_ll_(text):
	text = text.replace(l111lll_ll_ (u"ࠬࡢ࡜ࡶ࠲࠳࠷ࡨ࠭䓑"),l111lll_ll_ (u"࠭࠼ࠨ䓒"))
	text = text.replace(l111lll_ll_ (u"ࠧ࡝࡞ࡸ࠴࠵࠹ࡥࠨ䓓"),l111lll_ll_ (u"ࠨࡀࠪ䓔"))
	text = text.replace(l111lll_ll_ (u"ࠩ࡟ࡠࡺ࠶࠰࠳࠸ࠪ䓕"),l111lll_ll_ (u"ࠪࠪࠬ䓖"))
	text = text.replace(l111lll_ll_ (u"ࠫࡡࡢࠢࠨ䓗"),l111lll_ll_ (u"ࠬࠨࠧ䓘"))
	text = text.replace(l111lll_ll_ (u"࠭࡜࡝࠱ࠪ䓙"),l111lll_ll_ (u"ࠧ࠰ࠩ䓚"))
	text = text.replace(l111lll_ll_ (u"ࠨ࡞࡟ࡲࠬ䓛"),l111lll_ll_ (u"ࠩ࡟ࡲࠬ䓜"))
	#text = text.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ䓝"))
	#text = text.decode(l111lll_ll_ (u"ࠫࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ䓞"))
	#text = l1l1l11ll_ll_(text)
	#file = open(l111lll_ll_ (u"ࠬࡹ࠺࡝ࡧࡰࡥࡩ࠴ࡴࡹࡶࠪ䓟"), l111lll_ll_ (u"࠭ࡷࠨ䓠"))
	#file.write(text)
	#file.close()
	return text
def l11l1lllll1l_ll_(url,l11l1l1l1111_ll_):
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.youtube.l1lll1l11_ll_/watch?v=l11l1l1l1l1l_ll_&list=l11l1l1ll111_ll_
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.youtube.l1lll1l11_ll_/playlist?list=l11l1l1ll111_ll_
	html,c = l11l1ll1lll1_ll_(url,l11l1l1l1111_ll_)
	if c==l111lll_ll_ (u"ࠧࠨ䓡"): l11l1l1l1lll_ll_(url,html) ; return
	token = l111lll_ll_ (u"ࠨࠩ䓢")
	if l111lll_ll_ (u"ࠩ࠲ࡻࡦࡺࡣࡩࡁࡹࡁࠬ䓣") in url:
		l11l1ll1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠪࡰ࡮ࡹࡴ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨ䓤"),url+l111lll_ll_ (u"ࠫࠫ࠭䓥"),re.DOTALL)
		url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡀ࡮࡬ࡷࡹࡃࠧ䓦")+l11l1ll1ll1l_ll_[0]
		html,c = l11l1ll1lll1_ll_(url)
	if l111lll_ll_ (u"࠭ࡣࡵࡱ࡮ࡩࡳ࠭䓧") in url:
		f = c[1][l111lll_ll_ (u"ࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩ䓨")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ䓩")][l111lll_ll_ (u"ࠩࡳࡰࡦࡿ࡬ࡪࡵࡷ࡚࡮ࡪࡥࡰࡎ࡬ࡷࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ䓪")]
		if l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࡵࠪ䓫") in f.keys(): token = f[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡶࠫ䓬")][0][l111lll_ll_ (u"ࠬࡴࡥࡹࡶࡆࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡅࡣࡷࡥࠬ䓭")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠬ䓮")]
	else:
		d = c[l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩ䓯")]
		if l111lll_ll_ (u"ࠨ࠱ࡺࡥࡹࡩࡨࡀࡸࡀࠫ䓰") in url: f = d[l111lll_ll_ (u"ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ䓱")][l111lll_ll_ (u"ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬ䓲")][l111lll_ll_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࠭䓳")]
		else:
			e = d[l111lll_ll_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䓴")][l111lll_ll_ (u"࠭ࡴࡢࡤࡶࠫ䓵")][0]
			f = e[l111lll_ll_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ䓶")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ䓷")][l111lll_ll_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䓸")][l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䓹")][0][l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䓺")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ䓻")][0][l111lll_ll_ (u"࠭ࡰ࡭ࡣࡼࡰ࡮ࡹࡴࡗ࡫ࡧࡩࡴࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䓼")]
			if l111lll_ll_ (u"ࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡹࠧ䓽") in f.keys(): token = f[l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠨ䓾")][0][l111lll_ll_ (u"ࠩࡱࡩࡽࡺࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡉࡧࡴࡢࠩ䓿")][l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠩ䔀")]
	g = f[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䔁")]
	for i in range(len(g)):
		item = g[i]
		l11l1ll1ll11_ll_(item)
		#if item.keys()[0]==l111lll_ll_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ䔂"): continue
		#succeeded,title,link,img,count,duration,live,l11l1ll1llll_ll_ = l11ll111l1ll_ll_(item)
		#if not succeeded: continue
		#l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ䔃"),l1l1l1l_ll_+title,link,143,img,duration)
	if l111lll_ll_ (u"ࠧࠣࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡳࠣࠩ䔄") in html:
		continuation = settings.getSetting(l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䔅"))
		l11ll1111l1l_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱࡚ࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ䔆"))
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ䔇")+continuation
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䔈"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣหำื้ࠡ࠵࠶࠷࠸࠭䔉"),l1ll111_ll_,142,l111lll_ll_ (u"࠭ࠧ䔊"),l111lll_ll_ (u"ࠧࠨ䔋"),l11ll1111l1l_ll_)
	l111lll_ll_ (u"ࠣࠤࠥࠎࠎࠏࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦู࠭ࠪๆำษࠡษัี๎ࠦ࠹࠺࠻࠼ࠫ࠱ࡻࡲ࡭࠴࠯࠵࠹࠸ࠬࠨࠩ࠯࡭ࡳࡪࡥࡹ࠮࡙ࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࠤࡷࡳࡰ࡫࡮ࠣࠩࠣ࡭ࡳࠦࡨࡵ࡯࡯࠾ࠏࠏࠉ࡬ࡧࡼࠤࡂࠦࡳࡦࡶࡷ࡭ࡳ࡭ࡳ࠯ࡩࡨࡸࡘ࡫ࡴࡵ࡫ࡱ࡫࠭࠭ࡹࡰࡷࡷࡹࡧ࡫࠮࡬ࡧࡼࠫ࠮ࠐࠉࠊࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠧࠪࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ࠱࡫ࡦࡻࠍࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥุࠬࠩๅาฯࠠศะิํࠥ࠺࠴࠵࠶ࠪ࠰ࡺࡸ࡬࠳࠮࠴࠸࠹࠲ࠧࠨ࠮࡬ࡲࡩ࡫ࡸ࠭ࡸ࡬ࡷ࡮ࡺ࡯ࡳࡆࡤࡸࡦ࠯ࠊࠊࠤࠥࠦ䔌")
	return
def l11l1l11ll1l_ll_(url,page,text):
	if l111lll_ll_ (u"ࠩ࠲ࡪࡪ࡫ࡤ࠰ࡶࡵࡩࡳࡪࡩ࡯ࡩࠪ䔍") in url: l11l1lllll11_ll_(url)
	elif l111lll_ll_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡪࡹ࡮ࡪࡥࡠࡤࡸ࡭ࡱࡪࡥࡳࠩ䔎") in url: l11l1l1ll1ll_ll_(url,page,text)
	else: l11l1l1ll1ll_ll_(url,page,text)
	return
def l1l11l1_ll_(url,index=l111lll_ll_ (u"ࠫࠬ䔏"),l11l1l1l1111_ll_=l111lll_ll_ (u"ࠬ࠭䔐")):
	html,c = l11l1ll1lll1_ll_(url,l11l1l1l1111_ll_)
	#if c==l111lll_ll_ (u"࠭ࠧ䔑"): l11l1l1l1ll1_ll_(url,html) ; return
	if index==l111lll_ll_ (u"ࠧࠨ䔒"): index = l111lll_ll_ (u"ࠨ࠲ࠪ䔓")
	#l1ll1l_ll_(url,index)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䔔"),url)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䔕"),html)
	#token = l111lll_ll_ (u"ࠫࠬ䔖")
	if l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ䔗") in url:
		d = c[l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ䔘")][l111lll_ll_ (u"ࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡖࡩࡦࡸࡣࡩࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䔙")][l111lll_ll_ (u"ࠨࡲࡵ࡭ࡲࡧࡲࡺࡅࡲࡲࡹ࡫࡮ࡵࡵࠪ䔚")][l111lll_ll_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䔛")][l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䔜")]
		for i in range(len(d)):
			try: e = d[i][l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䔝")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ䔞")] ; break
			except: pass
	elif l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ䔟") in url:
		e = c[l111lll_ll_ (u"ࠧࡰࡰࡕࡩࡸࡶ࡯࡯ࡵࡨࡖࡪࡩࡥࡪࡸࡨࡨࡈࡵ࡭࡮ࡣࡱࡨࡸ࠭䔠")][0][l111lll_ll_ (u"ࠨࡣࡳࡴࡪࡴࡤࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࡅࡨࡺࡩࡰࡰࠪ䔡")][l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡊࡶࡨࡱࡸ࠭䔢")][0][l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䔣")][l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䔤")]
	elif l111lll_ll_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪࡅ࡫ࡦࡻࡀࠫ䔥") in url:
		e = c[l111lll_ll_ (u"࠭࡯࡯ࡔࡨࡷࡵࡵ࡮ࡴࡧࡕࡩࡨ࡫ࡩࡷࡧࡧࡅࡨࡺࡩࡰࡰࡶࠫ䔦")][0][l111lll_ll_ (u"ࠧࡢࡲࡳࡩࡳࡪࡃࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࡎࡺࡥ࡮ࡵࡄࡧࡹ࡯࡯࡯ࠩ䔧")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࠬ䔨")]
	elif l111lll_ll_ (u"ࠩ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ䔩") in url:
		d = c[l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䔪")][l111lll_ll_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䔫")][l111lll_ll_ (u"ࠬࡺࡡࡣࡵࠪ䔬")][0][l111lll_ll_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ䔭")][l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ䔮")][l111lll_ll_ (u"ࠨࡵࡨࡧࡹ࡯࡯࡯ࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䔯")][l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䔰")][int(index)][l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䔱")]
		e = d[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䔲")][0][l111lll_ll_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ䔳")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䔴")][l111lll_ll_ (u"ࠧࡦࡺࡳࡥࡳࡪࡥࡥࡕ࡫ࡩࡱ࡬ࡃࡰࡰࡷࡩࡳࡺࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩ䔵")][l111lll_ll_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ䔶")]
	elif l111lll_ll_ (u"ࠩࠥࡸࡪࡾࡴࠣ࠼ࠥࡖࡪࡩ࡯࡮࡯ࡨࡲࡩ࡫ࡤࠣࠩ䔷") in html:
		e = c[l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䔸")][l111lll_ll_ (u"ࠫࡹࡽ࡯ࡄࡱ࡯ࡹࡲࡴࡂࡳࡱࡺࡷࡪࡘࡥࡴࡷ࡯ࡸࡸࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䔹")][l111lll_ll_ (u"ࠬࡺࡡࡣࡵࠪ䔺")][0][l111lll_ll_ (u"࠭ࡴࡢࡤࡕࡩࡳࡪࡥࡳࡧࡵࠫ䔻")][l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ䔼")][l111lll_ll_ (u"ࠨࡴ࡬ࡧ࡭ࡍࡲࡪࡦࡕࡩࡳࡪࡥࡳࡧࡵࠫ䔽")][l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䔾")]
	elif l111lll_ll_ (u"ࠪࠦࡹ࡫ࡸࡵࠤ࠽ࠦฬ๊แ๋ัํ์์อสࠡษ็้็ะัฮหࠥࠫ䔿") in html:
		e = c[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䕀")][l111lll_ll_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䕁")][l111lll_ll_ (u"࠭ࡴࡢࡤࡶࠫ䕂")][0][l111lll_ll_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ䕃")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ䕄")][l111lll_ll_ (u"ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬ䕅")][l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䕆")]
	else: e = []
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡤࡶࡲ࡯ࡪࡴࠧࠡ࡫ࡱࠤࡺࡸ࡬࠻ࠌࠌࠍࡩࠦ࠽ࠡࡥ࡞࠵ࡢࡡࠧࡳࡧࡶࡴࡴࡴࡳࡦࠩࡠ࡟ࠬࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡇࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫࡢࠐࠉࠊࡧࠣࡁࠥࡪ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࠏࠏࠉࡵࡴࡼ࠾ࠥࡺ࡯࡬ࡧࡱࠤࡂࠦࡤ࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡰࡨࡼࡹࡉ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࡈࡦࡺࡡࠨ࡟࡞ࠫࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࠪࡡࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠡࡲࡤࡷࡸࠐࠉࠣࠤࠥ䕇")
	for i in range(len(e)):
		try: item = e[i][l111lll_ll_ (u"ࠬࡸࡩࡤࡪࡌࡸࡪࡳࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䕈")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䕉")]
		except: item = e[i]
		#if item.keys()[0]==l111lll_ll_ (u"ࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䕊"): continue
		l11l1ll1ll11_ll_(item)
	if l111lll_ll_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣࠩ䕋") in html:
		global settings
		key = settings.getSetting(l111lll_ll_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱࡯ࡪࡿࠧ䕌"))
		l11l1lll1lll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡻ࡯ࡳࡪࡶࡲࡶࡉࡧࡴࡢࠩ䕍"))
		l1ll111_ll_ = l111lll_ll_ (u"ࠫࠬ䕎")
		if l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ䕏") in url or l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠿࡬ࡧࡼࡁࠬ䕐") in url: l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ䕑")+key
		elif url==l1ll1l1_ll_ or l111lll_ll_ (u"ࠨ࠱ࡥࡶࡴࡽࡳࡦࡁ࡮ࡩࡾࡃࠧ䕒") in url: l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡤࡵࡳࡼࡹࡥࡀ࡭ࡨࡽࡂ࠭䕓")+key
		if l1ll111_ll_!=l111lll_ll_ (u"ࠪࠫ䕔"): l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䕕"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣหำื้ࠡ࠸࠹࠺࠻࠭䕖"),l1ll111_ll_,141,l111lll_ll_ (u"࠭ࠧ䕗"),index,l11l1lll1lll_ll_)
	l111lll_ll_ (u"ࠢࠣࠤࠍࠍࡪࡲࡩࡧࠢࠪࠦࡨࡵ࡮ࡵ࡫ࡱࡹࡦࡺࡩࡰࡰࡶࠦࠬࠦࡩ࡯ࠢ࡫ࡸࡲࡲ࠺ࠋࠋࠌࡧࡴࡴࡴࡪࡰࡸࡥࡹ࡯࡯࡯ࠢࡀࠤࡸ࡫ࡴࡵ࡫ࡱ࡫ࡸ࠴ࡧࡦࡶࡖࡩࡹࡺࡩ࡯ࡩࠫࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡯ࡶ࡬ࡲࡺࡧࡴࡪࡱࡱࠫ࠮ࠐࠉࠊࡘࡌࡗࡎ࡚ࡏࡓࡡࡌࡒࡋࡕ࠱ࡠࡎࡌ࡚ࡊࠦ࠽ࠡࡵࡨࡸࡹ࡯࡮ࡨࡵ࠱࡫ࡪࡺࡓࡦࡶࡷ࡭ࡳ࡭ࠨࠨࡻࡲࡹࡹࡻࡢࡦ࠰࡙ࡍࡘࡏࡔࡐࡔࡢࡍࡓࡌࡏ࠲ࡡࡏࡍ࡛ࡋࠧࠪࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡼ࡫ࡢࡴ࡫ࡷࡩ࠵ࡧࠫࠨ࠱ࡥࡶࡴࡽࡳࡦࡡࡤ࡮ࡦࡾ࠿ࡤࡶࡲ࡯ࡪࡴ࠽ࠨ࠭ࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠋࠋࠌࡥࡩࡪࡍࡦࡰࡸࡍࡹ࡫࡭ࠩࠩࡩࡳࡱࡪࡥࡳࠩ࠯ࡱࡪࡴࡵࡠࡰࡤࡱࡪ࠱ࠧึใะอࠥอฮา๋ࠣ࠹࠺࠻࠵ࠨ࠮ࡸࡶࡱ࠸ࠬ࠲࠶࠴࠰ࠬ࠭ࠬࡪࡰࡧࡩࡽ࠲ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈ࠭ࠏࠏࠢࠣࠤ䕘")
	return
def l11l1l1l11ll_ll_(url,index=l111lll_ll_ (u"ࠨࠩ䕙")):
	html,cc = l11l1ll1lll1_ll_(url)
	dd = cc[l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䕚")][l111lll_ll_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳࡈࡲࡰࡹࡶࡩࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䕛")][l111lll_ll_ (u"ࠫࡹࡧࡢࡴࠩ䕜")][0][l111lll_ll_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䕝")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䕞")][l111lll_ll_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䕟")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪ䕠")]
	if index==l111lll_ll_ (u"ࠩࠪ䕡"):
		for i in range(len(dd)):
			item = dd[i][l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䕢")][l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䕣")][0][l111lll_ll_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ䕤")]
			title = item[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ䕥")][l111lll_ll_ (u"ࠧࡴ࡫ࡰࡴࡱ࡫ࡔࡦࡺࡷࠫ䕦")]
			title = l1l1l11ll_ll_(title)
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䕧"),l1l1l1l_ll_+title,url,144,l111lll_ll_ (u"ࠩࠪ䕨"),str(i))
	else:
		ee = dd[int(index)][l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䕩")][l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䕪")][0][l111lll_ll_ (u"ࠬࡹࡨࡦ࡮ࡩࡖࡪࡴࡤࡦࡴࡨࡶࠬ䕫")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䕬")][l111lll_ll_ (u"ࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡐ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠩ䕭")][l111lll_ll_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ䕮")]
		for i in range(len(ee)):
			item = ee[i]
			l11l1ll1ll11_ll_(item)
	return