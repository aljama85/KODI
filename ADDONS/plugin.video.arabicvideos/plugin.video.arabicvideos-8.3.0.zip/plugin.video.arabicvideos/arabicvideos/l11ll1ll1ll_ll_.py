# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠭⷗")
headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨⷘ") : l111lll_ll_ (u"ࠬ࠭ⷙ") }
l1l1l1l_ll_=l111lll_ll_ (u"࠭࡟ࡎࡘ࡝ࡣࠬⷚ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1l1llll1_ll_ = l11l11l_ll_[l1ll_ll_][1]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==180: results = l11l1ll_ll_(url)
	elif mode==181: results = l1l11l1_ll_(url,text)
	elif mode==182: results = l11_ll_(url)
	elif mode==183: results = l1l11ll_ll_(url)
	elif mode==188: results = l11ll1l1l1_ll_()
	elif mode==189: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11ll1l1l1_ll_():
	message = l111lll_ll_ (u"่ࠧาสࠤฬ๊ๅ้ไ฼ࠤฯเ๊าࠢหห้้วๆๆࠣ࠲࠳࠴้ࠠสะหัฯࠠศๆ์ࠤฬ฿วะหࠣฬึ๋ฬส่๊ࠢࠥอไึใิࠤ࠳࠴࠮๊ࠡส่๊ฮัๆฮࠣัฬ๊๊ศุ่ࠢ฿๎ไ๊ࠡํ฽ฬ์๊ࠡ็้ࠤํ฿ใสุࠢั๏ฯࠠ࠯࠰࠱ࠤํ๊็ัษࠣืํ็๋ࠠสๅํࠥอไๆ๊ๅ฽ฺ๋ࠥๅไࠣห้๏ࠠๆษุࠣฬวࠠศๆ็๋ࠬⷛ")
	l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫⷜ"),message)
	return
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠩࠪⷝ")):
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪⷞ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⷟"),l111lll_ll_ (u"ࠬ࠭ⷠ"),189,l111lll_ll_ (u"࠭ࠧⷡ"),l111lll_ll_ (u"ࠧࠨⷢ"),l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬⷣ"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩⷤ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧⷥ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫอ๎ใิࠢส์ๆ๐ำࠡ็๋ๅ๏ุࠠๅษ้ำࠬⷦ"),l1ll1l1_ll_,181,l111lll_ll_ (u"ࠬ࠭ⷧ"),l111lll_ll_ (u"࠭ࠧⷨ"),l111lll_ll_ (u"ࠧࡣࡱࡻ࠱ࡴ࡬ࡦࡪࡥࡨࠫⷩ"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨⷪ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ⷫ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪวาีหࠡษ็หๆ๊วๆࠩⷬ"),l1ll1l1_ll_,181,l111lll_ll_ (u"ࠫࠬⷭ"),l111lll_ll_ (u"ࠬ࠭ⷮ"),l111lll_ll_ (u"࠭࡬ࡢࡶࡨࡷࡹ࠳࡭ࡰࡸ࡬ࡩࡸ࠭ⷯ"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧⷰ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬⷱ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯࠨⷲ"),l1ll1l1_ll_,181,l111lll_ll_ (u"ࠪࠫⷳ"),l111lll_ll_ (u"ࠫࠬⷴ"),l111lll_ll_ (u"ࠬࡺࡶࠨⷵ"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ⷶ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫⷷ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨⷸ"),l1ll1l1_ll_,181,l111lll_ll_ (u"ࠩࠪⷹ"),l111lll_ll_ (u"ࠪࠫⷺ"),l111lll_ll_ (u"ࠫࡹࡵࡰ࠮ࡸ࡬ࡩࡼࡹࠧⷻ"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬⷼ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪⷽ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧฤไ๋ํࠥอไศใ็ห๊ࠦวๅฯส่๏ฯࠧⷾ"),l1ll1l1_ll_,181,l111lll_ll_ (u"ࠨࠩⷿ"),l111lll_ll_ (u"ࠩࠪ⸀"),l111lll_ll_ (u"ࠪࡸࡴࡶ࠭࡮ࡱࡹ࡭ࡪࡹࠧ⸁"))
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬ⸂"),headers,l111lll_ll_ (u"ࠬ࠭⸃"),l111lll_ll_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ⸄"))
	items = re.findall(l111lll_ll_ (u"ࠧ࠽ࡪ࠵ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⸅"),html,re.DOTALL)
	for link,title in items:
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸆"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭⸇")+l1l1l1l_ll_+title,link,181)
	#l1ll1l_ll_(html,html)
	return html
def l1l11l1_ll_(url,type=l111lll_ll_ (u"ࠪࠫ⸈")):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬ⸉"),headers,l111lll_ll_ (u"ࠬ࠭⸊"),l111lll_ll_ (u"࠭ࡍࡐࡘࡌ࡞ࡑࡇࡎࡅ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ⸋"))
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	if type==l111lll_ll_ (u"ࠧ࡭ࡣࡷࡩࡸࡺ࠭࡮ࡱࡹ࡭ࡪࡹࠧ⸌"): block = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡶ࡬ࡸࡱ࡫ࡓࡦࡥࡷ࡭ࡴࡴࠢ࠿ละำะࠦวๅลไ่ฬ๋࠼࠰ࡪ࠴ࡂ࠭࠴ࠪࡀࠫ࠿࡬࠶࠭⸍"),html,re.DOTALL)[0]
	elif type==l111lll_ll_ (u"ࠩࡥࡳࡽ࠳࡯ࡧࡨ࡬ࡧࡪ࠭⸎"): block = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡸ࡮ࡺ࡬ࡦࡕࡨࡧࡹ࡯࡯࡯ࠤࡁฬํ้ำࠡษ๋ๅ๏ูࠠๆ๊ไ๎ืࠦไศ่าࡀ࠴࡮࠱࠿ࠪ࠱࠮ࡄ࠯࠼ࡩ࠳ࠪ⸏"),html,re.DOTALL)[0]
	elif type==l111lll_ll_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ⸐"): block = re.findall(l111lll_ll_ (u"ࠬࡨࡴ࡯࠯࠵࠱ࡴࡼࡥࡳ࡮ࡤࡽ࠭࠴ࠪࡀࠫ࠿ࡷࡹࡿ࡬ࡦࡀࠪ⸑"),html,re.DOTALL)[0]
	elif type==l111lll_ll_ (u"࠭ࡴࡰࡲ࠰ࡺ࡮࡫ࡷࡴࠩ⸒"): block = re.findall(l111lll_ll_ (u"ࠧࡣࡶࡱ࠱࠶ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠫ࠲࠯ࡅࠩࡣࡶࡱ࠱࠷ࠦࡢࡵࡰ࠰ࡥࡧࡹ࡯࡭ࡻࠪ⸓"),html,re.DOTALL)[0]
	elif type==l111lll_ll_ (u"ࠨࡶࡹࠫ⸔"): block = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡷ࡭ࡹࡲࡥࡔࡧࡦࡸ࡮ࡵ࡮ࠣࡀอ่๏็า๋๊้ࠤ๊๎แ๋ิ่ࠣฬ์ฯ࠽࠱࡫࠵ࡃ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡩࠥࠫ⸕"),html,re.DOTALL)[0]
	else: block = html
	if type in [l111lll_ll_ (u"ࠪࡸࡴࡶ࠭ࡷ࡫ࡨࡻࡸ࠭⸖"),l111lll_ll_ (u"ࠫࡹࡵࡰ࠮࡯ࡲࡺ࡮࡫ࡳࠨ⸗")]:
		items = re.findall(l111lll_ll_ (u"ࠬࡹࡴࡺ࡮ࡨࡁࠧࡨࡡࡤ࡭ࡪࡶࡴࡻ࡮ࡥ࠯࡬ࡱࡦ࡭ࡥ࠻ࡷࡵࡰࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡢࡰࡶࡷࡳࡲ࠳ࡴࡪࡶ࡯ࡩ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⸘"),block,re.DOTALL)
	else: items = re.findall(l111lll_ll_ (u"࠭ࡨࡦ࡫ࡪ࡬ࡹࡃࠢ࠴࡝࠳࠱࠾ࡣࠫࠣࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡥࡳࡹࡺ࡯࡮࠯ࡷ࡭ࡹࡲࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⸙"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	l11lllll1_ll_ = [l111lll_ll_ (u"ࠧโ์็้ࠬ⸚"),l111lll_ll_ (u"ࠨษ็ั้่ษࠨ⸛"),l111lll_ll_ (u"ࠩส่า๊โ่ࠩ⸜"),l111lll_ll_ (u"ࠪ฽ึ฼ࠧ⸝"),l111lll_ll_ (u"ࠫࡗࡧࡷࠨ⸞"),l111lll_ll_ (u"࡙ࠬ࡭ࡢࡥ࡮ࡈࡴࡽ࡮ࠨ⸟"),l111lll_ll_ (u"࠭วฺๆส๊ࠬ⸠"),l111lll_ll_ (u"ࠧศฮีหฦ࠭⸡")]
	for img,l1lllllll1l1_ll_,l11111111l1_ll_,l11111111ll_ll_ in items:
		if type in [l111lll_ll_ (u"ࠨࡶࡲࡴ࠲ࡼࡩࡦࡹࡶࠫ⸢"),l111lll_ll_ (u"ࠩࡷࡳࡵ࠳࡭ࡰࡸ࡬ࡩࡸ࠭⸣")]:
			img,link,l11ll1ll_ll_,title = img,l1lllllll1l1_ll_,l11111111l1_ll_,l11111111ll_ll_
		else: img,title,link,l11ll1ll_ll_ = img,l1lllllll1l1_ll_,l11111111l1_ll_,l11111111ll_ll_
		link = l1111_ll_(link)
		link = link.replace(l111lll_ll_ (u"ࠪࡃࡻ࡯ࡥࡸ࠿ࡷࡶࡺ࡫ࠧ⸤"),l111lll_ll_ (u"ࠫࠬ⸥"))
		#l1ll1l_ll_(link,l11ll1ll_ll_)
		title = unescapeHTML(title)
		#l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠮࠮ࠫࡁࠬࠬอา่ะหࡿฬั๎ฯ่ࠫࠪ⸦"),title,re.DOTALL)
		#if l11ll111_ll_: title = l11ll111_ll_[0][0]
		if l111lll_ll_ (u"࠭ศอ๊าอࠥ࠭⸧") in title or l111lll_ll_ (u"ࠧษฮ๋ำ์ࠦࠧ⸨") in title:
			title = l111lll_ll_ (u"ࠨࡡࡐࡓࡉࡥࠧ⸩") + title.replace(l111lll_ll_ (u"ࠩหะํีษࠡࠩ⸪"),l111lll_ll_ (u"ࠪࠫ⸫")).replace(l111lll_ll_ (u"ࠫอา่ะ้ࠣࠫ⸬"),l111lll_ll_ (u"ࠬ࠭⸭"))
		title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ⸮"))
		if l111lll_ll_ (u"ࠧศๆะ่็ฯࠧⸯ") in title or l111lll_ll_ (u"ࠨษ็ั้่็ࠨ⸰") in title:
			episode = re.findall(l111lll_ll_ (u"ࠩࠫ࠲࠯ࡅࠩࠡࠪส่า๊โสࡾส่า๊โ่ࠫࠣࡠࡩ࠱ࠧ⸱"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠪࡣࡒࡕࡄࡠࠩ⸲") + episode[0][0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⸳"),l1l1l1l_ll_+title,link,183,img)
					l1ll11ll_ll_.append(title)
		elif any(value in title for value in l11lllll1_ll_):
			link = link + l111lll_ll_ (u"ࠬࡅࡳࡦࡴࡹࡩࡷࡹ࠽ࠨ⸴") + l11ll1ll_ll_
			l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ⸵"),l1l1l1l_ll_+title,link,182,img)
		else:
			link = link + l111lll_ll_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ⸶") + l11ll1ll_ll_
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⸷"),l1l1l1l_ll_+title,link,183,img)
	if type==l111lll_ll_ (u"ࠩࠪ⸸"):
		items = re.findall(l111lll_ll_ (u"ࠪࡠࡳࡂ࡬ࡪࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⸹"),html,re.DOTALL)
		for link,title in items:
			title = unescapeHTML(title)
			title = title.replace(l111lll_ll_ (u"ࠫฬ๊ีโฯฬࠤࠬ⸺"),l111lll_ll_ (u"ࠬ࠭⸻"))
			if title!=l111lll_ll_ (u"࠭ࠧ⸼"):
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⸽"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦࠧ⸾")+title,link,181)
	return
def l1l11ll_ll_(url):
	l1ll111_ll_ = url.split(l111lll_ll_ (u"ࠩࡂࡷࡪࡸࡶࡦࡴࡶࡁࠬ⸿"))[0]
	html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠪࠫ⹀"),headers,l111lll_ll_ (u"ࠫࠬ⹁"),l111lll_ll_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ⹂"))
	block = re.findall(l111lll_ll_ (u"࠭࠼ࡵ࡫ࡷࡰࡪࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡪࡶ࡯ࡩࡃ࠴ࠪࡀࡪࡨ࡭࡬࡮ࡴ࠾ࠤࠫ࡟࠵࠳࠹࡞࠭ࠬࠦࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ⹃"),html,re.DOTALL)
	title,dummy,img = block[0]
	name = re.findall(l111lll_ll_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠨศๆะ่็ฯࡼศๆะ่็ํࠩࠡ࡝࠳࠱࠾ࡣࠫࠨ⹄"),title,re.DOTALL)
	if name: name = l111lll_ll_ (u"ࠨࡡࡐࡓࡉࡥࠧ⹅") + name[0][0]
	else: name = title
	items = []
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡨࡴ࡮ࡹ࡯ࡥࡧࡶࡒࡺࡳࡢࡦࡴࡶࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩ⹆"),html,re.DOTALL)
	if l1lll_ll_:
		#l1ll1l_ll_(l1ll111_ll_,str(l1lll_ll_))
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ⹇"),block,re.DOTALL)
		for link in items:
			link = l1111_ll_(link)
			title = re.findall(l111lll_ll_ (u"ࠫ࠭อไฮๆๅอࢁอไฮๆๅ๋࠮࠳ࠨ࡜࠲࠰࠽ࡢ࠱ࠩࠨ⹈"),link.split(l111lll_ll_ (u"ࠬ࠵ࠧ⹉"))[-2],re.DOTALL)
			if not title: title = re.findall(l111lll_ll_ (u"࠭ࠨࠪ࠯ࠫ࡟࠵࠳࠹࡞࠭ࠬࠫ⹊"),link.split(l111lll_ll_ (u"ࠧ࠰ࠩ⹋"))[-2],re.DOTALL)
			if title: title = l111lll_ll_ (u"ࠨࠢࠪ⹌") + title[0][1]
			else: title = l111lll_ll_ (u"ࠩࠪ⹍")
			title = name + l111lll_ll_ (u"ࠪࠤ࠲ࠦࠧ⹎") + l111lll_ll_ (u"ࠫฬ๊อๅไฬࠫ⹏") + title
			title = unescapeHTML(title)
			l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ⹐"),l1l1l1l_ll_+title,link,182,img)
	if not items:
		title = unescapeHTML(title)
		if l111lll_ll_ (u"࠭ศอ๊าอࠥ࠭⹑") in title or l111lll_ll_ (u"ࠧษฮ๋ำ์ࠦࠧ⹒") in title:
			title = l111lll_ll_ (u"ࠨࡡࡐࡓࡉࡥࠧ⹓") + title.replace(l111lll_ll_ (u"ࠩหะํีษࠡࠩ⹔"),l111lll_ll_ (u"ࠪࠫ⹕")).replace(l111lll_ll_ (u"ࠫอา่ะ้ࠣࠫ⹖"),l111lll_ll_ (u"ࠬ࠭⹗"))
		l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ⹘"),l1l1l1l_ll_+title,url,182,img)
	return
def l11_ll_(url):
	urls = url.split(l111lll_ll_ (u"ࠧࡀࡵࡨࡶࡻ࡫ࡲࡴ࠿ࠪ⹙"))
	l1ll111_ll_ = urls[0]
	del urls[0]
	html = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ⹚"),headers,l111lll_ll_ (u"ࠩࠪ⹛"),l111lll_ll_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⹜"))
	link = re.findall(l111lll_ll_ (u"ࠫ࡫ࡵ࡮ࡵ࠯ࡶ࡭ࡿ࡫࠺ࠡ࠴࠸ࡴࡽࡁࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ⹝"),html,re.DOTALL)[0]
	if link not in urls: urls.append(link)
	l1l111l_ll_ = []
	# l1lllllll11l_ll_
	for link in urls:
		if l111lll_ll_ (u"ࠬࡀ࠯࠰࡯ࡲࡷ࡭ࡧࡨࡥࡣ࠱ࠫ⹞") in link:
			l1lllllll11l_ll_ = link
			l1l111l_ll_.append(l1lllllll11l_ll_+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࡍࡢ࡫ࡱࠫ⹟"))
	# l1lllllllll1_ll_
	for link in urls:
		if l111lll_ll_ (u"ࠧ࠻࠱࠲ࡺࡧ࠴࡭ࡰࡸ࡬ࡾࡱࡧ࡮ࡥ࠰ࠪ⹠") in link:
			html = l111ll1_ll_(l11l1l_ll_,link,l111lll_ll_ (u"ࠨࠩ⹡"),headers,l111lll_ll_ (u"ࠩࠪ⹢"),l111lll_ll_ (u"ࠪࡑࡔ࡜ࡉ࡛ࡎࡄࡒࡉ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨ⹣"))
			html = html.decode(l111lll_ll_ (u"ࠫࡼ࡯࡮ࡥࡱࡺࡷ࠲࠷࠲࠶࠸ࠪ⹤")).encode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪ⹥"))
			#xbmc.log(html, level=xbmc.LOGNOTICE)
			#</a></div><br /><div l111111111l_ll_=l111lll_ll_ (u"ࠨࡣࡦࡰࡷࡩࡷࠨ⹦")>(\*\*\*\*\*\*\*\*|13721411411.png|)
			html = html.replace(l111lll_ll_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡨࡵ࡭࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ⹧"),l111lll_ll_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠬ⹨"))
			html = html.replace(l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴࡯࡯࡮࡬ࡲࡪ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ⹩"),l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠧ⹪"))
			html = html.replace(l111lll_ll_ (u"ࠫࡁ࠵ࡡ࠿࠾࠲ࡨ࡮ࡼ࠾࠽ࡤࡵࠤ࠴ࡄ࠼ࡥ࡫ࡹࠤࡦࡲࡩࡨࡰࡀࠦࡨ࡫࡮ࡵࡧࡵࠦࡃ࠭⹫"),l111lll_ll_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠨ⹬"))
			html = html.replace(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡴࡣࡱࡵࡨࡪࡸࠢࠡࡣ࡯࡭࡬ࡴ࠽ࠣࡥࡨࡲࡹ࡫ࡲࠣࠩ⹭"),l111lll_ll_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ⹮"))
			l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࠪࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵࡜ࡸ࠭࠱࡬ࡹࡳ࡬ࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠩࠨ⹯"),html,re.DOTALL)
			if l1lll_ll_:
				#l1ll1l_ll_(url,str(len(l1lll_ll_)))
				l1lllll1l_ll_,l1llllll1_ll_ = [],[]
				if len(l1lll_ll_)==1:
					title = l111lll_ll_ (u"ࠩࠪ⹰")
					block = html
				else:
					for block in l1lll_ll_:
						l11l1l11_ll_ = re.findall(l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧ࠴ࠪࡀࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠯ࠬࡂࡠ࠯ࡢࠪ࡝ࠬ࡟࠮ࡡ࠰࡜ࠫ࡞࠭࠯࠭࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠭ࠬ⹱"),block,re.DOTALL)
						if l11l1l11_ll_: block = l111lll_ll_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥ࠭⹲") + l11l1l11_ll_[0][1]
						l11l1l11_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢ࠯ࠬࡂࡀ࡭ࡸࠠࡴ࡫ࡽࡩࡂࠨ࠱ࠣࠢࡶࡸࡾࡲࡥ࠾ࠤࡦࡳࡱࡵࡲ࠻ࠥ࠶࠷࠸ࡁࠠࡣࡣࡦ࡯࡬ࡸ࡯ࡶࡰࡧ࠱ࡨࡵ࡬ࡰࡴ࠽ࠧ࠸࠹࠳ࠣࠢ࠲ࡂ࠭࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࡞࠱࠲࠯ࡅ࠯࡝ࡹ࠮࠲࡭ࡺ࡭࡭ࠤ࠱࠮ࡄࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠪࠩ⹳"),block,re.DOTALL)
						if l11l1l11_ll_: block = l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࠨ⹴") + l11l1l11_ll_[0]
						l11l1l11_ll_ = re.findall(l111lll_ll_ (u"ࠧࠩࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࡜࠯࠰࠭ࡃ࠴ࡢࡷࠬ࠰࡫ࡸࡲࡲࠢ࠯ࠬࡂ࠭ࡁ࡮ࡲࠡࡵ࡬ࡾࡪࡃࠢ࠲ࠤࠣࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡴࡲ࡯ࡳ࠼ࠦ࠷࠸࠹࠻ࠡࡤࡤࡧࡰ࡭ࡲࡰࡷࡱࡨ࠲ࡩ࡯࡭ࡱࡵ࠾ࠨ࠹࠳࠴ࠤࠣ࠳ࡃ࠴ࠪࡀࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠫ⹵"),block,re.DOTALL)
						if l11l1l11_ll_: block = l11l1l11_ll_[0] + l111lll_ll_ (u"ࠨࠢࠣࡠࡳࠦࠠࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠪ⹶")
						l1111111111_ll_ = re.findall(l111lll_ll_ (u"ࠩ࠿ࠬ࠳࠰࠿ࠪࡪࡷࡸࡵࡀ࠯࠰ࡷࡳ࠲ࡲࡵࡶࡪࡼ࡯ࡥࡳࡪ࠮ࠩࡱࡱࡰ࡮ࡴࡥࡽࡥࡲࡱ࠮࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯ࠨ⹷"),block,re.DOTALL)
						title = re.findall(l111lll_ll_ (u"ࠪࡂࠥ࠰ࠨ࡜ࡠ࠿ࡂࡢ࠱ࠩࠡࠬ࠿ࠫ⹸"),l1111111111_ll_[0][0],re.DOTALL)
						title = l111lll_ll_ (u"ࠫࠥ࠭⹹").join(title)
						title = title.strip(l111lll_ll_ (u"ࠬࠦࠧ⹺"))
						title = title.replace(l111lll_ll_ (u"࠭ࠠࠡࠩ⹻"),l111lll_ll_ (u"ࠧࠡࠩ⹼")).replace(l111lll_ll_ (u"ࠨࠢࠣࠫ⹽"),l111lll_ll_ (u"ࠩࠣࠫ⹾")).replace(l111lll_ll_ (u"ࠪࠤࠥ࠭⹿"),l111lll_ll_ (u"ࠫࠥ࠭⺀")).replace(l111lll_ll_ (u"ࠬࠦࠠࠨ⺁"),l111lll_ll_ (u"࠭ࠠࠨ⺂")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪ⺃"),l111lll_ll_ (u"ࠨࠢࠪ⺄"))
						l1lllll1l_ll_.append(title)
					selection = l1l1111_ll_(l111lll_ll_ (u"ࠩฦาฯืࠠศๆไ๎ิ๐่ࠡษ็้฼๊่ษ࠼ࠪ⺅"), l1lllll1l_ll_)
					if selection == -1 : return
					title = l1lllll1l_ll_[selection]
					block = l1lll_ll_[selection]
				link = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠻࠱࠲ࡱࡴࡹࡨࡢࡪࡧࡥࡡ࠴࠮ࠫࡁ࠲ࡠࡼ࠱࠮ࡩࡶࡰࡰ࠮ࠨࠧ⺆"),block,re.DOTALL)
				l1lllllll111_ll_ = link[0]
				l1l111l_ll_.append(l1lllllll111_ll_+l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࡋࡵࡲࡶ࡯ࠪ⺇"))
				block = block.replace(l111lll_ll_ (u"ࠬๆࠧ⺈"),l111lll_ll_ (u"࠭ࠧ⺉"))
				block = block.replace(l111lll_ll_ (u"ࠧࡴࡴࡦࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡻࡰ࠯࡯ࡲࡺ࡮ࢀ࡬ࡢࡰࡧ࠲ࡴࡴ࡬ࡪࡰࡨ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠵࠲࠹࠷࠵࠷࠷࠷࠶࠴࠼࠺࠳ࡶ࡮ࡨࠤࠪ⺊"),l111lll_ll_ (u"ࠨࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡸࡾࡶࡥࡵࡻࡳࡩࡂࠨࡢࡰࡶ࡫ࠦࠥࠦ࡜࡯ࠢࠣࠫ⺋"))
				block = block.replace(l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠢࡩࡶࡷࡴ࠿࠵࠯ࡶࡲ࠱ࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠴ࡣࡰ࡯࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠻࠱࠸࠶࠴࠶࠶࠽࠵࠳࠻࠹࠲ࡵࡴࡧࠣࠩ⺌"),l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡺࡹࡱࡧࡷࡽࡵ࡫࠽ࠣࡤࡲࡸ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭⺍"))
				block = block.replace(l111lll_ll_ (u"ุࠫ๐ัโำสฮࠥอไหฯ่๎้࠭⺎"),l111lll_ll_ (u"ࠬࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣࠢࠣࡠࡳࠦࠠࡵࡻࡳࡩࡹࡿࡰࡦ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧࠦࠠ࡝ࡰࠣࠤࠬ⺏"))
				block = block.replace(l111lll_ll_ (u"࠭ั้ษห฻ࠥอไหฯ่๎้࠭⺐"),l111lll_ll_ (u"ࠧࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠣࠤࡡࡴࠠࠡࡵࡵࡧࡂࠨ࠯ࡶࡲ࡯ࡳࡦࡪࡳ࠰࠳࠶࠻࠷࠷࠴࠲࠳࠷࠵࠶࠴ࡰ࡯ࡩࠥࠤࠥࡢ࡮ࠡࠢࡷࡽࡵ࡫ࡴࡺࡲࡨࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠢࠡࠢ࡟ࡲࠥࠦࠧ⺑"))
				block = block.replace(l111lll_ll_ (u"ࠨีํีๆืวหࠢสฺ่๊ว่ัࠪ⺒"),l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠢ࠰ࡷࡳࡰࡴࡧࡤࡴ࠱࠴࠷࠼࠸࠱࠵࠳࠴࠸࠶࠷࠮ࡱࡰࡪࠦࠥࠦ࡜࡯ࠢࠣࡷࡷࡩ࠽ࠣ࠱ࡸࡴࡱࡵࡡࡥࡵ࠲࠵࠸࠽࠲࠲࠶࠴࠵࠹࠷࠱࠯ࡲࡱ࡫ࠧࠦࠠ࡝ࡰࠣࠤࡹࡿࡰࡦࡶࡼࡴࡪࡃࠢࡸࡣࡷࡧ࡭ࠨࠠࠡ࡞ࡱࠤࠥ࠭⺓"))
				block = block.replace(l111lll_ll_ (u"ࠪีํอศุࠢสฺ่๊ว่ัࠪ⺔"),l111lll_ll_ (u"ࠫࡸࡸࡣ࠾ࠤ࠲ࡹࡵࡲ࡯ࡢࡦࡶ࠳࠶࠹࠷࠳࠳࠷࠵࠶࠺࠱࠲࠰ࡳࡲ࡬ࠨࠠࠡ࡞ࡱࠤࠥࡹࡲࡤ࠿ࠥ࠳ࡺࡶ࡬ࡰࡣࡧࡷ࠴࠷࠳࠸࠴࠴࠸࠶࠷࠴࠲࠳࠱ࡴࡳ࡭ࠢࠡࠢ࡟ࡲࠥࠦࡴࡺࡲࡨࡸࡾࡶࡥ࠾ࠤࡺࡥࡹࡩࡨࠣࠢࠣࡠࡳࠦࠠࠨ⺕"))
				l1lllllll1ll_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠮ࡳࡳࡥࡀࠦ࠴ࡻࡰ࡭ࡱࡤࡨࡸ࠵࠱࠴࠹࠵࠵࠹࠷࠱࠵࠳࠴࠲ࡵࡴࡧࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥ࡬ࡹࡺࡰ࠻࠱࠲ࡩ࠺ࡺࡳࡢࡴ࠱ࡧࡴࡳ࠯࡝ࡦ࠮ࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠵ࡵࡱ࡮ࡲࡥࡩࡹ࠯࠲࠵࠺࠶࠶࠺࠱࠲࠶࠴࠵࠳ࡶ࡮ࡨࠤࠬࠫ⺖"),block,re.DOTALL)
				for l1llllllll1l_ll_ in l1lllllll1ll_ll_:
					#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧ⺗"),str(l1llllllll1l_ll_))
					type = re.findall(l111lll_ll_ (u"ࠧࠡࡶࡼࡴࡪࡺࡹࡱࡧࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࠬ⺘"),l1llllllll1l_ll_)
					if type:
						if type[0]!=l111lll_ll_ (u"ࠨࡤࡲࡸ࡭࠭⺙"): type = l111lll_ll_ (u"ࠩࡢࡣࠬ⺚")+type[0]
						else: type = l111lll_ll_ (u"ࠪࠫ⺛")
					items = re.findall(l111lll_ll_ (u"ࠫ࠭ࡅ࠼ࠢࡪࡷࡸࡵࡀ࠯࠰ࡧ࠸ࡸࡸࡧࡲ࠯ࡥࡲࡱ࠴࠯ࠨ࡝ࡹ࠮࡟ࠥࡢࡷ࡞ࠬ࠿࠳࡫ࡵ࡮ࡵࡀ࠱࠮ࡄࢂ࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫ࠾ࡥࡶࠥ࠵࠾࠯ࠬࡂ࠭࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠼࠲࠳ࡪ࠻ࡴࡴࡣࡵ࠲ࡨࡵ࡭࠰࠰࠭ࡃ࠮ࠨࠧ⺜"),l1llllllll1l_ll_,re.DOTALL)
					for l1llllllll11_ll_,link in items:
						title = re.findall(l111lll_ll_ (u"ࠬ࠮࡜ࡸ࠭࡞ࠤࡡࡽ࡝ࠫࠫ࠿ࠫ⺝"),l1llllllll11_ll_)
						title = title[-1]
						link = link + l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⺞") + title + type
						l1l111l_ll_.append(link)
	# l1111111l11_ll_
	l11ll1_ll_ = l1ll111_ll_.replace(l1ll1l1_ll_,l1l1llll1_ll_)
	html = l111ll1_ll_(l11l1l_ll_,l11ll1_ll_,l111lll_ll_ (u"ࠧࠨ⺟"),headers,l111lll_ll_ (u"ࠨࠩ⺠"),l111lll_ll_ (u"ࠩࡐࡓ࡛ࡏ࡚ࡍࡃࡑࡈ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ⺡"))
	items = re.findall(l111lll_ll_ (u"ࠪࠦࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ⺢"),html,re.DOTALL)
	#l111ll1ll_ll_ = re.findall(l111lll_ll_ (u"ࠫࠧࠦࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠾࠴࠵࡭ࡰࡵ࡫ࡥ࡭ࡪࡡ࡝࠰࠱࠮ࡄ࠵ࡥ࡮ࡤࡨࡨࡒ࠳ࠨ࡝ࡹ࠮࠭࠲࠴ࠪࡀ࠰࡫ࡸࡲࡲࠩࠨ⺣"),html,re.DOTALL)
	#if l111ll1ll_ll_:
	if items:
		#l1111111l11_ll_ = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫࠯ࠨ⺤") + l111ll1ll_ll_[-1] + l111lll_ll_ (u"࠭࠮ࡩࡶࡰࡰࠬ⺥")
		l1111111l11_ll_ = items[-1]
		l1l111l_ll_.append(l1111111l11_ll_+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࡎࡱࡥ࡭ࡱ࡫ࠧ⺦"))
	l1llllll1lll_ll_,l1llllllllll_ll_ = [],[]
	for link in l1l111l_ll_:
		l11ll1ll_ll_,l11l11ll11_ll_ = link.split(l111lll_ll_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ⺧"))
		l1llllll1lll_ll_.append(l11ll1ll_ll_)
		l1llllllllll_ll_.append(l11l11ll11_ll_)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⺨"),l111lll_ll_ (u"ࠪ฾๏ืࠠใษาีࠥ฿ไ๊ࠢส๎ัอฯࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็้หุฮࠧ⺩"))
	else:
		#selection = l1l1111_ll_(l111lll_ll_ (u"ࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ⺪"), l1l111l_ll_)
		#if selection == -1 : return
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ⺫"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"࠭ࠧ⺬"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠧࠨ⺭"): return
	search = search.replace(l111lll_ll_ (u"ࠨࠢࠪ⺮"),l111lll_ll_ (u"ࠩ࠮ࠫ⺯"))
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫ⺰"),headers,l111lll_ll_ (u"ࠫࠬ⺱"),l111lll_ll_ (u"ࠬࡓࡏࡗࡋ࡝ࡐࡆࡔࡄ࠮ࡕࡈࡅࡗࡉࡈ࠮࠳ࡶࡸࠬ⺲"))
	items = re.findall(l111lll_ll_ (u"࠭࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡰࡲࡷ࡭ࡴࡴ࠾ࠨ⺳"),html,re.DOTALL)
	l11llll11_ll_ = [ l111lll_ll_ (u"ࠧࠨ⺴") ]
	l11ll1l11_ll_ = [ l111lll_ll_ (u"ࠨษ็็้่ࠦษั๋๊ࠥ็ไหำࠪ⺵") ]
	for category,title in items:
		l11llll11_ll_.append(category)
		l11ll1l11_ll_.append(title)
	if category:
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠩสาฯืࠠศๆไ่ฯืࠠศๆ่๊ฬูศ࠻ࠩ⺶"), l11ll1l11_ll_)
		if selection == -1 : return
		category = l11llll11_ll_[selection]
	else: category = l111lll_ll_ (u"ࠪࠫ⺷")
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠫ࠴ࡅࡳ࠾ࠩ⺸")+search+l111lll_ll_ (u"ࠬࠬ࡭ࡤࡣࡷࡁࠬ⺹")+category
	#l1ll1l_ll_(url,url)
	l1l11l1_ll_(url)
	return