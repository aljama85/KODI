# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ䀟")
l1l1l1l_ll_ = l111lll_ll_ (u"ࠨࡡࡖࡌ࡛ࡥࠧ䀠")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
headers = {l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭䀡"):None}
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==310: results = l11l1ll_ll_(url)
	elif mode==311: results = l1l11l1_ll_(url)
	elif mode==312: results = l11_ll_(url)
	elif mode==313: results = l11ll11ll1l1_ll_(url)
	elif mode==314: results = l1111l11_ll_(text)
	elif mode==319: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ䀢")):
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䀣"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬฮอฬࠢไ๎ࠥอไๆ๊ๅ฽ࠬ䀤"),l111lll_ll_ (u"࠭ࠧ䀥"),319,l111lll_ll_ (u"ࠧࠨ䀦"),l111lll_ll_ (u"ࠨࠩ䀧"),l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䀨"))
	#l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䀩"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫๆ๊สาࠩ䀪"),l111lll_ll_ (u"ࠬ࠭䀫"),114,l1ll1l1_ll_)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ䀬"),l1ll1l1_ll_,l111lll_ll_ (u"ࠧࠨ䀭"),l111lll_ll_ (u"ࠨࠩ䀮"),l111lll_ll_ (u"ࠩࠪ䀯"),l111lll_ll_ (u"ࠪࠫ䀰"),l111lll_ll_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩ䀱"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡯ࡤ࠾ࠤࡰࡩࡳࡻ࡬ࡪࡰ࡮ࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ䀲"),html,re.DOTALL)
	block = l1lll_ll_[0]
	if l1111l_ll_==l111lll_ll_ (u"࠭ࠧ䀳"): l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ䀴"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䀵"),l111lll_ll_ (u"ࠩࠪ䀶"),9999)
	items = re.findall(l111lll_ll_ (u"ࠪࡀ࡭࠻࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡩ࠷ࡁࠫ䀷"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq].strip(l111lll_ll_ (u"ࠫࠥ࠭䀸"))
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䀹"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ䀺")+l1l1l1l_ll_+title,l1ll1l1_ll_,314,l111lll_ll_ (u"ࠧࠨ䀻"),l111lll_ll_ (u"ࠨࠩ䀼"),str(seq+1))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䀽"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ䀾")+l1l1l1l_ll_+l111lll_ll_ (u"๊่ࠫวุ฻ุࠣ์ืࠧ䀿"),l1ll1l1_ll_,314,l111lll_ll_ (u"ࠬ࠭䁀"),l111lll_ll_ (u"࠭ࠧ䁁"),l111lll_ll_ (u"ࠧ࠱ࠩ䁂"))
	if l1111l_ll_==l111lll_ll_ (u"ࠨࠩ䁃"): l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ䁄"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭䁅"),l111lll_ll_ (u"ࠫࠬ䁆"),9999)
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡃࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡅࡂࠬ䁇"),block,re.DOTALL)
	for link,title in items:
		#title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ䁈"))
		#url = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡹࡳ࠱ࡨࡵ࡮ࡵࡧࡱࡸ࠴ࡺࡨࡦ࡯ࡨࡷ࠴ࡉࡩ࡮ࡣࡑࡳࡼ࠵ࡉ࡯ࡶࡨࡶ࡫ࡧࡣࡦ࠱ࡩ࡭ࡱࡺࡥࡳ࠰ࡳ࡬ࡵ࠭䁉")
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䁊"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭䁋")+l1l1l1l_ll_+title,link,311)
	return html
def l1111l11_ll_(seq):
	#t1 = time.time()
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䁌"),l111lll_ll_ (u"ࠫࡸࡺࡡࡳࡶࠪ䁍"))
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ䁎"),l1ll1l1_ll_,l111lll_ll_ (u"࠭ࠧ䁏"),l111lll_ll_ (u"ࠧࠨ䁐"),l111lll_ll_ (u"ࠨࠩ䁑"),l111lll_ll_ (u"ࠩࠪ䁒"),l111lll_ll_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡌࡂࡖࡈࡗ࡙࠳࠱ࡴࡶࠪ䁓"))
	html = response.content
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䁔"),l111lll_ll_ (u"ࠬ࡫࡬ࡱࡣࡶࡩࡩࠦ࠽ࠡࠩ䁕")+str(time.time()-t1))
	if seq==l111lll_ll_ (u"࠭࠰ࠨ䁖"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡵࡣࡥ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ䁗"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷ࡭ࡹࡲࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䁘"),block,re.DOTALL)
		for link,name,title in items:
			title = title.strip(l111lll_ll_ (u"ࠩࠣࠫ䁙"))
			name = name.strip(l111lll_ll_ (u"ࠪࠤࠬ䁚"))
			title = title+l111lll_ll_ (u"ࠫࠥ࠮ࠧ䁛")+name+l111lll_ll_ (u"ࠬ࠯ࠧ䁜")
			l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ䁝"),l1l1l1l_ll_+title,link,312)
	elif seq in [l111lll_ll_ (u"ࠧ࠲ࠩ䁞"),l111lll_ll_ (u"ࠨ࠴ࠪ䁟"),l111lll_ll_ (u"ࠩ࠶ࠫ䁠")]:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࠬࡁ࡮࠵࠿࠰࠭ࡃ࠮ࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡲ࠭࡭ࡩࠪ䁡"),html,re.DOTALL)
		l11ll11ll1ll_ll_ = int(seq)-1
		block = l1lll_ll_[l11ll11ll1ll_ll_]
		if seq==l111lll_ll_ (u"ࠫ࠶࠭䁢"): items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡴࡶࡵࡳࡳ࡭࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭䁣"),block,re.DOTALL)
		else: items = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ䁤"),block,re.DOTALL)
		for link,img,title,name in items:
			title = title.strip(l111lll_ll_ (u"ࠧࠡࠩ䁥"))
			name = name.strip(l111lll_ll_ (u"ࠨࠢࠪ䁦"))
			title = title+l111lll_ll_ (u"ࠩࠣࠬࠬ䁧")+name+l111lll_ll_ (u"ࠪ࠭ࠬ䁨")
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䁩"),l1l1l1l_ll_+title,link,311,img)
	elif seq in [l111lll_ll_ (u"ࠬ࠺ࠧ䁪"),l111lll_ll_ (u"࠭࠵ࠨ䁫"),l111lll_ll_ (u"ࠧ࠷ࠩ䁬")]:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࠪ࠿࡬࠺ࡄ࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ䁭"),html,re.DOTALL)
		seq = int(seq)-4
		block = l1lll_ll_[seq]
		items = re.findall(l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠯ࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䁮"),block,re.DOTALL)
		for img,link,l11l11l11l_ll_,title,l11l11ll11_ll_ in items:
			title = title.strip(l111lll_ll_ (u"ࠪࠤࠬ䁯"))
			l11l11l11l_ll_ = l11l11l11l_ll_.strip(l111lll_ll_ (u"ࠫࠥ࠭䁰"))
			l11l11ll11_ll_ = l11l11ll11_ll_.strip(l111lll_ll_ (u"ࠬࠦࠧ䁱"))
			if l11l11l11l_ll_: name = l11l11l11l_ll_
			else: name = l11l11ll11_ll_
			title = title+l111lll_ll_ (u"࠭ࠠࠩࠩ䁲")+name+l111lll_ll_ (u"ࠧࠪࠩ䁳")
			l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ䁴"),l1l1l1l_ll_+title,link,312,img)
	return
def l1l11l1_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࠪ䁵"))
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ䁶"),url,l111lll_ll_ (u"ࠫࠬ䁷"),l111lll_ll_ (u"ࠬ࠭䁸"),l111lll_ll_ (u"࠭ࠧ䁹"),l111lll_ll_ (u"ࠧࠨ䁺"),l111lll_ll_ (u"ࠨࡕࡋࡍࡆ࡜ࡏࡊࡅࡈ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ䁻"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡦࡴࡾ࠭ࡩࡧࡤࡨ࡮ࡴࡧࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡦ࡭ࡱࡤࡸ࠲ࡸࡩࡨࡪࡷࠫ䁼"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡴࡳࡱࡱ࡫ࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡤࡣࡷࡷࡺࡳ࠭࡮ࡱࡥ࡭ࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䁽"),block,re.DOTALL)
	if items:
		for img,link,title,count in items:
			count = count.replace(l111lll_ll_ (u"ࠫࠥอไึ๊อ๎ฮࡀࠠࠨ䁾"),l111lll_ll_ (u"ࠬࡀࠧ䁿"))
			title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ䂀"))
			title = title+l111lll_ll_ (u"ࠧࠡࠪࠪ䂁")+count+l111lll_ll_ (u"ࠨࠫࠪ䂂")
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䂃"),l1l1l1l_ll_+title,link,311,img)
	else: l1l11ll_ll_(html)
	return
def l1l11ll_ll_(html):
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥ࡭ࡧࡵࡸ࠮ࡥࡲࡲࡹ࡫࡮ࡵࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠫ䂄"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡨࡰࡱࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࡦࡩࡱࡲࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡧࡪࡲ࡬ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ䂅"),block,re.DOTALL)
	for link,title,name,count,duration in items:
		#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭䂆"),link+l111lll_ll_ (u"࠭ࠬࠨ䂇")+title+l111lll_ll_ (u"ࠧ࠭ࠩ䂈")+name+l111lll_ll_ (u"ࠨ࠮ࠪ䂉")+count+l111lll_ll_ (u"ࠩ࠯ࠫ䂊")+duration)
		title = title.strip(l111lll_ll_ (u"ࠪࠤࠬ䂋"))
		name = name.strip(l111lll_ll_ (u"ࠫࠥ࠭䂌"))
		title = title+l111lll_ll_ (u"ࠬࠦࠨࠨ䂍")+name+l111lll_ll_ (u"࠭ࠩࠨ䂎")
		l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䂏"),l1l1l1l_ll_+title,link,312,l111lll_ll_ (u"ࠨࠩ䂐"),duration)
	return
def l11ll11ll1l1_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭䂑"),url,l111lll_ll_ (u"ࠪࠫ䂒"),l111lll_ll_ (u"ࠫࠬ䂓"),l111lll_ll_ (u"ࠬ࠭䂔"),l111lll_ll_ (u"࠭ࠧ䂕"),l111lll_ll_ (u"ࠧࡔࡊࡌࡅ࡛ࡕࡉࡄࡇ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧ䂖"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠠࡱ࠯࠴ࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤ࡬ࡦࡴࡾ࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠩ䂗"),html,re.DOTALL)
	if not l1lll_ll_:
		l1l11ll_ll_(html)
		return
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ䂘"),block,re.DOTALL)
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"ࠪࠤࠬ䂙"))
		l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ䂚"),l1l1l1l_ll_+title,link,312)
	return
def l11_ll_(url):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ䂛"),url,l111lll_ll_ (u"࠭ࠧ䂜"),l111lll_ll_ (u"ࠧࠨ䂝"),l111lll_ll_ (u"ࠨࠩ䂞"),l111lll_ll_ (u"ࠩࠪ䂟"),l111lll_ll_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ䂠"))
	html = response.content
	link = re.findall(l111lll_ll_ (u"ࠫࡁࡧࡵࡥ࡫ࡲ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ䂡"),html,re.DOTALL)
	if not link: link = re.findall(l111lll_ll_ (u"ࠬࡂࡶࡪࡦࡨࡳ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ䂢"),html,re.DOTALL)
	link = link[0]
	l111lll1_ll_(link,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ䂣"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠧࠨ䂤"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠨࠩ䂥"): return
	search = search.replace(l111lll_ll_ (u"ࠩࠣࠫ䂦"),l111lll_ll_ (u"ࠪ࠯ࠬ䂧"))
	l111l1lll1_ll_ = [l111lll_ll_ (u"ࠫࠫࡺ࠽ࡢࠩ䂨"),l111lll_ll_ (u"ࠬࠬࡴ࠾ࡥࠪ䂩"),l111lll_ll_ (u"࠭ࠦࡵ࠿ࡶࠫ䂪")]
	if l1ll11_ll_:
		l111l111ll_ll_ = [l111lll_ll_ (u"ࠧใษิสࠬ䂫"),l111lll_ll_ (u"ࠨวุำฬืࠠ࠰่ࠢะ้ีࠧ䂬"),l111lll_ll_ (u"่ࠩๆ฼฿ࠠศๆุ์ฯ๐ࠧ䂭")]
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠪวำะัࠡษ็ฬาัࠠศๆ่๊ฬูศࠨ䂮"), l111l111ll_ll_)
		if selection == -1: return
	else: selection = 2
	type = l111l1lll1_ll_[selection]
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬࠳ࡶࡨࡱࡁࡴࡁࠬ䂯")+search+type
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ䂰"),url,l111lll_ll_ (u"࠭ࠧ䂱"),l111lll_ll_ (u"ࠧࠨ䂲"),l111lll_ll_ (u"ࠨࠩ䂳"),l111lll_ll_ (u"ࠩࠪ䂴"),l111lll_ll_ (u"ࠪࡗࡍࡏࡁࡗࡑࡌࡇࡊ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ䂵"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡮ࡨ࡯ࡹ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽ࠣ࡫ࡥࡳࡽ࠳ࡣࡰࡰࡷࡩࡳࡺࠢࠨ䂶"),html,re.DOTALL)
	block = l1lll_ll_[0]
	if selection in [0,1]:
		items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ䂷"),block,re.DOTALL)
		for link,img,title,name in items:
			title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ䂸"))
			name = name.strip(l111lll_ll_ (u"ࠧࠡࠩ䂹"))
			title = title+l111lll_ll_ (u"ࠨࠢࠫࠫ䂺")+name+l111lll_ll_ (u"ࠩࠬࠫ䂻")
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䂼"),l1l1l1l_ll_+title,link,313,img)
	elif selection==2:
		items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿࠾࠲ࡸࡩࡄ࠼ࡵࡦࡁࠬ࠳࠰࠿ࠪ࠾ࠪ䂽"),block,re.DOTALL)
		for link,title,name in items:
			title = title.strip(l111lll_ll_ (u"ࠬࠦࠧ䂾"))
			name = name.strip(l111lll_ll_ (u"࠭ࠠࠨ䂿"))
			title = title+l111lll_ll_ (u"ࠧࠡࠪࠪ䃀")+name+l111lll_ll_ (u"ࠨࠫࠪ䃁")
			l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ䃂"),l1l1l1l_ll_+title,link,312)
	return