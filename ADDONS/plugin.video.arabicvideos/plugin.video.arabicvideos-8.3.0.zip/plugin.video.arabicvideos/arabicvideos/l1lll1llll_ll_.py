# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
#
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠪࡈࡔ࡝ࡎࡍࡑࡄࡈࠬᒶ")
def l111l1l_ll_(mode,url,context):
	#l1ll1l_ll_(url,context)
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if context==l111lll_ll_ (u"ࠫ࠻ࡥࡒࡆࡏࡒ࡚ࡊ࠭ᒷ"): results = l1llll1ll1_ll_(url)
	elif mode==330: results = l11111ll1_ll_()
	elif mode==331: results = l11_ll_(url)
	elif mode==332: results = l1llll1lll_ll_()
	elif mode==333: results = l1lll1l111_ll_()
	else: results = False
	return results
def l1llll1ll1_ll_(l1lllll1l1_ll_):
	try: os.remove(l1lllll1l1_ll_.decode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪᒸ")))
	except: os.remove(l1lllll1l1_ll_)
	return
def l11_ll_(url):
	result = l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬᒹ"))
	#xbmc.Player().play(url)
	#l1ll1l_ll_(url,result)
	return
def l1lll1l111_ll_():
	message = l111lll_ll_ (u"ࠧฤา๊ฬࠥอไ๊ࠢิหอ฽ࠠศๆไ๎ิ๐่ࠡษ๋ࠤฬ๊ี้ฬࠣๅ๏ࠦวๅ็๋ๆ฾ࠦวๅ็ฺ่ํฮࠠฬ็ࠣว฻เืࠡ฻็ํุࠥัࠡษ็ๆฬฬๅสࠢส่๏๋๊็ࠢฮ้ࠥษฮหษิࠤࠧะอๆ์็ࠤ๊๊แศฬࠣๅ๏ี๊้ࠤࠣฯ๊ࠦวฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢหำะวา้ࠢ์฾ࠦๅๅใࠣห้฻่าหࠣ์อ฿ฯ่ษࠣืํ็๋ࠠสาวࠥอไหฯ่๎้࠭ᒺ")
	l1ll1l_ll_(l111lll_ll_ (u"ࠨูิ๎็ฯࠠหฯ่๎้ࠦวๅ็็ๅฬะࠧᒻ"),message)
	return
def l11111ll1_ll_():
	l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᒼ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ฽ั๋ไฬࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊࡞࠳ࡈࡕࡌࡐࡔࡠࠫᒽ"),l111lll_ll_ (u"ࠫࠬᒾ"),333)
	l1llll1l1l_ll_ = l1llll1l11_ll_()
	mtime = os.stat(l1llll1l1l_ll_).st_mtime
	files = []
	for filename in os.listdir(unicode(l1llll1l1l_ll_,l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪᒿ"))):
		if not filename.startswith(l111lll_ll_ (u"࠭ࡦࡪ࡮ࡨࡣࠬᓀ")): continue
		filepath = os.path.join(l1llll1l1l_ll_,filename)
		mtime = os.path.getmtime(filepath)
		#ctime = os.path.getctime(filepath)
		#mtime = os.stat(filepath).l11111l1l_ll_
		#filename = filename.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬᓁ")).encode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭ᓂ"))
		files.append([filename,mtime])
	files = sorted(files,reverse=True,key=lambda key: key[1])
	for filename,mtime in files:
		#l1ll1l_ll_(filename,filename)
		filename = filename.decode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧᓃ")).encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨᓄ"))
		filepath = os.path.join(l1llll1l1l_ll_,filename)
		l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪᓅ"),filename,filepath,331)
	return
def l1llll1l11_ll_():
	l1llll1l1l_ll_ = settings.getSetting(l111lll_ll_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠮ࡱࡣࡷ࡬ࠬᓆ"))
	if l1llll1l1l_ll_!=l111lll_ll_ (u"࠭ࠧᓇ"): return l1llll1l1l_ll_
	settings.setSetting(l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧᓈ"),l1lll11ll1_ll_)
	return l1lll11ll1_ll_
def l1llll1lll_ll_():
	l1llll1l1l_ll_ = l1llll1l11_ll_()
	l1lll1lll1_ll_ = l1llll1111_ll_(l1llll1l1l_ll_,l111lll_ll_ (u"ࠨ้ำหࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโษอࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮา๋ไ่ษࠣห๋ะࠠษษึฮำีวๆ๊ࠢิฬࠦวๅสิ๊ฬ๋ฬࠡ࠰๋้ࠣࠦสา์าࠤฯเ๊๋ำࠣห้๋ใศ่ࠣรࠬᓉ"),l111lll_ll_ (u"ࠩࠪᓊ"),l111lll_ll_ (u"ࠪࠫᓋ"),l111lll_ll_ (u"่๊ࠫวࠨᓌ"),l111lll_ll_ (u"ࠬ์ูๆࠩᓍ"))
	if l1lll1lll1_ll_:
		newpath = l1lllll111_ll_(3,l111lll_ll_ (u"࠭ๅไษ้ࠤฯำๅ๋ๆ้้ࠣ็วหࠢส่ๆ๐ฯ๋๊ࠪᓎ"),l111lll_ll_ (u"ࠧ࡭ࡱࡦࡥࡱ࠭ᓏ"),l111lll_ll_ (u"ࠨࠩᓐ"),False,True,l1llll1l1l_ll_)
		l111111l1_ll_ = l1llll1111_ll_(newpath,l111lll_ll_ (u"๊ࠩิฬࠦ็้ࠢส่๊้ว็ࠢส่ัี๊ะࠢ็ฮำุ๊็่่ࠢๆอสࠡษ็ๅ๏ี๊้ࠢส่ฯ๐ࠠหฯ่่์อࠠศ่อࠤออำหะาห๊ࠦ็ัษࠣห้ฮั็ษ่ะࠥ࠴่ࠠๆࠣฮึ๐ฯࠡษึฮำีวๆ้ࠣฬิ๊วࠡ็้ࠤฬ๊ๅไษ้ࠤฬ๊โะ์่ࠤฤ࠭ᓑ"),l111lll_ll_ (u"ࠪࠫᓒ"),l111lll_ll_ (u"ࠫࠬᓓ"),l111lll_ll_ (u"้ࠬไศࠩᓔ"),l111lll_ll_ (u"࠭ๆฺ็ࠪᓕ"))
		if l111111l1_ll_:
			settings.setSetting(l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳࡥࡹ࡮ࠧᓖ"),newpath)
			l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᓗ"),l111lll_ll_ (u"ࠩอ้ࠥะฺ๋์ิࠤ๊้ว็ࠢอาื๐ๆࠡษ็้้็วหࠢส่๊ำๅๅหࠪᓘ"))
	#if not l1lll1lll1_ll_ or not l111111l1_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᓙ"),l111lll_ll_ (u"ࠫฯ๋ࠠศๆ฽หฦࠦวๅ฻่่๏ฯࠧᓚ"))
	return
def l1llll11ll_ll_(url,l1lll11l1l_ll_):
	l1ll11l_ll_(l111lll_ll_ (u"ࠬ๐ัอ๋ࠣห้อๆหฺสีࠬᓛ"),l111lll_ll_ (u"࠭ฬศำํࠤๆำีࠡ็็ๅࠥอไหฯ่๎้࠭ᓜ"))
	l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᓝ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡕࡸࡥࡱࡣࡵ࡭ࡳ࡭ࠠࡵࡱࠣࡨࡴࡽ࡮࡭ࡱࡤࡨࠥࡺࡨࡦࠢࡹ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᓞ")+url+l111lll_ll_ (u"ࠩࠣࡡࠬᓟ"))
	#l1ll1l_ll_(url,l1lll11l1l_ll_)
	if l1lll11l1l_ll_==l111lll_ll_ (u"ࠪࠫᓠ"):
		if l111lll_ll_ (u"ࠫࡲࡶ࠴ࠨᓡ") in url.lower(): l1lll11l1l_ll_ = l111lll_ll_ (u"ࠬ࠴࡭ࡱ࠶ࠪᓢ")
		elif l111lll_ll_ (u"࠭࡭࠴ࡷ࠻ࠫᓣ") in url.lower(): l1lll11l1l_ll_ = l111lll_ll_ (u"ࠧ࠯࡯࠶ࡹ࠽࠭ᓤ")
		elif l111lll_ll_ (u"ࠨࡹࡨࡦࡲ࠭ᓥ") in url.lower(): l1lll11l1l_ll_ = l111lll_ll_ (u"ࠩ࠱ࡻࡪࡨ࡭ࠨᓦ")
		else: l1lll11l1l_ll_ = l111lll_ll_ (u"้ࠪัํ่ๅࠩᓧ")
	if l1lll11l1l_ll_ not in [l111lll_ll_ (u"ࠫ࠳ࡺࡳࠨᓨ"),l111lll_ll_ (u"ࠬ࠴࡭࡬ࡸࠪᓩ"),l111lll_ll_ (u"࠭࠮࡮ࡲ࠷ࠫᓪ"),l111lll_ll_ (u"ࠧ࠯࡯ࡳ࠷ࠬᓫ"),l111lll_ll_ (u"ࠨ࠰ࡩࡰࡻ࠭ᓬ"),l111lll_ll_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᓭ"),l111lll_ll_ (u"ࠪ࠲ࡦࡼࡩࠨᓮ"),l111lll_ll_ (u"ࠫ࠳ࡽࡥࡣ࡯ࠪᓯ")]:
		l1ll1l_ll_(l111lll_ll_ (u"ࠬะๆำ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᓰ"),l111lll_ll_ (u"࠭วๅ็็ๅ๋ࠥๆ่๋ࠡ฽ࠥ࠭ᓱ")+l1lll11l1l_ll_+l111lll_ll_ (u"๊ࠧࠡส่อืๆศ็ฯࠤาอไ๋ษࠣ฾๏ืࠠอษ๊ึ๊ࠥสฮ็ํ่ࠥํะศࠢส่๋๎ูࠡ็้ࠤฬ๊ๅๅใสฮࠬᓲ"))
		l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭ᓳ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥ࡜ࡩࡥࡧࡲࠤࡹࡿࡰࡦ࠱ࡨࡼࡹ࡫࡮ࡴ࡫ࡲࡲࠥ࡯ࡳࠡࡰࡲࡸࠥࡹࡵࡱࡲࡲࡶࡹ࡫ࡤ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᓴ")+url+l111lll_ll_ (u"ࠪࠤࡢ࠭ᓵ"))
		return
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫ࡫ࡸࡥࡦࠢࡶࡴࡦࡩࡥࠨᓶ"),str(l1111111l_ll_))
	filename = l1l1l_ll_.replace(l111lll_ll_ (u"ࠬࠦࠠࠨᓷ"),l111lll_ll_ (u"࠭ࠠࠨᓸ")).replace(l111lll_ll_ (u"ࠧࠡࠩᓹ"),l111lll_ll_ (u"ࠨࡡࠪᓺ"))
	filename = l111lll_ll_ (u"ࠩࡩ࡭ࡱ࡫࡟ࠨᓻ")+str(int(now))[-4:]+l111lll_ll_ (u"ࠪࡣࠬᓼ")+filename+l1lll11l1l_ll_
	l1llll1l1l_ll_ = l1llll1l11_ll_()
	l1lll111ll_ll_ = l1lllllll1_ll_(filename).decode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩᓽ"))
	l11111111_ll_ = os.path.join(l1llll1l1l_ll_,l1lll111ll_ll_)
	l1lllll1l1_ll_ = os.path.join(l1llll1l1l_ll_,filename)
	#l1ll1l_ll_(l1llll1l1l_ll_,filename)
	url = url.replace(l111lll_ll_ (u"ࠬࡼࡥࡳ࡫ࡩࡽࡵ࡫ࡥࡳ࠿ࡩࡥࡱࡹࡥࠨᓾ"),l111lll_ll_ (u"࠭ࠧᓿ"))
	if l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࡁࠬᔀ") in url:
		l1ll111_ll_,l1ll11l11_ll_ = url.rsplit(l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࡂ࠭ᔁ"),1)
		l1ll11l11_ll_ = l1ll11l11_ll_.replace(l111lll_ll_ (u"ࠩࡿࠫᔂ"),l111lll_ll_ (u"ࠪࠫᔃ")).replace(l111lll_ll_ (u"ࠫࠫ࠭ᔄ"),l111lll_ll_ (u"ࠬ࠭ᔅ"))
	else: l1ll111_ll_,l1ll11l11_ll_ = url,None
	if l111lll_ll_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸ࠽ࠨᔆ") in l1ll111_ll_: l1ll111_ll_,referer = l1ll111_ll_.rsplit(l111lll_ll_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲ࠾ࠩᔇ"),1)
	else: l1ll111_ll_,referer = l1ll111_ll_,l111lll_ll_ (u"ࠨࠩᔈ")
	l1ll111_ll_ = l1ll111_ll_.strip(l111lll_ll_ (u"ࠩࡿࠫᔉ")).strip(l111lll_ll_ (u"ࠪࠪࠬᔊ")).strip(l111lll_ll_ (u"ࠫࢁ࠭ᔋ")).strip(l111lll_ll_ (u"ࠬࠬࠧᔌ"))
	referer = referer.replace(l111lll_ll_ (u"࠭ࡼࠨᔍ"),l111lll_ll_ (u"ࠧࠨᔎ")).replace(l111lll_ll_ (u"ࠨࠨࠪᔏ"),l111lll_ll_ (u"ࠩࠪᔐ"))
	headers = {l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧᔑ"):l1ll11l11_ll_}
	if referer!=l111lll_ll_ (u"ࠫࠬᔒ"):	headers[l111lll_ll_ (u"ࠬࡘࡥࡧࡧࡵࡩࡷ࠭ᔓ")] = referer
	l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᔔ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡈࡴࡽ࡮࡭ࡱࡤࡨ࡮ࡴࡧࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥࠦࠠࡖࡔࡏ࠾ࠥࡡࠠࠨᔕ")+l1ll111_ll_+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡈࡦࡣࡧࡩࡷࡹ࠺ࠡ࡝ࠣࠫᔖ")+str(headers)+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᔗ")+l1lllll1l1_ll_+l111lll_ll_ (u"ࠪࠤࡢ࠭ᔘ"))
	#l1ll1l_ll_(l1ll111_ll_,str(headers))
	#l1ll1l_ll_(xbmc.getInfoLabel(l111lll_ll_ (u"ࠫࡘࡿࡳࡵࡧࡰ࠲࡚ࡹࡥࡥࡕࡳࡥࡨ࡫ࠧᔙ")),xbmc.getInfoLabel(l111lll_ll_ (u"࡙ࠬࡹࡴࡶࡨࡱ࠳࡚࡯ࡵࡣ࡯ࡗࡵࡧࡣࡦࠩᔚ")))
	#l1ll1l_ll_(xbmc.getInfoLabel(l111lll_ll_ (u"࠭ࡓࡺࡵࡷࡩࡲ࠴ࡕࡴࡧࡧࡗࡵࡧࡣࡦࡒࡨࡶࡨ࡫࡮ࡵࠩᔛ")),xbmc.getInfoLabel(l111lll_ll_ (u"ࠧࡔࡻࡶࡸࡪࡳ࠮ࡇࡴࡨࡩࡘࡶࡡࡤࡧࡓࡩࡷࡩࡥ࡯ࡶࠪᔜ")))
	l11111lll_ll_ = 1024*1024
	l1llllllll_ll_ =	xbmc.getInfoLabel(l111lll_ll_ (u"ࠨࡕࡼࡷࡹ࡫࡭࠯ࡈࡵࡩࡪ࡙ࡰࡢࡥࡨࠫᔝ"))
	l1111111l_ll_ = int(re.findall(l111lll_ll_ (u"ࠩ࡟ࡨ࠰࠭ᔞ"),l1llllllll_ll_)[0])
	if l1111111l_ll_==0:
		try:
			st = os.l1lll11l11_ll_(l1llll1l1l_ll_)
			l1111111l_ll_ = st.f_frsize*st.f_bavail/l11111lll_ll_
			#l1ll1l_ll_(l1llll11l1_ll_,str(l1111111l_ll_))
			#string = str(st.f_bavail)+l111lll_ll_ (u"ࠪ࠰ࠬᔟ")+str(st.f_frsize)+l111lll_ll_ (u"ࠫ࠱࠭ᔠ")+str(st.f_blocks)
			#string += l111lll_ll_ (u"ࠬ࠲ࠧᔡ")+str(st.f_bfree)+l111lll_ll_ (u"࠭ࠬࠨᔢ")+str(st.f_bsize)+l111lll_ll_ (u"ࠧ࠭ࠩᔣ")+str(st.f_ffree)
			#l1ll1l_ll_(str(l1llllll1l_ll_),str(dir(st)))
		except: pass
		if l1111111l_ll_==0:
			l1111l11l_ll_(l111lll_ll_ (u"ࠨ็ึหาฯࠠศๆอาื๐ๆࠡ็ฯ๋ํ๊ษࠨᔤ"),l111lll_ll_ (u"ࠩ็่ศูแࠡษ็ฬึ์วๆฮࠣ฾๏ืࠠใษาีࠥษๆࠡ์ะำิࠦๅใัสี๋ࠥำศฯฬࠤฬ๊สฯิํ๊ࠥอไโษิ฾ฮࠦแ๋ࠢฯ๋ฬุใ๊ࠡ฼่๏ํࠠโษ้ࠤฯำๅ๋ๆࠣห้็๊ะ์๋๋ฬะࠠๅ่ࠣ๎฾๋ไࠡ฻้ำ่ࠦลๅ๋ࠣว๋๊ࠦใ๊่ࠤ๊ฮัๆฮํࠤอืๆศ็ฯࠤ่๎ฯ๋ࠢหั้ࠦ็ั้ࠣห้๋ิไๆฬࠤ้อๆࠡฬะ้๏๊ࠠศๆไ๎ิ๐่่ษอࠤ็ี๋ࠠีหฬࠥอๅหๆสลࠥา็ศิๆࠤออไๆๆไหฯ่่ࠦาสࠤๆ๐็ࠡะฺ์ึฯฺࠠๆ์ࠤ฾๋ไࠡฮ๊หื้ࠠษื๋ีฮࠦีฮ์ะอࠥ๎ไ่าสࠤฬ๊ำษสࠣๆฬ๋ࠠศๆ่ฬึ๋ฬࠡ็วๆฯอࠠษ็้฽ࠥอไษำ้ห๊าࠠๆ่ࠣฮา๋๊ๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭ᔥ"),l111lll_ll_ (u"ࠪࡦ࡮࡭ࠧᔦ"),l111lll_ll_ (u"ࠫࡷ࡯ࡧࡩࡶࠪᔧ"))
			l1111l1l_ll_(l111lll_ll_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᔨ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡘࡲࡦࡨ࡬ࡦࠢࡷࡳࠥࡪࡥࡵࡧࡵࡱ࡮ࡴࡥࠡࡶ࡫ࡩࠥࡪࡩࡴ࡭ࠣࡪࡷ࡫ࡥࠡࡵࡳࡥࡨ࡫ࠧᔩ"))
			return
	import requests
	headers[l111lll_ll_ (u"ࠧࡂࡥࡦࡩࡵࡺ࠭ࡆࡰࡦࡳࡩ࡯࡮ࡨࠩᔪ")] = l111lll_ll_ (u"ࠨࠩᔫ")
	if l1lll11l1l_ll_==l111lll_ll_ (u"ࠩ࠱ࡱ࠸ࡻ࠸ࠨᔬ"):
		l11111111_ll_ = l11111111_ll_.rsplit(l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᔭ"))[0]+l111lll_ll_ (u"ࠫ࠳ࡳࡰ࠵ࠩᔮ")
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩᔯ"),l1ll111_ll_,l111lll_ll_ (u"࠭ࠧᔰ"),headers,l111lll_ll_ (u"ࠧࠨᔱ"),l111lll_ll_ (u"ࠨࠩᔲ"),l111lll_ll_ (u"ࠩࡇࡓ࡜ࡔࡌࡐࡃࡇ࠱ࡉࡕࡗࡏࡎࡒࡅࡉࡥࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩᔳ"))
		l1111111_ll_ = response.content
		l1l111l_ll_ = []
		links = re.findall(l111lll_ll_ (u"ࠪࡠࠨࡋࡘࡕࡋࡑࡊ࠿࠴ࠪࡀ࡝࡟ࡲࡡࡸ࡝ࠩ࠰࠭ࡃ࠮ࡡ࡜࡯࡞ࡵࡡࠬᔴ"),l1111111_ll_+l111lll_ll_ (u"ࠫࡡࡴ࡜ࡳࠩᔵ"),re.DOTALL)
		if not links:
			l1111l1l_ll_(l111lll_ll_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪᔶ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡗ࡬ࡪࠦ࡭࠴ࡷ࠻ࠤ࡫࡯࡬ࡦࠢࡧ࡭ࡩࠦ࡮ࡰࡶࠣ࡬ࡦࡼࡥࠡࡶ࡫ࡩࠥࡸࡥࡲࡷ࡬ࡶࡪࡪࠠ࡭࡫ࡱ࡯ࡸࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩᔷ")+l1ll111_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪᔸ"))
			return
		try: file = open(l11111111_ll_,l111lll_ll_ (u"ࠨࡹࡥࠫᔹ"))
		except: file = open(l11111111_ll_.encode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧᔺ")),l111lll_ll_ (u"ࠪࡻࡧ࠭ᔻ"))
		response = requests.get(links[0])
		chunk = response.content
		response.close()
		file.write(chunk)
		chunksize = len(chunk)
		l1llll111l_ll_ = len(links)
		filesize = chunksize*l1llll111l_ll_
	else:
		chunksize = 1*l11111lll_ll_
		response = requests.request(l111lll_ll_ (u"ࠫࡌࡋࡔࠨᔼ"),l1ll111_ll_,headers=headers,verify=False,stream=True)
		try: filesize = int(response.headers[l111lll_ll_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡌࡦࡰࡪࡸ࡭࠭ᔽ")])
		except: filesize = 0
		l1llll111l_ll_ = int(filesize/chunksize)
		if filesize>102400:
			try: file = open(l11111111_ll_,l111lll_ll_ (u"࠭ࡷࡣࠩᔾ"))
			except: file = open(l11111111_ll_.encode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬᔿ")),l111lll_ll_ (u"ࠨࡹࡥࠫᕀ"))
	l111111ll_ll_ = int(1+filesize/l11111lll_ll_)
	if filesize<=102400:
		l1111l1l_ll_(l111lll_ll_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧᕁ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡖࡪࡦࡨࡳࠥ࡬ࡩ࡭ࡧࠣ࡭ࡸࠦࡴࡰࡱࠣࡷࡲࡧ࡬࡭ࠢࡤࡲࡩ࠵࡯ࡳࠢࡶࡳࡲ࡫ࡴࡩ࡫ࡱ࡫ࠥࡽࡲࡰࡰࡪࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᕂ")+l1ll111_ll_+l111lll_ll_ (u"ࠫࠥࡣ࡙ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡳࡪࡼࡨ࠾ࠥࡡࠠࠨᕃ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠬࠦࡍࡃࠢࡠࠤࠥࠦࡁࡷࡣ࡬ࡰࡦࡨ࡬ࡦࠢࡶ࡭ࡿ࡫࠺ࠡ࡝ࠣࠫᕄ")+str(l1111111l_ll_)+l111lll_ll_ (u"࠭ࠠࡎࡄࠣࡡࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩᕅ")+l1lllll1l1_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪᕆ"))
		l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫᕇ"),l111lll_ll_ (u"ࠩไุ้ࠦแ๋่ࠢ฽ึ็ษࠡฯฯ้๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣ์้ํะศࠢ็หࠥ๐ๅไ่่้ࠣฮั็ษ่ะࠥะอๆ์็ࠤ์ึวࠡษ็้้็ࠧᕈ"))
		if l1lll11l1l_ll_==l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᕉ"): file.close()
		return
	l1lll1l1ll_ll_ = l1111111l_ll_-l111111ll_ll_
	if l1lll1l1ll_ll_<500:
		l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩᕊ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡐࡲࡸࠥ࡫࡮ࡰࡷࡪ࡬ࠥࡪࡩࡴ࡭ࠣࡷࡵࡧࡣࡦࠢࡷࡳࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡵࡪࡨࠤࡻ࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥ࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫᕋ")+l1ll111_ll_+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤ࡛࡯ࡤࡦࡱࠣࡪ࡮ࡲࡥࠡࡵ࡬ࡾࡪࡀࠠ࡜ࠢࠪᕌ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠧࠡࡏࡅࠤࡢࠦࠠࠡࡃࡹࡥ࡮ࡲࡡࡣ࡮ࡨࠤࡸ࡯ࡺࡦ࠼ࠣ࡟ࠥ࠭ᕍ")+str(l1111111l_ll_)+l111lll_ll_ (u"ࠨࠢࡐࡆࠥࡣࠠࠡࠢࡉ࡭ࡱ࡫࠺ࠡ࡝ࠣࠫᕎ")+l1lllll1l1_ll_+l111lll_ll_ (u"ࠩࠣࡡࠬᕏ"))
		l1ll1l_ll_(l111lll_ll_ (u"่ࠪฬ๊้ࠦฮาࠤู๊วฮหࠣ็ฬ็๊สࠢ็่ฯำๅ๋ๆࠪᕐ"),l111lll_ll_ (u"ࠫฬ๊ๅๅใࠣห้๋ืๅ๊หࠤฯำๅ๋ๆ๊ࠤาาๅ่ࠢࠪᕑ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠬࠦๅ๋฼สฬฬ๐ส๊ࠡฯ๋ฬุใࠡใํ๋๋ࠥำศฯฬࠤๆอั฻หࠣࠫᕒ")+str(l1111111l_ll_)+l111lll_ll_ (u"࠭ࠠๆ์฽หออ๊ห๋่้๋ࠢอศใ฻อࠥ฿ไ๊ࠢ฼้้ࠦฬ่ษี็ࠥฮฯู้่้ࠣอใๅࠢํะอࠦวษไสลࠥ࠻࠰࠱่ࠢ๎฿อศศ์อࠤๆอั฻หࠣำฬฬๅศ๋๋ࠢีอࠠๆ฻้ห์ࠦฬ่ษี็๊ࠥวࠡฬ๋ะิࠦแุ๋้้ࠣออสࠢๆหๆ๐ษࠡๆอั๊๐ไࠡ็็ๅࠥอไโ์า๎ํࠦวๅ็ฺ่ํฮࠧᕓ"))
		file.close()
		return
	l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"่ࠧๆࠣฮึ๐ฯࠡฬะ้๏๊ࠠศๆ่่ๆࠦฟࠨᕔ"),l111lll_ll_ (u"ࠨษ็้้็ࠠศๆ่฻้๎ศࠡฯฯ้์ࠦสใำํฬฬࠦࠧᕕ")+str(l111111ll_ll_)+l111lll_ll_ (u"้ࠩࠣ๏เวษษํฮࠥ๎ฬ่ษี็ࠥ็๊่่ࠢืฬำษࠡใสี฿ฯࠠหไิ๎ออࠠࠨᕖ")+str(l1111111l_ll_)+l111lll_ll_ (u"ࠪࠤ๊๐ฺศสส๎ฯ่่ࠦาสࠤฬ๊ๅๅใࠣๆิ๊ࠦฮฬสะࠥฮูืࠢส่ํ่สࠡๆ็ฮา๋๊ๅ่๊ࠢࠥอไฤ่อี๋๐สࠡว็ํࠥา็ศิๆࠤ࠳ࠦ็ๅࠢส๊ฯࠦๅหลๆำࠥ๎สา์าࠤฬ๊วิฬ่ีฬืࠠษฬะ้๏๊ࠠๆๆไࠤฬ๊แ๋ัํ์ࠥลࠧᕗ"),l111lll_ll_ (u"ࠫࠬᕘ"),l111lll_ll_ (u"ࠬ࠭ᕙ"),l111lll_ll_ (u"࠭ใๅษࠪᕚ"),l111lll_ll_ (u"ࠧ็฻่ࠫᕛ"))
	if not l111111l1_ll_:
		l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩᕜ"),l111lll_ll_ (u"ࠩอ้ࠥหไ฻ษฤࠤ฾๋ไ๋หࠣฮา๋๊ๅ่่ࠢๆࠦวๅใํำ๏๎ࠧᕝ"))
		file.close()
		l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᕞ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡖࡵࡨࡶࠥࡸࡥࡧࡷࡶࡩࡩࠦࡴࡰࠢࡶࡸࡦࡸࡴࠡࡶ࡫ࡩࠥࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠࡰࡨࠣࡸ࡭࡫ࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧᕟ")+l1ll111_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡊ࡮ࡲࡥ࠻ࠢ࡞ࠤࠬᕠ")+l1lllll1l1_ll_+l111lll_ll_ (u"࠭ࠠ࡞ࠩᕡ"))
		return
	l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᕢ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡉࡵࡷ࡯࡮ࡲࡥࡩࠦࡳࡵࡣࡵࡸࡪࡪࠠࡴࡷࡦࡧࡪࡹࡳࡧࡷ࡯ࡰࡾ࠭ᕣ"))
	l1111l111_ll_ = l11111l11_ll_()
	l1111l111_ll_.create(l11111111_ll_,l111lll_ll_ (u"ࠩสุ่฽ัࠡใ๋ๆࠥํ่ࠡ็ๆห๋ࠦสฯิํ๊๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠪᕤ"))
	l1lllll1ll_ll_ = True
	t1 = time.time()
	if l1lll11l1l_ll_==l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᕥ"): # l1111111_ll_ and l1lll1ll11_ll_ chunks video files
		for i in range(1,l1llll111l_ll_):
			link = links[i]
			if l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࠩᕦ") not in link: link = l1ll111_ll_.rsplit(l111lll_ll_ (u"ࠬ࠵ࠧᕧ"),1)[0]+l111lll_ll_ (u"࠭࠯ࠨᕨ")+link
			response = requests.get(link)
			chunk = response.content
			response.close()
			file.write(chunk)
			l1lll1l1l1_ll_ = time.time()
			l1lll11lll_ll_ = l1lll1l1l1_ll_-t1
			l1lll1l11l_ll_ = l1lll11lll_ll_/i
			l1lllll11l_ll_ = l1lll1l11l_ll_*(l1llll111l_ll_+1)
			l1lll1ll1l_ll_ = l1lllll11l_ll_-l1lll11lll_ll_
			l1111l111_ll_.update(int(100*i/(l1llll111l_ll_+1)),l111lll_ll_ (u"ࠧศๆึ฻ึࠦแ้ไ๋ࠣํࠦๅไษ้ࠤฯิา๋่้้ࠣ็ࠠศๆไ๎ิ๐่ࠨᕩ"),l111lll_ll_ (u"ࠨฮ็ฬ๋ࠥไโࠢส่ๆ๐ฯ๋๊࠽࠱ࠥอไอิฤࠤึ่ๅࠨᕪ"),str(i*chunksize/l11111lll_ll_)+l111lll_ll_ (u"ࠩ࠲ࠫᕫ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠪࠤࡒࡈࠠࠡࠢࠣ์็ะࠠๆฬหๆ๏ࡀࠠࠨᕬ")+time.strftime(l111lll_ll_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᕭ"),time.gmtime(l1lll1ll1l_ll_))+l111lll_ll_ (u"ࠬࠦเࠨᕮ"))
			if l1111l111_ll_.iscanceled():
				l1lllll1ll_ll_ = False
				break
	else: # l111llll_ll_ and other l1llllll11_ll_ file videos
		i = 0
		for chunk in response.iter_content(chunk_size=chunksize):
			file.write(chunk)
			#file = file+chunk
			i = i+1
			l1lll1l1l1_ll_ = time.time()
			l1lll11lll_ll_ = l1lll1l1l1_ll_-t1
			l1lll1l11l_ll_ = l1lll11lll_ll_/i
			l1lllll11l_ll_ = l1lll1l11l_ll_*(l1llll111l_ll_+1)
			l1lll1ll1l_ll_ = l1lllll11l_ll_-l1lll11lll_ll_
			l1111l111_ll_.update(int(100*i/(l1llll111l_ll_+1)),l111lll_ll_ (u"࠭วๅีฺีࠥ็่ใ๊ࠢ์๋ࠥใศ่ࠣฮำุ๊็่่ࠢๆࠦวๅใํำ๏๎ࠧᕯ"),l111lll_ll_ (u"ࠧอๆหࠤ๊๊แࠡษ็ๅ๏ี๊้࠼࠰ࠤฬ๊ฬำรࠣี็๋ࠧᕰ"),str(i*chunksize/l11111lll_ll_)+l111lll_ll_ (u"ࠨ࠱ࠪᕱ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠩࠣࡑࡇ๋ࠦࠠࠡࠢๆฯࠦๅหสๅ๎࠿ࠦࠧᕲ")+time.strftime(l111lll_ll_ (u"ࠥࠩࡍࡀࠥࡎ࠼ࠨࡗࠧᕳ"),time.gmtime(l1lll1ll1l_ll_))+l111lll_ll_ (u"ࠫࠥๆࠧᕴ"))
			if l1111l111_ll_.iscanceled():
				l1lllll1ll_ll_ = False
				break
		response.close()
		#with open(filename,l111lll_ll_ (u"ࠬࡽࠧᕵ")) as f: f.write(file)
	file.close()
	l1111l111_ll_.close()
	if not l1lllll1ll_ll_:
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ᕶ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࡙ࠧࠡࠢࠣࡸ࡫ࡲࠡࡥࡤࡲࡨ࡫࡬࡭ࡧࡧ࠳࡮ࡴࡴࡦࡴࡵࡹࡵࡺࡥࡥࠢࡷ࡬ࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡲࡵࡳࡨ࡫ࡳࡴࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᕷ")+l1ll111_ll_+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡆࡪ࡮ࡨ࠾ࠥࡡࠠࠨᕸ")+l1lllll1l1_ll_+l111lll_ll_ (u"ࠩࠣࡡࠬᕹ"))
		l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫᕺ"),l111lll_ll_ (u"ࠫฯ๋ࠠฦๆ฽หฦูࠦๆๆํอࠥะอๆ์็ࠤ๊๊แࠡษ็ๅ๏ี๊้ࠩᕻ"))
		return
	else:
		l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬᕼ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࡙࠭ࠠࠡࠢ࡭ࡩ࡫࡯ࠡࡨ࡬ࡰࡪࠦࡤࡰࡹࡱࡰࡴࡧࡤࡦࡦࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬᕽ")+l1ll111_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤࠥࡌࡩ࡭ࡧ࠽ࠤࡠࠦࠧᕾ")+l1lllll1l1_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫᕿ"))
		l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪᖀ"),l111lll_ll_ (u"ࠪฮ๊ࠦสฮ็ํ่๋ࠥไโࠢส่ๆ๐ฯ๋๊ࠣฬ๋าวฮࠩᖁ"))
		return