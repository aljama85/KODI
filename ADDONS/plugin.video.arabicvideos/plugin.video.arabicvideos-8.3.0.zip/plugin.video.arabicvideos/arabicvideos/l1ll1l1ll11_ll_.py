# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㺖")
headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㺗") : l111lll_ll_ (u"ࠨࠩ㺘") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡗࡍࡇ࡟ࠨ㺙")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩ㺚"),l111lll_ll_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㺛"),l111lll_ll_ (u"ࠬ฿ัฺุ้้ࠣอัฺหࠪ㺜"),l111lll_ll_ (u"࠭วๅๅ็ࠫ㺝"),l111lll_ll_ (u"ࠧศใ็ห๊࠭㺞")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==110: results = l11l1ll_ll_(url)
	elif mode==111: results = l1l11l1_ll_(url)
	elif mode==112: results = l11_ll_(url)
	elif mode==113: results = l1l11ll_ll_(url)
	elif mode==114: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࡡࡢࡣࠬ㺟")+text)
	elif mode==115: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘࡥ࡟ࡠࠩ㺠")+text)
	elif mode==119: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ㺡")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬ㺢"):
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㺣"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭㺤"),l111lll_ll_ (u"ࠧࠨ㺥"),119,l111lll_ll_ (u"ࠨࠩ㺦"),l111lll_ll_ (u"ࠩࠪ㺧"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㺨"))
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㺩"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็ไหำ้ࠣาีฯࠨ㺪"),l1ll1l1_ll_,115)
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㺫"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧโๆอี้ࠥวๆๆࠪ㺬"),l1ll1l1_ll_,114)
		#l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㺭"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩไ่ฯืࠧ㺮"),l111lll_ll_ (u"ࠪࠫ㺯"),114,l1ll1l1_ll_)
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ㺰"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㺱"),l111lll_ll_ (u"࠭ࠧ㺲"),9999)
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠧࠨ㺳"),headers,l111lll_ll_ (u"ࠨࠩ㺴"),l111lll_ll_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭㺵"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࡲࡴࠦࡥࡹ࡫ࡷࠫ㺶"),html)
	if l111lll_ll_ (u"ࠫࡤࡥࡅࡳࡴࡲࡶࡤࡥࠧ㺷") not in html:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡷࡥࡧࡹࠨ࠯ࠬࡂ࠭ࡦࡪࡶࡢࡰࡦࡩࡩ࠳ࡳࡦࡣࡵࡧ࡭࠭㺸"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㺹"),block,re.DOTALL)
		for link,title in items:
			url = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫ㺺")+link
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㺻"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭㺼")+l1l1l1l_ll_+title,url,111)
		if l1111l_ll_==l111lll_ll_ (u"ࠪࠫ㺽"): l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ㺾"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ㺿"),l111lll_ll_ (u"࠭ࠧ㻀"),9999)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㻁"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㻂"),block,re.DOTALL)
		#l11ll11l1_ll_ = [l111lll_ll_ (u"่ࠩืู้ไศฬࠣࠫ㻃"),l111lll_ll_ (u"ࠪหๆ๊วๆࠢࠪ㻄"),l111lll_ll_ (u"ࠫอืวๆฮࠪ㻅"),l111lll_ll_ (u"ࠬ฿ัุ้ࠪ㻆"),l111lll_ll_ (u"࠭ใๅ์หหฯ࠭㻇"),l111lll_ll_ (u"ࠧศ฼ส๊๎࠭㻈")]
		if l111lll_ll_ (u"ࠨษไ่ฬฺ๋ࠠำห๎ࠬ㻉") not in str(items):
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻊"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ㻋")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ็ไศ็ࠣ฽ึฮ๊ࠨ㻌"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ษไ่ฬฺ๋࠭ำห๎࠲࠷ࠧ㻍"),111)
		for link,title in items:
			if l111lll_ll_ (u"࠭ࡪࡢࡸࡤࡷࡨࡸࡩࡱࡶࠪ㻎") in link: continue
			if l111lll_ll_ (u"ࠧࡩࡶࡷࡴࠬ㻏") not in link: link = l1ll1l1_ll_+link
			l111lll_ll_ (u"ࠣࠤࠥࠎࠎࠏࠉࡪࡨࠣࠫࠪ࠭ࠠࡪࡰࠣࡰ࡮ࡴ࡫࠻ࠌࠌࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦࡕࡏࡓࡘࡓ࡙ࡋࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠊࠋࠌࡰ࡮ࡴ࡫ࠡ࠿ࠣࡰ࡮ࡴ࡫࠯ࡴࡨࡴࡱࡧࡣࡦ๋ࠪࠪࠬ࠲ࠧสࠩࠬࠎࠎࠏࠉࠊ࡮࡬ࡲࡰࠦ࠽ࠡ࡮࡬ࡲࡰ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨ๋ࠪ࠰ࠬ๐ࠧࠪࠌࠌࠍࠎࠨࠢࠣ㻐")
			title = title.strip(l111lll_ll_ (u"ࠩࠣࠫ㻑"))
			#if not any(value in title for value in l11lll1_ll_):
			#	if any(value in title for value in l11ll11l1_ll_):
			if title not in l11lll1_ll_:
				l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㻒"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ㻓")+l1l1l1l_ll_+title,link,111)
	return html
def l1l11l1_ll_(url):
	#l1ll1l_ll_(url,url)
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠬ࠭㻔"),headers,True,l111lll_ll_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ㻕"))
	if l111lll_ll_ (u"ࠧࡨࡧࡷࡴࡴࡹࡴࡴࠩ㻖") in url: block = html
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡲࡤ࡫ࡪ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡹࡧࡧࡴ࠯ࡦࡰࡴࡻࡤࠨ㻗"),html,re.DOTALL)
		block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡥࡳࡽ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㻘"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	l11lllll1_ll_ = [l111lll_ll_ (u"ู้ࠪอ็ะหࠪ㻙"),l111lll_ll_ (u"ࠫๆ๐ไๆࠩ㻚"),l111lll_ll_ (u"ࠬอฺ็์ฬࠫ㻛"),l111lll_ll_ (u"࠭ใๅ์หࠫ㻜"),l111lll_ll_ (u"ࠧศ฻็ห๋࠭㻝"),l111lll_ll_ (u"ࠨ้าหๆ࠭㻞"),l111lll_ll_ (u"่ࠩฬฬืวสࠩ㻟"),l111lll_ll_ (u"ࠪ฽ึ฼ࠧ㻠"),l111lll_ll_ (u"๊ࠫํัอษ้ࠫ㻡"),l111lll_ll_ (u"ࠬอไษ๊่ࠫ㻢")]
	for img,link,title in items:
		if l111lll_ll_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ㻣") in link: continue
		link = l1111_ll_(link).strip(l111lll_ll_ (u"ࠧ࠰ࠩ㻤"))
		title = unescapeHTML(title)
		title = title.strip(l111lll_ll_ (u"ࠨࠢࠪ㻥"))
		if l111lll_ll_ (u"ࠩ࠲ࡪ࡮ࡲ࡭࠰ࠩ㻦") in link or any(value in title for value in l11lllll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㻧"),l1l1l1l_ll_+title,link,112,img)
		elif l111lll_ll_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ㻨") in link and l111lll_ll_ (u"ࠬอไฮๆๅอࠬ㻩") in title:
			episode = re.findall(l111lll_ll_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩ㻪"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠧࡠࡏࡒࡈࡤ࠭㻫") + episode[0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㻬"),l1l1l1l_ll_+title,link,113,img)
					l1ll11ll_ll_.append(title)
		else: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㻭"),l1l1l1l_ll_+title,link,113,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫ㻮"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠫࡁࡧࠠࡩࡴࡨࡪࡂࡡࠢ࡝ࠩࡠࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㻯"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l111lll_ll_ (u"ࠬอไึใะอࠥ࠭㻰"),l111lll_ll_ (u"࠭ࠧ㻱"))
			if title!=l111lll_ll_ (u"ࠧࠨ㻲"): l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㻳"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨ㻴")+title,link,111)
	return
def l1l11ll_ll_(url):
	l1l11111l_ll_,items,l11l1111_ll_ = -1,[],[]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠪࠫ㻵"),headers,True,l111lll_ll_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡅࡑࡋࡖࡓࡉࡋࡓ࠮࠳ࡶࡸࠬ㻶"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡺࡩ࠮࡮࡬ࡷࡹ࠳࡮ࡶ࡯ࡥࡩࡷ࡫ࡤࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬ㻷"),html,re.DOTALL)
	if l1lll_ll_:
		l11l1111_ll_ = []
		l1lll1l_ll_ = l111lll_ll_ (u"࠭ࠧ㻸").join(l1lll_ll_)
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㻹"),l1lll1l_ll_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡐࡦࡨࡥ࡭ࠩ㻺"))
	for link in items:
		link = link.strip(l111lll_ll_ (u"ࠩ࠲ࠫ㻻"))
		title = l111lll_ll_ (u"ࠪࡣࡒࡕࡄࡠࠩ㻼") + link.split(l111lll_ll_ (u"ࠫ࠴࠭㻽"))[-1].replace(l111lll_ll_ (u"ࠬ࠳ࠧ㻾"),l111lll_ll_ (u"࠭ࠠࠨ㻿"))
		sequence = re.findall(l111lll_ll_ (u"ࠧศๆะ่็ฯ࠭ࠩ࡞ࡧ࠯࠮࠭㼀"),link.split(l111lll_ll_ (u"ࠨ࠱ࠪ㼁"))[-1],re.DOTALL)
		if sequence: sequence = sequence[0]
		else: sequence = l111lll_ll_ (u"ࠩ࠳ࠫ㼂")
		l11l1111_ll_.append([link,title,sequence])
	items = sorted(l11l1111_ll_, reverse=False, key=lambda key: int(key[2]))
	l11llllll_ll_ = str(items).count(l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ㼃"))
	l1l11111l_ll_ = str(items).count(l111lll_ll_ (u"ࠫ࠴࡫ࡰࡪࡵࡲࡨࡪ࠵ࠧ㼄"))
	if l11llllll_ll_>1 and l1l11111l_ll_>0 and l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧ㼅") not in url:
		for link,title,sequence in items:
			if l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ㼆") in link: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㼇"),l1l1l1l_ll_+title,link,113)
	else:
		for link,title,sequence in items:
			if l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ㼈") not in link: l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㼉"),l1l1l1l_ll_+title,link,112)
	return
def l11_ll_(url):
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㼊"),l111lll_ll_ (u"ࠫࡊࡓࡁࡅࠢ࠴࠵࠶࠭㼋"))
	l1l111l_ll_ = []
	parts = url.split(l111lll_ll_ (u"ࠬ࠵ࠧ㼌"))
	#l1ll1l_ll_(url,l111lll_ll_ (u"࠭ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ㼍"))
	#url = l1111_ll_(l1lll111_ll_(url))
	hostname = l1ll1l1_ll_
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ㼎"),url,l111lll_ll_ (u"ࠨࠩ㼏"),headers,True,True,l111lll_ll_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭㼐"))
	html = response.content#.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ㼑"))
	id = re.findall(l111lll_ll_ (u"ࠫࡵࡵࡳࡵࡋࡧ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㼒"),html,re.DOTALL)
	if not id: id = re.findall(l111lll_ll_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭㼓"),html,re.DOTALL)
	if not id: id = re.findall(l111lll_ll_ (u"࠭ࡰࡰࡵࡷ࠱࡮ࡪ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㼔"),html,re.DOTALL)
	if id: id = id[0]
	else: l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㼕"),l111lll_ll_ (u"ࠨ์ิะ๎ࠦลาีส่ࠥํะ่ࠢสฺ่๊ใๅหࠣษ้๏ࠠศๆ่ฬึ๋ฬ่๊่ࠡࠢࠥวว็ฬࠤำีๅศฬࠣห้ฮั็ษ่ะࠬ㼖"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㼗"),l111lll_ll_ (u"ࠪࡉࡒࡇࡄࠡࡕࡗࡅࡗ࡚ࠠࡕࡋࡐࡍࡓࡍࠠ࠲࠳࠴ࠫ㼘"))
	if True or l111lll_ll_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫࠳ࠬ㼙") in html:
		#parts = url.split(l111lll_ll_ (u"ࠬ࠵ࠧ㼚"))
		l1ll111_ll_ = url.replace(parts[3],l111lll_ll_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ㼛"))
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ㼜"),l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ㼝"),headers,True,True,l111lll_ll_ (u"ࠩࡄࡖࡇࡒࡉࡐࡐ࡝࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭㼞"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ㼟"))
		l1111ll1_ll_ = re.findall(l111lll_ll_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㼠"),l1l111l1_ll_,re.DOTALL)
		l1llll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࡪࡡࡵࡣ࠰ࡩࡲࡨࡥࡥࡦࡀࠦ࠳࠰࠿ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠫࠦࢁࠬࡱࡶࡱࡷ࠿࠮࠭㼡"),l1l111l1_ll_,re.DOTALL)
		l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠪࡶࡻ࡯ࡵ࠽ࠫ࠲࠯ࡅࠩࠧࡳࡸࡳࡹࡁ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ㼢"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࡜࡯ࠬ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ㼣"),l1l111l1_ll_)
		l11l1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠨࡵࡵࡧࡂࠬࡱࡶࡱࡷ࠿࠭࠴ࠪࡀࠫࠩࡵࡺࡵࡴ࠼࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㼤"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		l11lll111_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶࡩࡷࡼࡥࡳ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㼥"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		items = l1111ll1_ll_+l1llll111_ll_+l1lll1lll_ll_+l1lll1l1l_ll_+l11l1ll1l_ll_+l11lll111_ll_
		#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㼦"),l111lll_ll_ (u"ࠫࡊࡓࡁࡅࠢࡖࡘࡆࡘࡔࠡࡖࡌࡑࡎࡔࡇࠡ࠶࠷࠸ࠬ㼧"))
		if not items:
			items = re.findall(l111lll_ll_ (u"ࠬࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㼨"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l111lll_ll_ (u"࠭࠮ࡱࡰࡪࠫ㼩") in server: continue
			if l111lll_ll_ (u"ࠧ࠯࡬ࡳ࡫ࠬ㼪") in server: continue
			if l111lll_ll_ (u"ࠨࠨࡴࡹࡴࡺ࠻ࠨ㼫") in server: continue
			quality = re.findall(l111lll_ll_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪ㼬"),title,re.DOTALL)
			if quality:
				quality = quality[0]
				if quality in title: title = title.replace(quality+l111lll_ll_ (u"ࠪࡴࠬ㼭"),l111lll_ll_ (u"ࠫࠬ㼮")).replace(quality,l111lll_ll_ (u"ࠬ࠭㼯")).strip(l111lll_ll_ (u"࠭ࠠࠨ㼰"))
				quality = l111lll_ll_ (u"ࠧࡠࡡࡢࡣࠬ㼱")+quality
			else: quality = l111lll_ll_ (u"ࠨࠩ㼲")
			#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㼳"),l111lll_ll_ (u"ࠪ࡟ࠬ㼴")+str(id)+l111lll_ll_ (u"ࠫࡢࠦࠠ࡜ࠩ㼵")+str(hostname)+l111lll_ll_ (u"ࠬࡣࠠࠡ࡝ࠪ㼶")+str(title)+l111lll_ll_ (u"࠭࡝ࠡࠢ࡞ࠫ㼷")+str(quality)+l111lll_ll_ (u"ࠧ࡞ࠩ㼸"))
			if server.isdigit():
				link = hostname+l111lll_ll_ (u"ࠨ࠱ࡂࡴࡴࡹࡴࡪࡦࡀࠫ㼹")+id+l111lll_ll_ (u"ࠩࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠭㼺")+server+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㼻")+title+l111lll_ll_ (u"ࠫࡤࡥࡷࡢࡶࡦ࡬ࠬ㼼")+quality
			else:
				if l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪ㼽") not in server: server = l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾ࠬ㼾")+server
				quality = re.findall(l111lll_ll_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ㼿"),title,re.DOTALL)
				if quality: quality = l111lll_ll_ (u"ࠨࡡࡢࡣࡤ࠭㽀")+quality[0]
				else: quality = l111lll_ll_ (u"ࠩࠪ㽁")
				link = server+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡽࡡࡵࡥ࡫ࠫ㽂")+quality
			l1l111l_ll_.append(link)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㽃"),l111lll_ll_ (u"ࠬࡡࠧ㽄")+quality+l111lll_ll_ (u"࠭࡝ࠡࠢࠣࠤࡠ࠭㽅")+title+l111lll_ll_ (u"ࠧ࡞ࠩ㽆"))
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭㽇"), l1l111l_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡺࡥࡹࡩࡨࠡ࠳ࠪ㽈"),	str(len(items)))
	if l111lll_ll_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࡓࡵࡷࠨ㽉") in html:
		l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㽊"):l111lll_ll_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧ࠿ࠥࡩࡨࡢࡴࡶࡩࡹࡃࡕࡕࡈ࠰࠼ࠬ㽋") }
		l1ll111_ll_ = url.replace(parts[3],l111lll_ll_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤࠨ㽌"))
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ㽍"),l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ㽎"),l1ll11l1l_ll_,True,l111lll_ll_ (u"ࠩࠪ㽏"),l111lll_ll_ (u"ࠪࡗࡍࡇࡈࡊࡆ࠷࡙࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧ㽐"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ㽑"))
		#l1ll1l_ll_(l1ll111_ll_,l1l111l1_ll_)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡵ࡭ࠢࡦࡰࡦࡹࡳ࠾ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱࡮ࡺࡥ࡮ࡵࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭㽒"),l1l111l1_ll_,re.DOTALL)
		for block in l1lll_ll_:
			items = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡂࡰ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㽓"),block,re.DOTALL)
			for link,name,quality in items:
				link = link+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㽔")+name+l111lll_ll_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㽕")+l111lll_ll_ (u"ࠩࡢࡣࡤࡥࠧ㽖")+quality
				l1l111l_ll_.append(link)
	elif l111lll_ll_ (u"ࠪ࠳ࡩࡵࡷ࡯࡮ࡲࡥࡩ࠵ࠧ㽗") in html:
		l1ll11l1l_ll_ = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㽘"):l111lll_ll_ (u"ࠬ࠭㽙") , l111lll_ll_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ㽚"):l111lll_ll_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ㽛") }
		l1ll111_ll_ = hostname + l111lll_ll_ (u"ࠨ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡨࡴࡽ࡮࡭ࡱࡤࡨࡱ࡯࡮࡬ࡵࠩࡴࡴࡹࡴࡊࡦࡀࠫ㽜")+id
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭㽝"),l1ll111_ll_,l111lll_ll_ (u"ࠪࠫ㽞"),l1ll11l1l_ll_,True,True,l111lll_ll_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡐࡍࡃ࡜࠱࠹ࡺࡨࠨ㽟"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪ㽠"))
		if l111lll_ll_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠮ࡤࡷࡲࡸ࠭㽡") in l1l111l1_ll_:
			l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㽢"),l1l111l1_ll_,re.DOTALL)
			for l11ll1_ll_ in l1lll1lll_ll_:
				if l111lll_ll_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ㽣") not in l11ll1_ll_ and l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࠧ㽤") in l11ll1_ll_:
					l11ll1_ll_ = l11ll1_ll_+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㽥")
					l1l111l_ll_.append(l11ll1_ll_)
				elif l111lll_ll_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫ㽦") in l11ll1_ll_:
					quality = l111lll_ll_ (u"ࠬ࠭㽧")
					response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㽨"),l11ll1_ll_,l111lll_ll_ (u"ࠧࠨ㽩"),headers,True,True,l111lll_ll_ (u"ࠨࡕࡋࡅࡍࡏࡄ࠵ࡗ࠰ࡔࡑࡇ࡙࠮࠷ࡷ࡬ࠬ㽪"))
					l11ll11ll_ll_ = response.content#.encode(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ㽫"))
					l1lll1l_ll_ = re.findall(l111lll_ll_ (u"ࠪࠬࡁࡹࡴࡳࡱࡱ࡫ࡃ࠴ࠪࡀࠫ࠰࠱࠲࠳࠭ࠨ㽬"),l11ll11ll_ll_,re.DOTALL)
					for l1l111111_ll_ in l1lll1l_ll_:
						l11ll1l1l_ll_ = l111lll_ll_ (u"ࠫࠬ㽭")
						l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡳࡵࡴࡲࡲ࡬ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡳࡵࡴࡲࡲ࡬ࡄࠧ㽮"),l1l111111_ll_,re.DOTALL)
						for l11lll1l1_ll_ in l1lll1l1l_ll_:
							item = re.findall(l111lll_ll_ (u"࠭࡜ࡥ࡞ࡧࡠࡩ࠱ࠧ㽯"),l11lll1l1_ll_,re.DOTALL)
							if item:
								quality = l111lll_ll_ (u"ࠧࡠࡡࡢࡣࠬ㽰")+item[0]
								break
						for l11lll1l1_ll_ in reversed(l1lll1l1l_ll_):
							item = re.findall(l111lll_ll_ (u"ࠨ࡞ࡺࡠࡼ࠱ࠧ㽱"),l11lll1l1_ll_,re.DOTALL)
							if item:
								l11ll1l1l_ll_ = item[0]
								break
						l11l1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㽲"),l1l111111_ll_,re.DOTALL)
						for l11ll1lll_ll_ in l11l1ll1l_ll_:
							l11ll1lll_ll_ = l11ll1lll_ll_+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㽳")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㽴")+quality
							l1l111l_ll_.append(l11ll1lll_ll_)
			#l1ll1l_ll_(l111lll_ll_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠠ࠲ࠩ㽵"),	str(len(l1l111l_ll_))	)
		elif l111lll_ll_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠫ㽶") in l1l111l1_ll_:
			l1l111l1_ll_ = l1l111l1_ll_.replace(l111lll_ll_ (u"ࠧ࠽ࡪ࠹ࠤࠬ㽷"),l111lll_ll_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠢࡀࡁࡘ࡚ࡁࡓࡖࡀࡁࠬ㽸"))+l111lll_ll_ (u"ࠩࡀࡁࡊࡔࡄ࠾࠿ࠪ㽹")
			l1l111l1_ll_ = l1l111l1_ll_.replace(l111lll_ll_ (u"ࠪࡀ࡭࠹ࠠࠨ㽺"),l111lll_ll_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨ㽻"))+l111lll_ll_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭㽼")
			#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㽽"),l1l111l1_ll_)
			#with open(l111lll_ll_ (u"ࠧࡴ࠼࡟ࡠࡪࡳࡡࡥ࠰࡫ࡸࡲࡲࠧ㽾"),l111lll_ll_ (u"ࠨࡹࠪ㽿")) as f: f.write(l1l111l1_ll_)
			l11l1lll1_ll_ = re.findall(l111lll_ll_ (u"ࠩࡀࡁࡘ࡚ࡁࡓࡖࡀࡁ࠭࠴ࠪࡀࠫࡀࡁࡊࡔࡄ࠾࠿ࠪ㾀"),l1l111l1_ll_,re.DOTALL)
			if l11l1lll1_ll_:
				for l1l111111_ll_ in l11l1lll1_ll_:
					if l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠩ㾁") not in l1l111111_ll_: continue
					#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩࠦ࠱࠲࠳ࠪ㾂"),	l1l111111_ll_	)
					l11lll1ll_ll_ = l111lll_ll_ (u"ࠬ࠭㾃")
					l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳ࡭ࡱࡺ࠱ࡲࡵࡴࡪࡱࡱࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㾄"),l1l111111_ll_,re.DOTALL)
					for l11lll1l1_ll_ in l1lll1l1l_ll_:
						item = re.findall(l111lll_ll_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨ㾅"),l11lll1l1_ll_,re.DOTALL)
						if item:
							l11lll1ll_ll_ = l111lll_ll_ (u"ࠨࡡࡢࡣࡤ࠭㾆")+item[0]
							break
					l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡴࡥࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ㾇"),l1l111111_ll_,re.DOTALL)
					if l1lll1l1l_ll_:
						for l11ll1l1l_ll_,l11ll1ll1_ll_ in l1lll1l1l_ll_:
							l11ll1ll1_ll_ = l11ll1ll1_ll_+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㾈")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ㾉")+l11lll1ll_ll_
							l1l111l_ll_.append(l11ll1ll1_ll_)
					else:
						l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࡪࡷࡸࡵ࠴ࠪࡀࠫࠥ࠲࠯ࡅ࡮ࡢ࡯ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㾊"),l1l111111_ll_,re.DOTALL)
						for l11ll1ll1_ll_,l11ll1l1l_ll_ in l1lll1l1l_ll_:
							l11ll1ll1_ll_ = l11ll1ll1_ll_.strip(l111lll_ll_ (u"࠭ࠠࠨ㾋"))+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㾌")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㾍")+l11lll1ll_ll_
							l1l111l_ll_.append(l11ll1ll1_ll_)
			else:
				l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡂ࠭ࡢࡷࠬࠫ࠿ࠫ㾎"),l1l111l1_ll_,re.DOTALL)
				for l11ll1ll1_ll_,l11ll1l1l_ll_ in l1lll1l1l_ll_:
					l11ll1ll1_ll_ = l11ll1ll1_ll_.strip(l111lll_ll_ (u"ࠪࠤࠬ㾏"))+l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㾐")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩ㾑")
					l1l111l_ll_.append(l11ll1ll1_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㾒"),l111lll_ll_ (u"ࠧࡆࡏࡄࡈࠥ࠸࠲࠳ࠩ㾓"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࡤࡲࡸ࡭ࡀࠠࡸࡣࡷࡧ࡭ࠦࠦࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠪ㾔"),	str(len(l1l111l_ll_))	)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠩฦาฯืࠠศๆหัะࠦวๅ็้หุฮࠧ㾕"), l1l111l_ll_)
	if len(l1l111l_ll_)==0: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㾖"),l111lll_ll_ (u"ࠫฬ๊ัศสฺࠤ้๐ำࠡใํ๋ࠥ็๊ะ์๋ࠫ㾗"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ㾘"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"࠭ࠧ㾙"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠧࠨ㾚"): return
	search = search.replace(l111lll_ll_ (u"ࠨࠢࠪ㾛"),l111lll_ll_ (u"ࠩ࠮ࠫ㾜"))
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫ㾝"),headers,True,l111lll_ll_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪ㾞"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩࡨࡦࡸࡵࡳࡳ࠳ࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㾟"),html,re.DOTALL)
	if l1ll11_ll_ and l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㾠"),block,re.DOTALL)
		l11llll11_ll_,l11ll1l11_ll_ = [],[]
		for category,title in items:
			if title in [l111lll_ll_ (u"ฺࠧำฺ๋๋ࠥีศำ฼อࠬ㾡")]: continue
			l11llll11_ll_.append(category)
			l11ll1l11_ll_.append(title)
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨ㾢"), l11ll1l11_ll_)
		if selection == -1 : return
		category = l11llll11_ll_[selection]
	else: category = l111lll_ll_ (u"ࠩࠪ㾣")
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧ㾤")+search+l111lll_ll_ (u"ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨ㾥")+category
	l1l11l1_ll_(url)
	return
def l1111l1_ll_(url,filter):
	filter = filter.replace(l111lll_ll_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㾦"),l111lll_ll_ (u"࠭ࠧ㾧"))
	#l1ll1l_ll_(filter,url)
	l1l1ll1l_ll_ = [l111lll_ll_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ㾨"),l111lll_ll_ (u"ࠨࡩࡨࡲࡷ࡫ࠧ㾩"),l111lll_ll_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ㾪")]
	if l111lll_ll_ (u"ࠪࡃࠬ㾫") in url: url = url.split(l111lll_ll_ (u"ࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࠨ㾬"))[0]
	type,filter = filter.split(l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ㾭"),1)
	if filter==l111lll_ll_ (u"࠭ࠧ㾮"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"ࠧࠨ㾯"),l111lll_ll_ (u"ࠨࠩ㾰")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"ࠩࡢࡣࡤ࠭㾱"))
	if type==l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ㾲"):
		if l1l1ll1l_ll_[0]+l111lll_ll_ (u"ࠫࡂ࠭㾳") not in l1l1l1ll_ll_: category = l1l1ll1l_ll_[0]
		for i in range(len(l1l1ll1l_ll_[0:-1])):
			if l1l1ll1l_ll_[i]+l111lll_ll_ (u"ࠬࡃࠧ㾴") in l1l1l1ll_ll_: category = l1l1ll1l_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"࠭ࠦࠨ㾵")+category+l111lll_ll_ (u"ࠧ࠾࠲ࠪ㾶")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠨࠨࠪ㾷")+category+l111lll_ll_ (u"ࠩࡀ࠴ࠬ㾸")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"ࠪࠪࠬ㾹"))+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ㾺")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠬࠬࠧ㾻"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩ㾼"))
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࠫ㾽")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ㾾"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫ㾿"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"ࠪࠫ㿀"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ㿁"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠬ࠭㿂"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪ㿃")+l1l1l1l1_ll_
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿄"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨล฻๋ฬืࠠใษษ้ฮࠦวๅใํำ๏๎ࠠศๆอ๎ࠥะๅࠡษัฮ๏อั่ษࠣࠫ㿅"),l1ll111_ll_,111)
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㿆"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪ㿇")+l1l1111l_ll_+l111lll_ll_ (u"ࠫࠥࠦࠠ࡞࡟ࠪ㿈"),l1ll111_ll_,111)
		l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ㿉"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㿊"),l111lll_ll_ (u"ࠧࠨ㿋"),9999)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠨࠩ㿌"),headers,True,l111lll_ll_ (u"ࠩࡖࡌࡆࡎࡉࡅ࠶ࡘ࠱ࡋࡏࡌࡕࡇࡕࡗࡤࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ㿍"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡀ࡫ࡵࡲ࡮ࠢࡦࡰࡦࡹࡳࠩ࠰࠭ࡃ࠮ࡂ࠯ࡧࡱࡵࡱࡃ࠭㿎"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l11111l_ll_ = re.findall(l111lll_ll_ (u"ࠫࡸ࡫࡬ࡦࡥࡷ࠲࠯ࡅ࠼ࡢ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡧ࠾࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡤࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ㿏"),block,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭㿐"),str(l11111l_ll_))
	dict = {}
	for name,l1lllll1_ll_,block in l11111l_ll_:
		name = name.replace(l111lll_ll_ (u"࠭࠭࠮ࠩ㿑"),l111lll_ll_ (u"ࠧࠨ㿒"))
		items = re.findall(l111lll_ll_ (u"ࠨࡦࡤࡸࡦ࠳ࡣࡢࡶࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣࡩࡧࡦ࡯ࡲࡧࡲ࡬࠯ࡥࡳࡱࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㿓"),block,re.DOTALL)
		if l111lll_ll_ (u"ࠩࡀࠫ㿔") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧ㿕"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"ࠫࡈࡇࡔࡆࡉࡒࡖࡎࡋࡓࡠࡡࡢࠫ㿖")+l1l1llll_ll_)
				return
			else:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿗"),l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅฮ่๎฾ࠦࠧ㿘"),l1ll111_ll_,111)
				else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿙"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ะ๊๐ูࠡࠩ㿚"),l1ll111_ll_,115,l111lll_ll_ (u"ࠩࠪ㿛"),l111lll_ll_ (u"ࠪࠫ㿜"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ㿝"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠬࠬࠧ㿞")+l1lllll1_ll_+l111lll_ll_ (u"࠭࠽࠱ࠩ㿟")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠧࠧࠩ㿠")+l1lllll1_ll_+l111lll_ll_ (u"ࠨ࠿࠳ࠫ㿡")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭㿢")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㿣"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭㿤")+name,l1ll111_ll_,114,l111lll_ll_ (u"ࠬ࠭㿥"),l111lll_ll_ (u"࠭ࠧ㿦"),l1l1llll_ll_+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㿧"))
		dict[l1lllll1_ll_] = {}
		for value,option in items:
			if option in l11lll1_ll_: continue
			#if l111lll_ll_ (u"ࠨࡸࡤࡰࡺ࡫ࠧ㿨") not in value: value = option
			#else: value = re.findall(l111lll_ll_ (u"ࠩࠥࠬ࠳࠰࠿ࠪࠤࠪ㿩"),value,re.DOTALL)[0]
			dict[l1lllll1_ll_][value] = option
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠪࠪࠬ㿪")+l1lllll1_ll_+l111lll_ll_ (u"ࠫࡂ࠭㿫")+option
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠬࠬࠧ㿬")+l1lllll1_ll_+l111lll_ll_ (u"࠭࠽ࠨ㿭")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ㿮")+l1ll1l11_ll_
			title = option+l111lll_ll_ (u"ࠨࠢ࠽ࠫ㿯")#+dict[l1lllll1_ll_][l111lll_ll_ (u"ࠩ࠳ࠫ㿰")]
			title = option+l111lll_ll_ (u"ࠪࠤ࠿࠭㿱")+name
			if type==l111lll_ll_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ㿲"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㿳"),l1l1l1l_ll_+title,url,114,l111lll_ll_ (u"࠭ࠧ㿴"),l111lll_ll_ (u"ࠧࠨ㿵"),l1llll1l_ll_+l111lll_ll_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㿶"))
			elif type==l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭㿷") and l1l1ll1l_ll_[-2]+l111lll_ll_ (u"ࠪࡁࠬ㿸") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ㿹"))
				l11ll1_ll_ = url+l111lll_ll_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩ㿺")+l1l11ll1_ll_
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㿻"),l1l1l1l_ll_+title,l11ll1_ll_,111)
			else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㿼"),l1l1l1l_ll_+title,url,115,l111lll_ll_ (u"ࠨࠩ㿽"),l111lll_ll_ (u"ࠩࠪ㿾"),l1llll1l_ll_)
	return
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠪࡖࡊࡉࡏࡏࡕࡗࡖ࡚ࡉࡔࡠࡈࡌࡐ࡙ࡋࡒࠡ࠳࠴ࠫ㿿"))
	# mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭䀀")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨ䀁")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"࠭ࡡ࡭࡮ࠪ䀂")					all filters (l1l11l11_ll_ empty filter)
	filters = filters.replace(l111lll_ll_ (u"ࠧ࠾ࠨࠪ䀃"),l111lll_ll_ (u"ࠨ࠿࠳ࠪࠬ䀄"))
	filters = filters.strip(l111lll_ll_ (u"ࠩࠩࠫ䀅"))
	l1l1ll11_ll_ = {}
	if l111lll_ll_ (u"ࠪࡁࠬ䀆") in filters:
		items = filters.split(l111lll_ll_ (u"ࠫࠫ࠭䀇"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"ࠬࡃࠧ䀈"))
			l1l1ll11_ll_[var] = value
	l1llll11_ll_ = l111lll_ll_ (u"࠭ࠧ䀉")
	l1lll1l1_ll_ = [l111lll_ll_ (u"ࠧࡲࡷࡤࡰ࡮ࡺࡹࠨ䀊"),l111lll_ll_ (u"ࠨࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸࠧ䀋"),l111lll_ll_ (u"ࠩࡪࡩࡳࡸࡥࠨ䀌"),l111lll_ll_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࠬ䀍")]
	for key in l1lll1l1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"ࠫ࠵࠭䀎")
		if l111lll_ll_ (u"ࠬࠫࠧ䀏") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨ䀐") and value!=l111lll_ll_ (u"ࠧ࠱ࠩ䀑"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠨࠢ࠮ࠤࠬ䀒")+value
		elif mode==l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ䀓") and value!=l111lll_ll_ (u"ࠪ࠴ࠬ䀔"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠫࠫ࠭䀕")+key+l111lll_ll_ (u"ࠬࡃࠧ䀖")+value
		elif mode==l111lll_ll_ (u"࠭ࡡ࡭࡮ࠪ䀗"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠧࠧࠩ䀘")+key+l111lll_ll_ (u"ࠨ࠿ࠪ䀙")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠩࠣ࠯ࠥ࠭䀚"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠪࠪࠬ䀛"))
	l1llll11_ll_ = l1llll11_ll_.replace(l111lll_ll_ (u"ࠫࡂ࠶ࠧ䀜"),l111lll_ll_ (u"ࠬࡃࠧ䀝"))
	#l1ll1l_ll_(filters,l111lll_ll_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧ䀞"))
	return l1llll11_ll_