# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_ = l111lll_ll_ (u"ࠫࡆࡒࡆࡂࡖࡌࡑࡎ࠭౒")
l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡥࡆࡕࡏࡢࠫ౓")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1lll111l_ll_ = [l111lll_ll_ (u"࠭࠱࠳࠵࠼ࠫ౔"),l111lll_ll_ (u"ࠧ࠲࠴࠸࠴ౕࠬ"),l111lll_ll_ (u"ࠨ࠳࠵࠸࠺ౖ࠭"),l111lll_ll_ (u"ࠩ࠵࠴ࠬ౗"),l111lll_ll_ (u"ࠪ࠵࠷࠻࠹ࠨౘ"),l111lll_ll_ (u"ࠫ࠷࠷࠸ࠨౙ"),l111lll_ll_ (u"ࠬ࠺࠸࠶ࠩౚ"),l111lll_ll_ (u"࠭࠱࠳࠵࠻ࠫ౛"),l111lll_ll_ (u"ࠧ࠲࠴࠸࠼ࠬ౜"),l111lll_ll_ (u"ࠨ࠴࠼࠶ࠬౝ")]
l1lll1111_ll_ = [l111lll_ll_ (u"ࠩ࠶࠴࠸࠶ࠧ౞"),l111lll_ll_ (u"ࠪ࠺࠷࠾ࠧ౟")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==60: results = l11l1ll_ll_(url)
	elif mode==61: results = l1l11l1_ll_(url,text)
	elif mode==62: results = l1l11ll_ll_(url)
	elif mode==63: results = l11_ll_(url)
	elif mode==64: results = l1lll11l1_ll_(text)
	elif mode==69: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠫࠬౠ")):
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬౡ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ౢ"),l111lll_ll_ (u"ࠧࠨౣ"),69,l111lll_ll_ (u"ࠨࠩ౤"),l111lll_ll_ (u"ࠩࠪ౥"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ౦"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ౧"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ౨")+l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅศࠢํฮ๊ࠦๅีษ๊ำฯํࠠศๆส๊ࠬ౩"),l1ll1l1_ll_,64,l111lll_ll_ (u"ࠧࠨ౪"),l111lll_ll_ (u"ࠨࠩ౫"),l111lll_ll_ (u"ࠩࡵࡩࡨ࡫࡮ࡵࡡࡹ࡭ࡪࡽࡥࡥࡡࡹ࡭ࡩࡹࠧ౬"))
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ౭"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ౮")+l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไศๅฮี๋ࠥิศ้าอࠬ౯"),l1ll1l1_ll_,64,l111lll_ll_ (u"࠭ࠧ౰"),l111lll_ll_ (u"ࠧࠨ౱"),l111lll_ll_ (u"ࠨ࡯ࡲࡷࡹࡥࡶࡪࡧࡺࡩࡩࡥࡶࡪࡦࡶࠫ౲"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ౳"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ౴")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ฼๊โฬ้ࠣษิัศࠩ౵"),l1ll1l1_ll_,64,l111lll_ll_ (u"ࠬ࠭౶"),l111lll_ll_ (u"࠭ࠧ౷"),l111lll_ll_ (u"ࠧࡳࡧࡦࡩࡳࡺ࡬ࡺࡡࡤࡨࡩ࡫ࡤࡠࡸ࡬ࡨࡸ࠭౸"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ౹"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭౺")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪๅ๏ี๊้ࠢ฼ุํอฦ๋ࠩ౻"),l1ll1l1_ll_,64,l111lll_ll_ (u"ࠫࠬ౼"),l111lll_ll_ (u"ࠬ࠭౽"),l111lll_ll_ (u"࠭ࡲࡢࡰࡧࡳࡲࡥࡶࡪࡦࡶࠫ౾"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ౿"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬಀ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬࠪಁ"),l1ll1l1_ll_,61,l111lll_ll_ (u"ࠪࠫಂ"),l111lll_ll_ (u"ࠫࠬಃ"),l111lll_ll_ (u"ࠬ࠳࠱ࠨ಄"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಅ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫಆ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ฬึอๅอࠢส่ิ๐ๆ๋หࠪಇ"),l1ll1l1_ll_,61,l111lll_ll_ (u"ࠩࠪಈ"),l111lll_ll_ (u"ࠪࠫಉ"),l111lll_ll_ (u"ࠫ࠲࠸ࠧಊ"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಋ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪಌ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧࡆࡰࡪࡰ࡮ࡹࡨࠡࡘ࡬ࡨࡪࡵࡳࠨ಍"),l1ll1l1_ll_,61,l111lll_ll_ (u"ࠨࠩಎ"),l111lll_ll_ (u"ࠩࠪಏ"),l111lll_ll_ (u"ࠪ࠱࠸࠭ಐ"))
	return l111lll_ll_ (u"ࠫࠬ಑")
def l1l11l1_ll_(url,category):
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭ಒ"), category)
	cat = l111lll_ll_ (u"࠭ࠧಓ")
	if category not in [l111lll_ll_ (u"ࠧ࠮࠳ࠪಔ"),l111lll_ll_ (u"ࠨ࠯࠵ࠫಕ"),l111lll_ll_ (u"ࠩ࠰࠷ࠬಖ")]: cat = l111lll_ll_ (u"ࠪࡃࡨࡧࡴ࠾ࠩಗ")+category
	l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡳࡥ࡯ࡷࡢࡰࡪࡼࡥ࡭࠰ࡳ࡬ࡵ࠭ಘ")+cat
	html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭ಙ"),l111lll_ll_ (u"࠭ࠧಚ"),l111lll_ll_ (u"ࠧࠨಛ"),l111lll_ll_ (u"ࠨࡃࡏࡊࡆ࡚ࡉࡎࡋ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠵ࡸࡺࠧಜ"))
	items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡴࡦࡴ࠾ࠨಝ"),html,re.DOTALL)
	l1ll1llll_ll_,found = False,False
	for link,title,count in items:
		title = unescapeHTML(title)
		title = title.strip(l111lll_ll_ (u"ࠪࠤࠬಞ"))
		if l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࠩಟ") not in link: link = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫಠ")+link
		cat = re.findall(l111lll_ll_ (u"࠭ࡣࡢࡶࡀࠬ࠳࠰࠿ࠪࠨࠪಡ"),link,re.DOTALL)[0]
		if category==cat: l1ll1llll_ll_ = True
		elif l1ll1llll_ll_ 	or (category==l111lll_ll_ (u"ࠧ࠮࠳ࠪಢ") and cat in l1lll111l_ll_) \
						or (category==l111lll_ll_ (u"ࠨ࠯࠵ࠫಣ") and cat not in l1lll1111_ll_ and cat not in l1lll111l_ll_) \
						or (category==l111lll_ll_ (u"ࠩ࠰࠷ࠬತ") and cat in l1lll1111_ll_):
							if count==l111lll_ll_ (u"ࠪ࠵ࠬಥ"): l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪದ"),l1l1l1l_ll_+title,link,63)
							else: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬಧ"),l1l1l1l_ll_+title,link,61,l111lll_ll_ (u"࠭ࠧನ"),l111lll_ll_ (u"ࠧࠨ಩"),cat)
							found = True
	if not found: l1l11ll_ll_(url)
	return
def l1l11ll_ll_(url):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠨࠩಪ"),l111lll_ll_ (u"ࠩࠪಫ"),True,l111lll_ll_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫಬ"))
	#l1ll1l_ll_(url , html)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡩࡳࡴࡺࡥࡳࠩಭ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠬ࡭ࡲࡪࡦࡢࡺ࡮࡫ࡷ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠳࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪಮ"),block,re.DOTALL)
	link = l111lll_ll_ (u"࠭ࠧಯ")
	for img,title,link in items:
		title = title.replace(l111lll_ll_ (u"ࠧࡂࡦࡧࠫರ"),l111lll_ll_ (u"ࠨࠩಱ")).replace(l111lll_ll_ (u"ࠩࡷࡳࠥࡗࡵࡪࡥ࡮ࡰ࡮ࡹࡴࠨಲ"),l111lll_ll_ (u"ࠪࠫಳ")).strip(l111lll_ll_ (u"ࠫࠥ࠭಴"))
		if l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪವ") not in link: link = l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾ࠬಶ")+link
		l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ಷ"),l1l1l1l_ll_+title,link,63,img)
	l1lll_ll_=re.findall(l111lll_ll_ (u"ࠨࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪಸ"),block,re.DOTALL)
	block=l1lll_ll_[0]
	block=re.findall(l111lll_ll_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪಹ"),html,re.DOTALL)[0]
	items=re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ಺"),block,re.DOTALL)
	l1ll111_ll_ = url.split(l111lll_ll_ (u"ࠫࡄ࠭಻"))[0]
	for link,l1ll1ll1l_ll_ in items:
		link = l1ll111_ll_ + link
		title = unescapeHTML(l1ll1ll1l_ll_)
		title = l111lll_ll_ (u"ࠬ฻แฮห಼ࠣࠫ") + title
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ಽ"),l1l1l1l_ll_+title,link,62)
	return link
def l11_ll_(url):
	if l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴࡹ࠮ࡱࡪࡳࠫಾ") in url: url = l1l11ll_ll_(url)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠨࠩಿ"),l111lll_ll_ (u"ࠩࠪೀ"),True,l111lll_ll_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍ࠲ࡖࡌࡂ࡛࠰࠵ࡸࡺࠧು"))
	items = re.findall(l111lll_ll_ (u"ࠫࡵࡲࡡࡺ࡮࡬ࡷࡹ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫೂ"),html,re.DOTALL)
	url = items[0]
	if l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪೃ") not in url: url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾ࠬೄ")+url
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࠨ೅"))
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧೆ"))
	return
def l1lll11l1_ll_(category):
	payload = { l111lll_ll_ (u"ࠩࡰࡳࡩ࡫ࠧೇ") : category }
	url = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡥࡱ࡬ࡡࡵ࡫ࡰ࡭࠳ࡺࡶ࠰ࡣ࡭ࡥࡽ࠴ࡰࡩࡲࠪೈ")
	headers = { l111lll_ll_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ೉") : l111lll_ll_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫೊ") }
	data = l1lll11ll_ll_(payload)
	html = l111ll1_ll_(l11111l1_ll_,url,data,headers,True,l111lll_ll_ (u"࠭ࡁࡍࡈࡄࡘࡎࡓࡉ࠮ࡏࡒࡗ࡙࡙࠭࠲ࡵࡷࠫೋ"))
	items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦࠨೌ"),html,re.DOTALL)
	for link,title,img in items:
		title = title.strip(l111lll_ll_ (u"ࠨ್ࠢࠪ"))
		if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࠧ೎") not in link: link = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ೏")+link
		l111_ll_(l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ೐"),l1l1l1l_ll_+title,link,63,img)
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠬ࠭೑"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"࠭ࠧ೒"): return
	#l1ll1l_ll_(search, l1ll1l1_ll_)
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠧࠡࠩ೓"),l111lll_ll_ (u"ࠨ࠭ࠪ೔"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡢࡶࡪࡹࡵ࡭ࡶ࠱ࡴ࡭ࡶ࠿ࡲࡷࡨࡶࡾࡃࠧೕ") + l1llll1_ll_ # + l111lll_ll_ (u"ࠪࠪࡵࡧࡧࡦ࠿࠴ࠫೖ")
	l1l11ll_ll_(url)
	return