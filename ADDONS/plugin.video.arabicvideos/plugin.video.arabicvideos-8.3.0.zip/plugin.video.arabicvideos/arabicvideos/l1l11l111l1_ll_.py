# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠨࡏ࡜ࡇࡎࡓࡁࠨ⽏")
headers = {l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⽐"):l111lll_ll_ (u"ࠪࠫ⽑")}
l1l1l1l_ll_=l111lll_ll_ (u"ࠫࡤࡓࡃࡎࡡࠪ⽒")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"๋ࠬีศำ฼อࠥำัสࠩ⽓")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==360: results = l11l1ll_ll_(url)
	elif mode==361: results = l1l11l1_ll_(url,text)
	elif mode==362: results = l11_ll_(url)
	elif mode==363: results = l1l11ll_ll_(url,text)
	elif mode==364: results = l1111l1_ll_(url,l111lll_ll_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭⽔")+text)
	elif mode==365: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࡠࡡࡢࠫ⽕")+text)
	elif mode==366: results = l1l1l11l1_ll_(url)
	elif mode==369: results = l1lll1_ll_(text,url)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠨࠩ⽖")):
	#response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭⽗"),l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫ⽘"),l111lll_ll_ (u"ࠫࠬ⽙"),False,l111lll_ll_ (u"ࠬ࠭⽚"),l111lll_ll_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨ⽛"))
	#hostname = response.headers[l111lll_ll_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ⽜")]
	#hostname = hostname.strip(l111lll_ll_ (u"ࠨ࠱ࠪ⽝"))
	hostname = l1ll1l1_ll_
	if l1111l_ll_==l111lll_ll_ (u"ࠩࠪ⽞"):
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⽟"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ⽠"),hostname,369,l111lll_ll_ (u"ࠬ࠭⽡"),l111lll_ll_ (u"࠭ࠧ⽢"),l111lll_ll_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ⽣"))
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⽤"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩไ่ฯืࠠๆฯาำࠬ⽥"),hostname,364)
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⽦"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧ⽧"),hostname,365)
		l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ⽨"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⽩"),l111lll_ll_ (u"ࠧࠨ⽪"),9999)
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ⽫"):hostname,l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⽬"):l111lll_ll_ (u"ࠪࠫ⽭")}
	url = hostname+l111lll_ll_ (u"ࠫ࠴ࡇࡪࡢࡺࡆࡩࡳࡺࡥࡳ࠱ࡕ࡭࡬࡮ࡴࡃࡣࡵࠫ⽮")
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ⽯"),url,l111lll_ll_ (u"࠭ࠧ⽰"),l111lll_ll_ (u"ࠧࠨ⽱"),l111lll_ll_ (u"ࠨࠩ⽲"),l111lll_ll_ (u"ࠩࠪ⽳"),l111lll_ll_ (u"ࠪࡑ࡞ࡉࡉࡎࡃ࠰ࡑࡊࡔࡕ࠮࠴ࡱࡨࠬ⽴"))
	html = response.content
	html = l1l1l11ll_ll_(html)
	html = html.replace(l111lll_ll_ (u"ࠫࡡࡢࠧ⽵"),l111lll_ll_ (u"ࠬ࠭⽶"))
	#l1l1l1111_ll_(html)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡲࡪࡩ࡫ࡸࡧࡧࡲࠩ࠰࠭ࡃ࠮࡬ࡩ࡭ࡶࡨࡶࠬ⽷"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⽸"),block,re.DOTALL)
		for link,title in items:
			if l111lll_ll_ (u"ࠨࠧࡧ࠽ࠪ࠾࠵ࠦࡦ࠻ࠩࡧ࠻ࠥࡥ࠺ࠨࡥ࠼ࠫࡤ࠹ࠧࡥ࠵ࠪࡪ࠸ࠦࡤ࠼ࠩࡩ࠾ࠥࡢ࠻࠰ࠩࡩ࠾ࠥࡢࡦࠨࡨ࠽ࠫࡢ࠲ࠧࡧ࠼ࠪࡧ࠹ࠨ⽹") in link: continue
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⽺"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ⽻")+l1l1l1l_ll_+title,link,366)
		if l1111l_ll_==l111lll_ll_ (u"ࠫࠬ⽼"): l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ⽽"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⽾"),l111lll_ll_ (u"ࠧࠨ⽿"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ⾀"),hostname,l111lll_ll_ (u"ࠩࠪ⾁"),l111lll_ll_ (u"ࠪࠫ⾂"),l111lll_ll_ (u"ࠫࠬ⾃"),l111lll_ll_ (u"ࠬ࠭⾄"),l111lll_ll_ (u"࠭ࡍ࡚ࡅࡌࡑࡆ࠳ࡍࡆࡐࡘ࠱࠷ࡴࡤࠨ⾅"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡮࡫ࡧࡨࡱ࡫࠭࠮ࡪࡨࡥࡩ࡫ࡲࠩ࠰࠭ࡃ࠮ࡳࡩࡥࡦ࡯ࡩ࠲࠳ࡨࡦࡣࡧࡩࡷ࠭⾆"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺ࠳ࡩࡵࡧࡰ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⾇"),block,re.DOTALL)
		for link,title in items:
			if hostname not in link:
				server = l1ll1l111_ll_(link)
				link = link.replace(server,hostname)
			if l111lll_ll_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨ࠲ࡹࡥࡳ࡫ࡨࡷࠬ⾈") in link:
				title = l111lll_ll_ (u"ࠪฮา๋๊ๅ่ࠢืู้ไศฬࠣฬึอศุ๋ࠢหาีࠧ⾉")
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾊"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ⾋")+l1l1l1l_ll_+title,link,361)
			else:
				if title==l111lll_ll_ (u"࠭ࠧ⾌"): continue
				if not any(value in title for value in l11lll1_ll_):
					l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⾍"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬ⾎")+l1l1l1l_ll_+title,link,366)
		if l1111l_ll_==l111lll_ll_ (u"ࠩࠪ⾏"): l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⾐"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⾑"),l111lll_ll_ (u"ࠬ࠭⾒"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡨࡰࡸࡨࡶࡦࡨ࡬ࡦࠢࡤࡧࡹ࡯ࡶࡢࡤ࡯ࡩ࠭࠴ࠪࡀࠫ࡫ࡳࡻ࡫ࡲࡢࡤ࡯ࡩࠥࡧࡣࡵ࡫ࡹࡥࡧࡲࡥࠨ⾓"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ⾔"),block,re.DOTALL)
		for link,img,title in items:
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⾕"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭⾖")+l1l1l1l_ll_+title,link,366,img)
	return html
def l1l1l11l1_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫ⾗"))
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ⾘"):url,l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ⾙"):l111lll_ll_ (u"࠭ࠧ⾚")}
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ⾛"),url,l111lll_ll_ (u"ࠨࠩ⾜"),l111lll_ll_ (u"ࠩࠪ⾝"),l111lll_ll_ (u"ࠪࠫ⾞"),l111lll_ll_ (u"ࠫࠬ⾟"),l111lll_ll_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡕࡃࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⾠"))
	html = response.content
	#l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⾡"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧโๆอี๋ࠥอะัࠪ⾢"),url,364)
	#l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⾣"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩไ่ฯืࠠไษ่่ࠬ⾤"),url,365)
	if l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡱ࡯ࡤࡦࡴ࠰࠱ࡌࡸࡩࡥࠤࠪ⾥") in html:
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾦"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไๆ็ํึฮ࠭⾧"),url,361,l111lll_ll_ (u"࠭ࠧ⾨"),l111lll_ll_ (u"ࠧࠨ⾩"),l111lll_ll_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪ⾪"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡯࡭ࡸࡺ࠭࠮ࡖࡤࡦࡸࡻࡩࠣࠪ࠱࠮ࡄ࠯ࡤࡪࡸࠪ⾫"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⾬"),block,re.DOTALL)
		for link,title in items:
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⾭"),l1l1l1l_ll_+title,link,361)
	return
def l1l11l1_ll_(l1llllll1ll1_ll_,type=l111lll_ll_ (u"ࠬ࠭⾮")):
	#l1ll1l_ll_(l1llllll1ll1_ll_,l111lll_ll_ (u"࠭ࡔࡊࡖࡏࡉࡘ࠭⾯"))
	if l111lll_ll_ (u"ࠧ࠻࠼ࠪ⾰") in l1llllll1ll1_ll_:
		l11ll1_ll_,url = l1llllll1ll1_ll_.split(l111lll_ll_ (u"ࠨ࠼࠽ࠫ⾱"))
		server = l1ll1l111_ll_(l11ll1_ll_)
		url = server+url
	else: url,l11ll1_ll_ = l1llllll1ll1_ll_,l1llllll1ll1_ll_
	#l1ll1l_ll_(url,l11ll1_ll_)
	#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠩࠪ⾲"))
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ⾳"):l11ll1_ll_,l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ⾴"):l111lll_ll_ (u"ࠬ࠭⾵")}
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ⾶"),url,l111lll_ll_ (u"ࠧࠨ⾷"),l111lll_ll_ (u"ࠨࠩ⾸"),l111lll_ll_ (u"ࠩࠪ⾹"),l111lll_ll_ (u"ࠪࠫ⾺"),l111lll_ll_ (u"ࠫࡒ࡟ࡃࡊࡏࡄ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⾻"))
	html = response.content
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⾼"),html)
	#l1ll1l_ll_(str(l1lll_ll_),html)
	if type==l111lll_ll_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࠨ⾽"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸ࠭࠮ࡉࡵ࡭ࡩࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡱ࡯ࡳࡵ࠯࠰ࡘࡦࡨࡳࡶ࡫ࠥࠫ⾾"),html,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩ⾿"):
		l1lll_ll_ = [html.replace(l111lll_ll_ (u"ࠩ࡟ࡠ࠴࠭⿀"),l111lll_ll_ (u"ࠪ࠳ࠬ⿁")).replace(l111lll_ll_ (u"ࠫࡡࡢࠢࠨ⿂"),l111lll_ll_ (u"ࠬࠨࠧ⿃"))]
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡇࡳ࡫ࡧ࠱࠲ࡓࡹࡤ࡫ࡰࡥࡕࡵࡳࡵࡵࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡰ࡮ࡄ࠼࠰ࡷ࡯ࡂࡁ࠵ࡤࡪࡸࡁࡀ࠴ࡪࡩࡷࡀࠪ⿄"),html,re.DOTALL)
	l1ll11ll_ll_ = []
	if l1lll_ll_:
		block = l1lll_ll_[0]
		#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡕࡋࡗࡐࡊ࡙ࠠ࠮ࠢࡉࡍࡑ࡚ࡅࡓࡕࠪ⿅"),block)
		items = re.findall(l111lll_ll_ (u"ࠨࡉࡵ࡭ࡩࡏࡴࡦ࡯ࠥࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯ࠧ⿆"),block,re.DOTALL)
		for link,title,img in items:
			title = unescapeHTML(title)
			title = l1l1l11ll_ll_(title)
			title = title.replace(l111lll_ll_ (u"ุ่ࠩฬํฯสࠢࠪ⿇"),l111lll_ll_ (u"ࠪࠫ⿈"))
			if l111lll_ll_ (u"ࠫ࠴ࡹࡥࡳ࡫ࡨࡷ࠴࠭⿉") in link: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⿊"),l1l1l1l_ll_+title,link,363,img)
			elif l111lll_ll_ (u"࠭อๅไฬࠫ⿋") in title:
				episode = re.findall(l111lll_ll_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦࠫฮๆๅอࠥ࠱࡜ࡥ࠭ࠪ⿌"),title,re.DOTALL)
				if episode: title = l111lll_ll_ (u"ࠨࡡࡐࡓࡉࡥࠧ⿍") + episode[0]
				if title not in l1ll11ll_ll_:
					l1ll11ll_ll_.append(title)
					l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿎"),l1l1l1l_ll_+title,link,363,img)
			else:
				l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⿏"),l1l1l1l_ll_+title,link,362,img)
		if type==l111lll_ll_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⿐"):
			l1llllll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠬࠨ࡭ࡰࡴࡨࡣࡧࡻࡴࡵࡱࡱࡣࡵࡧࡧࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪ⿑"),block,re.DOTALL)
			if l1llllll1l1l_ll_:
				count = l1llllll1l1l_ll_[0]
				link = url+l111lll_ll_ (u"࠭࠯ࡰࡨࡩࡷࡪࡺ࠯ࠨ⿒")+count
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⿓"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦรฯำ์ࠫ⿔"),link,361,l111lll_ll_ (u"ࠩࠪ⿕"),l111lll_ll_ (u"ࠪࠫ⿖"),l111lll_ll_ (u"ࠫ࡫࡯࡬ࡵࡧࡵࡷࠬ⿗"))
		elif type==l111lll_ll_ (u"ࠬ࠭⿘"):
			l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⿙"),html,re.DOTALL)
			if l1lll_ll_:
				block = l1lll_ll_[0]
				items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⿚"),block,re.DOTALL)
				for link,title in items:
					title = l111lll_ll_ (u"ࠨืไัฮࠦࠧ⿛")+unescapeHTML(title)
					l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⿜"),l1l1l1l_ll_+title,link,361)
	return
def l1l11ll_ll_(url,type=l111lll_ll_ (u"ࠪࠫ⿝")):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠫࠬ⿞"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬ࠭⿟"),url)
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ⿠"):url,l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ⿡"):l111lll_ll_ (u"ࠨࠩ⿢")}
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭⿣"),url,l111lll_ll_ (u"ࠪࠫ⿤"),l111lll_ll_ (u"ࠫࠬ⿥"),l111lll_ll_ (u"ࠬ࠭⿦"),l111lll_ll_ (u"࠭ࠧ⿧"),l111lll_ll_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭⿨"))
	html = response.content
	html = l1111_ll_(html)
	#l1l1l1111_ll_(html)
	name = re.findall(l111lll_ll_ (u"ࠨ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦ࡮ࡺࡥ࡮ࠤࠣ࡬ࡷ࡫ࡦ࠾ࠤ࠱࠮ࡄ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࠨ࠯ࠬࡂ࠭ࠧ࠭⿩"),html,re.DOTALL)
	if name: name = name[-1].replace(l111lll_ll_ (u"ࠩ࠰ࠫ⿪"),l111lll_ll_ (u"ࠪࠤࠬ⿫")).strip(l111lll_ll_ (u"ࠫ࠴࠭⿬"))
	if l111lll_ll_ (u"๋่ࠬิ็ࠪ⿭") in name and type==l111lll_ll_ (u"࠭ࠧ⿮"):
		name = name.split(l111lll_ll_ (u"ࠧๆ๊ึ้ࠬ⿯"))[0]
		name = name.replace(l111lll_ll_ (u"ࠨ็ืห์ีษࠨ⿰"),l111lll_ll_ (u"ࠩࠪ⿱")).strip(l111lll_ll_ (u"ࠪࠤࠬ⿲"))
	elif l111lll_ll_ (u"ࠫา๊โสࠩ⿳") in name:
		name = name.split(l111lll_ll_ (u"ࠬำไใหࠪ⿴"))[0]
		name = name.replace(l111lll_ll_ (u"࠭ๅีษ๊ำฮ࠭⿵"),l111lll_ll_ (u"ࠧࠨ⿶")).strip(l111lll_ll_ (u"ࠨࠢࠪ⿷"))
	else: name = name
	#l1ll1l_ll_(name,l111lll_ll_ (u"ࠩࠪ⿸"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡗࡪࡧࡳࡰࡰࡶ࠱࠲ࡋࡰࡪࡵࡲࡨࡪࡹࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴ࡫ࡱ࡫ࡱ࡫ࡳࡦࡥࡷ࡭ࡴࡴࠧ⿹"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		if type==l111lll_ll_ (u"ࠫࠬ⿺"):
			items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡦࡄࠧ⿻"),block,re.DOTALL)
			for link,title in items:
				if l111lll_ll_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࠧ⿼") in title: continue
				title = name+l111lll_ll_ (u"ࠧࠡ࠯ࠣࠫ⿽")+title
				l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ⿾"),l1l1l1l_ll_+title,link,363,l111lll_ll_ (u"ࠩࠪ⿿"),l111lll_ll_ (u"ࠪࠫ　"),l111lll_ll_ (u"ࠫࡪࡶࡩࡴࡱࡧࡩࡸ࠭、"))
		if len(l11l11lll_ll_)==0:
			l11l1l11_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡋࡰࡪࡵࡲࡨࡪࡹ࠭࠮ࡕࡨࡥࡸࡵ࡮ࡴ࠯࠰ࡉࡵ࡯ࡳࡰࡦࡨࡷࠧ࠮࠮ࠫࡁࠬࠪࠫ࠭。"),block+l111lll_ll_ (u"࠭ࠦࠧࠩ〃"),re.DOTALL)
			if l11l1l11_ll_: block = l11l1l11_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡴ࡮ࡹ࡯ࡥࡧࡗ࡭ࡹࡲࡥ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ〄"),block,re.DOTALL)
			for link,title in items:
				title = title.strip(l111lll_ll_ (u"ࠨࠢࠪ々"))
				title = name+l111lll_ll_ (u"ࠩࠣ࠱ࠥ࠭〆")+title
				l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ〇"),l1l1l1l_ll_+title,link,362)
	if len(l11l11lll_ll_)==0:
		title = re.findall(l111lll_ll_ (u"ࠫࡁࡺࡩࡵ࡮ࡨࡂ࠭࠴ࠪࡀࠫ࠿ࠫ〈"),html,re.DOTALL)
		if title: title = title[0].replace(l111lll_ll_ (u"ࠬࠦ࠭ࠡ็ส๎ู๊ࠥๆษࠪ〉"),l111lll_ll_ (u"࠭ࠧ《")).replace(l111lll_ll_ (u"ࠧๆึส๋ิฯࠠࠨ》"),l111lll_ll_ (u"ࠨࠩ「"))
		else: title = l111lll_ll_ (u"่่ࠩๆࠦวๅฬื฾๏๊ࠧ」")
		l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ『"),l1l1l1l_ll_+title,url,362)
	return
def l11_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠫࠬ』"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬ࠭【"),url)
	l1l111l_ll_ = []
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ】"):url,l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ〒"):l111lll_ll_ (u"ࠨࠩ〓")}
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭〔"),url,l111lll_ll_ (u"ࠪࠫ〕"),l111lll_ll_ (u"ࠫࠬ〖"),l111lll_ll_ (u"ࠬ࠭〗"),l111lll_ll_ (u"࠭ࠧ〘"),l111lll_ll_ (u"ࠧࡎ࡛ࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩ〙"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ศๆอู๋๐แ࠽࠰࠭ࡃࡁࡧ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ〚"),html,re.DOTALL)
	if l1llll_ll_:
		l1llll_ll_ = [l1llll_ll_[0][0],l1llll_ll_[0][1]]
		if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	# watch links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤ࡚ࡥࡹࡩࡨࡔࡧࡵࡺࡪࡸࡳࡍ࡫ࡶࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿࡛ࠥࡦࡺࡣࡩࡕࡨࡶࡻ࡫ࡲࡴࡇࡰࡦࡪࡪࠢࠨ〛"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡷࡵࡰࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡷࡶࡴࡴࡧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ〜"),block,re.DOTALL)
		for link,name in items:
			if name==l111lll_ll_ (u"ุࠫ๐ัโำ้ࠣฬ๐ࠠิ์่หࠬ〝"): name = l111lll_ll_ (u"ࠬࡳࡹࡤ࡫ࡰࡥࠬ〞")
			link = link+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ〟")+name+l111lll_ll_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ〠")
			l1l111l_ll_.append(link)
	# download links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡎ࡬ࡷࡹ࠳࠭ࡅࡱࡺࡲࡱࡵࡡࡥࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭〡"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴࡯࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ〢"),block,re.DOTALL)
		for link,quality in items:
			quality = re.findall(l111lll_ll_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ〣"),quality,re.DOTALL)
			if quality: quality = l111lll_ll_ (u"ࠫࡤࡥ࡟ࡠࠩ〤")+quality[0]
			else: quality = l111lll_ll_ (u"ࠬ࠭〥")
			link = link+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡭ࡺࡥ࡬ࡱࡦ࠭〦")+l111lll_ll_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ〧")+quality
			l1l111l_ll_.append(link)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠨลัฮึࠦวๅสะฯࠥอไๆ่สือ࠭〨"), l1l111l_ll_)
	if len(l1l111l_ll_)==0: l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ〩"),l111lll_ll_ (u"ࠪห้ืวษู่ࠣ๏ูࠠโ์๊ࠤๆ๐ฯ๋๊〪ࠪ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱ〫ࠪ"))
	return
def l1lll1_ll_(search,hostname):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠬ࠭〬"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"〭࠭ࠧ"): return
	search = search.replace(l111lll_ll_ (u"〮ࠧࠡࠩ"),l111lll_ll_ (u"ࠨ〯࠭ࠪ"))
	l1l111l_ll_ = [l111lll_ll_ (u"ࠩ࠲ࠫ〰"),l111lll_ll_ (u"ࠪ࠳ࡱ࡯ࡳࡵ࠱ࡶࡩࡷ࡯ࡥࡴࠩ〱"),l111lll_ll_ (u"ࠫ࠴ࡲࡩࡴࡶ࠲ࡥࡳ࡯࡭ࡦࠩ〲"),l111lll_ll_ (u"ࠬ࠵࡬ࡪࡵࡷ࠳ࡹࡼࠧ〳"),l111lll_ll_ (u"࠭࠯࡭࡫ࡶࡸࠬ〴")]
	l11l1lll11_ll_ = [l111lll_ll_ (u"ࠧศๆฦๅ้อๅࠨ〵"),l111lll_ll_ (u"ࠨษ็ุ้๊ำๅษอࠫ〶"),l111lll_ll_ (u"ࠩส่ฬ์๊ๆ์ࠣ์ࠥอไไำอ์๋࠭〷"),l111lll_ll_ (u"ࠪห้ฮัศ็ฯࠤฯ๊๊โิํ์๋๐ษࠨ〸"),l111lll_ll_ (u"ࠫ฿๐ัࠡ็ะำิ࠭〹")]
	selection = l1l1111_ll_(l111lll_ll_ (u"ࠬอฮหำࠣห้์ฺ่ࠢส่๊฽ไ้ส࠽ࠫ〺"), l11l1lll11_ll_)
	if selection == -1 : return l111lll_ll_ (u"࠭ࠧ〻")
	if hostname==l111lll_ll_ (u"ࠧࠨ〼"):
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ〽"),l1ll1l1_ll_,l111lll_ll_ (u"ࠩࠪ〾"),l111lll_ll_ (u"ࠪࠫ〿"),False,l111lll_ll_ (u"ࠫࠬ぀"),l111lll_ll_ (u"ࠬࡓ࡙ࡄࡋࡐࡅ࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩぁ"))
		hostname = response.headers[l111lll_ll_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨあ")]
		hostname = hostname.strip(l111lll_ll_ (u"ࠧ࠰ࠩぃ"))
	l1ll111_ll_ = hostname+l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩ࠱ࠪい")+search+l1l111l_ll_[selection]
	l1l11l1_ll_(l1ll111_ll_)
	return
def l1111l1_ll_(l1llllll1ll1_ll_,filter):
	#l1ll1l_ll_(filter,url)
	if l111lll_ll_ (u"ࠩࡂࡃࠬぅ") in l1llllll1ll1_ll_: url = l1llllll1ll1_ll_.split(l111lll_ll_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩう"))[0]
	else: url = l1llllll1ll1_ll_
	#l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬぇ"):l1llllll1ll1_ll_,l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩえ"):l111lll_ll_ (u"࠭ࠧぉ")}
	filter = filter.replace(l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩお"),l111lll_ll_ (u"ࠨࠩか"))
	type,filter = filter.split(l111lll_ll_ (u"ࠩࡢࡣࡤ࠭が"),1)
	if filter==l111lll_ll_ (u"ࠪࠫき"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"ࠫࠬぎ"),l111lll_ll_ (u"ࠬ࠭く")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"࠭࡟ࡠࡡࠪぐ"))
	if type==l111lll_ll_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫけ"):
		if l1l11lll1_ll_[0]+l111lll_ll_ (u"ࠨ࠿ࡀࠫげ") not in l1l1l1ll_ll_: category = l1l11lll1_ll_[0]
		for i in range(len(l1l11lll1_ll_[0:-1])):
			if l1l11lll1_ll_[i]+l111lll_ll_ (u"ࠩࡀࡁࠬこ") in l1l1l1ll_ll_: category = l1l11lll1_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠪࠪࠫ࠭ご")+category+l111lll_ll_ (u"ࠫࡂࡃ࠰ࠨさ")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠬࠬࠦࠨざ")+category+l111lll_ll_ (u"࠭࠽࠾࠲ࠪし")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"ࠧࠧࠨࠪじ"))+l111lll_ll_ (u"ࠨࡡࡢࡣࠬす")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠩࠩࠪࠬず"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭せ"))
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪぜ")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭そ"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨぞ"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"ࠧࠨた"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫだ"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠩࠪち"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩぢ")+l1l1l1l1_ll_
		l1l11llll_ll_ = l1l11ll1l_ll_(l1ll111_ll_,l1llllll1ll1_ll_)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫっ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬษุ่ษิࠤ็อฦๆหࠣห้็๊ะ์๋ࠤฬ๊ส๋ࠢอ้ࠥอฮห์สี์อࠠࠨつ"),l1l11llll_ll_,361,l111lll_ll_ (u"࠭ࠧづ"),l111lll_ll_ (u"ࠧࠨて"),l111lll_ll_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩで"))
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩと"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪど")+l1l1111l_ll_+l111lll_ll_ (u"ࠫࠥࠦࠠ࡞࡟ࠪな"),l1l11llll_ll_,361,l111lll_ll_ (u"ࠬ࠭に"),l111lll_ll_ (u"࠭ࠧぬ"),l111lll_ll_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨね"))
		l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭の"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬは"),l111lll_ll_ (u"ࠪࠫば"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨぱ"),url,l111lll_ll_ (u"ࠬ࠭ひ"),l111lll_ll_ (u"࠭ࠧび"),l111lll_ll_ (u"ࠧࠨぴ"),l111lll_ll_ (u"ࠨࠩふ"),l111lll_ll_ (u"ࠩࡐ࡝ࡈࡏࡍࡂ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬぶ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡀࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶ࠭࠴ࠪࡀࠫ࠿࠳ࡲࡿࡣࡪ࡯ࡤ࠱࠲࡬ࡩ࡭ࡶࡨࡶࡃ࠭ぷ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l11111l_ll_ = re.findall(l111lll_ll_ (u"ࠫࡹࡧࡸࡰࡰࡲࡱࡾࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼ࠩ࠰࠭ࡃ࠮ࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩへ"),block+l111lll_ll_ (u"ࠬࡂࡦࡪ࡮ࡷࡩࡷࡨ࡯ࡹࠩべ"),re.DOTALL)
	dict = {}
	for l1lllll1_ll_,name,block in l11111l_ll_:
		if l111lll_ll_ (u"࠭ࡩ࡯ࡶࡨࡶࡪࡹࡴࠨぺ") in l1lllll1_ll_: continue
		items = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡷࡥ࠲ࡺࡥࡳ࡯ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡵࡺࡷࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡹࡾࡴ࠿ࠩほ"),block,re.DOTALL)
		if l111lll_ll_ (u"ࠨ࠿ࡀࠫぼ") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ぽ"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l11lll1_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪま")+l1l1llll_ll_)
				return
			else:
				l1l11llll_ll_ = l1l11ll1l_ll_(l1ll111_ll_,l1llllll1ll1_ll_)
				if l1lllll1_ll_==l1l11lll1_ll_[-1]:
					l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫみ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไอ็ํ฽ࠥ࠭む"),l1l11llll_ll_,361,l111lll_ll_ (u"࠭ࠧめ"),l111lll_ll_ (u"ࠧࠨも"),l111lll_ll_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩゃ"))
				else: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩや"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้าๅ๋฻ࠣࠫゅ"),l1ll111_ll_,364,l111lll_ll_ (u"ࠫࠬゆ"),l111lll_ll_ (u"ࠬ࠭ょ"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧよ"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠧࠧࠨࠪら")+l1lllll1_ll_+l111lll_ll_ (u"ࠨ࠿ࡀ࠴ࠬり")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠩࠩࠪࠬる")+l1lllll1_ll_+l111lll_ll_ (u"ࠪࡁࡂ࠶ࠧれ")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨろ")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬゎ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅฮ่๎฾ࠦ࠺ࠨわ")+name,l1ll111_ll_,365,l111lll_ll_ (u"ࠧࠨゐ"),l111lll_ll_ (u"ࠨࠩゑ"),l1l1llll_ll_+l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫを"))
		dict[l1lllll1_ll_] = {}
		for value,option in items:
			if option in l11lll1_ll_: continue
			if l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࠨん") in option: continue
			if l111lll_ll_ (u"ࠫฬ๊ใๅࠩゔ") in option: continue
			if l111lll_ll_ (u"ࠬࡴ࠭ࡢࠩゕ") in value: continue
			#if value in [l111lll_ll_ (u"࠭ࡲࠨゖ"),l111lll_ll_ (u"ࠧ࡯ࡥ࠰࠵࠼࠭゗"),l111lll_ll_ (u"ࠨࡶࡹ࠱ࡲࡧࠧ゘")]: continue
			#if l1lllll1_ll_==l111lll_ll_ (u"ࠩࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲࠨ゙"): option = value
			if option==l111lll_ll_ (u"゚ࠪࠫ"): option = value
			l1l11l11l_ll_ = option
			l11l11l11l_ll_ = re.findall(l111lll_ll_ (u"ࠫࡁࡴࡡ࡮ࡧࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡲࡦࡳࡥ࠿ࠩ゛"),option,re.DOTALL)
			if l11l11l11l_ll_: l1l11l11l_ll_ = l11l11l11l_ll_[0]
			l11ll111_ll_ = name+l111lll_ll_ (u"ࠬࡀࠠࠨ゜")+l1l11l11l_ll_
			dict[l1lllll1_ll_][value] = l11ll111_ll_
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"࠭ࠦࠧࠩゝ")+l1lllll1_ll_+l111lll_ll_ (u"ࠧ࠾࠿ࠪゞ")+l1l11l11l_ll_
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠨࠨࠩࠫゟ")+l1lllll1_ll_+l111lll_ll_ (u"ࠩࡀࡁࠬ゠")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧァ")+l1ll1l11_ll_
			if type==l111lll_ll_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬア"):
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬィ"),l1l1l1l_ll_+l11ll111_ll_,url,365,l111lll_ll_ (u"࠭ࠧイ"),l111lll_ll_ (u"ࠧࠨゥ"),l1llll1l_ll_+l111lll_ll_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࠪウ"))
			elif type==l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ェ") and l1l11lll1_ll_[-2]+l111lll_ll_ (u"ࠪࡁࡂ࠭エ") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧォ"))
				#l1ll1l_ll_(l1l11ll1_ll_,l1ll1l11_ll_)
				l11ll1_ll_ = url+l111lll_ll_ (u"ࠬ࠵࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࡂࠫオ")+l1l11ll1_ll_
				l1l11llll_ll_ = l1l11ll1l_ll_(l11ll1_ll_,l1llllll1ll1_ll_)
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭カ"),l1l1l1l_ll_+l11ll111_ll_,l1l11llll_ll_,361,l111lll_ll_ (u"ࠧࠨガ"),l111lll_ll_ (u"ࠨࠩキ"),l111lll_ll_ (u"ࠩࡩ࡭ࡱࡺࡥࡳࡵࠪギ"))
			else: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪク"),l1l1l1l_ll_+l11ll111_ll_,url,364,l111lll_ll_ (u"ࠫࠬグ"),l111lll_ll_ (u"ࠬ࠭ケ"),l1llll1l_ll_)
	return
l1l11lll1_ll_ = [l111lll_ll_ (u"࠭ࡧࡦࡰࡵࡩࠬゲ"),l111lll_ll_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭コ"),l111lll_ll_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨゴ")]
l1l111ll1_ll_ = [l111lll_ll_ (u"ࠩࡰࡴࡦࡧࠧサ"),l111lll_ll_ (u"ࠪ࡫ࡪࡴࡲࡦࠩザ"),l111lll_ll_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪシ"),l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧジ"),l111lll_ll_ (u"࠭ࡑࡶࡣ࡯࡭ࡹࡿࠧス"),l111lll_ll_ (u"ࠧࡪࡰࡷࡩࡷ࡫ࡳࡵࠩズ"),l111lll_ll_ (u"ࠨࡰࡤࡸ࡮ࡵ࡮ࠨセ"),l111lll_ll_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫゼ")]
def l1l11ll1l_ll_(l1ll111_ll_,l11ll1_ll_):
	l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀࠩソ"),l111lll_ll_ (u"ࠫ࠿ࡀ࠯ࡂ࡬ࡤࡼࡈ࡫࡮ࡵࡧࡵ࠳ࡋ࡯࡬ࡵࡧࡵ࡭ࡳ࡭࠯ࠨゾ"))
	l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠬࡃ࠽ࠨタ"),l111lll_ll_ (u"࠭࠯ࠨダ"))
	l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠧࠧࠨࠪチ"),l111lll_ll_ (u"ࠨ࠱ࠪヂ"))
	return l1ll111_ll_
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠩࡌࡒࠥࠦࠠࠡࠩッ")+mode)
	# mode==l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬツ")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧヅ")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"ࠬࡧ࡬࡭ࠩテ")					all filters (l1l11l11_ll_ empty filter)
	filters = filters.strip(l111lll_ll_ (u"࠭ࠦࠧࠩデ"))
	l1l1ll11_ll_,l1llll11_ll_ = {},l111lll_ll_ (u"ࠧࠨト")
	if l111lll_ll_ (u"ࠨ࠿ࡀࠫド") in filters:
		items = filters.split(l111lll_ll_ (u"ࠩࠩࠪࠬナ"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"ࠪࡁࡂ࠭ニ"))
			l1l1ll11_ll_[var] = value
	for key in l1l111ll1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"ࠫ࠵࠭ヌ")
		if l111lll_ll_ (u"ࠬࠫࠧネ") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡸࡤࡰࡺ࡫ࡳࠨノ") and value!=l111lll_ll_ (u"ࠧ࠱ࠩハ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠨࠢ࠮ࠤࠬバ")+value
		elif mode==l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬパ") and value!=l111lll_ll_ (u"ࠪ࠴ࠬヒ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠫࠫࠬࠧビ")+key+l111lll_ll_ (u"ࠬࡃ࠽ࠨピ")+value
		elif mode==l111lll_ll_ (u"࠭ࡡ࡭࡮ࠪフ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠧࠧࠨࠪブ")+key+l111lll_ll_ (u"ࠨ࠿ࡀࠫプ")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠩࠣ࠯ࠥ࠭ヘ"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠪࠪࠫ࠭ベ"))
	#l1ll1l_ll_(l1llll11_ll_,l111lll_ll_ (u"ࠫࡔ࡛ࡔࠨペ"))
	return l1llll11_ll_