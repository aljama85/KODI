# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
#
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㎞")
#l1l1ll11l1ll_ll_ = [ l111lll_ll_ (u"࠭࡭ࡺࡵࡷࡶࡪࡧ࡭ࠨ㎟"),l111lll_ll_ (u"ࠧࡷ࡫ࡰࡴࡱ࡫ࠧ㎠"),l111lll_ll_ (u"ࠨࡸ࡬ࡨࡧࡵ࡭ࠨ㎡"),l111lll_ll_ (u"ࠩࡪࡳࡺࡴ࡬ࡪ࡯࡬ࡸࡪࡪࠧ㎢") ]
l1l1ll11l1ll_ll_ = []
headers = {l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㎣"):l111lll_ll_ (u"ࠫࠬ㎤")}
def l11_ll_(l1l111l_ll_,l1ll_ll_=l111lll_ll_ (u"ࠬ࠭㎥"),type=l111lll_ll_ (u"࠭ࠧ㎦")):
	l1l111l_ll_ = list(set(l1l111l_ll_))
	l1111ll_ll_,l1l111l_ll_ = l1l11ll111ll_ll_(l1l111l_ll_,l1ll_ll_)
	l1ll1111l11l_ll_ = str(l1l111l_ll_).count(l111lll_ll_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ㎧"))
	l1l11lllll11_ll_ = str(l1l111l_ll_).count(l111lll_ll_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㎨"))
	l1ll1111l1ll_ll_ = len(l1l111l_ll_)-l1ll1111l11l_ll_-l1l11lllll11_ll_
	l1l11ll1l1ll_ll_ = l111lll_ll_ (u"ุ่ࠩฬํฯส࠼ࠪ㎩")+str(l1ll1111l11l_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࠠหฯ่๎้ࡀࠧ㎪")+str(l1l11lllll11_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࠡลัี๎ࡀࠧ㎫")+str(l1ll1111l1ll_ll_)
	#l1ll1l_ll_(str(l1ll1111l11l_ll_),str(l1l11lllll11_ll_))
	#selection = l1l1111_ll_(l1l11ll1l1ll_ll_, l1l111l_ll_)
	if len(l1l111l_ll_)==0:
		result = l111lll_ll_ (u"ࠬࡻ࡮ࡳࡧࡶࡳࡱࡼࡥࡥࠩ㎬")
		l1111llll_ll_ = l111lll_ll_ (u"࠭ࠧ㎭")
	else:
		while True:
			l1111llll_ll_ = l111lll_ll_ (u"ࠧࠨ㎮")
			if len(l1l111l_ll_)==1: selection = 0
			else: selection = l1l1111_ll_(l1l11ll1l1ll_ll_, l1111ll_ll_)
			if selection == -1: result = l111lll_ll_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠵ࡸࡺ࡟࡮ࡧࡱࡹࠬ㎯")
			else:
				title = l1111ll_ll_[selection]
				url = l1l111l_ll_[selection]
				#l1ll1l_ll_(str(l11l1lllll_ll_[selection]),str(l11l1lllll_ll_[selection]))
				if l111lll_ll_ (u"ࠩึ๎ึ็ัࠨ㎰") in title and l111lll_ll_ (u"ࠪ࠶๊า็้ๆ࠵ࠫ㎱") in title:
					l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ㎲"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡖࡩࡱ࡫ࡣࡵࡧࡧࠤࡘ࡫ࡲࡷࡧࡵࠤࠥࠦࡓࡦࡴࡹࡩࡷࡀࠠ࡜ࠢࠪ㎳")+title+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ㎴")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ㎵"))
					import l1l111ll111_ll_
					l1l111ll111_ll_.l111l1l_ll_(156)
					result = l111lll_ll_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㎶")
				else:
					l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㎷"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡐ࡭ࡣࡼ࡭ࡳ࡭ࠠࡔࡧ࡯ࡩࡨࡺࡥࡥࠢࡖࡩࡷࡼࡥࡳࠢࠣࠤࡘ࡫ࡲࡷࡧࡵ࠾ࠥࡡࠠࠨ㎸")+title+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ㎹")+url+l111lll_ll_ (u"ࠬࠦ࡝ࠨ㎺"))
					result,l1111llll_ll_,l1llllll1_ll_ = l11111ll_ll_(url,l1ll_ll_,type)
					#l1ll1l_ll_(result,l1111llll_ll_)
			if l111lll_ll_ (u"࠭࡜࡯ࠩ㎻") not in l1111llll_ll_: l1l1ll1lll11_ll_,l1l1ll1ll1ll_ll_ = l1111llll_ll_,l111lll_ll_ (u"ࠧࠨ㎼")
			else: l1l1ll1lll11_ll_,l1l1ll1ll1ll_ll_ = l1111llll_ll_.split(l111lll_ll_ (u"ࠨ࡞ࡱࠫ㎽"),1)
			if result in [l111lll_ll_ (u"ࠩࡕࡉ࡙࡛ࡒࡏࠩ㎾"),l111lll_ll_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࠬ㎿"),l111lll_ll_ (u"ࠫࡵࡲࡡࡺ࡫ࡱ࡫ࠬ㏀"),l111lll_ll_ (u"ࠬࡩࡡ࡯ࡥࡨࡰࡪࡪ࡟࠲ࡵࡷࡣࡲ࡫࡮ࡶࠩ㏁")] or len(l1l111l_ll_)==1: break
			elif result in [l111lll_ll_ (u"࠭ࡦࡢ࡫࡯ࡩࡩ࠭㏂"),l111lll_ll_ (u"ࠧࡵ࡫ࡰࡩࡴࡻࡴࠨ㏃"),l111lll_ll_ (u"ࠨࡶࡵ࡭ࡪࡪࠧ㏄")]: break
			elif result not in [l111lll_ll_ (u"ࠩࡦࡥࡳࡩࡥ࡭ࡧࡧࡣ࠷ࡴࡤࡠ࡯ࡨࡲࡺ࠭㏅"),l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴࠩ㏆")]: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ㏇"),l111lll_ll_ (u"ࠬอไิ์ิๅึࠦไๆࠢํ฽๊๊ࠠอำหࠤุ๐ัโำࠣ฾๏ื็ࠨ㏈")+l111lll_ll_ (u"࠭࡜࡯ࠩ㏉")+l1l1ll1lll11_ll_+l111lll_ll_ (u"ࠧ࡝ࡰࠪ㏊")+l1l1ll1ll1ll_ll_)
	if result==l111lll_ll_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㏋") and len(l1111ll_ll_)>0: l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ㏌"),l111lll_ll_ (u"ࠪื๏ืแา๊ࠢิฬࠦวๅใํำ๏๎ࠠๅ็ࠣ๎฾๋ไࠡฮิฬࠥ็๊ะ์๋ࠤ฿๐ั่ࠩ㏍")+l111lll_ll_ (u"ࠫࡡࡴࠧ㏎")+l1111llll_ll_)
	elif result in [l111lll_ll_ (u"ࠬ࡬ࡡࡪ࡮ࡨࡨࠬ㏏"),l111lll_ll_ (u"࠭ࡴࡪ࡯ࡨࡳࡺࡺࠧ㏐")] and l1111llll_ll_!=l111lll_ll_ (u"ࠧࠨ㏑"): l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㏒"),l1111llll_ll_)
	elif l1111llll_ll_==l111lll_ll_ (u"ࠩࡕࡉ࡙࡛ࡒࡏࡡࡗࡓࡤ࡟ࡏࡖࡖࡘࡆࡊ࠭㏓"): result = l1111llll_ll_+l111lll_ll_ (u"ࠪ࠾࠿࠭㏔")+l1llllll1_ll_[0]
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࡲࡦࡵࡸࡰࡹࠦࡩ࡯ࠢ࡞ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠱ࡴࡶࡢࡱࡪࡴࡵࠨ࠮ࠪࡧࡦࡴࡣࡦ࡮ࡨࡨࡤ࠸࡮ࡥࡡࡰࡩࡳࡻࠧ࡞࠼ࠍࠍࠎࠩࡌࡐࡉࡢࡘࡍࡏࡓࠩࠩࡑࡓ࡙ࡏࡃࡆࠩ࠯ࡐࡔࡍࡇࡊࡐࡊࠬࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠫ࠮ࠫࠥࠦࠠࡕࡧࡶࡸ࠿ࠦࠠࠡࠩ࠮ࡷࡾࡹ࠮ࡢࡴࡪࡺࡠ࠶࡝ࠬࡵࡼࡷ࠳ࡧࡲࡨࡸ࡞࠶ࡢ࠯ࠊࠊࠋࡻࡦࡲࡩࡰ࡭ࡷࡪ࡭ࡳ࠴ࡳࡦࡶࡕࡩࡸࡵ࡬ࡷࡧࡧ࡙ࡷࡲࠨࡢࡦࡧࡳࡳࡥࡨࡢࡰࡧࡰࡪ࠲ࠠࡇࡣ࡯ࡷࡪ࠲ࠠࡹࡤࡰࡧ࡬ࡻࡩ࠯ࡎ࡬ࡷࡹࡏࡴࡦ࡯ࠫ࠭࠮ࠐࠉࠊࡲ࡯ࡥࡾࡥࡩࡵࡧࡰࠤࡂࠦࡸࡣ࡯ࡦ࡫ࡺ࡯࠮ࡍ࡫ࡶࡸࡎࡺࡥ࡮ࠪࡳࡥࡹ࡮࠽ࠨࡲ࡯ࡹ࡬࡯࡮࠻࠱࠲ࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡤࡶࡦࡨࡩࡤࡸ࡬ࡨࡪࡵࡳ࠰ࡁࡰࡳࡩ࡫࠽࠲࠶࠶ࠪࡺࡸ࡬࠾ࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࠨ࠷ࡋࡼࠥ࠴ࡆࡪࡻࡧ࠷ࡰࡹࡘࡷࡻ࠾ࡗࠧࠪࠌࠌࠍࡽࡨ࡭ࡤ࠰ࡓࡰࡦࡿࡥࡳࠪࠬ࠲ࡵࡲࡡࡺࠪࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳࡫ࡲࡶ࠲࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠵ࡩࡱࡪࡲࡲࡪ࠵࠱࠳࠵࠷࠸࠼࠴࡭ࡱ࠶ࠪ࠰ࡵࡲࡡࡺࡡ࡬ࡸࡪࡳࠩࠋࠋࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࠨฬ่ࠤฬ๊วๅ฼สลࠬ࠲ࠧࠨࠫࠍࠍࠧࠨࠢ㏕")
	return result
	#if l1ll_ll_==l111lll_ll_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇࠧ㏖"): l1l1l1l_ll_=l111lll_ll_ (u"࠭ࡈࡍࡃࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㏗")
	#elif l1ll_ll_==l111lll_ll_ (u"ࠧ࠵ࡊࡈࡐࡆࡒࠧ㏘"): l1l1l1l_ll_=l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡌࡊࡒࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㏙")
	#elif l1ll_ll_==l111lll_ll_ (u"ࠩࡄࡏࡔࡇࡍࠨ㏚"): l1l1l1l_ll_=l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡇࡋࡎࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㏛")
	#elif l1ll_ll_==l111lll_ll_ (u"ࠫࡘࡎࡁࡉࡋࡇ࠸࡚࠭㏜"): l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡔࡊࡄࠤࠬ㏝")
	#size = len(l11l1lllll_ll_)
	#for i in range(0,size):
	#	title = l1l1ll1ll1l1_ll_[i]
	#	link = l11l1lllll_ll_[i]
	#	l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ㏞"),l1l1l1l_ll_+title,link,160,l111lll_ll_ (u"ࠧࠨ㏟"),l111lll_ll_ (u"ࠨࠩ㏠"),l1ll_ll_)
def l11111ll_ll_(url,l1ll_ll_,type=l111lll_ll_ (u"ࠩࠪ㏡")):
	url = url.strip(l111lll_ll_ (u"ࠪࠤࠬ㏢")).strip(l111lll_ll_ (u"ࠫࠫ࠭㏣")).strip(l111lll_ll_ (u"ࠬࡅࠧ㏤")).strip(l111lll_ll_ (u"࠭࠯ࠨ㏥"))
	l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll1l1ll_ll_(url)
	#l1ll1l_ll_(url,l1111llll_ll_)
	if l111lll_ll_ (u"ࠧࡓࡇࡗ࡙ࡗࡔ࡟ࡕࡑࡢ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㏦") in l1111llll_ll_: result,l1111llll_ll_ = l111lll_ll_ (u"ࠨࡔࡈࡘ࡚ࡘࡎࠨ㏧"),l111lll_ll_ (u"ࠩࡕࡉ࡙࡛ࡒࡏࡡࡗࡓࡤ࡟ࡏࡖࡖࡘࡆࡊ࠭㏨")
	elif l1l111l_ll_:
		while True:
			if len(l1l111l_ll_)==1: selection = 0
			else: selection = l1l1111_ll_(l111lll_ll_ (u"ࠪหำะัࠡษ็้้็ࠠศๆ่๊ฬูศ࠻ࠩ㏩"), l1111ll_ll_)
			if selection == -1: result = l111lll_ll_ (u"ࠫࡨࡧ࡮ࡤࡧ࡯ࡩࡩࡥ࠲࡯ࡦࡢࡱࡪࡴࡵࠨ㏪")
			else:
				l1ll1l111ll1_ll_ = l1l111l_ll_[selection]
				title = l1111ll_ll_[selection]
				l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㏫"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡷࡪࡲࡥࡤࡶࡨࡨࠥࡼࡩࡥࡧࡲࠤࠥࠦࡓࡦ࡮ࡨࡧࡹ࡫ࡤ࠻ࠢ࡞ࠤࠬ㏬")+title+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㏭")+str(l1ll1l111ll1_ll_)+l111lll_ll_ (u"ࠨࠢࡠࠫ㏮"))
				if l111lll_ll_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤ࠲ࠬ㏯") in l1ll1l111ll1_ll_ and l111lll_ll_ (u"ࠪࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ㏰") in l1ll1l111ll1_ll_:
					l1l1l11l1l11_ll_,l1lllll1l_ll_,l1llllll1_ll_ = l1l1l11111l1_ll_(l1ll1l111ll1_ll_)
					if l1llllll1_ll_: l1ll1l111ll1_ll_ = l1llllll1_ll_[0]
					else: l1ll1l111ll1_ll_ = l111lll_ll_ (u"ࠫࠬ㏱")
				if l1ll1l111ll1_ll_==l111lll_ll_ (u"ࠬ࠭㏲"): result = l111lll_ll_ (u"࠭ࡵ࡯ࡴࡨࡷࡴࡲࡶࡦࡦࠪ㏳")
				else: result = l111lll1_ll_(l1ll1l111ll1_ll_,l1ll_ll_,type)
			if result in [l111lll_ll_ (u"ࠧࡱ࡮ࡤࡽ࡮ࡴࡧࠨ㏴"),l111lll_ll_ (u"ࠨࡥࡤࡲࡨ࡫࡬ࡦࡦࡢ࠶ࡳࡪ࡟࡮ࡧࡱࡹࠬ㏵")] or len(l1l111l_ll_)==1: break
			elif result in [l111lll_ll_ (u"ࠩࡩࡥ࡮ࡲࡥࡥࠩ㏶"),l111lll_ll_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ㏷"),l111lll_ll_ (u"ࠫࡹࡸࡩࡦࡦࠪ㏸")]: break
			else: l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㏹"),l111lll_ll_ (u"࠭วๅ็็ๅ๊ࠥๅࠡ์฼้้ࠦฬาส้้ࠣ็ࠠ฻์ิ๋ࠬ㏺"))
		l111lll_ll_ (u"ࠢࠣࠤࠍࠍࠎ࡯ࡦࠡࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡱࡵࡪࠧࠡ࡫ࡱࠤࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡡ࠰࡞࠼ࠍࠍࠎࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࡧࡱ࡯ࡣ࡬ࠢࡲ࡯ࠥࡺ࡯ࠡࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠣࡸ࡭࡫ࠠࡩࡶࡷࡴࠥࡹࡥࡳࡸࡨࡶࠬ࠲ࠧࠨࠫࠍࠍࠎࠏࠣࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡅࡄࡇࡍࡋࡄࠩࡐࡒࡣࡈࡇࡃࡉࡇ࠯ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡱࡵࡣࡢ࡮࡫ࡳࡸࡺ࠺࠶࠷࠳࠹࠺࠵ࡳࡩࡷࡷࡨࡴࡽ࡮ࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡒࡏࡅ࡞ࡥࡌࡊࡐࡎ࠱࠶ࡹࡴࠨࠫࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࡝࠳ࡡ࠳ࡹࡨࡶࡶࡧࡳࡼࡴࠨࠪࠌࠌࠍࠧࠨࠢ㏻")
	else:
		result = l111lll_ll_ (u"ࠨࡷࡱࡶࡪࡹ࡯࡭ࡸࡨࡨࠬ㏼")
		l1lll11l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩࠫࡠ࠳ࡧࡶࡪࡾ࡟࠲ࡹࡹࡼ࡝࠰ࡰࡴ࠹ࢂ࡜࠯࡯࠶ࡹࢁࡢ࠮࡮࠵ࡸ࠼ࢁࡢ࠮࡮ࡲࡧࢀࡡ࠴࡭࡬ࡸࡿࡠ࠳࡬࡬ࡷࡾ࡟࠲ࡲࡶ࠳ࠪࠪࡿࡠࡄ࠴ࠪࡀࡾ࠲ࡠࡄ࠴ࠪࡀࡾ࡟ࢀ࠳࠰࠿ࠪࠨࠩࠫ㏽"),url.lower()+l111lll_ll_ (u"ࠪࠪࠫ࠭㏾"),re.DOTALL|re.IGNORECASE)
		if l1lll11l1l_ll_: result = l111lll1_ll_(url,l1ll_ll_,type)
	return result,l1111llll_ll_,l1l111l_ll_
	#title = xbmc.getInfoLabel( l111lll_ll_ (u"ࠦࡑ࡯ࡳࡵࡋࡷࡩࡲ࠴ࡌࡢࡤࡨࡰࠧ㏿") )
	#if l111lll_ll_ (u"ู๊ࠬาใิࠤ฾อๅࠡ็ฯ๋ํ๊ࠧ㐀") in title:
	#	import l1l111ll111_ll_
	#	l1l111ll111_ll_.l111l1l_ll_(156)
	#	return l111lll_ll_ (u"࠭ࠧ㐁")
def l1l1l11llll1_ll_(url):
	# url = url+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨ㐂")+name+l111lll_ll_ (u"ࠨࡡࡢࠫ㐃")+type+l111lll_ll_ (u"ࠩࡢࡣࠬ㐄")+filetype+l111lll_ll_ (u"ࠪࡣࡤ࠭㐅")+quality
	# url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡦࡱࡷࡢ࡯࠱ࡲࡪࡺ࠿࡯ࡣࡰࡩࡩࡃࡡ࡬ࡹࡤࡱࡤࡥࡷࡢࡶࡦ࡬ࡤࡥ࡭ࡱ࠶ࡢࡣ࠼࠸࠰ࠨ㐆")
	#l1ll1l_ll_(url.split(l111lll_ll_ (u"ࠬࡅࠧ㐇"))[2],l111lll_ll_ (u"࠭ࠧ㐈"))
	url = url.replace(l111lll_ll_ (u"ࠧิ์ิๅึࠦࠧ㐉"),l111lll_ll_ (u"ࠨࠢࠪ㐊")).replace(l111lll_ll_ (u"่ࠩฬฬฺัࠡࠩ㐋"),l111lll_ll_ (u"ࠪࠤࠬ㐌"))
	l1ll111_ll_,l1l1l1l1ll11_ll_,server,l1l1l1llll1l_ll_,name,type,filetype,quality,source = url,l111lll_ll_ (u"ࠫࠬ㐍"),l111lll_ll_ (u"ࠬ࠭㐎"),l111lll_ll_ (u"࠭ࠧ㐏"),l111lll_ll_ (u"ࠧࠨ㐐"),l111lll_ll_ (u"ࠨࠩ㐑"),l111lll_ll_ (u"ࠩࠪ㐒"),l111lll_ll_ (u"ࠪࠫ㐓"),l111lll_ll_ (u"ࠫࠬ㐔")
	if l111lll_ll_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭㐕") in url:
		l1ll111_ll_,l1l1l1l1ll11_ll_ = url.split(l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㐖"),1)
		l1l1l1l1ll11_ll_ = l1l1l1l1ll11_ll_+l111lll_ll_ (u"ࠧࡠࡡࠪ㐗")+l111lll_ll_ (u"ࠨࡡࡢࠫ㐘")+l111lll_ll_ (u"ࠩࡢࡣࠬ㐙")+l111lll_ll_ (u"ࠪࡣࡤ࠭㐚")
		l1l1l1l1ll11_ll_ = l1l1l1l1ll11_ll_.lower()
		name,type,filetype,quality,source = l1l1l1l1ll11_ll_.split(l111lll_ll_ (u"ࠫࡤࡥࠧ㐛"))[:5]
	if quality==l111lll_ll_ (u"ࠬ࠭㐜"): quality = l111lll_ll_ (u"࠭࠰ࠨ㐝")
	else: quality = quality.replace(l111lll_ll_ (u"ࠧࡱࠩ㐞"),l111lll_ll_ (u"ࠨࠩ㐟")).replace(l111lll_ll_ (u"ࠩࠣࠫ㐠"),l111lll_ll_ (u"ࠪࠫ㐡"))
	l1ll111_ll_ = l1ll111_ll_.strip(l111lll_ll_ (u"ࠫࡄ࠭㐢")).strip(l111lll_ll_ (u"ࠬ࠵ࠧ㐣")).strip(l111lll_ll_ (u"࠭ࠦࠨ㐤"))
	server = l1l11l1lll_ll_(l1ll111_ll_,True)
	if len(name)>1: l1l1l1llll1l_ll_ = name
	elif len(source)>1: l1l1l1llll1l_ll_ = source
	else: l1l1l1llll1l_ll_ = server
	l1l1l1llll1l_ll_ = l1l11l1lll_ll_(l1l1l1llll1l_ll_,False)
	#l1ll1l_ll_(l1l1l1llll1l_ll_,name)
	return l1ll111_ll_,l1l1l1l1ll11_ll_,server,l1l1l1llll1l_ll_,name,type,filetype,quality,source
def l1ll1111l1l1_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠫ㐥"))
	# l1l1ll111lll_ll_	: سيرفر خاص
	# l1l1l1l11111_ll_		: سيرفر عام معروف
	# external	: سيرفر عام خارجي
	# resolver	: سيرفر عام خارجي
	# named		: سيرفر محدد
	l1ll11l1llll_ll_,name,l1l1ll111lll_ll_,l1l1l1l11111_ll_,external,named,resolver = l111lll_ll_ (u"ࠨࠩ㐦"),l111lll_ll_ (u"ࠩࠪ㐧"),None,None,None,None,None
	l1ll111_ll_,l1l1l1l1ll11_ll_,server,l1l1l1llll1l_ll_,name,type,filetype,quality,source = l1l1l11llll1_ll_(url)
	if l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ㐨") in url:
		if type==l111lll_ll_ (u"ࠫࡼࡧࡴࡤࡪࠪ㐩"): type = l111lll_ll_ (u"ࠬࠦࠧ㐪")+l111lll_ll_ (u"࠭ๅีษ๊ำฮ࠭㐫")
		elif type==l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㐬"): type = l111lll_ll_ (u"ࠨࠢࠪ㐭")+l111lll_ll_ (u"ࠩࠨࠩฯำๅ๋ๆࠪ㐮")
		elif type==l111lll_ll_ (u"ࠪࡦࡴࡺࡨࠨ㐯") or type==l111lll_ll_ (u"ࠫࠬ㐰"): type = l111lll_ll_ (u"ࠬࠦࠧ㐱")+l111lll_ll_ (u"࠭ࠥๆึส๋ิฯ้ࠠฬะ้๏๊ࠧ㐲")
		if filetype!=l111lll_ll_ (u"ࠧࠨ㐳"):
			if l111lll_ll_ (u"ࠨ࡯ࡳ࠸ࠬ㐴") not in filetype: filetype = l111lll_ll_ (u"ࠩࠨࠫ㐵")+filetype
			filetype = l111lll_ll_ (u"ࠪࠤࠬ㐶")+filetype
		if quality!=l111lll_ll_ (u"ࠫࠬ㐷"):
			quality = l111lll_ll_ (u"ࠬࠫࠥࠦࠧࠨࠩࠪࠫࠥࠨ㐸")+quality
			quality = l111lll_ll_ (u"࠭ࠠࠨ㐹")+quality[-9:]
	#if any(value in server for value in l1l1ll11l1ll_ll_): return l111lll_ll_ (u"ࠧࠨ㐺")
	#l1ll1l_ll_(name,l1l1l1llll1l_ll_)
	if   l111lll_ll_ (u"ࠨࡣ࡮ࡳࡦࡳࠧ㐻")		in source: named	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠩࡤ࡯ࡼࡧ࡭ࠨ㐼")		in source: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠪࡥࡰࡽࡡ࡮ࠩ㐽")
	elif l111lll_ll_ (u"ࠫࡦࡸࡡࡣࡵࡨࡩࡩ࠭㐾")		in server: l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠬ࡬ࡡࡴࡧ࡯࡬ࡩ࠭㐿")		in server: l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"࠭࡭ࡰࡸࡶ࠸ࡺ࠭㑀")		in name:   l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠧ࡮ࡻࡨ࡫ࡾࡼࡩࡱࠩ㑁")		in name:   l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ㑂")		in name:   l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠩไะึ࠭㑃")			in name:   l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠪࡪࡦࡰࡥࡳࠩ㑄")
	elif l111lll_ll_ (u"ࠫๆ๊ำุ์้ࠫ㑅")		in name:   l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠬࡶࡡ࡭ࡧࡶࡸ࡮ࡴࡥࠨ㑆")
	elif l111lll_ll_ (u"࠭ࡧࡥࡴ࡬ࡺࡪ࠭㑇")		in l1ll111_ll_:   l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫ࠧ㑈")
	elif l111lll_ll_ (u"ࠨ࡯ࡼࡧ࡮ࡳࡡࠨ㑉")		in name:   l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㑊")		in name:   l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠪࡨࡦ࡯࡬ࡺ࡯ࡲࡸ࡮ࡵ࡮ࠨ㑋")	in server: l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ㑌")		in server: l1l1ll111lll_ll_	= l1l1l1llll1l_ll_
	#elif l111lll_ll_ (u"ࠬࡩࡩ࡮ࡣࡱࡳࡼ࠴࡮ࡦࡶࠪ㑍")	in l1ll111_ll_:   l1l1ll111lll_ll_	= l111lll_ll_ (u"࠭ࠠࠨ㑎")
	elif l111lll_ll_ (u"ࠧࡴࡪࡤ࡬࡮ࡪ࠴ࡶࠩ㑏")		in server: named	= l1l1l1llll1l_ll_
	elif l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࠧ㑐")	 	in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧࠪ㑑")
	elif l111lll_ll_ (u"ࠪࡽ࠷ࡻ࠮ࡣࡧࠪ㑒")	 	in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩࠬ㑓")
	elif l111lll_ll_ (u"ࠬࡪ࠮ࡦࡩࡼࡦࡪࡹࡴ࠯ࡦࠪ㑔")	in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"࠭ࡥࡨࡻࡥࡩࡸࡺࡶࡪࡲࠪ㑕")
	elif l111lll_ll_ (u"ࠧࡦࡩࡼࡦࡪࡹࡴࠨ㑖")		in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠨࡧࡪࡽࡧ࡫ࡳࡵࠩ㑗")
	elif l111lll_ll_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ㑘")		in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠪࡱࡴࡼࡩࡻ࡮ࡤࡲࡩ࠭㑙")
	elif l111lll_ll_ (u"ࠫ࡫ࡧࡣࡶ࡮ࡷࡽࡧࡵ࡯࡬ࡵࠪ㑚")	in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠬ࡬ࡡࡤࡷ࡯ࡸࡾࡨ࡯ࡰ࡭ࡶࠫ㑛")
	elif l111lll_ll_ (u"࠭ࡩ࡯ࡨ࡯ࡥࡲ࠴ࡣࡤࠩ㑜")	in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠧࡪࡰࡩࡰࡦࡳࠧ㑝")
	elif l111lll_ll_ (u"ࠨࡤࡸࡾࡿࡼࡲ࡭ࠩ㑞")		in server: l1l1ll111lll_ll_	= l111lll_ll_ (u"ࠩࡥࡹࡿࢀࡶࡳ࡮ࠪ㑟")
	elif l111lll_ll_ (u"ࠪࡥࡷࡧࡢ࡭ࡱࡤࡨࡸ࠭㑠")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ㑡")
	elif l111lll_ll_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭㑢")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"࠭ࡡࡳࡥ࡫࡭ࡻ࡫ࠧ㑣")
	elif l111lll_ll_ (u"ࠧࡤࡣࡷࡧ࡭࠴ࡩࡴࠩ㑤")	 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠨࡥࡤࡸࡨ࡮ࠧ㑥")
	elif l111lll_ll_ (u"ࠩࡩ࡭ࡱ࡫ࡲࡪࡱࠪ㑦")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠪࡪ࡮ࡲࡥࡳ࡫ࡲࠫ㑧")
	elif l111lll_ll_ (u"ࠫࡻ࡯ࡤࡣ࡯ࠪ㑨")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠬࡼࡩࡥࡤࡰࠫ㑩")
	elif l111lll_ll_ (u"࠭ࡶࡪࡦ࡫ࡨࠬ㑪")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠧࡷ࡫ࡧ࡬ࡩ࠭㑫")
	elif l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࡢࡪࡰࠪ㑬")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࡣ࡫ࡱࠫ㑭")
	elif l111lll_ll_ (u"ࠪ࡫ࡴࡼࡩࡥࠩ㑮")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠫ࡬ࡵࡶࡪࡦࠪ㑯")
	elif l111lll_ll_ (u"ࠬࡲࡩࡪࡸ࡬ࡨࡪࡵࠧ㑰") 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"࠭࡬ࡪ࡫ࡹ࡭ࡩ࡫࡯ࠨ㑱")
	elif l111lll_ll_ (u"ࠧ࡮ࡲ࠷ࡹࡵࡲ࡯ࡢࡦࠪ㑲")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠨ࡯ࡳ࠸ࡺࡶ࡬ࡰࡣࡧࠫ㑳")
	elif l111lll_ll_ (u"ࠩࡳࡹࡧࡲࡩࡤࡸ࡬ࡨࡪࡵࠧ㑴")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠪࡴࡺࡨ࡬ࡪࡥࡹ࡭ࡩ࡫࡯ࠨ㑵")
	elif l111lll_ll_ (u"ࠫࡷࡧࡰࡪࡦࡹ࡭ࡩ࡫࡯ࠨ㑶") 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ㑷")
	elif l111lll_ll_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ㑸")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠧࡵࡱࡳ࠸ࡹࡵࡰࠨ㑹")
	elif l111lll_ll_ (u"ࠨࡷࡳࡦࡴࡳࠧ㑺") 		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠩࡸࡴࡧࡵ࡭ࠨ㑻")
	elif l111lll_ll_ (u"ࠪࡹࡵࡶ࡯࡮ࠩ㑼") 		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠫࡺࡶࡰࡰ࡯ࠪ㑽")
	elif l111lll_ll_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ㑾") 		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"࠭ࡵࡲ࡮ࡲࡥࡩ࠭㑿")
	elif l111lll_ll_ (u"ࠧࡷࡥࡶࡸࡷ࡫ࡡ࡮ࠩ㒀") 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠨࡸࡦࡷࡹࡸࡥࡢ࡯ࠪ㒁")
	elif l111lll_ll_ (u"ࠩࡹ࡭ࡩࡨ࡯ࡣࠩ㒂")		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠪࡺ࡮ࡪࡢࡰࡤࠪ㒃")
	elif l111lll_ll_ (u"ࠫࡻ࡯ࡤࡰࡼࡤࠫ㒄") 		in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠬࡼࡩࡥࡱࡽࡥࠬ㒅")
	elif l111lll_ll_ (u"࠭ࡷࡢࡶࡦ࡬ࡻ࡯ࡤࡦࡱࠪ㒆") 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠧࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲࠫ㒇")
	elif l111lll_ll_ (u"ࠨࡹ࡬ࡲࡹࡼ࠮࡭࡫ࡹࡩࠬ㒈")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠩࡺ࡭ࡳࡺࡶ࠯࡮࡬ࡺࡪ࠭㒉")
	elif l111lll_ll_ (u"ࠪࡾ࡮ࡶࡰࡺࡵ࡫ࡥࡷ࡫ࠧ㒊")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ㒋")
	#elif l111lll_ll_ (u"ࠬࡻࡰࡵࡱࡥࡳࡽ࠭㒌") 	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"࠭ࡵࡱࡶࡲࡦࡴࡾࠧ㒍")
	#elif l111lll_ll_ (u"ࠧࡶࡲࡷࡳࡸࡺࡲࡦࡣࡰࠫ㒎")	in server: l1l1l1l11111_ll_	= l111lll_ll_ (u"ࠨࡷࡳࡸࡴࡹࡴࡳࡧࡤࡱࠬ㒏")
	else:
		#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㒐"),url+l111lll_ll_ (u"ࠪࡁࡂࡃࠧ㒑")+l1ll111_ll_)
		try:
			import resolveurl
			resolver = resolveurl.l1ll111l1l1l_ll_(l1ll111_ll_).l1l1ll11llll_ll_()
		except: pass
		l111lll_ll_ (u"ࠦࠧࠨࠊࠊࠋ࡬ࡪࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࡵ࠾ࠏࠏࠉࠊࠥࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬࡔࡏࡕࡋࡆࡉࠬ࠲ࠧ࠲࠳࠴࠵ࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࠫ࠮ࠐࠉࠊࠋࡵࡩࡸࡵ࡬ࡷࡧࡵࠤࡂࠦࡆࡢ࡮ࡶࡩࠏࠏࠉࠊࠥࠣ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡾࡵࡵࡵࡷࡥࡩ࠲ࡪ࡬࠯ࡱࡵ࡫ࠏࠏࠉࠊ࡮࡬ࡷࡹࡥࡵࡳ࡮ࠣࡁࠥ࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡺࡶࡧࡰ࠲ࡵࡲࡨ࠰ࡪ࡭ࡹ࡮ࡵࡣ࠰࡬ࡳ࠴ࡿ࡯ࡶࡶࡸࡦࡪ࠳ࡤ࡭࠱ࡶࡹࡵࡶ࡯ࡳࡶࡨࡨࡸ࡯ࡴࡦࡵ࠱࡬ࡹࡳ࡬ࠨࠌࠌࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡌࡐࡐࡊࡣࡈࡇࡃࡉࡇ࠯ࡰ࡮ࡹࡴࡠࡷࡵࡰ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡗࡋࡓࡐࡎ࡙ࡅࡇࡒࡅ࠮࠳ࡶࡸࠬ࠯ࠊࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨ࠾ࡸࡰࡃ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡭ࡺ࡭࡭࠼ࠍࠍࠎࠏࠉࡩࡶࡰࡰࠥࡃࠠࡩࡶࡰࡰࡠ࠶࡝࠯࡮ࡲࡻࡪࡸࠨࠪࠌࠌࠍࠎࠏࡨࡵ࡯࡯ࠤࡂࠦࡨࡵ࡯࡯࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࠼࡭࡫ࡁࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡁࡨ࠾ࠨ࠮ࠪࠫ࠮ࠐࠉࠊࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣ࡬ࡹࡳ࡬࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࡀ࠴ࡲࡩ࠿ࠩ࠯ࠫࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩ࠿࠳ࡧࡄࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠦࡐࡔࡍ࡟ࡕࡊࡌࡗ࠭࠭ࡎࡐࡖࡌࡇࡊ࠭ࠬࠨ࠴࠵࠶࠷ࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ࠯ࠊࠊࠋࠌࠍࡵࡧࡲࡵࡵࠣࡁࠥࡹࡥࡳࡸࡨࡶ࠳ࡹࡰ࡭࡫ࡷࠬࠬ࠴ࠧࠪࠌࠌࠍࠎࠏࡦࡰࡴࠣࡴࡦࡸࡴࠡ࡫ࡱࠤࡵࡧࡲࡵࡵ࠽ࠎࠎࠏࠉࠊࠋ࡬ࡪࠥࡲࡥ࡯ࠪࡳࡥࡷࡺࠩ࠽࠶࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࠋࠌࠍࡪࡲࡩࡧࠢࡳࡥࡷࡺࠠࡪࡰࠣ࡬ࡹࡳ࡬࠻ࠌࠌࠍࠎࠏࠉࠊࡴࡨࡷࡴࡲࡶࡦࡴࠣࡁ࡚ࠥࡲࡶࡧࠍࠍࠎࠏࠉࠊࠋࡥࡶࡪࡧ࡫ࠋࠋࠌࠦࠧࠨ㒒")
	#l1ll1l_ll_(url,l1ll111_ll_)
	if   l1l1ll111lll_ll_:	l1ll11l1llll_ll_,name = l111lll_ll_ (u"ࠬิวึࠩ㒓"),l1l1ll111lll_ll_
	elif named:		l1ll11l1llll_ll_,name = l111lll_ll_ (u"࠭ࠥๆฯาำࠬ㒔"),named
	elif l1l1l1l11111_ll_:		l1ll11l1llll_ll_,name = l111lll_ll_ (u"ࠧࠦࠧ฼ห๊ࠦๅฺำ๋ๅࠬ㒕"),l1l1l1l11111_ll_
	elif external:	l1ll11l1llll_ll_,name = l111lll_ll_ (u"ࠨࠧࠨࠩ฾อๅࠡะสีั๐ࠧ㒖"),external
	elif resolver:	l1ll11l1llll_ll_,name = l111lll_ll_ (u"ࠩࠨูࠩࠪࠫศ็ࠣาฬืฬ๋ࠩ㒗"),l1l1l1llll1l_ll_
	else:			l1ll11l1llll_ll_,name = l111lll_ll_ (u"ࠪࠩࠪࠫࠥࠦ฻ส้๋ࠥฬ่๊็ࠫ㒘"),l1l1l1llll1l_ll_
	return l1ll11l1llll_ll_,name,type,filetype,quality
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊࡧ࡯࡭࡫ࠦࠧࡱ࡮ࡤࡽࡷ࠴࠴ࡩࡧ࡯ࡥࡱ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡶࡲࡪࡸࡤࡸࡪࠦ࠽ࠡࠩ࡫ࡩࡱࡧ࡬ࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡨࡷࡹࡸࡥࡢ࡯ࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡥࡴࡶࡵࡩࡦࡳࠧࠋࠋࡨࡰ࡮࡬ࠠࠨࡩࡲࡹࡳࡲࡩ࡮࡫ࡷࡩࡩ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡨࡱࡸࡲࡱ࡯࡭ࡪࡶࡨࡨࠬࠐࠉࡦ࡮࡬ࡪࠥ࠭ࡩ࡯ࡶࡲࡹࡵࡲ࡯ࡢࡦࠪࠤࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠳࠼ࠌ࡯ࡳࡵࡷ࡯ࠢࡀࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠍࠍࡪࡲࡩࡧࠢࠪࡸ࡭࡫ࡶࡪࡦࡨࡳࠬࠏࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠵࠾ࠎࡱ࡮ࡰࡹࡱࠤࡂࠦࠧࡵࡪࡨࡺ࡮ࡪࡥࡰࠩࠍࠍࡪࡲࡩࡧࠢࠪࡺࡪࡼ࠮ࡪࡱࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡦࡸࠪࠎࠎ࡫࡬ࡪࡨࠣࠫࡻ࡯ࡤࡣࡱࡰࠫࠎࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡥࡳࡲ࠭ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧ࡬ࡩ࠭ࠠࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠷ࡀࠉ࡬ࡰࡲࡻࡳࠦ࠽ࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩࡹࡨࡢࡴࡨࠫࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠴࠽ࠍࡰࡴ࡯ࡸࡰࠣࡁࠥ࠭ࡶࡪࡦࡶ࡬ࡦࡸࡥࠨࠌࠌࠦࠧࠨ㒙")
def l1l1ll11111l_ll_(url):
	l1ll111_ll_,l1l1l1l1ll11_ll_,server,l1l1l1llll1l_ll_,name,type,filetype,quality,source = l1l1l11llll1_ll_(url)
	#l1ll1l_ll_(named,server)
	#if l111lll_ll_ (u"ࠬ࡭࡯ࡶࡰ࡯࡭ࡲ࡯ࡴࡦࡦࠪ㒚")	in server: l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠭㒛"),l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠭㒜"))
	#if any(value in server for value in l1l1ll11l1ll_ll_): l1111ll_ll_,l1l111l_ll_ = [l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡈࡗࡔࡒࡖࡆࠢࡧࡳࡪࡹࠠ࡯ࡱࡷࠤࡷ࡫ࡳࡰ࡮ࡹࡩࠥࡺࡨࡪࡵࠣࡷࡪࡸࡶࡦࡴࠪ㒝")],[]
	if   l111lll_ll_ (u"ࠩࡤ࡯ࡴࡧ࡭࠯ࡥࡤࡱࠬ㒞")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll1_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠪࡥࡰࡵࡡ࡮ࠩ㒟")		in source: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l_ll_(l1ll111_ll_,name)
	elif l111lll_ll_ (u"ࠫࡦࡱࡷࡢ࡯ࠪ㒠")		in source: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll_ll_(l1ll111_ll_,type,quality)
	elif l111lll_ll_ (u"ࠬࡹࡨࡢࡪ࡬ࡨ࠹ࡻࠧ㒡")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll1l1ll11_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"࠭࡭ࡺࡧࡪࡽࡻ࡯ࡰࠨ㒢")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll11l11111_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠧࡷࡵ࠷ࡹࠬ㒣")			in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l11l1ll11l1_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠨࡨࡤ࡮ࡪࡸࠧ㒤")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1ll1_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪ㒥")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l11l111ll_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠪࡱࡾࡩࡩ࡮ࡣࠪ㒦")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l111l1_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠫࡧࡵ࡫ࡳࡣࠪ㒧")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l11l1l1l1_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠬࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰࠪ㒨")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111l1111_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"࠭ࡡࡳࡣࡥࡷࡪ࡫ࡤࠨ㒩")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l111l11_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠧࡢࡴࡥࡰ࡮ࡵ࡮ࡻࠩ㒪")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l11llll1l_ll_(l1ll111_ll_)
	elif l111lll_ll_ (u"ࠨࡦ࠱ࡩ࡬ࡿࡢࡦࡵࡷ࠲ࡩ࠭㒫")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"ࠩࠪ㒬"),[l111lll_ll_ (u"ࠪࠫ㒭")],[l1ll111_ll_]
	elif l111lll_ll_ (u"ࠫࡪ࡭ࡹࡣࡧࡶࡸࠬ㒮")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111lll_ll_(url)
	elif l111lll_ll_ (u"ࠬࡹࡥࡳ࡫ࡨࡷ࠹ࡽࡡࡵࡥ࡫ࠫ㒯")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1lll11ll11_ll_(l1ll111_ll_)
	else: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㒰"),[l111lll_ll_ (u"ࠧࠨ㒱")],[l1ll111_ll_]
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࡋࡑࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡘࠦ࠱ࠨ㒲"),str(l1ll111_ll_))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡌࡒ࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠠ࠳ࠩ㒳"),str(l1l111l_ll_))
	return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
def l1l1l11ll111_ll_(url):
	server = l1l11l1lll_ll_(url,False)
	#if l111lll_ll_ (u"ࠪ࡫ࡴࡻ࡮࡭࡫ࡰ࡭ࡹ࡫ࡤࠨ㒴")	in server: l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ㒵"),l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽ࠫ㒶"))
	#if any(value in server for value in l1l1ll11l1ll_ll_): l1111ll_ll_,l1l111l_ll_ = [l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡆࡕࡒࡐ࡛ࡋࠠࡥࡱࡨࡷࠥࡴ࡯ࡵࠢࡵࡩࡸࡵ࡬ࡷࡧࠣࡸ࡭࡯ࡳࠡࡵࡨࡶࡻ࡫ࡲࠨ㒷")],[]
	if   l111lll_ll_ (u"ࠧࡺࡱࡸࡸࡺ࠭㒸")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll11ll_ll_(url)
	elif l111lll_ll_ (u"ࠨࡻ࠵ࡹ࠳ࡨࡥࠨ㒹")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll11ll_ll_(url)
	elif l111lll_ll_ (u"ࠩࡰࡳࡸ࡮ࡡࡩࡦࡤࠫ㒺")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l11111l1_ll_(url)
	elif l111lll_ll_ (u"ࠪࡪࡦࡹࡥ࡭ࡪࡧࠫ㒻")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l111ll11_ll_(url)
	elif l111lll_ll_ (u"ࠫࡦࡸࡡࡣ࡮ࡲࡥࡩࡹࠧ㒼")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lllll111_ll_(url)
	elif l111lll_ll_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠭㒽")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111lll1l_ll_(url)
	elif l111lll_ll_ (u"࠭ࡢࡶࡼࡽࡺࡷࡲࠧ㒾")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111ll1l1_ll_(url)
	elif l111lll_ll_ (u"ࠧࡦ࠷ࡷࡷࡦࡸࠧ㒿")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l11ll1l_ll_(url)
	elif l111lll_ll_ (u"ࠨࡨࡤࡧࡺࡲࡴࡺࡤࡲࡳࡰࡹࠧ㓀")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1l11l1_ll_(url)
	elif l111lll_ll_ (u"ࠩ࡬ࡲ࡫ࡲࡡ࡮࠰ࡦࡧࠬ㓁")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1l11l1_ll_(url)
	elif l111lll_ll_ (u"ࠪࡧࡦࡺࡣࡩ࠰࡬ࡷࠬ㓂")	 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
	elif l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࡴ࡬ࡳࠬ㓃")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
	elif l111lll_ll_ (u"ࠬࡼࡩࡥࡤࡰࠫ㓄")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
	elif l111lll_ll_ (u"࠭ࡶࡪࡦ࡫ࡨࠬ㓅")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
	elif l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴࡨࡩ࡯ࠩ㓆")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
	elif l111lll_ll_ (u"ࠨࡩࡲࡺ࡮ࡪࠧ㓇")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11ll1111l_ll_(url)
	elif l111lll_ll_ (u"ࠩ࡯࡭࡮ࡼࡩࡥࡧࡲࠫ㓈") 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll111l11_ll_(url)
	elif l111lll_ll_ (u"ࠪࡱࡵ࠺ࡵࡱ࡮ࡲࡥࡩ࠭㓉")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111l1lll_ll_(url)
	elif l111lll_ll_ (u"ࠫࡵࡻࡢ࡭࡫ࡦࡺ࡮ࡪࡥࡰࡪࡲࠫ㓊")in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll1l1l111l_ll_(url)
	elif l111lll_ll_ (u"ࠬࡸࡡࡱ࡫ࡧࡺ࡮ࡪࡥࡰࠩ㓋") 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11ll1lll1_ll_(url)
	elif l111lll_ll_ (u"࠭ࡴࡰࡲ࠷ࡸࡴࡶࠧ㓌")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll1lllll_ll_(url)
	elif l111lll_ll_ (u"ࠧࡶࡲࡥࡦࡴࡳࠧ㓍") 		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1l1111_ll_(url)
	elif l111lll_ll_ (u"ࠨࡷࡳࡦࡴࡳࠧ㓎") 		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1l1111_ll_(url)
	elif l111lll_ll_ (u"ࠩࡸࡴࡵࡵ࡭ࠨ㓏") 		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l1l1111_ll_(url)
	#elif l111lll_ll_ (u"ࠪࡹࡵࡺ࡯ࡣࡱࡻࠫ㓐") 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111l11ll_ll_(url)
	#elif l111lll_ll_ (u"ࠫࡺࡶࡴࡰࡵࡷࡶࡪࡧ࡭ࠨ㓑")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111l11ll_ll_(url)
	elif l111lll_ll_ (u"ࠬࡻࡱ࡭ࡱࡤࡨࠬ㓒") 		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll11lll1_ll_(url)
	elif l111lll_ll_ (u"࠭ࡶࡤࡵࡷࡶࡪࡧ࡭ࠨ㓓") 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l1ll1l11_ll_(url)
	elif l111lll_ll_ (u"ࠧࡷ࡫ࡧࡦࡴࡨࠧ㓔")		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll1llll1_ll_(url)
	elif l111lll_ll_ (u"ࠨࡸ࡬ࡨࡴࢀࡡࠨ㓕") 		in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l11l111l_ll_(url)
	elif l111lll_ll_ (u"ࠩࡺࡥࡹࡩࡨࡷ࡫ࡧࡩࡴ࠭㓖") 	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll1ll11l_ll_(url)
	elif l111lll_ll_ (u"ࠪࡻ࡮ࡴࡴࡷ࠰࡯࡭ࡻ࡫ࠧ㓗")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11l11ll11_ll_(url)
	elif l111lll_ll_ (u"ࠫࡿ࡯ࡰࡱࡻࡶ࡬ࡦࡸࡥࠨ㓘")	in server: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1ll111ll11l_ll_(url)
	else: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡡ࠴ࠤࡋࡧࡩ࡭ࡧࡧࠫ㓙"),[],[]
	return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
	l111lll_ll_ (u"ࠨࠢࠣࠌࠌࡩࡱ࡯ࡦࠡࠩࡨࡷࡹࡸࡥࡢ࡯ࠪࠍࠥࠏࡩ࡯ࠢࡶࡩࡷࡼࡥࡳ࠼ࠣࡩࡷࡸ࡯ࡳ࡯ࡶ࡫࠱ࡺࡩࡵ࡮ࡨࡐࡎ࡙ࡔ࠭࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡋࡓࡕࡔࡈࡅࡒ࠮ࡵࡳ࡮ࠬࠎࠎ࡫࡬ࡪࡨࠣࠫ࡬ࡵࡵ࡯࡮࡬ࡱ࡮ࡺࡥࡥࠩࠌ࡭ࡳࠦࡳࡦࡴࡹࡩࡷࡀࠠࡦࡴࡵࡳࡷࡳࡳࡨ࠮ࡷ࡭ࡹࡲࡥࡍࡋࡖࡘ࠱ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠠ࠾ࠢࡊࡓ࡚ࡔࡌࡊࡏࡌࡘࡊࡊࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬ࡯࡮ࡵࡱࡸࡴࡱࡵࡡࡥࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿ࠣࡍࡓ࡚ࡏࡖࡒࡏࡓࡆࡊࠨࡶࡴ࡯࠭ࠏࠏࡥ࡭࡫ࡩࠤࠬࡺࡨࡦࡸ࡬ࡨࡪࡵࠧࠊࠋ࡬ࡲࠥࡹࡥࡳࡸࡨࡶ࠿ࠦࡥࡳࡴࡲࡶࡲࡹࡧ࠭ࡶ࡬ࡸࡱ࡫ࡌࡊࡕࡗ࠰ࡱ࡯࡮࡬ࡎࡌࡗ࡙ࠦ࠽ࠡࡖࡋࡉ࡛ࡏࡄࡆࡑࠫࡹࡷࡲࠩࠋࠋࡨࡰ࡮࡬ࠠࠨࡸࡨࡺ࠳࡯࡯ࠨࠋࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿࡚ࠣࡊ࡜ࡉࡐࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡱ࡮ࡤࡽࡷ࠴࠴ࡩࡧ࡯ࡥࡱ࠭ࠉࡪࡰࠣࡷࡪࡸࡶࡦࡴ࠽ࠤࡪࡸࡲࡰࡴࡰࡷ࡬࠲ࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠮࡯࡭ࡳࡱࡌࡊࡕࡗࠤࡂࠦࡈࡆࡎࡄࡐ࠭ࡻࡲ࡭ࠫࠍࠍࡪࡲࡩࡧࠢࠪࡺ࡮ࡪࡢࡰ࡯ࠪࠍࠎ࡯࡮ࠡࡵࡨࡶࡻ࡫ࡲ࠻ࠢࡨࡶࡷࡵࡲ࡮ࡵࡪ࠰ࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚ࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠢࡀࠤ࡛ࡏࡄࡃࡑࡐࠬࡺࡸ࡬ࠪࠌࠌࡩࡱ࡯ࡦࠡࠩࡹ࡭ࡩ࡮ࡤࠨࠢࠌࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿࡚ࠣࡎࡊࡈࡅࠪࡸࡶࡱ࠯ࠊࠊࡧ࡯࡭࡫ࠦࠧࡷ࡫ࡧࡷ࡭ࡧࡲࡦࠩࠣࠍ࡮ࡴࠠࡴࡧࡵࡺࡪࡸ࠺ࠡࡧࡵࡶࡴࡸ࡭ࡴࡩ࠯ࡸ࡮ࡺ࡬ࡦࡎࡌࡗ࡙࠲࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠡ࠿࡚ࠣࡎࡊࡓࡉࡃࡕࡉ࠭ࡻࡲ࡭ࠫࠍࠍࠧࠨࠢ㓚")
def	l1l1l11l11l1_ll_(urls):
	if l111lll_ll_ (u"ࠧ࡭࡫ࡶࡸࠬ㓛") in str(type(urls)):
		links = []
		for link in urls:
			if l111lll_ll_ (u"ࠨࡵࡷࡶࠬ㓜") in str(type(link)):
				link = link.replace(l111lll_ll_ (u"ࠩ࡟ࡶࠬ㓝"),l111lll_ll_ (u"ࠪࠫ㓞")).replace(l111lll_ll_ (u"ࠫࡡࡴࠧ㓟"),l111lll_ll_ (u"ࠬ࠭㓠")).strip(l111lll_ll_ (u"࠭ࠠࠨ㓡"))
			links.append(link)
	else: links = urls.replace(l111lll_ll_ (u"ࠧ࡝ࡴࠪ㓢"),l111lll_ll_ (u"ࠨࠩ㓣")).replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬ㓤"),l111lll_ll_ (u"ࠪࠫ㓥")).strip(l111lll_ll_ (u"ࠫࠥ࠭㓦"))
	return links
def l1l1lll1l1ll_ll_(url):
	l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㓧"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡴࡢࡴࡷࡩࡩࠦࠠࠡࡈࡲࡶ࠿࡛ࠦࠡࠩ㓨")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ㓩"))
	resolver,link,l1l1l11l11ll_ll_ = l111lll_ll_ (u"ࠨࡋࡑࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࠬ㓪"),l111lll_ll_ (u"ࠩࠪ㓫"),l111lll_ll_ (u"ࠪࠫ㓬")
	l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1ll11111l_ll_(url)
	l1l111l_ll_ = l1l1l11l11l1_ll_(l1l111l_ll_)
	if l1111llll_ll_==l111lll_ll_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㓭"):
		#l1111llll_ll_ = l1111llll_ll_.replace(l111lll_ll_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㓮"),l111lll_ll_ (u"࠭ࠧ㓯"))
		link = l1l111l_ll_[0]
		#l1ll1l_ll_(link,l111lll_ll_ (u"ࠧࠨ㓰"))
		resolver = l111lll_ll_ (u"ࠨࡇ࡛ࡘࡊࡘࡎࡂࡎࡢࡖࡊ࡙ࡏࡍࡘࡈࡖࡤ࠷ࠧ㓱")
		l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l11ll111_ll_(link)
		l1l111l_ll_ = l1l1l11l11l1_ll_(l1l111l_ll_)
		if l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠩ㓲") in l1111llll_ll_:
			l1l1l11l11ll_ll_ = l1l1l11l11ll_ll_+l111lll_ll_ (u"ࠪࡠࡳࡘࡥࡴࡱ࡯ࡺࡪࡸࠠ࠲࠼ࠣࠫ㓳")+l1111llll_ll_
			resolver = l111lll_ll_ (u"ࠫࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡠ࠴ࠪ㓴")
			l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l11l1lll_ll_(link)
			l1l111l_ll_ = l1l1l11l11l1_ll_(l1l111l_ll_)
			if l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠬ㓵") in l1111llll_ll_:
				l1l1l11l11ll_ll_ = l1l1l11l11ll_ll_+l111lll_ll_ (u"࠭࡜࡯ࡔࡨࡷࡴࡲࡶࡦࡴࠣ࠶࠿ࠦࠧ㓶")+l1111llll_ll_
				resolver = l111lll_ll_ (u"ࠧࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡣ࠸࠭㓷")
				l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1l11l1ll1_ll_(link)
				l1l111l_ll_ = l1l1l11l11l1_ll_(l1l111l_ll_)
				if l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠨ㓸") in l1111llll_ll_:
					l1l1l11l11ll_ll_ = l1l1l11l11ll_ll_+l111lll_ll_ (u"ࠩ࡟ࡲࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦ࠳࠻ࠢࠪ㓹")+l1111llll_ll_
					#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ㓺"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡂ࡮࡯ࠤࡊࡾࡴࡦࡴࡱࡥࡱࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࡴࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡒ࡫ࡳࡴࡣࡪࡩࡸࡀࠠ࡜ࠢࠪ㓻")+l1l1l11l11ll_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡊࡴࡸ࠺ࠡ࡝ࠣࠫ㓼")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡑ࡯࡮࡬࠼ࠣ࡟ࠥ࠭㓽")+link+l111lll_ll_ (u"ࠧࠡ࡟ࠪ㓾"))
	elif l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠨ㓿") in l1111llll_ll_: l1l1l11l11ll_ll_ = l111lll_ll_ (u"ࠩࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࠵ࡀࠠࠨ㔀")+l1111llll_ll_
	if l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠪ㔁") not in l1111llll_ll_: return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
	l1l1l11l11ll_ll_ = l1l1l11l11ll_ll_.strip(l111lll_ll_ (u"ࠫࡡࡴࠧ㔂"))
	if len(l1l111l_ll_)>0:
		l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㔃"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥࡹࡵࡤࡥࡨࡩࡩ࡫ࡤࠡࠢࠣࡖࡪࡹ࡯࡭ࡸࡨࡶ࠿࡛ࠦࠡࠩ㔄")+resolver+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤࠥࡘࡥࡴࡷ࡯ࡸ࠿࡛ࠦࠡࠩ㔅")+str(l1l111l_ll_)+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡍࡦࡵࡶࡥ࡬࡫ࡳ࠻ࠢ࡞ࠤࠬ㔆")+l1l1l11l11ll_ll_+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡇࡱࡵ࠾ࠥࡡࠠࠨ㔇")+url+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡎ࡬ࡲࡰࡀࠠ࡜ࠢࠪ㔈")+link+l111lll_ll_ (u"ࠫࠥࡣࠧ㔉"))
	else: l1111l1l_ll_(l111lll_ll_ (u"ࠬࡋࡒࡓࡑࡕࡣࡑࡏࡎࡆࡕࠪ㔊"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡕࡩࡸࡵ࡬ࡷ࡫ࡱ࡫ࠥ࡬ࡡࡪ࡮ࡨࡨࠥࠦࠠࡓࡧࡶࡳࡱࡼࡥࡳ࠼ࠣ࡟ࠥ࠭㔋")+resolver+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤࠥࡓࡥࡴࡵࡤ࡫ࡪࡹ࠺ࠡ࡝ࠣࠫ㔌")+l1l1l11l11ll_ll_+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡆࡰࡴ࠽ࠤࡠࠦࠧ㔍")+url+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡍ࡫ࡱ࡯࠿࡛ࠦࠡࠩ㔎")+link+l111lll_ll_ (u"ࠪࠤࡢ࠭㔏"))
	#l1l1l11l11ll_ll_ = l1l1l11l11ll_ll_.replace(l111lll_ll_ (u"ࠫࡡࡴࠧ㔐"),l111lll_ll_ (u"ࠬࠦ࠮࠯࠰ࠣࠫ㔑"))
	return l1l1l11l11ll_ll_,l1111ll_ll_,l1l111l_ll_
l111lll_ll_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡓࡆࡔ࡙ࡉࡗ࡙࡟ࡤࡣࡦ࡬ࡪࡪ࡟ࡐࡎࡇࠬࡱ࡯࡮࡬ࡎࡌࡗ࡙࠲ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨࡁࠬ࠭ࠩ࠻ࠌࠌࠧࡹ࠷ࠠ࠾ࠢࡷ࡭ࡲ࡫࠮ࡵ࡫ࡰࡩ࠭࠯ࠊࠊࡥࡤࡧ࡭࡫ࡰࡦࡴ࡬ࡳࡩࠦ࠽ࠡࡎࡒࡒࡌࡥࡃࡂࡅࡋࡉࠏࠏࡣࡰࡰࡱࠤࡂࠦࡳࡲ࡮࡬ࡸࡪ࠹࠮ࡤࡱࡱࡲࡪࡩࡴࠩࡦࡥࡪ࡮ࡲࡥࠪࠌࠌࡧࠥࡃࠠࡤࡱࡱࡲ࠳ࡩࡵࡳࡵࡲࡶ࠭࠯ࠊࠊࡥࡲࡲࡳ࠴ࡴࡦࡺࡷࡣ࡫ࡧࡣࡵࡱࡵࡽࠥࡃࠠࡴࡶࡵࠎࠎࡩ࠮ࡦࡺࡨࡧࡺࡺࡥࠩࠩࡖࡉࡑࡋࡃࡕࠢࡶࡩࡷࡼࡥࡳࡵࡏࡍࡘ࡚ࠬࡶࡴ࡯ࡐࡎ࡙ࡔࠡࡈࡕࡓࡒࠦࡳࡦࡴࡹࡩࡷࡹࡣࡢࡥ࡫ࡩࠥ࡝ࡈࡆࡔࡈࠤࡱ࡯࡮࡬ࡎࡌࡗ࡙ࡃࠢࠨ࠭ࡶࡸࡷ࠮࡬ࡪࡰ࡮ࡐࡎ࡙ࡔࠪ࠭ࠪࠦࠬ࠯ࠊࠊࡴࡲࡻࡸࠦ࠽ࠡࡥ࠱ࡪࡪࡺࡣࡩࡣ࡯ࡰ࠭࠯ࠊࠊ࡫ࡩࠤࡷࡵࡷࡴ࠼ࠍࠍࠎࠩ࡭ࡦࡵࡶࡥ࡬࡫ࠠ࠾ࠢࠪࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡩࡡࡤࡪࡨࠫࠏࠏࠉࡴࡧࡵࡺࡪࡸࡳࡍࡋࡖࡘ࠱ࡻࡲ࡭ࡎࡌࡗ࡙ࠦ࠽ࠡࡧࡹࡥࡱ࠮ࡲࡰࡹࡶ࡟࠵ࡣ࡛࠱࡟ࠬ࠰ࡪࡼࡡ࡭ࠪࡵࡳࡼࡹ࡛࠱࡟࡞࠵ࡢ࠯ࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋࠦࡱࡪࡹࡳࡢࡩࡨࠤࡂࠦࠧ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠣ࡭ࡳࠦࡣࡢࡥ࡫ࡩࠬࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࡴࡎࡌࡗ࡙࠲ࡵࡳ࡮ࡏࡍࡘ࡚ࠠ࠾ࠢࡖࡉࡗ࡜ࡅࡓࡕࠫࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠮ࠐࠉࠊࡶࠣࡁࠥ࠮࡮ࡰࡹ࠮ࡧࡦࡩࡨࡦࡲࡨࡶ࡮ࡵࡤ࠭ࡵࡷࡶ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠩ࠭ࡵࡷࡶ࠭ࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖࠬ࠰ࡸࡺࡲࠩࡷࡵࡰࡑࡏࡓࡕࠫࠬࠎࠎࠏࡣ࠯ࡧࡻࡩࡨࡻࡴࡦࠪࠥࡍࡓ࡙ࡅࡓࡖࠣࡍࡓ࡚ࡏࠡࡵࡨࡶࡻ࡫ࡲࡴࡥࡤࡧ࡭࡫ࠠࡗࡃࡏ࡙ࡊ࡙ࠠࠩࡁ࠯ࡃ࠱ࡅࠬࡀࠫࠥ࠰ࡹ࠯ࠊࠊࠋࡦࡳࡳࡴ࠮ࡤࡱࡰࡱ࡮ࡺࠨࠪࠌࠌࡧࡴࡴ࡮࠯ࡥ࡯ࡳࡸ࡫ࠨࠪࠌࠌࠧࡹ࠸ࠠ࠾ࠢࡷ࡭ࡲ࡫࠮ࡵ࡫ࡰࡩ࠭࠯ࠊࠊࠥࡇࡍࡆࡒࡏࡈࡡࡑࡓ࡙ࡏࡆࡊࡅࡄࡘࡎࡕࡎࠩ࡯ࡨࡷࡸࡧࡧࡦ࠮ࡶࡸࡷ࠮ࡩ࡯ࡶࠫࡸ࠷࠳ࡴ࠲ࠫࠬ࠯ࠬࠦ࡭ࡴࠩࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡥࡳࡸࡨࡶࡸࡒࡉࡔࡖ࠯ࡹࡷࡲࡌࡊࡕࡗࠎࠧࠨࠢ㔒")
def l1l11ll111ll_ll_(l1llllll1_ll_,l1ll_ll_=l111lll_ll_ (u"ࠧࠨ㔓")):
	l1l11lll1ll_ll_ = l11l1l_ll_
	data = l1llll11l1l_ll_(l111lll_ll_ (u"ࠨࡕࡈࡖ࡛ࡋࡒࡔࠩ㔔"),[l1llllll1_ll_,l1ll_ll_])
	if data:
		l1111ll_ll_,l1l111l_ll_ = zip(*data)
		return l1111ll_ll_,l1l111l_ll_
	l1111ll_ll_,l1l111l_ll_,l11ll1l_ll_ = [],[],[]
	for link in l1llllll1_ll_:
		if l111lll_ll_ (u"ࠩ࠲࠳ࠬ㔕") not in link: continue
		l1ll11l1llll_ll_,name,type,filetype,quality = l1ll1111l1l1_ll_(link)
		quality = re.findall(l111lll_ll_ (u"ࠪࡠࡩ࠱ࠧ㔖"),quality,re.DOTALL)
		if quality:
			l1l11lllllll_ll_ = sorted(quality,reverse=True,key=lambda key: int(key))
			quality = int(l1l11lllllll_ll_[0])
		else: quality = 0
		l11ll1l_ll_.append([l1ll11l1llll_ll_,name,type,filetype,quality,link])
	l1ll1l11ll11_ll_ = sorted(l11ll1l_ll_, reverse=True, key=lambda key: (key[0],int(key[4]),key[2],reversed(key[1]),key[3],key[5]))
	for l1ll11l1llll_ll_,name,type,filetype,quality,link in l1ll1l11ll11_ll_:
		if quality==0: quality = l111lll_ll_ (u"ࠫࠬ㔗")
		title = l111lll_ll_ (u"ู๊ࠬาใิࠫ㔘")+l111lll_ll_ (u"࠭ࠠࠨ㔙")+type+l111lll_ll_ (u"ࠧࠡࠩ㔚")+l1ll11l1llll_ll_+l111lll_ll_ (u"ࠨࠢࠪ㔛")+str(quality)+l111lll_ll_ (u"ࠩࠣࠫ㔜")+filetype+l111lll_ll_ (u"ࠪࠤࠬ㔝")+name
		title = title.replace(l111lll_ll_ (u"ࠫࠪ࠭㔞"),l111lll_ll_ (u"ࠬ࠭㔟")).strip(l111lll_ll_ (u"࠭ࠠࠨ㔠")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪ㔡"),l111lll_ll_ (u"ࠨࠢࠪ㔢")).replace(l111lll_ll_ (u"ࠩࠣࠤࠬ㔣"),l111lll_ll_ (u"ࠪࠤࠬ㔤")).replace(l111lll_ll_ (u"ࠫࠥࠦࠧ㔥"),l111lll_ll_ (u"ࠬࠦࠧ㔦"))
		l1111ll_ll_.append(title)
		l1l111l_ll_.append(link)
	data = zip(l1111ll_ll_,l1l111l_ll_)
	l1111l1lll_ll_(l111lll_ll_ (u"࠭ࡓࡆࡔ࡙ࡉࡗ࡙ࠧ㔧"),[l1llllll1_ll_,l1ll_ll_],data,l1l11lll1ll_ll_)
	return l1111ll_ll_,l1l111l_ll_
l111lll_ll_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡔࡇࡕ࡚ࡊࡘࡓࡠࡑࡏࡈ࠭ࡲࡩ࡯࡭ࡏࡍࡘ࡚ࠬࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩࡂ࠭ࠧࠪ࠼ࠍࠍࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠮ࡸࡶࡱࡒࡉࡔࡖ࠯ࡹࡳࡱ࡮ࡰࡹࡱࡐࡎ࡙ࡔ࠭ࡵࡨࡶࡻ࡫ࡲࡴࡆࡌࡇ࡙ࠦ࠽ࠡ࡝ࡠ࠰ࡠࡣࠬ࡜࡟࠯࡟ࡢࠐࠉࠤ࡮࡬ࡲࡰࡒࡉࡔࡖࠣࡁࠥࡲࡩࡴࡶࠫࡷࡪࡺࠨ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠬࠎࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ࠲ࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠍࠍࠨ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࡃࠠ࠮࠳ࠣ࠾ࠥࡸࡥࡵࡷࡵࡲࠥ࠭ࠧࠋࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮ࠤ࡮ࡴࠠ࡭࡫ࡱ࡯ࡑࡏࡓࡕ࠼ࠍࠍࠎ࡯ࡦࠡ࡮࡬ࡲࡰࡃ࠽ࠨࠩ࠽ࠤࡨࡵ࡮ࡵ࡫ࡱࡹࡪࠐࠉࠊࡵࡨࡶࡻ࡫ࡲࡏࡃࡐࡉࠥࡃࠠࡓࡇࡖࡓࡑ࡜ࡁࡃࡎࡈࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࡹࡥࡳࡸࡨࡶࡸࡊࡉࡄࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࠤࡠࡹࡥࡳࡸࡨࡶࡓࡇࡍࡆ࠮࡯࡭ࡳࡱ࡝ࠡࠫࠍࠍࡸࡵࡲࡵࡧࡧࡈࡎࡉࡔࠡ࠿ࠣࡷࡴࡸࡴࡦࡦࠫࡷࡪࡸࡶࡦࡴࡶࡈࡎࡉࡔ࠭ࠢࡵࡩࡻ࡫ࡲࡴࡧࡀࡘࡷࡻࡥ࠭ࠢ࡮ࡩࡾࡃ࡬ࡢ࡯ࡥࡨࡦࠦ࡫ࡦࡻ࠽ࠤࡰ࡫ࡹ࡜࠲ࡠ࠭ࠏࠏࡦࡰࡴࠣࡷࡪࡸࡶࡦࡴ࠯ࡰ࡮ࡴ࡫ࠡ࡫ࡱࠤࡸࡵࡲࡵࡧࡧࡈࡎࡉࡔ࠻ࠌࠌࠍࡸ࡫ࡲࡷࡧࡵࠤࡂࠦࡳࡦࡴࡹࡩࡷ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠧࠪ࠰ࠬ࠭ࠩࠋࠋࠌࡷࡪࡸࡶࡦࡴࡶࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩࡵࡨࡶࡻ࡫ࡲࠪࠌࠌࠍࡺࡸ࡬ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡲࡩ࡯࡭ࠬࠎࠎࠩ࡬ࡪࡰࡨࡷࠥࡃࠠ࡭ࡧࡱࠬࡺࡴ࡫࡯ࡱࡺࡲࡑࡏࡓࡕࠫࠍࠍࠨ࡯ࡦࠡ࡮࡬ࡲࡪࡹ࠾࠱࠼ࠍࠍࠨࠏ࡭ࡦࡵࡶࡥ࡬࡫ࠠ࠾ࠢࠪࡠࡡࡴࠧࠋࠋࠦࠍ࡫ࡵࡲࠡ࡮࡬ࡲࡰࠦࡩ࡯ࠢࡸࡲࡰࡴ࡯ࡸࡰࡏࡍࡘ࡚࠺ࠋࠋࠦࠍࠎࡳࡥࡴࡵࡤ࡫ࡪࠦࠫ࠾ࠢ࡯࡭ࡳࡱࠠࠬࠢࠪࡠࡡࡴࠧࠋࠋࠦࠍࡸࡻࡢ࡫ࡧࡦࡸࠥࡃࠠࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࡷࠥࡃࠠࠨࠢ࠮ࠤࡸࡺࡲࠩ࡮࡬ࡲࡪࡹࠩࠋࠋࠦࠍࡷ࡫ࡳࡶ࡮ࡷࠤࡂࠦࡓࡆࡐࡇࡣࡊࡓࡁࡊࡎࠫࡷࡺࡨࡪࡦࡥࡷ࠰ࡲ࡫ࡳࡴࡣࡪࡩ࠱ࡌࡡ࡭ࡵࡨ࠰ࠬ࠭ࠬࠨࡈࡕࡓࡒ࠳ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࠪ࠯ࡸࡩࡲࡪࡲࡷࡣࡳࡧ࡭ࡦࠫࠍࠍࡷ࡫ࡴࡶࡴࡱࠤࡸ࡫ࡲࡷࡧࡵࡷࡑࡏࡓࡕ࠮ࡸࡶࡱࡒࡉࡔࡖࠍࠦࠧࠨ㔨")
def	l1l1l11l1lll_ll_(url):
	#url = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡇࡧࡗࡠ࡬ࡨࡲࡴࢀࡋࡤࠩ㔩")
	try:
		import resolveurl
		result = resolveurl.l1ll111l1l1l_ll_(url).l1ll11l111ll_ll_()
	except: result = False
	# resolveurl l1ll11lll1l1_ll_ fail l1ll111ll1ll_ll_ with l1lll1l1l11l_ll_ error or l1l1l1ll11ll_ll_ value False
	if result==False:
		l1l11l1lll1_ll_ = traceback.format_exc()
		sys.stderr.write(l1l11l1lll1_ll_)
		if l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ㔪") in l1l11l1lll1_ll_: l1111llll_ll_ = l1l11l1lll1_ll_.splitlines()[-1]
		else: l1111llll_ll_ = l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘ࡟࠳ࠢࡉࡥ࡮ࡲࡥࡥࠩ㔫")
		#l1ll1l_ll_(l1111llll_ll_,str(result))
		return l1111llll_ll_,[],[]
	return l111lll_ll_ (u"ࠫࠬ㔬"),[l111lll_ll_ (u"ࠬ࠭㔭")],[result]
def	l1l1l11l1ll1_ll_(url):
	#url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿ࡅࡥ࡜ࡥࡪࡦࡰࡲࡾࡐࡩࠧ㔮")
	#url = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡪࡡࡪ࡮ࡼࡱࡴࡺࡩࡰࡰ࠱ࡧࡴࡳ࠯ࡷ࡫ࡧࡩࡴ࠵ࡸ࠸ࡻࡼ࠸࠶ࡹࠧ㔯")
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࠩ㔰"))
	try:
		import youtube_dl
		ydl = youtube_dl.YoutubeDL({l111lll_ll_ (u"ࠩࡱࡳࡤࡩ࡯࡭ࡱࡵࠫ㔱"): True})
		results = ydl.extract_info(url,download=False)
	except: results = False
	#l11l1l1ll_ll_(l111lll_ll_ (u"ࠪࠫ㔲"),str(results))
	# youtube_dl l1ll11lll1l1_ll_ fail l1ll111ll1ll_ll_ with l1lll1l1l11l_ll_ error or l1l1l1ll11ll_ll_ value False
	if not results or l111lll_ll_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ㔳") not in results.keys():
		l1l11l1lll1_ll_ = traceback.format_exc()
		sys.stderr.write(l1l11l1lll1_ll_)
		if l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥ࠭㔴") in l1l11l1lll1_ll_: l1111llll_ll_ = l1l11l1lll1_ll_.splitlines()[-1]
		else: l1111llll_ll_ = l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡢ࠷ࠥࡌࡡࡪ࡮ࡨࡨࠬ㔵")
		return l1111llll_ll_,[],[]
	else:
		l1111ll_ll_,l1l111l_ll_ = [],[]
		for link in results[l111lll_ll_ (u"ࠧࡧࡱࡵࡱࡦࡺࡳࠨ㔶")]:
			l1111ll_ll_.append(link[l111lll_ll_ (u"ࠨࡨࡲࡶࡲࡧࡴࠨ㔷")])
			l1l111l_ll_.append(link[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㔸")])
		return l111lll_ll_ (u"ࠪࠫ㔹"),l1111ll_ll_,l1l111l_ll_
#=================================================================================
# l1ll1ll11l_ll_ of the l1l1ll1lll_ll_ functions l1ll111ll1_ll_ added from:
# l1ll1l1l_ll_://l1l1lllll1_ll_.l1lll1l11_ll_/l1l1ll1l11_ll_/l1ll111l1l_ll_-l1l1ll11ll_ll_/blob/master/l1l1llll11_ll_.video.matrix/resources/l1l11l1l1l_ll_/l1l11lllll_ll_.l1ll1l1lll_ll_
#=================================================================================
def l1ll111lllll_ll_(script):
	data,page,l1l11l11ll_ll_ = script,l111lll_ll_ (u"ࠫࠬ㔺"),l111lll_ll_ (u"ࠬ࠭㔻")
	l1l111l1ll_ll_ = re.findall(l111lll_ll_ (u"࠭࠼ࡴࡥࡵ࡭ࡵࡺ࠮ࠫࡁ࠾࠲࠯ࡅ࡜ࠨࠪ࠱࠮ࡄ࠯࠻ࠨ㔼"), data, re.S)
	l1l111lll1_ll_ = re.findall(l111lll_ll_ (u"ࠧ࠰ࡩ࠱࠲࠳࠴࠮ࠩ࠰࠭ࡃ࠮ࡢࠩࠨ㔽"), data, re.S)
	if l1l111l1ll_ll_ and l1l111lll1_ll_:
		script = l1l111l1ll_ll_[0].replace(l111lll_ll_ (u"ࠣࠩࠥ㔾"),l111lll_ll_ (u"ࠩࠪ㔿"))
		script = script.replace(l111lll_ll_ (u"ࠥ࠯ࠧ㕀"),l111lll_ll_ (u"ࠫࠬ㕁"))
		script = script.replace(l111lll_ll_ (u"ࠧࡢ࡮ࠣ㕂"),l111lll_ll_ (u"࠭ࠧ㕃"))
		sc = script.split(l111lll_ll_ (u"ࠧ࠯ࠩ㕄"))
		page = l111lll_ll_ (u"ࠨࠩ㕅")
		for l1ll11l1l1_ll_ in sc:
				l1l111llll_ll_ = base64.b64decode(l1ll11l1l1_ll_+l111lll_ll_ (u"ࠩࡀࡁࠬ㕆"))
				l1l11l1111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡠࡩ࠱ࠧ㕇"), l1l111llll_ll_, re.S)
				if l1l11l1111_ll_:
					l1l11l111l_ll_ = int(l1l11l1111_ll_[0])+int(l1l111lll1_ll_[0])
					page = page + chr(l1l11l111l_ll_)
		l1l11l11ll_ll_ = re.findall(l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㕈"), page, re.S)
		return page,l1l11l11ll_ll_
def l1l111ll11_ll_(url):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ㕉"),url,l111lll_ll_ (u"࠭ࠧ㕊"),l111lll_ll_ (u"ࠧࠨ㕋"),l111lll_ll_ (u"ࠨࠩ㕌"),l111lll_ll_ (u"ࠩࠪ㕍"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡆࡂࡕࡈࡐࡍࡊ࠭࠲ࡵࡷࠫ㕎"))
	html = response.content
	page,url = l1ll111lllll_ll_(html)
	if url: l1l111l_ll_ = [url]
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡆࡂࡕࡈࡐࡍࡊࠠࡇࡣ࡬ࡰࡪࡪࠧ㕏"),[],[]
	return l111lll_ll_ (u"ࠬ࠭㕐"),[l111lll_ll_ (u"࠭ࠧ㕑")],l1l111l_ll_
def l1ll11l11111_ll_(url):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ㕒"),url,l111lll_ll_ (u"ࠨࠩ㕓"),l111lll_ll_ (u"ࠩࠪ㕔"),l111lll_ll_ (u"ࠪࠫ㕕"),l111lll_ll_ (u"ࠫࠬ㕖"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡏ࡜ࡉࡌ࡟ࡖࡊࡒ࠰࠵ࡸࡺࠧ㕗"))
	html = response.content
	link = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰ࡮࠰ࡷࡲ࠳࠱࠳ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㕘"),html,re.DOTALL)
	if not link: return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡐ࡝ࡊࡍ࡙ࡗࡋࡓࠤࡋࡧࡩ࡭ࡧࡧࠫ㕙"),[],[]
	link = link[0]
	return l111lll_ll_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㕚"),[l111lll_ll_ (u"ࠩࠪ㕛")],[link]
def l111l1111_ll_(url):
	id = url.split(l111lll_ll_ (u"ࠪ࠳ࠬ㕜"))[-1]
	link = url.replace(l111lll_ll_ (u"ࠫ࠳ࡩ࡯࡮࠱ࠪ㕝"),l111lll_ll_ (u"ࠬ࠴ࡣࡰ࡯࠲ࡴࡱࡧࡹࡦࡴ࠲ࡱࡪࡺࡡࡥࡣࡷࡥ࠴࠭㕞"))
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㕟"),link,l111lll_ll_ (u"ࠧࠨ㕠"),l111lll_ll_ (u"ࠨࠩ㕡"),l111lll_ll_ (u"ࠩࠪ㕢"),l111lll_ll_ (u"ࠪࠫ㕣"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒ࠲࠷ࡳࡵࠩ㕤"))
	html = response.content
	l1111llll_ll_ = l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡅࡃࡌࡐ࡞ࡓࡏࡕࡋࡒࡒࠥࡌࡡࡪ࡮ࡨࡨࠬ㕥")
	error = re.findall(l111lll_ll_ (u"࠭ࠢࡦࡴࡵࡳࡷࠨ࠮ࠫࡁࠥࡱࡪࡹࡳࡢࡩࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㕦"),html,re.DOTALL)
	if error: l1111llll_ll_ = error[0]
	url = re.findall(l111lll_ll_ (u"ࠧࡹ࠯ࡰࡴࡪ࡭ࡕࡓࡎࠥ࠰ࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㕧"),html,re.DOTALL)
	if not url: return l1111llll_ll_,[],[]
	url = url[0].replace(l111lll_ll_ (u"ࠨ࡞࡟ࠫ㕨"),l111lll_ll_ (u"ࠩࠪ㕩"))
	return l111lll_ll_ (u"ࠪࠫ㕪"),[l111lll_ll_ (u"ࠫࠬ㕫")],[url]
def l11l1l1l1_ll_(link):
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ㕬"),link,l111lll_ll_ (u"࠭ࠧ㕭"),l111lll_ll_ (u"ࠧࠨ㕮"),l111lll_ll_ (u"ࠨࠩ㕯"),l111lll_ll_ (u"ࠩࠪ㕰"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡂࡐࡍࡕࡅ࠲࠷ࡳࡵࠩ㕱"))
	html = response.content
	if l111lll_ll_ (u"ࠫ࠳ࡰࡳࡰࡰࠪ㕲") in link: url = re.findall(l111lll_ll_ (u"ࠬࠨࡳࡳࡥࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㕳"),html,re.DOTALL)
	else: url = re.findall(l111lll_ll_ (u"࠭ࡳࡰࡷࡵࡧࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㕴"),html,re.DOTALL)
	if not url: return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡅࡓࡐࡘࡁࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㕵"),[],[]
	url = url[0]
	if l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀࠧ㕶") not in url: url = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ㕷")+url
	return l111lll_ll_ (u"ࠪࠫ㕸"),[l111lll_ll_ (u"ࠫࠬ㕹")],[url]
def l1l1l11111l1_ll_(url):
	# http://l1l1ll11l11l_ll_.l1l11ll11lll_ll_/l1ll11111lll_ll_.html?named=l1l11lll1lll_ll_
	# http://l1l1ll11l11l_ll_.l1l11ll11lll_ll_/dl?op=l1l1lll1l1l1_ll_&id=l1ll11111lll_ll_&mode=o&hash=62516-107-159-1560654817-4fa63debbd8f3714289ad753ebf598ae
	headers = { l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㕺") : l111lll_ll_ (u"࠭ࠧ㕻") }
	if l111lll_ll_ (u"ࠧࡰࡲࡀࡨࡴࡽ࡮࡭ࡱࡤࡨࡤࡵࡲࡪࡩࠪ㕼") in url:
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠨࠩ㕽"),headers,l111lll_ll_ (u"ࠩࠪ㕾"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡍࡐࡕࡋࡅࡍࡊࡁ࠮࠳ࡶࡸࠬ㕿"))
		#xbmc.log(html)
		#l1ll1l_ll_(url,html)
		items = re.findall(l111lll_ll_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࠤࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㖀"),html,re.DOTALL)
		if items: return l111lll_ll_ (u"ࠬ࠭㖁"),[l111lll_ll_ (u"࠭ࠧ㖂")],[items[0]]
		else:
			message = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡦࡴࡵࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㖃"),html,re.DOTALL)
			if message:
				l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋่ใ฻ࠣห้อีๅ์ࠪ㖄"),message[0])
				return l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࠪ㖅")+message[0],[],[]
	else:
		#l1ll1l_ll_(link,l111lll_ll_ (u"ࠪࠫ㖆"))
		#url,l11l11ll11_ll_ = url.split(l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬ㖇"))
		#l11l11ll11_ll_ = l11l11ll11_ll_.lower()
		l11l11ll11_ll_ = l111lll_ll_ (u"ࠬࡳ࡯ࡷ࡫ࡽࡰࡦࡴࡤࠨ㖈")
		# watch links
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"࠭ࠧ㖉"),headers,l111lll_ll_ (u"ࠧࠨ㖊"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠲࡯ࡦࠪ㖋"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡉࡳࡷࡳࠠ࡮ࡧࡷ࡬ࡴࡪ࠽ࠣࡒࡒࡗ࡙ࠨࠠࡢࡥࡷ࡭ࡴࡴ࠽࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠫ࠲࠯ࡅࠩࡥ࡫ࡹࠫ㖌"),html,re.DOTALL)
		if not l1lll_ll_: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡇࡣ࡬ࡰࡪࡪࠧ㖍"),[],[]
		l11ll1ll_ll_ = l1lll_ll_[0][0]
		block = l1lll_ll_[0][1]
		if l111lll_ll_ (u"ࠫ࠳ࡸࡡࡳࠩ㖎") in block or l111lll_ll_ (u"ࠬ࠴ࡺࡪࡲࠪ㖏") in block: return l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡐࡲࡸࠥࡧࠠࡷ࡫ࡧࡩࡴࠦࡦࡪ࡮ࡨࠫ㖐"),[],[]
		items = re.findall(l111lll_ll_ (u"ࠧ࡯ࡣࡰࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㖑"),block,re.DOTALL)
		payload = {}
		for name,value in items:
			payload[name] = value
		data = l1lll11ll_ll_(payload)
		html = l111ll1_ll_(l11111l1_ll_,l11ll1ll_ll_,data,headers,l111lll_ll_ (u"ࠨࠩ㖒"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡓࡏࡔࡊࡄࡌࡉࡇ࠭࠴ࡴࡧࠫ㖓"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡈࡴࡽ࡮࡭ࡱࡤࡨࠥ࡜ࡩࡥࡧࡲ࠲࠯ࡅࡧࡦࡶ࡟ࠬࡡ࠭ࠨ࠯ࠬࡂ࠭ࡡ࠭࠮ࠫࡁࡶࡳࡺࡸࡣࡦࡵ࠽ࠬ࠳࠰࠿ࠪ࡫ࡰࡥ࡬࡫࠺ࠨ㖔"),html,re.DOTALL)
		if not l1lll_ll_: return l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡍࡐࡕࡋࡅࡍࡊࡁࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㖕"),[],[]
		download = l1lll_ll_[0][0]
		block = l1lll_ll_[0][1]
		items = re.findall(l111lll_ll_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠬ࠱ࡲࡡࡣࡧ࡯࠾ࠧ࠴ࠪࡀࠤࡿ࠭ࠬ㖖"),block,re.DOTALL)
		l1l11l11llll_ll_,l1111ll_ll_,l1l1l1l1ll1l_ll_,l1l111l_ll_,l1l1l1l111ll_ll_ = [],[],[],[],[]
		for link,title in items:
			if l111lll_ll_ (u"࠭࠮࡮࠵ࡸ࠼ࠬ㖗") in link:
				l1l11l11llll_ll_,l1l1l1l1ll1l_ll_ = l11l1l1l_ll_(link)
				l1l111l_ll_ = l1l111l_ll_ + l1l1l1l1ll1l_ll_
				if l1l11l11llll_ll_[0]==l111lll_ll_ (u"ࠧ࠮࠳ࠪ㖘"): l1111ll_ll_.append(l111lll_ll_ (u"ࠨࠢึ๎ึ็ัࠡะสูࠥ࠭㖙")+l111lll_ll_ (u"ࠩࡰ࠷ࡺ࠾ࠠࠨ㖚")+l11l11ll11_ll_)
				else:
					for title in l1l11l11llll_ll_:
						l1111ll_ll_.append(l111lll_ll_ (u"ࠪࠤุ๐ัโำࠣาฬ฻ࠠࠨ㖛")+l111lll_ll_ (u"ࠫࡲ࠹ࡵ࠹ࠢࠪ㖜")+l11l11ll11_ll_+l111lll_ll_ (u"ࠬࠦࠧ㖝")+title)
			else:
				title = title.replace(l111lll_ll_ (u"࠭ࠬ࡭ࡣࡥࡩࡱࡀࠢࠨ㖞"),l111lll_ll_ (u"ࠧࠨ㖟"))
				title = title.strip(l111lll_ll_ (u"ࠨࠤࠪ㖠"))
				#l1ll1l_ll_(title,str(l1l1l1l111ll_ll_))
				title = l111lll_ll_ (u"ࠩࠣื๏ืแาࠢࠣาฬ฻ࠠࠨ㖡")+l111lll_ll_ (u"ࠪࠤࡲࡶ࠴ࠡࠩ㖢")+l11l11ll11_ll_+l111lll_ll_ (u"ࠫࠥ࠭㖣")+title
				l1111ll_ll_.append(title)
				l1l111l_ll_.append(link)
		# download links
		link = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡳ࡯ࡴࡪࡤ࡬ࡩࡧ࠮ࡰࡰ࡯࡭ࡳ࡫ࠧ㖤") + download
		html = l111ll1_ll_(l11111l1_ll_,link,l111lll_ll_ (u"࠭ࠧ㖥"),headers,l111lll_ll_ (u"ࠧࠨ㖦"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡓࡉࡃࡋࡈࡆ࠳࠵ࡵࡪࠪ㖧"))
		items = re.findall(l111lll_ll_ (u"ࠤࡧࡳࡼࡴ࡬ࡰࡣࡧࡣࡻ࡯ࡤࡦࡱ࡟ࠬࠬ࠮࠮ࠫࡁࠬࠫ࠱࠭ࠨ࠯ࠬࡂ࠭ࠬ࠲ࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࠿ࡸࡩࡄࠨ࠯ࠬࡂ࠭࠱ࠨ㖨"),html,re.DOTALL)
		for id,mode,hash,resolution in items:
			title = l111lll_ll_ (u"ࠪࠤุ๐ัโำࠣฮา๋๊ๅࠢัหฺࠦࠧ㖩")+l111lll_ll_ (u"ࠫࠥࡳࡰ࠵ࠢࠪ㖪")+l11l11ll11_ll_+l111lll_ll_ (u"ࠬࠦࠧ㖫")+resolution.split(l111lll_ll_ (u"࠭ࡸࠨ㖬"))[1]
			link = l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࡮ࡱࡶ࡬ࡦ࡮ࡤࡢ࠰ࡲࡲࡱ࡯࡮ࡦ࠱ࡧࡰࡄࡵࡰ࠾ࡦࡲࡻࡳࡲ࡯ࡢࡦࡢࡳࡷ࡯ࡧࠧ࡫ࡧࡁࠬ㖭")+id+l111lll_ll_ (u"ࠨࠨࡰࡳࡩ࡫࠽ࠨ㖮")+mode+l111lll_ll_ (u"ࠩࠩ࡬ࡦࡹࡨ࠾ࠩ㖯")+hash
			l1l1l1l111ll_ll_.append(resolution)
			l1111ll_ll_.append(title)
			l1l111l_ll_.append(link)
		l1l1l1l111ll_ll_ = set(l1l1l1l111ll_ll_)
		l1l1ll1l1111_ll_,l1ll1l1111l1_ll_ = [],[]
		for title in l1111ll_ll_:
			#l1ll1l_ll_(title,l111lll_ll_ (u"ࠪࠫ㖰"))
			res = re.findall(l111lll_ll_ (u"ࠦࠥ࠮࡜ࡥࠬࡻࢀࡡࡪࠪࠪࠨࠩࠦ㖱"),title+l111lll_ll_ (u"ࠬࠬࠦࠨ㖲"),re.DOTALL)
			for resolution in l1l1l1l111ll_ll_:
				if res[0] in resolution:
					title = title.replace(res[0],resolution.split(l111lll_ll_ (u"࠭ࡸࠨ㖳"))[1])
			l1l1ll1l1111_ll_.append(title)
		#xbmc.log(items[0][0])
		for i in range(len(l1l111l_ll_)):
			items = re.findall(l111lll_ll_ (u"ࠢࠧࠨࠫ࠲࠯ࡅࠩࠩ࡞ࡧ࠮࠮ࠬࠦࠣ㖴"),l111lll_ll_ (u"ࠨࠨࠩࠫ㖵")+l1l1ll1l1111_ll_[i]+l111lll_ll_ (u"ࠩࠩࠪࠬ㖶"),re.DOTALL)
			l1ll1l1111l1_ll_.append( [l1l1ll1l1111_ll_[i],l1l111l_ll_[i],items[0][0],items[0][1]] )
		l1ll1l1111l1_ll_ = sorted(l1ll1l1111l1_ll_, key=lambda x: x[3], reverse=True)
		l1ll1l1111l1_ll_ = sorted(l1ll1l1111l1_ll_, key=lambda x: x[2], reverse=False)
		l1111ll_ll_,l1l111l_ll_ = [],[]
		for i in range(len(l1ll1l1111l1_ll_)):
			l1111ll_ll_.append(l1ll1l1111l1_ll_[i][0])
			l1l111l_ll_.append(l1ll1l1111l1_ll_[i][1])
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡓࡏࡔࡊࡄࡌࡉࡇࠠࡇࡣ࡬ࡰࡪࡪࠧ㖷"),[],[]
	return l111lll_ll_ (u"ࠫࠬ㖸"),l1111ll_ll_,l1l111l_ll_
def l1l11l11ll1l_ll_(url):
	# http://l1l11llll1ll_ll_.l1lll1l11_ll_/717254
	parts = url.split(l111lll_ll_ (u"ࠬࡅࠧ㖹"))
	l1ll111_ll_ = parts[0]
	headers = { l111lll_ll_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㖺") : l111lll_ll_ (u"ࠧࠨ㖻") }
	html = l111ll1_ll_(l11111l1_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ㖼"),headers,l111lll_ll_ (u"ࠩࠪ㖽"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡅ࠶ࡖࡖࡅࡗ࠳࠱ࡴࡶࠪ㖾"))
	items = re.findall(l111lll_ll_ (u"ࠫࡕࡲࡥࡢࡵࡨࠤࡼࡧࡩࡵ࠰࠭ࡃ࡭ࡸࡥࡧ࠿࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬ㖿"),html,re.DOTALL)
	url = items[0]
	#l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1llll11ll_ll_(url)
	#return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
	return l111lll_ll_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㗀"),[l111lll_ll_ (u"࠭ࠧ㗁")],[url]
def l1ll111ll1l1_ll_(url):
	# l1ll1l1l_ll_://l1l1l1ll11_ll_.org/l1l1l1ll1l_ll_
	# l1ll1l1l_ll_://l1l1l11111_ll_.cc/l1l1l1ll1l_ll_
	l1111ll_ll_,l1l111l_ll_ = [],[]
	headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㗂") : l111lll_ll_ (u"ࠨࠩ㗃") }
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠩࠪ㗄"),headers,l111lll_ll_ (u"ࠪࠫ㗅"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡆ࡙ࡑ࡚࡙ࡃࡑࡒࡏࡘ࠳࠱ࡴࡶࠪ㗆"))
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡶࡴ࡯࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㗇"),html,re.DOTALL)
	if l1ll111_ll_: return l111lll_ll_ (u"࠭ࠧ㗈"),[l111lll_ll_ (u"ࠧࠨ㗉")],[l1ll111_ll_[0]]
	else: return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡆ࡚ࡠ࡚ࡗࡔࡏࠤࡋࡧࡩ࡭ࡧࡧࠫ㗊"),[],[]
def l1l11l1l11l1_ll_(url):
	# l1ll1l1l_ll_://l1l1l1ll11_ll_.org/l1l1l1ll1l_ll_
	# l1ll1l1l_ll_://l1l1l11111_ll_.cc/l1l1l1ll1l_ll_
	l1111ll_ll_,l1l111l_ll_ = [],[]
	headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㗋") : l111lll_ll_ (u"ࠪࠫ㗌") }
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠫࠬ㗍"),headers,l111lll_ll_ (u"ࠬ࠭㗎"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡉࡅࡈ࡛ࡌࡕ࡛ࡅࡓࡔࡑࡓ࠮࠳ࡶࡸࠬ㗏"))
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࠧ࠲ࠢࠩࡪࡷࡸ࠳࠰࠿ࠪࠤࠪ㗐"),html,re.DOTALL)
	if l1ll111_ll_: return l111lll_ll_ (u"ࠨࠩ㗑"),[l111lll_ll_ (u"ࠩࠪ㗒")],[l1ll111_ll_[0]]
	else: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡌࡁࡄࡗࡏࡘ࡞ࡈࡏࡐࡍࡖࠤࡋࡧࡩ࡭ࡧࡧࠫ㗓"),[],[]
def l1l11l1ll1_ll_(url):
	#l1ll1l_ll_(url,str(0000))
	# watch    l1ll1l1l_ll_://show.l1l1ll111111_ll_.l1lll1l11_ll_/l1l1lll111l1_ll_-l1l1ll1ll111_ll_/l1l1ll1ll111_ll_-l1l1lll11l11_ll_.l1lllll11_ll_?action=l1l1l1l11l1l_ll_&post=32513&l1l11ll111_ll_=1&type=movie
	# download l1ll1l1l_ll_://show.l1l1ll111111_ll_.l1lll1l11_ll_/links/l1l1lll1llll_ll_
	l1111ll_ll_,l1l111l_ll_,errno = [],[],l111lll_ll_ (u"ࠫࠬ㗔")
	# watch
	if l111lll_ll_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࠩ㗕") in url:
		l1ll111_ll_,data2 = l1l11l1111l_ll_(url)
		l1ll11l1l_ll_ = {l111lll_ll_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ㗖"):l111lll_ll_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩࡁࠠࡤࡪࡤࡶࡸ࡫ࡴ࠾ࡗࡗࡊ࠲࠾ࠧ㗗")}
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠨࡒࡒࡗ࡙࠭㗘"),l1ll111_ll_,data2,l1ll11l1l_ll_,l111lll_ll_ (u"ࠩࠪ㗙"),l111lll_ll_ (u"ࠪࠫ㗚"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠶ࡳࡪࠧ㗛"))
		l1l111l1_ll_ = response.content
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࡠ࠭ࠢ࡞ࠪ࠱࠮ࡄ࠯࡛ࠨࠤࡠࠫࠬ࠭㗜"),l1l111l1_ll_,re.DOTALL)
		l1ll111_ll_ = l1ll111_ll_[0]
		#l1ll1l_ll_(l1ll111_ll_,str(1111))
	# download
	elif l111lll_ll_ (u"࠭࠯࡭࡫ࡱ࡯ࡸ࠵ࠧ㗝") in url:
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ㗞"),url,l111lll_ll_ (u"ࠨࠩ㗟"),l111lll_ll_ (u"ࠩࠪ㗠"),False,l111lll_ll_ (u"ࠪࠫ㗡"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰࠵ࡸࡺࠧ㗢"))
		l1l111l1_ll_ = response.content
		if l111lll_ll_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㗣") in response.headers.keys(): l1ll111_ll_ = response.headers[l111lll_ll_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ㗤")]
		else: l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠧࡪࡦࡀࠦࡱ࡯࡮࡬ࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㗥"),l1l111l1_ll_,re.DOTALL)[0]
		#l1ll1l_ll_(l1ll111_ll_,str(2222))
	if l111lll_ll_ (u"ࠨ࠱ࡹ࠳ࠬ㗦") in l1ll111_ll_ or l111lll_ll_ (u"ࠩ࠲ࡪ࠴࠭㗧") in l1ll111_ll_:
		l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠪ࠳࡫࠵ࠧ㗨"),l111lll_ll_ (u"ࠫ࠴ࡧࡰࡪ࠱ࡶࡳࡺࡸࡣࡦ࠱ࠪ㗩"))
		l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠬ࠵ࡶ࠰ࠩ㗪"),l111lll_ll_ (u"࠭࠯ࡢࡲ࡬࠳ࡸࡵࡵࡳࡥࡨ࠳ࠬ㗫"))
		#l1ll1l_ll_(l1ll111_ll_,str(3333))
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠧࡑࡑࡖࡘࠬ㗬"),l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ㗭"),l111lll_ll_ (u"ࠩࠪ㗮"),l111lll_ll_ (u"ࠪࠫ㗯"),l111lll_ll_ (u"ࠫࠬ㗰"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱࠸ࡸࡤࠨ㗱"))
		l1l111l1_ll_ = response.content
		items = re.findall(l111lll_ll_ (u"࠭ࠢࡧ࡫࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣ࡮ࡤࡦࡪࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㗲"),l1l111l1_ll_,re.DOTALL)
		if items:
			for link,title in items:
				link = link.replace(l111lll_ll_ (u"ࠧ࡝࡞ࠪ㗳"),l111lll_ll_ (u"ࠨࠩ㗴"))
				l1111ll_ll_.append(title)
				l1l111l_ll_.append(link)
		else:
			items = re.findall(l111lll_ll_ (u"ࠩࠥࡪ࡮ࡲࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㗵"),l1l111l1_ll_,re.DOTALL)
			if items:
				link = items[0]
				link = link.replace(l111lll_ll_ (u"ࠪࡠࡡ࠭㗶"),l111lll_ll_ (u"ࠫࠬ㗷"))
				l1111ll_ll_.append(l111lll_ll_ (u"ࠬ࠭㗸"))
				l1l111l_ll_.append(link)
	else: return l111lll_ll_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㗹"),[l111lll_ll_ (u"ࠧࠨ㗺")],[l1ll111_ll_]
	#l1ll1l_ll_(str(data2),l1ll111_ll_)
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡊࡆࡐࡅࡓࡕࡋࡓ࡜ࠦࡆࡢ࡫࡯ࡩࡩ࠭㗻"),[],[]
	return l111lll_ll_ (u"ࠩࠪ㗼"),l1111ll_ll_,l1l111l_ll_
def l11l1ll11l1_ll_(url):
	# watch l111llll_ll_  l1ll1l1l_ll_://l1l1lllll1l1_ll_.l1l1l111111l_ll_.org/player/l1l11l1l111l_ll_.l1lllll11_ll_?s=07&id=l1l1lll1ll1l_ll_,&img=2wh9shmvcTypozADtS8EpvgrwWS.l1l1l1l111l1_ll_&l1l11llll111_ll_=l1l1l11lll1l_ll_&l1ll111l111l_ll_=l1l11ll1l111_ll_
	# watch l1111111_ll_ l1ll1l1l_ll_://l1l1l1ll11l1_ll_.l1l1l111111l_ll_.org/player/l1l1l1llllll_ll_.l1lllll11_ll_?l1l11ll11l1l_ll_=l1l1l1l1l1l1_ll_&l1l1l11lll11_ll_=8a26a6cc61a884e89076504130c71626&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1l1l111l1_ll_&l1l11llll111_ll_=l1l1l11lll1l_ll_&img=8r8m4A09GmYAp7wjBjYPhwPXI6x.l1l1l1l111l1_ll_&l1l11llll111_ll_=l1l1l11lll1l_ll_&l1ll111l111l_ll_=l1l1ll11ll11_ll_
	# download l1ll1l1l_ll_://l1l1l1l1111l_ll_.l1l1l1111111_ll_.l1l1l111111_ll_/download_link?server=l1l1l1ll1l1l_ll_&id=l1l11l1l1lll_ll_,,
	# embed l1ll1l1l_ll_://l1l1l1111111_ll_.l1l1l1l1l1ll_ll_/embed/l1ll11l11l1l_ll_
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ㗽"),url,l111lll_ll_ (u"ࠫࠬ㗾"),l111lll_ll_ (u"ࠬ࠭㗿"),l111lll_ll_ (u"࠭ࠧ㘀"),l111lll_ll_ (u"ࠧࠨ㘁"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠶ࡹࡴࠨ㘂"))
	html = response.content
	l1111ll_ll_,l1l111l_ll_,errno = [],[],l111lll_ll_ (u"ࠩࠪ㘃")
	if l111lll_ll_ (u"ࠪࡴࡱࡧࡹࡦࡴࡢࡩࡲࡨࡥࡥ࠰ࡳ࡬ࡵ࠭㘄") in url or l111lll_ll_ (u"ࠫ࠴࡫࡭ࡣࡧࡧ࠳ࠬ㘅") in url:
		if l111lll_ll_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡤ࡫࡭ࡣࡧࡧ࠲ࡵ࡮ࡰࠨ㘆") in url:
			l1ll111_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㘇"),html,re.DOTALL)
			l1ll111_ll_ = l1ll111_ll_[0]
		else: l1ll111_ll_ = url
		if l111lll_ll_ (u"ࠧ࡮ࡱࡹࡷ࠹ࡻࠧ㘈") not in l1ll111_ll_: return l111lll_ll_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㘉"),[l111lll_ll_ (u"ࠩࠪ㘊")],[l1ll111_ll_]
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ㘋"),l1ll111_ll_,l111lll_ll_ (u"ࠫࠬ㘌"),l111lll_ll_ (u"ࠬ࠭㘍"),l111lll_ll_ (u"࠭ࠧ㘎"),l111lll_ll_ (u"ࠧࠨ㘏"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒࡕࡖࡔ࠶ࡘ࠱࠷ࡴࡤࠨ㘐"))
		html = response.content
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨࡰ࡭ࡣࡼࡩࡷࠨࠨ࠯ࠬࡂ࠭ࡻ࡯ࡤࡦࡱ࡭ࡷࠬ㘑"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡱࡧࡢࡦ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㘒"),block,re.DOTALL)
		if items:
			for link,label in items:
				l1111ll_ll_.append(label)
				l1l111l_ll_.append(link)
	elif l111lll_ll_ (u"ࠫࡲࡧࡩ࡯ࡡࡳࡰࡦࡿࡥࡳ࠰ࡳ࡬ࡵ࠭㘓") in url:
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࡻࡲ࡭࠿ࠫ࠲࠯ࡅࠩࠣࠩ㘔"),html,re.DOTALL)
		l1ll111_ll_ = l1ll111_ll_[0]
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㘕"),l1ll111_ll_,l111lll_ll_ (u"ࠧࠨ㘖"),l111lll_ll_ (u"ࠨࠩ㘗"),l111lll_ll_ (u"ࠩࠪ㘘"),l111lll_ll_ (u"ࠪࠫ㘙"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡑ࡙ࡗ࠹࡛࠭࠴ࡴࡧࠫ㘚"))
		html = response.content
		l11ll1_ll_ = re.findall(l111lll_ll_ (u"ࠬࠨࡦࡪ࡮ࡨࠦ࠿ࠦࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㘛"),html,re.DOTALL)
		l11ll1_ll_ = l11ll1_ll_[0]
		l1111ll_ll_.append(l111lll_ll_ (u"࠭ࠧ㘜"))
		l1l111l_ll_.append(l11ll1_ll_)
	elif l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡ࡯࡭ࡳࡱࠧ㘝") in url:
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠨ࠾ࡦࡩࡳࡺࡥࡳࡀ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㘞"),html,re.DOTALL)
		if l1ll111_ll_:
			l1ll111_ll_ = l1ll111_ll_[0]
			return l111lll_ll_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㘟"),[l111lll_ll_ (u"ࠪࠫ㘠")],[l1ll111_ll_]
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡍࡐࡘࡖ࠸࡚ࠦࡆࡢ࡫࡯ࡩࡩ࠭㘡"),[],[]
	return l111lll_ll_ (u"ࠬ࠭㘢"),l1111ll_ll_,l1l111l_ll_
def l1ll111lll_ll_(url):
	# l1ll1l1l_ll_://l11l11l11l1_ll_.l1l1ll11ll1_ll_/api?call=l1ll11l11lll_ll_&auth=874ded32a2e3b91d6ae55186274469e2?named=l1l11ll111l1_ll_
	# l1ll1l1l_ll_://l11l11l11l1_ll_.l1l1ll11ll1_ll_/api?call=l1ll11l11lll_ll_&auth=874ded32a2e3b91d6ae55186274469e2?named=l1l1lll1111l_ll_
	l1ll111_ll_ = url.split(l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㘣"),1)[0].strip(l111lll_ll_ (u"ࠧࡀࠩ㘤")).strip(l111lll_ll_ (u"ࠨ࠱ࠪ㘥")).strip(l111lll_ll_ (u"ࠩࠩࠫ㘦"))
	l1111ll_ll_,l1l111l_ll_,items,l11ll1_ll_ = [],[],[],l111lll_ll_ (u"ࠪࠫ㘧")
	headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㘨"):l111lll_ll_ (u"ࠬࡓ࡯ࡻ࡫࡯ࡰࡦ࠵࠵࠯࠲ࠣࠬ࡜࡯࡮ࡥࡱࡺࡷࠥࡔࡔࠡ࠳࠳࠲࠵ࡁࠠࡘ࡫ࡱ࠺࠹ࡁࠠࡹ࠸࠷࠭ࠬ㘩") }
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㘪"),l1ll111_ll_,l111lll_ll_ (u"ࠧࠨ㘫"),headers,False,l111lll_ll_ (u"ࠨࠩ㘬"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡋࡇ࡚ࡄࡈࡗ࡙࠳࠱ࡴࡶࠪ㘭"))
	if l111lll_ll_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㘮") in response.headers:
		l11ll1_ll_ = response.headers[l111lll_ll_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭㘯")]
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ㘰"),l11ll1_ll_,l111lll_ll_ (u"࠭ࠧ㘱"),headers,False,l111lll_ll_ (u"ࠧࠨ㘲"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡊࡍ࡙ࡃࡇࡖࡘ࠲࠸࡮ࡥࠩ㘳"))
	if l111lll_ll_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㘴") in response.headers:
		l11ll1_ll_ = response.headers[l111lll_ll_ (u"ࠪࡐࡴࡩࡡࡵ࡫ࡲࡲࠬ㘵")]
	#l1ll1l_ll_(l11ll1_ll_,response.content)
	if l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࠩ㘶") in l11ll1_ll_:
		# l1ll1l1l_ll_://l1ll11ll1l_ll_.top/f/l1l1llll1l11_ll_/?l1ll1lll11_ll_=l1ll11llll1l_ll_
		# l1ll1l1l_ll_://l1ll11ll1l_ll_.top/v/l1l1llll1l11_ll_/?l1ll1lll11_ll_=58888a3c0b432423a217819ac7b6b5ebdc5fe250434aec29a2321f5bSVVVXrSGTVXViVXtTXpagMmXtruoSHtOipmGorgoDTijtVtEmQeXiXVXWSGTVXViVXtitiiMViStmeXiXVXWTSCXViVXSpAvEawgmBtLAzpszStLVXiXVXrPYVXViVXsssVBNSSXVRzOpfVXiXVXPQcVXViVXStGoaeSuxfpOpfVXVL
		if l111lll_ll_ (u"ࠬࡥ࡟ࡸࡣࡷࡧ࡭࠭㘷") in url: l11ll1_ll_ = l11ll1_ll_.replace(l111lll_ll_ (u"࠭࠯ࡧ࠱ࠪ㘸"),l111lll_ll_ (u"ࠧ࠰ࡸ࠲ࠫ㘹"))
		l1l1ll1l1lll_ll_ = l1ll111_ll_.split(l111lll_ll_ (u"ࠨࡁࡓࡌࡕ࡙ࡉࡅ࠿ࠪ㘺"))[1]
		headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㘻"):headers[l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㘼")] , l111lll_ll_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ㘽"):l111lll_ll_ (u"ࠬࡖࡈࡑࡕࡌࡈࡂ࠭㘾")+l1l1ll1l1lll_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㘿"),l11ll1_ll_,l111lll_ll_ (u"ࠧࠨ㙀"),headers,False,l111lll_ll_ (u"ࠨࠩ㙁"),l111lll_ll_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖ࠰ࡔࡑࡇ࡙࠮࠵ࡵࡨࠬ㙂"))
		html = response.content
		#xbmc.log(html)
		#html = l111ll1_ll_(l11111l1_ll_,l11ll1_ll_,l111lll_ll_ (u"ࠪࠫ㙃"),headers,l111lll_ll_ (u"ࠫࠬ㙄"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡇࡊ࡝ࡇࡋࡓࡕ࠯࠶ࡶࡩ࠭㙅"))
		if l111lll_ll_ (u"࠭࠯ࡧ࠱ࠪ㙆") in l11ll1_ll_: items = re.findall(l111lll_ll_ (u"ࠧ࠽ࡪ࠵ࡂ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㙇"),html,re.DOTALL)
		elif l111lll_ll_ (u"ࠨ࠱ࡹ࠳ࠬ㙈") in l11ll1_ll_: items = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨࡶࡪࡦࡨࡳࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㙉"),html,re.DOTALL)
		if items: return [],[l111lll_ll_ (u"ࠪࠫ㙊")],[ items[0] ]
		elif l111lll_ll_ (u"ࠫࡁ࡮࠱࠿࠶࠳࠸ࡁ࠵ࡨ࠲ࡀࠪ㙋") in html:
			return l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ู๊ࠥาใิࠤฬ๊แ๋ัํ์ࠥ็๊่ࠢะะอࠦึะࠢๆ์ิ๐้ࠠ็ุำึํࠠๆ่ࠣห้อๆหำ้๎ฯࠦวๅะสูฮࠦศไࠩ㙌"),[],[]
	else: return l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡇࡊ࡝ࡇࡋࡓࡕࠢࡉࡥ࡮ࡲࡥࡥࠩ㙍"),[],[]
	#xbmc.log(html)
def l1lll11ll11_ll_(link):
	# l1ll1l1l_ll_://l1ll1l111lll_ll_.net/?l1l111ll_ll_=147043&l1l11l1l_ll_=5
	parts = re.findall(l111lll_ll_ (u"ࠧࡱࡱࡶࡸ࡮ࡪ࠽ࠩ࠰࠭ࡃ࠮ࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࠧࠩ㙎"),link+l111lll_ll_ (u"ࠨࠨࠩࠫ㙏"),re.DOTALL|re.IGNORECASE)
	l1l111ll_ll_,l1l11l1l_ll_ = parts[0]
	url = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡷࡪࡸࡩࡦࡵ࠷ࡻࡦࡺࡣࡩ࠰ࡱࡩࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡴࡧࡵࡺࡪࡸࠦࡠࡲࡲࡷࡹࡥࡩࡥ࠿ࠪ㙐")+l1l111ll_ll_+l111lll_ll_ (u"ࠪࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠧ㙑")+l1l11l1l_ll_
	headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㙒"):l111lll_ll_ (u"ࠬ࠭㙓") , l111lll_ll_ (u"࠭ࡘ࠮ࡔࡨࡵࡺ࡫ࡳࡵࡧࡧ࠱࡜࡯ࡴࡩࠩ㙔"):l111lll_ll_ (u"࡙ࠧࡏࡏࡌࡹࡺࡰࡓࡧࡴࡹࡪࡹࡴࠨ㙕") }
	l1ll111_ll_ = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠨࠩ㙖"),headers,l111lll_ll_ (u"ࠩࠪ㙗"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡓࡆࡔࡌࡉࡘ࠺ࡗࡂࡖࡆࡌ࠲࠷ࡳࡵࠩ㙘"))
	#l1ll1l_ll_(url,l1ll111_ll_)
	#l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1llll11ll_ll_(l1ll111_ll_)
	#return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
	return l111lll_ll_ (u"ࠫࡓࡋࡅࡅࡡࡈ࡜࡙ࡋࡒࡏࡃࡏࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙ࠧ㙙"),[l111lll_ll_ (u"ࠬ࠭㙚")],[l1ll111_ll_]
def l1l11l111l1_ll_(url):
	# l1ll1l1l_ll_://l1l1ll111ll1_ll_.video/run/152ecad6d1a6a57667cb09358e0524e990d682af751ffbec43c173ec2f819baed512f327529538ac2a7f0ee61034cbbb78500401c1ec8fa4e08c91b1d20ebb31c0777fa174ee0e97e8214150e54b0388567597a1655b98166909201a59d2ab16e6f116?l1l1llll111l_ll_=0GfHI4TukZPPkW7vi8eP8Q&l1l11ll1ll1l_ll_=1608181746
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㙛"),l111lll_ll_ (u"ࠧࡆࡏࡄࡈࠥࡋࡍࡂࡆ࠽ࠤࠬ㙜")+url)
	#l1ll1l_ll_(url,url)
	server = l1ll1l111_ll_(url)
	l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠨࡔࡨࡪࡪࡸࡥࡳࠩ㙝"):server,l111lll_ll_ (u"ࠩࡄࡧࡨ࡫ࡰࡵ࠯ࡈࡲࡨࡵࡤࡪࡰࡪࠫ㙞"):l111lll_ll_ (u"ࠪ࡫ࡿ࡯ࡰ࠭ࠢࡧࡩ࡫ࡲࡡࡵࡧࠪ㙟")}
	response = l111111_ll_(l1l1l11ll1l_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ㙠"),url,l111lll_ll_ (u"ࠬ࠭㙡"),l1ll11l1l_ll_,l111lll_ll_ (u"࠭ࠧ㙢"),l111lll_ll_ (u"ࠧࠨ㙣"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡒ࡟ࡃࡊࡏࡄ࠱࠶ࡹࡴࠨ㙤"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡳࡰࡦࡿࡥࡳ࠰ࡴࡹࡦࡲࡩࡵࡻࡶࡩࡱ࡫ࡣࡵࡱࡵࠬ࠳࠰࠿ࠪࡨࡲࡶࡲࡧࡴࡴ࠼ࠪ㙥"),html,re.DOTALL)
	l1ll111_ll_ = l111lll_ll_ (u"ࠪࠫ㙦")
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷ࠾ࠥࡢࠧࠩ࡞ࡧ࠲࠯ࡅࠩ࡝ࠩ࠯ࠤࡸࡸࡣ࠻ࠢࠥࠬ࠳࠰࠿ࠪࠤࠪ㙧"),block,re.DOTALL)
		l1111ll_ll_,l1l111l_ll_ = [],[]
		for title,link in items:
			l1111ll_ll_.append(title)
			l1l111l_ll_.append(link)
		if len(l1l111l_ll_)==1: l1ll111_ll_ = l1l111l_ll_[0]
		elif len(l1l111l_ll_)>1:
			selection = l1l1111_ll_(l111lll_ll_ (u"ࠬษฮหำࠣห้๋ไโࠢส่๊์วิสࠪ㙨"), l1111ll_ll_)
			if selection==-1: return l111lll_ll_ (u"࠭ࠧ㙩"),[],[]
			l1ll111_ll_ = l1l111l_ll_[selection]
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㙪"),html,re.DOTALL)
		if l1lll_ll_: l1ll111_ll_ = l1lll_ll_[0]
	if not l1ll111_ll_: return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡑ࡞ࡉࡉࡎࡃࠣࡊࡦ࡯࡬ࡦࡦࠪ㙫"),[],[]
	return l111lll_ll_ (u"ࠩࡑࡉࡊࡊ࡟ࡆ࡚ࡗࡉࡗࡔࡁࡍࡡࡕࡉࡘࡕࡌࡗࡇࡕࡗࠬ㙬"),[l111lll_ll_ (u"ࠪࠫ㙭")],[l1ll111_ll_]
def l1l1lll1_ll_(link):
	# l1ll1l1l_ll_://w.l1l1l1llll11_ll_.l1l1l111llll_ll_/l1l1lll111l1_ll_-content/themes/l1l1l1lll1l1_ll_/l1l1l111l111_ll_/l1ll1111lll1_ll_/Single/l1l1lll11ll1_ll_.l1lllll11_ll_?l1l111ll_ll_=42869&l1l11l1l_ll_=4
	#l1ll1l_ll_(link,html)
	parts = re.findall(l111lll_ll_ (u"ࠫ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯࡜ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠪ࠱࠮ࡄ࠯ࠦࡴࡧࡵࡺࡪࡸࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࠨࠪ㙮"),link+l111lll_ll_ (u"ࠬࠬࠦࠨ㙯"),re.DOTALL)
	url,l1l111ll_ll_,l1l11l1l_ll_ = parts[0]
	data = {l111lll_ll_ (u"࠭ࡰࡰࡵࡷࡣ࡮ࡪࠧ㙰"):l1l111ll_ll_,l111lll_ll_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ㙱"):l1l11l1l_ll_}
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠨࡒࡒࡗ࡙࠭㙲"),url,data,l111lll_ll_ (u"ࠩࠪ㙳"),l111lll_ll_ (u"ࠪࠫ㙴"),l111lll_ll_ (u"ࠫࠬ㙵"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎࡓࡆࡓࡃࡂࡏ࠰࠵ࡸࡺࠧ㙶"))
	html = response.content
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"࠭ࡩࡧࡴࡤࡱࡪࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㙷"),html,re.DOTALL)[0]
	return l111lll_ll_ (u"ࠧࡏࡇࡈࡈࡤࡋࡘࡕࡇࡕࡒࡆࡒ࡟ࡓࡇࡖࡓࡑ࡜ࡅࡓࡕࠪ㙸"),[l111lll_ll_ (u"ࠨࠩ㙹")],[l1ll111_ll_]
def l11l111ll_ll_(url):
	# l1ll1l1l_ll_://l1ll111l1111_ll_.l1l1l1l1llll_ll_.cc/l1l1lll111l1_ll_-content/themes/l1l1ll1l11ll_ll_%20Now%20New/core.l1lllll11_ll_?action=l1lll111ll1l_ll_&index=00&id=58504
	# l1ll1l1l_ll_://l1l11l1ll1ll_ll_.l1l1l1l1llll_ll_.net/l1ll11l1l1l1_ll_/2021/04/05/_1ll111ll111_ll_-l1ll11lll1ll_ll_.l1l11l11l1ll_ll_ 200.l1l11ll11ll1_ll_.2020.l1ll11111111_ll_/[l1l1ll1l11ll_ll_-l1ll11lll1ll_ll_.l1l11l11l1l1_ll_] 200.l1l11ll11ll1_ll_.2020.l1ll11111111_ll_-360p.l111llll_ll_
	l1l11l1lll1l_ll_ = l1ll1l111_ll_(url)
	if l111lll_ll_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ㙺") in url:
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ㙻"),url,l111lll_ll_ (u"ࠫࠬ㙼"),l111lll_ll_ (u"ࠬ࠭㙽"),l111lll_ll_ (u"࠭ࠧ㙾"),l111lll_ll_ (u"ࠧࠨ㙿"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡈࡏࡍࡂࡐࡒ࡛࠲࠷ࡳࡵࠩ㚀"))
		html = response.content
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡪࡷࡧ࡭ࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㚁"),html,re.DOTALL)[0]
		if l111lll_ll_ (u"ࠪࡧ࡮ࡳࡡ࡯ࡱࡺࠫ㚂") in l1ll111_ll_:
			headers = {l111lll_ll_ (u"ࠫࡗ࡫ࡦࡦࡴࡨࡶࠬ㚃"):l1l11l1lll1l_ll_}
			response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ㚄"),l1ll111_ll_,l111lll_ll_ (u"࠭ࠧ㚅"),headers,l111lll_ll_ (u"ࠧࠨ㚆"),l111lll_ll_ (u"ࠨࠩ㚇"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ㚈"))
			l1l111l1_ll_ = response.content
			items = re.findall(l111lll_ll_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㚉"),l1l111l1_ll_,re.DOTALL)
			l1111ll_ll_,l1l111l_ll_ = [],[]
			l1l1l1l11lll_ll_ = l1ll1l111_ll_(l1ll111_ll_)
			for link,quality in reversed(items):
				link = l1l1l1l11lll_ll_+link+l111lll_ll_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㚊")+l1l1l1l11lll_ll_
				l1111ll_ll_.append(quality)
				l1l111l_ll_.append(link)
			return l111lll_ll_ (u"ࠬ࠭㚋"),l1111ll_ll_,l1l111l_ll_
		else: return l111lll_ll_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㚌"),[l111lll_ll_ (u"ࠧࠨ㚍")],[l1ll111_ll_]
	else:
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ㚎")+l1l11l1lll1l_ll_
		return l111lll_ll_ (u"ࠩࠪ㚏"),[l111lll_ll_ (u"ࠪࠫ㚐")],[l1ll111_ll_]
def l11l111l1_ll_(link):
	# l1ll1l1l_ll_://l1l1l1l1llll_ll_.l1l1l111llll_ll_/l1l1lll111l1_ll_-content/themes/l1ll1l1l1l1l_ll_/l1l1llll1111_ll_/server.l1lllll11_ll_?l1l111ll_ll_=42869&l1l11l1l_ll_=4
	# l1ll1l1l_ll_://l1l1l1lll11l_ll_.l1l1l1l1llll_ll_.net/l1ll11l1l1l1_ll_/2020/08/14/_1ll111ll111_ll_-l1ll11lll1ll_ll_.l1l11l11l1ll_ll_ l1l11l1l1l11_ll_.l1l11lll1111_ll_.2020.l1l1l11111ll_ll_-l1l1l1111ll1_ll_/[l1l1ll1l11ll_ll_-l1ll11lll1ll_ll_.l1l11l11l1l1_ll_] l1l11l1l1l11_ll_.l1l11lll1111_ll_.2020.l1l1l11111ll_ll_-l1l1l1111ll1_ll_-1080p.l111llll_ll_
	#l1ll1l_ll_(url,html)
	l1l11l1lll1l_ll_ = l1ll1l111_ll_(link)
	if l111lll_ll_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ㚑") in link:
		parts = re.findall(l111lll_ll_ (u"ࠬ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩ࡝ࡁࡳࡳࡸࡺࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠬ࠳࠰࠿ࠪࠨࠩࠫ㚒"),link+l111lll_ll_ (u"࠭ࠦࠧࠩ㚓"),re.DOTALL)
		url,l1l111ll_ll_,l1l11l1l_ll_ = parts[0]
		data = {l111lll_ll_ (u"ࠧࡪࡦࠪ㚔"):l1l111ll_ll_,l111lll_ll_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠨ㚕"):l1l11l1l_ll_}
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡓࡓࡘ࡚ࠧ㚖"),url,data,l111lll_ll_ (u"ࠪࠫ㚗"),l111lll_ll_ (u"ࠫࠬ㚘"),l111lll_ll_ (u"ࠬ࠭㚙"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡆࡍࡒࡇࡎࡐ࡙࠰࠵ࡸࡺࠧ㚚"))
		html = response.content
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠧࡪࡨࡵࡥࡲ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㚛"),html,re.DOTALL)[0]
		if l111lll_ll_ (u"ࠨࡥ࡬ࡱࡦࡴ࡯ࡸࠩ㚜") in l1ll111_ll_:
			headers = {l111lll_ll_ (u"ࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ㚝"):l1l11l1lll1l_ll_,l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㚞"):l111lll_ll_ (u"ࠫࠬ㚟")}
			response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ㚠"),l1ll111_ll_,l111lll_ll_ (u"࠭ࠧ㚡"),headers,l111lll_ll_ (u"ࠧࠨ㚢"),l111lll_ll_ (u"ࠨࠩ㚣"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡉࡉࡎࡃࡑࡓ࡜࠳࠲࡯ࡦࠪ㚤"))
			l1l111l1_ll_ = response.content
			items = re.findall(l111lll_ll_ (u"ࠪࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡷ࡮ࢀࡥ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㚥"),l1l111l1_ll_,re.DOTALL)
			l1111ll_ll_,l1l111l_ll_ = [],[]
			l1l1l1l11lll_ll_ = l1ll1l111_ll_(l1ll111_ll_)
			for link,quality in reversed(items):
				link = l1l1l1l11lll_ll_+link+l111lll_ll_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㚦")+l1l1l1l11lll_ll_
				l1111ll_ll_.append(quality)
				l1l111l_ll_.append(link)
			return l111lll_ll_ (u"ࠬ࠭㚧"),l1111ll_ll_,l1l111l_ll_
		else: return l111lll_ll_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㚨"),[l111lll_ll_ (u"ࠧࠨ㚩")],[l1ll111_ll_]
	else:
		link = link+l111lll_ll_ (u"ࠨࡾࡕࡩ࡫࡫ࡲࡦࡴࡀࠫ㚪")+l1l11l1lll1l_ll_
		return l111lll_ll_ (u"ࠩࠪ㚫"),[l111lll_ll_ (u"ࠪࠫ㚬")],[link]
def l11llll1l_ll_(link):
	# http://l1ll11111l11_ll_.tv/?l1l111ll_ll_=159485&l1l11l1l_ll_=0
	if l111lll_ll_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࠫ㚭") in link:
		parts = re.findall(l111lll_ll_ (u"ࠬࡶ࡯ࡴࡶ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࡸ࡫ࡲࡷࡧࡵ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠫࠬࠧ㚮"),link+l111lll_ll_ (u"࠭ࠦࠧࠩ㚯"),re.DOTALL|re.IGNORECASE)
		l1l111ll_ll_,l1l11l1l_ll_ = parts[0]
		host = l1ll1l111_ll_(link)
		#l1ll1l_ll_(link,host)
		url = host+l111lll_ll_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡶࡩࡷࡼࡥࡳࠨࡢࡴࡴࡹࡴࡠ࡫ࡧࡁࠬ㚰")+l1l111ll_ll_+l111lll_ll_ (u"ࠨࠨࡶࡩࡷࡼࡥࡳ࡫ࡧࡁࠬ㚱")+l1l11l1l_ll_
		headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭㚲"):l111lll_ll_ (u"ࠪࠫ㚳") , l111lll_ll_ (u"ࠫ࡝࠳ࡒࡦࡳࡸࡩࡸࡺࡥࡥ࠯࡚࡭ࡹ࡮ࠧ㚴"):l111lll_ll_ (u"ࠬ࡞ࡍࡍࡊࡷࡸࡵࡘࡥࡲࡷࡨࡷࡹ࠭㚵") }
		l1ll111_ll_ = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"࠭ࠧ㚶"),headers,l111lll_ll_ (u"ࠧࠨ㚷"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡘࡂࡍࡋࡒࡒ࡟࠳࠱ࡴࡶࠪ㚸"))
		l1ll111_ll_ = l1ll111_ll_.replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬ㚹"),l111lll_ll_ (u"ࠪࠫ㚺")).replace(l111lll_ll_ (u"ࠫࡡࡸࠧ㚻"),l111lll_ll_ (u"ࠬ࠭㚼"))
		#l1ll1l_ll_(url,l1ll111_ll_)
		#l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1llll11ll_ll_(l1ll111_ll_)
		#return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
		return l111lll_ll_ (u"࠭ࡎࡆࡇࡇࡣࡊ࡞ࡔࡆࡔࡑࡅࡑࡥࡒࡆࡕࡒࡐ࡛ࡋࡒࡔࠩ㚽"),[l111lll_ll_ (u"ࠧࠨ㚾")],[l1ll111_ll_]
	elif l111lll_ll_ (u"ࠨ࠱ࡵࡩࡩ࡯ࡲࡦࡥࡷ࠳ࠬ㚿") in link:
		counts = 0
		while l111lll_ll_ (u"ࠩ࠲ࡶࡪࡪࡩࡳࡧࡦࡸ࠴࠭㛀") in link and counts<5:
			response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ㛁"),link,l111lll_ll_ (u"ࠫࠬ㛂"),l111lll_ll_ (u"ࠬ࠭㛃"),False,l111lll_ll_ (u"࠭ࠧ㛄"),l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡈࡌࡊࡑࡑ࡞࠲࠸࡮ࡥࠩ㛅"))
			if l111lll_ll_ (u"ࠨࡎࡲࡧࡦࡺࡩࡰࡰࠪ㛆") in response.headers.keys():
				link = response.headers[l111lll_ll_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㛇")]
			counts += 1
		return l111lll_ll_ (u"ࠪࠫ㛈"),[l111lll_ll_ (u"ࠫࠬ㛉")],[link]
	else: return l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡂࡔࡅࡐࡎࡕࡎ࡛ࠢࡉࡥ࡮ࡲࡥࡥࠩ㛊"),[],[]
def l1l111l11_ll_(url):
	headers = {l111lll_ll_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㛋"):l111lll_ll_ (u"ࠧࠨ㛌")}
	#l1ll1l_ll_(url,url)
	if l111lll_ll_ (u"ࠨ࠱ࡖࡩࡷࡼࡥࡳ࠰ࡳ࡬ࡵ࠭㛍") in url:
		l1ll11l1l_ll_ = headers
		l1ll11l1l_ll_[l111lll_ll_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㛎")] = l111lll_ll_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㛏")
		l1ll111_ll_,data2 = l1l11l1111l_ll_(url)
		#l1ll1l_ll_(l1ll111_ll_,str(data2))
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠫࡕࡕࡓࡕࠩ㛐"),l1ll111_ll_,data2,l1ll11l1l_ll_,True,l111lll_ll_ (u"ࠬ࠭㛑"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡖࡆࡈࡓࡆࡇࡇ࠱࠶ࡹࡴࠨ㛒"))
		html = response.content
		items = re.findall(l111lll_ll_ (u"ࠧࡔࡔࡆࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㛓"),html,re.DOTALL|re.IGNORECASE)
		#l1ll1l_ll_(str(items),html)
		link = items[0]
		if l111lll_ll_ (u"ࠨࡣࡵࡥࡧࡹࡥࡦࡦࠪ㛔") not in link:
			l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l1lll1l1ll_ll_(link)
			return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
		else: url = link
	if l111lll_ll_ (u"ࠩ࠱ࡱࡵ࠺࠮ࡩࡶࡰࡰࠬ㛕") in url:
		l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l1l11lll111l_ll_(url)
		return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
	else:
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠪࠫ㛖"),headers,l111lll_ll_ (u"ࠫࠬ㛗"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰࠶ࡳࡪࠧ㛘"))
		links = re.findall(l111lll_ll_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㛙"),html,re.DOTALL)
		if links: return l111lll_ll_ (u"ࠧࠨ㛚"),[l111lll_ll_ (u"ࠨࠩ㛛")],[links[0]]
		return l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡆࡘࡁࡃࡕࡈࡉࡉࠦࡆࡢ࡫࡯ࡩࡩ࠭㛜"),[],[]
l111lll_ll_ (u"ࠥࠦࠧࠐࠉࠊࠋࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡓࡇࡔ࡙ࡊ࡙ࡔࡔࡡࡆࡅࡈࡎࡅࡅࠪࡖࡌࡔࡘࡔࡠࡅࡄࡇࡍࡋࠬࠨࡉࡈࡘࠬ࠲࡬ࡪࡰ࡮࠰ࠬ࠭ࠬࡩࡧࡤࡨࡪࡸࡳ࠳࠮ࡗࡶࡺ࡫ࠬࠨࠩ࠯ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡂࡔࡄࡆࡘࡋࡅࡅ࠯࠵ࡲࡩ࠭ࠩࠋࠋࠌࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠋࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩ࠿ࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࡿࡶࡪ࠴ࡉࡈࡐࡒࡖࡊࡉࡁࡔࡇࠬࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞ࠌࠌࠍࠎࡸࡥࡵࡷࡵࡲࠥ࠭ࠧ࠭࡝ࠪࠫࡢ࠲࡛࡭࡫ࡱ࡯ࡢࠐࠉࠊࡧ࡯ࡷࡪࡀࠠࠋࠤࠥࠦ㛝")
def l1ll1l1ll11_ll_(link):
	# l1ll1l1l_ll_://l1l1l111lll1_ll_.net/?l1l111ll_ll_=142302&l1l11l1l_ll_=4
	parts = re.findall(l111lll_ll_ (u"ࠫࡵࡵࡳࡵ࡫ࡧࡁ࠭࠴ࠪࡀࠫࠩࡷࡪࡸࡶࡦࡴ࡬ࡨࡂ࠮࠮ࠫࡁࠬࠪࠫ࠭㛞"),link+l111lll_ll_ (u"ࠬࠬࠦࠨ㛟"),re.DOTALL|re.IGNORECASE)
	l1l111ll_ll_,l1l11l1l_ll_ = parts[0]
	url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡰࡰ࠱ࡷ࡭ࡧࡨࡪࡦ࠷ࡹ࠳ࡴࡥࡵ࠱ࡤ࡮ࡦࡾࡃࡦࡰࡷࡩࡷࡅ࡟ࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡷࡪࡸࡶࡦࡴࠩࡣࡵࡵࡳࡵࡡ࡬ࡨࡂ࠭㛠")+l1l111ll_ll_+l111lll_ll_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ㛡")+l1l11l1l_ll_
	headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㛢"):l111lll_ll_ (u"ࠩࠪ㛣") , l111lll_ll_ (u"ࠪ࡜࠲ࡘࡥࡲࡷࡨࡷࡹ࡫ࡤ࠮࡙࡬ࡸ࡭࠭㛤"):l111lll_ll_ (u"ࠫ࡝ࡓࡌࡉࡶࡷࡴࡗ࡫ࡱࡶࡧࡶࡸࠬ㛥") }
	l1ll111_ll_ = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭㛦"),headers,l111lll_ll_ (u"࠭ࠧ㛧"),l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡗࡍࡇࡈࡊࡆ࠷࡙࠲࠷ࡳࡵࠩ㛨"))
	return l111lll_ll_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㛩"),[l111lll_ll_ (u"ࠩࠪ㛪")],[l1ll111_ll_]
def l1l1lll_ll_(l1ll111_ll_,type,quality):
	#l1ll1l_ll_(url,named)
	# l1ll1l1l_ll_://l1l1llllll1l_ll_-2o.l1lll1l11_ll_/watch/12899		?named=		__1ll1l1l1l11_ll_
	# l1ll1l1l_ll_://l1l1llllll1l_ll_-2o.l1lll1l11_ll_/link/12899			?named=		__1l1l1111lll_ll_
	l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠪࠫ㛫"),l111lll_ll_ (u"ࠫࠬ㛬"),True,l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡃࡎ࡛ࡆࡓ࠭࠲ࡵࡷࠫ㛭"))
	l11ll1_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㛮"),l1l111l1_ll_,re.DOTALL)
	if l11ll1_ll_: l11ll1_ll_ = l1111_ll_(l11ll1_ll_[0])
	else: l11ll1_ll_ = l1ll111_ll_
	l1l111l_ll_,l1111ll_ll_ = [],[]
	if type==l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠩ㛯"):
		l1l11l1l11ll_ll_ = l111ll1_ll_(l11111l1_ll_,l11ll1_ll_,l111lll_ll_ (u"ࠨࠩ㛰"),l111lll_ll_ (u"ࠩࠪ㛱"),True,l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡁࡌ࡙ࡄࡑ࠲࠸࡮ࡥࠩ㛲"))
		l1l11llll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡧࡺ࡮࠮࡮ࡲࡥࡩ࡫ࡲ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㛳"),l1l11l1l11ll_ll_,re.DOTALL)
		if l1l11llll_ll_:
			link = l1111_ll_(l1l11llll_ll_[0])
			l1l111l_ll_.append(link)
			l1111ll_ll_.append(quality)
	elif type==l111lll_ll_ (u"ࠬࡽࡡࡵࡥ࡫ࠫ㛴"):
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"࠭ࠧ㛵"))
		l1l11l1l11ll_ll_ = l111ll1_ll_(l11111l1_ll_,l11ll1_ll_,l111lll_ll_ (u"ࠧࠨ㛶"),l111lll_ll_ (u"ࠨࠩ㛷"),True,l111lll_ll_ (u"ࠩࡄࡏ࡜ࡇࡍ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ㛸"))
		links = re.findall(l111lll_ll_ (u"ࠪࡀࡸࡵࡵࡳࡥࡨ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪࡼࡨࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㛹"),l1l11l1l11ll_ll_,re.DOTALL)
		for link,size in links:
			if quality in size:
				l1111ll_ll_.append(size)
				l1l111l_ll_.append(link)
				break
		if not l1l111l_ll_:
			for link,size in links:
				l1111ll_ll_.append(size)
				l1l111l_ll_.append(link)
	if not l1l111l_ll_: return l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡁࡌ࡙ࡄࡑࠥࡌࡡࡪ࡮ࡨࡨࠬ㛺"),[],[]
	return l111lll_ll_ (u"ࠬ࠭㛻"),l1111ll_ll_,l1l111l_ll_
def l1l_ll_(url,name):
	#l1ll1l_ll_(url,named)
	# http://go.l1l1l1llll11_ll_.net/5cf68c23e6e79			?named=			__1ll11ll11l1_ll_
	# http://w.l11lllll_ll_.org/5e14fd0a2806e			?named=			ok.l1ll11l1l111_ll_
	#named = named.replace(l111lll_ll_ (u"࠭ࡡ࡬ࡱࡤࡱࡤࡥࠧ㛼"),l111lll_ll_ (u"ࠧࠨ㛽")).split(l111lll_ll_ (u"ࠨࡡࡢࠫ㛾"))[1]
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭㛿"),url,l111lll_ll_ (u"ࠪࠫ㜀"),l111lll_ll_ (u"ࠫࠬ㜁"),True,l111lll_ll_ (u"ࠬ࠭㜂"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡄࡏࡔࡇࡍ࠮࠳ࡶࡸࠬ㜃"))
	html = response.content
	cookies = response.cookies.get_dict()
	if l111lll_ll_ (u"ࠧࡨࡱ࡯࡭ࡳࡱࠧ㜄") in cookies.keys():
		cookie = cookies[l111lll_ll_ (u"ࠨࡩࡲࡰ࡮ࡴ࡫ࠨ㜅")]
		cookie = l1111_ll_(l1l1l11ll_ll_(cookie))
		items = re.findall(l111lll_ll_ (u"ࠩࡵࡳࡺࡺࡥࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㜆"),cookie,re.DOTALL)
		l1ll111_ll_ = items[0].replace(l111lll_ll_ (u"ࠪࡠ࠴࠭㜇"),l111lll_ll_ (u"ࠫ࠴࠭㜈"))
		l1ll111_ll_ = l1l1l11ll_ll_(l1ll111_ll_)
	else: l1ll111_ll_ = url
	if l111lll_ll_ (u"ࠬࡩࡡࡵࡥ࡫࠲࡮ࡹࠧ㜉") in l1ll111_ll_:
		id = l1ll111_ll_.split(l111lll_ll_ (u"࠭ࠥ࠳ࡈࠪ㜊"))[-1]
		l1ll111_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡤࡣࡷࡧ࡭࠴ࡩࡴ࠱ࠪ㜋")+id
		return l111lll_ll_ (u"ࠨࡐࡈࡉࡉࡥࡅ࡙ࡖࡈࡖࡓࡇࡌࡠࡔࡈࡗࡔࡒࡖࡆࡔࡖࠫ㜌"),[l111lll_ll_ (u"ࠩࠪ㜍")],[l1ll111_ll_]
	else:
		l1111l_ll_ = l11l11l_ll_[l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎࠩ㜎")][0]
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ㜏"),l1111l_ll_,l111lll_ll_ (u"ࠬ࠭㜐"),l111lll_ll_ (u"࠭ࠧ㜑"),True,l111lll_ll_ (u"ࠧࠨ㜒"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡆࡑࡏࡂࡏ࠰࠶ࡳࡪࠧ㜓"))
		l1l1ll11l1l1_ll_ = response.url
		#l1l1ll11l1l1_ll_ = response.headers[l111lll_ll_ (u"ࠩࡏࡳࡨࡧࡴࡪࡱࡱࠫ㜔")]
		#l1ll1l_ll_(response.url,l1111l_ll_)
		l1ll11lll11l_ll_ = l1ll111_ll_.split(l111lll_ll_ (u"ࠪ࠳ࠬ㜕"))[2]
		l1ll1l11ll1l_ll_ = l1l1ll11l1l1_ll_.split(l111lll_ll_ (u"ࠫ࠴࠭㜖"))[2]
		l11ll1_ll_ = l1ll111_ll_.replace(l1ll11lll11l_ll_,l1ll1l11ll1l_ll_.encode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪ㜗")))
		headers = { l111lll_ll_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㜘"):l111lll_ll_ (u"ࠧࠨ㜙") , l111lll_ll_ (u"ࠨ࡚࠰ࡖࡪࡷࡵࡦࡵࡷࡩࡩ࠳ࡗࡪࡶ࡫ࠫ㜚"):l111lll_ll_ (u"࡛ࠩࡑࡑࡎࡴࡵࡲࡕࡩࡶࡻࡥࡴࡶࠪ㜛") , l111lll_ll_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫ㜜"):l11ll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠫࡕࡕࡓࡕࠩ㜝"), l11ll1_ll_, l111lll_ll_ (u"ࠬ࠭㜞"), headers, False,l111lll_ll_ (u"࠭ࠧ㜟"),l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡐࡕࡁࡎ࠯࠶ࡶࡩ࠭㜠"))
		html = response.content
		#xbmc.log(str(l11ll1_ll_), level=xbmc.LOGERROR)
		items = re.findall(l111lll_ll_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㜡"),html,re.DOTALL|re.IGNORECASE)
		if not items:
			items = re.findall(l111lll_ll_ (u"ࠩ࠿࡭࡫ࡸࡡ࡮ࡧ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㜢"),html,re.DOTALL|re.IGNORECASE)
			if not items:
				items = re.findall(l111lll_ll_ (u"ࠪࡀࡪࡳࡢࡦࡦ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㜣"),html,re.DOTALL|re.IGNORECASE)
		#l1ll1l_ll_(str(items),html)
		if items:
			link = items[0].replace(l111lll_ll_ (u"ࠫࡡ࠵ࠧ㜤"),l111lll_ll_ (u"ࠬ࠵ࠧ㜥"))
			link = link.rstrip(l111lll_ll_ (u"࠭࠯ࠨ㜦"))
			if l111lll_ll_ (u"ࠧࡩࡶࡷࡴࠬ㜧") not in link: link = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀࠧ㜨") + link
			if name==l111lll_ll_ (u"ࠩࠪ㜩"): l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"ࠪࠫ㜪"),[l111lll_ll_ (u"ࠫࠬ㜫")],[link]
			else: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"ࠬࡔࡅࡆࡆࡢࡉ࡝࡚ࡅࡓࡐࡄࡐࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࡓࠨ㜬"),[l111lll_ll_ (u"࠭ࠧ㜭")],[link]
		else: l1111llll_ll_,l1111ll_ll_,l1l111l_ll_ = l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡄࡏࡔࡇࡍࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㜮"),[],[]
		#l1ll1l_ll_(l1l111l_ll_[0],l1111llll_ll_)
		return l1111llll_ll_,l1111ll_ll_,l1l111l_ll_
def l1l11ll1lll1_ll_(url):
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.l1l1l11l1l1l_ll_.l1lll1l11_ll_/e/l1ll11l11ll1_ll_
	headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㜯") : l111lll_ll_ (u"ࠩࠪ㜰") }
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠪࠫ㜱"),headers,l111lll_ll_ (u"ࠫࠬ㜲"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡔࡄࡔࡎࡊࡖࡊࡆࡈࡓ࠲࠷ࡳࡵࠩ㜳"))
	#l1ll1l_ll_(url,html)
	items = re.findall(l111lll_ll_ (u"࠭࠼ࡴࡱࡸࡶࡨ࡫ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭ࡣࡥࡩࡱࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㜴"),html,re.DOTALL)
	l1111ll_ll_,l1l111l_ll_,errno = [],[],l111lll_ll_ (u"ࠧࠨ㜵")
	if items:
		for link,label in items:
			l1111ll_ll_.append(label)
			l1l111l_ll_.append(link)
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣࡖࡆࡖࡉࡅࡘࡌࡈࡊࡕࠠࡇࡣ࡬ࡰࡪࡪࠧ㜶"),[],[]
	return l111lll_ll_ (u"ࠩࠪ㜷"),l1111ll_ll_,l1l111l_ll_
def l1l1ll11lll1_ll_(url):
	# l1ll1l1l_ll_://l1l1l111l1ll_ll_.l1lll1l11_ll_/embed-l1ll11l1ll11_ll_.html
	url = url.replace(l111lll_ll_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ㜸"),l111lll_ll_ (u"ࠫࠬ㜹"))
	headers = { l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㜺") : l111lll_ll_ (u"࠭ࠧ㜻") }
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠧࠨ㜼"),headers,l111lll_ll_ (u"ࠨࠩ㜽"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡛ࡑࡍࡑࡄࡈ࠲࠷ࡳࡵࠩ㜾"))
	items = re.findall(l111lll_ll_ (u"ࠪࡷࡴࡻࡲࡤࡧࡶ࠾ࠥࡢ࡛ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㜿"),html,re.DOTALL)
	#l1ll1l_ll_(url,items[0])
	if items:
		url = items[0]+l111lll_ll_ (u"ࠫࢁࡘࡥࡧࡧࡵࡩࡷࡃࠧ㝀")+url
		return l111lll_ll_ (u"ࠬ࠭㝁"),[l111lll_ll_ (u"࠭ࠧ㝂")],[url]
	else: return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡘࡕࡑࡕࡁࡅࠢࡉࡥ࡮ࡲࡥࡥࠩ㝃"),[],[]
def l1l1l1ll1l11_ll_(url):
	# l1ll1l1l_ll_://l1l11ll1llll_ll_.to/embed/5c83f14297d62
	url = url.strip(l111lll_ll_ (u"ࠨ࠱ࠪ㝄"))
	if l111lll_ll_ (u"ࠩ࠲ࡩࡲࡨࡥࡥ࠱ࠪ㝅") in url: id = url.split(l111lll_ll_ (u"ࠪ࠳ࠬ㝆"))[4]
	else: id = url.split(l111lll_ll_ (u"ࠫ࠴࠭㝇"))[-1]
	url = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡶࡤࡵࡷࡶࡪࡧ࡭࠯ࡶࡲ࠳ࡵࡲࡡࡺࡧࡵࡃ࡫࡯ࡤ࠾ࠩ㝈") + id
	headers = { l111lll_ll_ (u"࠭ࡕࡴࡧࡵ࠱ࡆ࡭ࡥ࡯ࡶࠪ㝉") : l111lll_ll_ (u"ࠧࠨ㝊") }
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠨࠩ㝋"),headers,l111lll_ll_ (u"ࠩࠪ㝌"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡖࡄࡕࡗࡖࡊࡇࡍ࠮࠳ࡶࡸࠬ㝍"))
	html = html.replace(l111lll_ll_ (u"ࠫࡡࡢࠧ㝎"),l111lll_ll_ (u"ࠬ࠭㝏"))
	#l1ll1l_ll_(url,html)
	items = re.findall(l111lll_ll_ (u"࠭ࡦࡪ࡮ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㝐"),html,re.DOTALL)
	if items: return l111lll_ll_ (u"ࠧࠨ㝑"),[l111lll_ll_ (u"ࠨࠩ㝒")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡛ࡉࡓࡕࡔࡈࡅࡒࠦࡆࡢ࡫࡯ࡩࡩ࠭㝓"),[],[]
def l1l1l11l111l_ll_(url):
	# l1ll1l1l_ll_://l1l1lllll11l_ll_.net/embed-l1ll1l1l11ll_ll_.html
	url = url.replace(l111lll_ll_ (u"ࠪࡩࡲࡨࡥࡥ࠯ࠪ㝔"),l111lll_ll_ (u"ࠫࠬ㝕"))
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭㝖"),l111lll_ll_ (u"࠭ࠧ㝗"),l111lll_ll_ (u"ࠧࠨ㝘"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡛ࡏࡄࡐ࡜ࡄ࠱࠶ࡹࡴࠨ㝙"))
	items = re.findall(l111lll_ll_ (u"ࠩࡶࡶࡨࡀࠠࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡰࡦࡨࡥ࡭࠼ࠥࠬ࠳࠰࠿ࠪࠤ࠯ࠤࡷ࡫ࡳ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㝚"),html,re.DOTALL)
	l1111ll_ll_,l1l111l_ll_ = [],[]
	for link,label,res in items:
		l1111ll_ll_.append(label+l111lll_ll_ (u"ࠪࠤࠬ㝛")+res)
		l1l111l_ll_.append(link)
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠫࡊࡸࡲࡰࡴ࠽ࠤࡗ࡫ࡳࡰ࡮ࡹࡩࡷࠦࡖࡊࡆࡒ࡞ࡆࠦࡆࡢ࡫࡯ࡩࡩ࠭㝜"),[],[]
	return l111lll_ll_ (u"ࠬ࠭㝝"),l1111ll_ll_,l1l111l_ll_
def l1l1ll1ll11l_ll_(url):
	# l1ll1l1l_ll_://l1ll11l1111l_ll_.l1l11ll1ll_ll_/embed-l1l1l1lll111_ll_.html
	url = url.replace(l111lll_ll_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭㝞"),l111lll_ll_ (u"ࠧࠨ㝟"))
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠨࠩ㝠"),l111lll_ll_ (u"ࠩࠪ㝡"),l111lll_ll_ (u"ࠪࠫ㝢"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡘࡃࡗࡇࡍ࡜ࡉࡅࡇࡒ࠱࠶ࡹࡴࠨ㝣"))
	items = re.findall(l111lll_ll_ (u"ࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡷ࡫ࡧࡩࡴࡢࠨࠨࠪ࠱࠮ࡄ࠯ࠧ࠭ࠩࠫ࠲࠯ࡅࠩࠨ࠮ࠪࠬ࠳࠰࠿ࠪࠩ࡟࠭ࡡࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡢࡀ࠱࠮ࡄࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠭࠰࠭ࡃࡁ࠵ࡴࡥࡀࠥ㝤"),html,re.DOTALL)
	items = set(items)
	l1111ll_ll_,l1l111l_ll_ = [],[]
	for id,mode,hash,label,res in items:
		url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡣࡷࡧ࡭ࡼࡩࡥࡧࡲ࠲ࡺࡹ࠯ࡥ࡮ࡂࡳࡵࡃࡤࡰࡹࡱࡰࡴࡧࡤࡠࡱࡵ࡭࡬ࠬࡩࡥ࠿ࠪ㝥")+id+l111lll_ll_ (u"ࠧࠧ࡯ࡲࡨࡪࡃࠧ㝦")+mode+l111lll_ll_ (u"ࠨࠨ࡫ࡥࡸ࡮࠽ࠨ㝧")+hash
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠩࠪ㝨"),l111lll_ll_ (u"ࠪࠫ㝩"),l111lll_ll_ (u"ࠫࠬ㝪"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡙ࡄࡘࡈࡎࡖࡊࡆࡈࡓ࠲࠸࡮ࡥࠩ㝫"))
		items = re.findall(l111lll_ll_ (u"࠭ࡤࡪࡴࡨࡧࡹࠦ࡬ࡪࡰ࡮࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ㝬"),html,re.DOTALL)
		for link in items:
			l1111ll_ll_.append(label+l111lll_ll_ (u"ࠧࠡࠩ㝭")+res)
			l1l111l_ll_.append(link)
	if len(l1l111l_ll_)==0: return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴ࡛ࠣࡆ࡚ࡃࡉࡘࡌࡈࡊࡕࠠࡇࡣ࡬ࡰࡪࡪࠧ㝮"),[],[]
	return l111lll_ll_ (u"ࠩࠪ㝯"),l1111ll_ll_,l1l111l_ll_
def l1l11l1l1111_ll_(url):
	# http://l1l1lll11lll_ll_.live/l1ll1111l111_ll_/l1ll11l1lll1_ll_.l1l11l1l1ll1_ll_.l1l11ll1l11l_ll_.2018.1080p.l1l1l11111ll_ll_-l1l1l1111ll1_ll_.l1l1ll1l1ll1_ll_.l111llll_ll_.html
	url = url.replace(l111lll_ll_ (u"ࠪࡹࡵࡨ࡯࡮࠰࡯࡭ࡻ࡫ࠧ㝰"),l111lll_ll_ (u"ࠫࡺࡶࡰࡰ࡯࠱ࡰ࡮ࡼࡥࠨ㝱"))
	url = url.split(l111lll_ll_ (u"ࠬ࠵ࠧ㝲"))
	id = url[3]
	url = l111lll_ll_ (u"࠭࠯ࠨ㝳").join(url[0:4])
	headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㝴") : l111lll_ll_ (u"ࠨࠩ㝵") , l111lll_ll_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ㝶") : l111lll_ll_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ㝷") }
	payload = { l111lll_ll_ (u"ࠫ࡮ࡪࠧ㝸") : id  , l111lll_ll_ (u"ࠬࡵࡰࠨ㝹") : l111lll_ll_ (u"࠭ࡤࡰࡹࡱࡰࡴࡧࡤ࠳ࠩ㝺") , l111lll_ll_ (u"ࠧ࡮ࡧࡷ࡬ࡴࡪ࡟ࡧࡴࡨࡩࠬ㝻"):l111lll_ll_ (u"ࠨࡈࡵࡩࡪ࠱ࡄࡰࡹࡱࡰࡴࡧࡤࠬࠧ࠶ࡉࠪ࠹ࡅࠨ㝼") }
	data = l1lll11ll_ll_(payload)
	html = l111ll1_ll_(l11111l1_ll_,url,data,headers,l111lll_ll_ (u"ࠩࠪ㝽"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡕࡑࡄࡒࡑ࠲࠷ࡳࡵࠩ㝾"))
	#l1ll1l_ll_(url,html)
	#xbmc.log(html)
	items = re.findall(l111lll_ll_ (u"ࠫࡩ࡯ࡲࡦࡥࡷࡣࡱ࡯࡮࡬࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㝿"),html,re.DOTALL)
	if items: return l111lll_ll_ (u"ࠬ࠭㞀"),[l111lll_ll_ (u"࠭ࠧ㞁")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡘࡔࡇࡕࡍࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㞂"),[],[]
def l1l1ll111l11_ll_(url):
	# l1ll1l1l_ll_://l1l1l1l1111l_ll_.l1ll1l11l1l1_ll_.l1lll1l11_ll_/012ocyw9li6g.html
	headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㞃") : l111lll_ll_ (u"ࠩࠪ㞄") }
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠪࠫ㞅"),headers,l111lll_ll_ (u"ࠫࠬ㞆"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮ࡎࡌࡍ࡛ࡏࡄࡆࡑ࠰࠵ࡸࡺࠧ㞇"))
	items = re.findall(l111lll_ll_ (u"࠭ࡳࡰࡷࡵࡧࡪࡹ࠺࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥ࠰ࠧ࠮࠮ࠫࡁࠬࠦࠬ㞈"),html,re.DOTALL)
	l1111ll_ll_,l1l111l_ll_ = [],[]
	if items:
		l1111ll_ll_.append(l111lll_ll_ (u"ࠧ࡮ࡲ࠷ࠫ㞉"))
		l1l111l_ll_.append(items[0][1])
		l1111ll_ll_.append(l111lll_ll_ (u"ࠨ࡯࠶ࡹ࠽࠭㞊"))
		l1l111l_ll_.append(items[0][0])
		return l111lll_ll_ (u"ࠩࠪ㞋"),l1111ll_ll_,l1l111l_ll_
	else: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡒࡉࡊࡘࡌࡈࡊࡕࠠࡇࡣ࡬ࡰࡪࡪࠧ㞌"),[],[]
def l1l1lll11ll_ll_(url):
	# subtitles l11ll1l1l11_ll_			url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾ࡧࡇࡰ࡟࠻ࡶࡂࡐࡔ࡙࡬࠭㞍")
	# l1l1l1l1lll1_ll_ .l1ll11ll1l11_ll_ l11ll1l1l11_ll_		url = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡸࡹ࠱ࡽࡴࡻࡴࡶࡤࡨ࠲ࡨࡵ࡭࠰ࡹࡤࡸࡨ࡮࠿ࡷ࠿࡛ࡺࡲ࡙ࡎࡂࡻࡨࡽࡋࡏࠧ㞎")
	# hls ts .l1111111_ll_ l11ll1l1l11_ll_		url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡺࡥࡹࡩࡨࡀࡸࡀࡋ࡫࠸࠭ࡏࡕࡷࡗࡸࡔࡷࠨ㞏")
	# signature l11ll1l1l11_ll_			url = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡪࡥࡓ࠺ࡘࡹࡎࡒ࠷ࡐࡊࠩ㞐")
	# l1ll1ll11l_ll_ files have l1l1ll1l111l_ll_ l1l1l111ll1l_ll_		url = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡺࡻࡼ࠴ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡰ࠳ࡼࡧࡴࡤࡪࡂࡺࡂ࠷ࡷࡅࡔࡘ࡚ࡨ࡙ࡹࡠࡓࠪ㞑")
	# url = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡽࡴࡻࡴࡶ࠰ࡥࡩ࠴࡫ࡄ࡭࡜࠸ࡺࡆࡔࡑࡖࡩࠪ㞒")
	# url = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡽ࠷ࡻ࠮ࡣࡧ࠲ࡩࡉࡲ࡚࠶ࡸࡄࡒࡖ࡛ࡧࠨ㞓")
	# url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠵ࡥࡅ࡮࡝࠹ࡻࡇࡎࡒࡗࡪࠫ㞔")
	# youtube l1ll11l11l11_ll_ details   l1ll1l1l_ll_://l1l1l1ll1lll_ll_.me/l1l1l11ll1ll_ll_/l1l11l1llll1_ll_-l1l11lllll1l_ll_-l1ll1l111l11_ll_
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋࡼࡳࡺࡺࡵࡣࡧࡌࡈࠥࡃࠠࡶࡴ࡯࠲ࡸࡶ࡬ࡪࡶࠫࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧࠪ࡝࠰࠵ࡢࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࡺࡸ࡬࠭ࡻࡲࡹࡹࡻࡢࡦࡋࡇ࠭ࠏࠏࠣࡪࡦࠣࡁࠥࡻࡲ࡭࠰ࡶࡴࡱ࡯ࡴࠩࠩ࠲ࠫ࠮ࡡ࠭࠲࡟ࠍࠍࠨࡿ࡯ࡶࡶࡸࡦࡪࡏࡄࠡ࠿ࠣ࡭ࡩ࠴ࡳࡱ࡮࡬ࡸ࠭࠭࠿ࠨࠫ࡞࠴ࡢࠐࠉࡶࡴ࡯ࠤࡂࠦࠧࡱ࡮ࡸ࡫࡮ࡴ࠺࠰࠱ࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦ࠱ࡳࡰࡦࡿ࠯ࡀࡸ࡬ࡨࡪࡵ࡟ࡪࡦࡀࠫ࠰ࡿ࡯ࡶࡶࡸࡦࡪࡏࡄࠋࠋࡵࡩࡹࡻࡲ࡯ࠢࠪࠫ࠱ࡡࠧࠨ࡟࠯࡟ࡺࡸ࡬࡞ࠌࠌࠦࠧࠨ㞕")
	id = url.split(l111lll_ll_ (u"࠭࠯ࠨ㞖"))[-1]
	id = id.replace(l111lll_ll_ (u"ࠧࡸࡣࡷࡧ࡭ࡅࡶ࠾ࠩ㞗"),l111lll_ll_ (u"ࠨࠩ㞘"))
	if l111lll_ll_ (u"ࠩࡨࡱࡧ࡫ࡤࠨ㞙") in url: url = l11l11l_ll_[l111lll_ll_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࠫ㞚")][0]+l111lll_ll_ (u"ࠫ࠴ࡽࡡࡵࡥ࡫ࡃࡻࡃࠧ㞛")+id
	#html = l111ll1_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴ࠻࠷࠸࠴࠺࠻࠯ࡴࡪࡸࡸࡩࡵࡷ࡯ࠩ㞜"),l111lll_ll_ (u"࠭ࠧ㞝"),l111lll_ll_ (u"ࠧࠨ㞞"),l111lll_ll_ (u"ࠨࠩ㞟"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲࡟ࡏࡖࡖࡘࡆࡊ࠳࠱ࡴࡶࠪ㞠"))
	l1l11l1lllll_ll_,l1l1ll1l1l1l_ll_,l1l1lll11111_ll_,l111ll1l1ll_ll_ = l111lll_ll_ (u"ࠪࠫ㞡"),l111lll_ll_ (u"ࠫࠬ㞢"),l111lll_ll_ (u"ࠬ࠭㞣"),l111lll_ll_ (u"࠭ࠧ㞤")
	#headers = {l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㞥"):l111lll_ll_ (u"ࠨࡏࡲࡾ࡮ࡲ࡬ࡢ࠱࠸࠲࠵ࠦࠨࡘ࡫ࡱࡨࡴࡽࡳࠡࡐࡗࠤ࠶࠶࠮࠱࠽࡛ࠣ࡮ࡴ࠶࠵࠽ࠣࡼ࠻࠺ࠩࠡࡃࡳࡴࡱ࡫ࡗࡦࡤࡎ࡭ࡹ࠵࠵࠴࠹࠱࠷࠻ࠦࠨࡌࡊࡗࡑࡑ࠲ࠠ࡭࡫࡮ࡩࠥࡍࡥࡤ࡭ࡲ࠭ࠥࡉࡨࡳࡱࡰࡩ࠴࠽࠶࠯࠲࠱࠷࠽࠶࠹࠯࠳࠳࠴࡙ࠥࡡࡧࡣࡵ࡭࠴࠻࠳࠸࠰࠶࠺ࠬ㞦")}
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠩࠪ㞧"),l111lll_ll_ (u"ࠪࠫ㞨"),l111lll_ll_ (u"ࠫࠬ㞩"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠵ࡲࡩ࠭㞪"))
	#xbmc.log(l111lll_ll_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨ㞫"),level=xbmc.LOGNOTICE)
	html = html.replace(l111lll_ll_ (u"ࠧ࡝࡞ࡸ࠴࠵࠸࠶ࠨ㞬"),l111lll_ll_ (u"ࠨࠨࠩࠫ㞭")).replace(l111lll_ll_ (u"ࠩ࡟ࡠࠬ㞮"),l111lll_ll_ (u"ࠪࠫ㞯"))
	#xbmc.log(html,level=xbmc.LOGNOTICE)
	#l1ll1l_ll_(str(message),html)
	#xbmc.log(l111lll_ll_ (u"ࠫࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭㞰"),level=xbmc.LOGNOTICE)
	#xbmc.log(html,level=xbmc.LOGNOTICE)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡶ࡬ࡢࡻࡨࡶࡈࡧࡰࡵ࡫ࡲࡲࡸ࡚ࡲࡢࡥ࡮ࡰ࡮ࡹࡴࡓࡧࡱࡨࡪࡸࡥࡳࠪ࠱࠮ࡄ࠯ࡤࡦࡨࡤࡹࡱࡺࡁࡶࡦ࡬ࡳ࡙ࡸࡡࡤ࡭ࡌࡲࡩ࡫ࡸࠨ㞱"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0].replace(l111lll_ll_ (u"࠭ࡵ࠱࠲࠵࠺ࠬ㞲"),l111lll_ll_ (u"ࠧࠧࠨࠪ㞳"))
		items = re.findall(l111lll_ll_ (u"ࠨࡽࠥࡰࡦࡴࡧࡶࡣࡪࡩࡈࡵࡤࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㞴"),block,re.DOTALL)
		l1111ll_ll_,l1l111l_ll_ = [l111lll_ll_ (u"ࠩหำํ์ࠠหำฯ้ฮ๊้ࠦฬํ์อ࠭㞵")],[l111lll_ll_ (u"ࠪࠫ㞶")]
		for lang,title in items:
			l1111ll_ll_.append(title)
			l1l111l_ll_.append(lang)
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠫฬิสาࠢส่ฯืฬๆหࠣห้๋ๆศีหอ࠿࠭㞷"), l1111ll_ll_)
		if selection not in [0,-1]:
			l1l11l1lllll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡨࡡࡴࡧࡘࡶࡱࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㞸"),block,re.DOTALL)
			l1l11l1lllll_ll_ = l1l11l1lllll_ll_[0]+l111lll_ll_ (u"࠭ࠦࡧ࡯ࡷࡁࡻࡺࡴࠧࡶࡼࡴࡪࡃࡴࡳࡣࡦ࡯ࠫࡺ࡬ࡢࡰࡪࡁࠬ㞹")+l1l111l_ll_[selection]
	l1111ll_ll_,l1l111l_ll_ = [],[]
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡶ࡬ࡒࡧ࡮ࡪࡨࡨࡷࡹ࡛ࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㞺"),html,re.DOTALL)
	if l1lll_ll_:
		if l111lll_ll_ (u"ࠨ࠱ࡶ࡭࡬ࡴࡡࡵࡷࡵࡩ࠴࠭㞻") in l1lll_ll_[0]: l1l1ll1l1l1l_ll_ = l1lll_ll_[0]
		else: l1l1ll1l1l1l_ll_ = l1lll_ll_[0].replace(l111lll_ll_ (u"ࠩ࠲ࡷ࠴࠭㞼"),l111lll_ll_ (u"ࠪ࠳ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࠯ࠨ㞽"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫ࡭ࡲࡳࡎࡣࡱ࡭࡫࡫ࡳࡵࡗࡵࡰࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㞾"),html,re.DOTALL)
	if l1lll_ll_:
		l1l1lll11111_ll_ = l1lll_ll_[0]
		#l1l111l1_ll_ = l111ll1_ll_(l11111l1_ll_,l1l1lll11111_ll_,l111lll_ll_ (u"ࠬ࠭㞿"),l111lll_ll_ (u"࠭ࠧ㟀"),l111lll_ll_ (u"ࠧࠨ㟁"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡞ࡕࡕࡕࡗࡅࡉ࠲࠹ࡲࡥࠩ㟂"))
		#items = re.findall(l111lll_ll_ (u"࡛ࠩ࠱ࡒࡋࡄࡊࡃ࠽࡙ࡗࡏ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠭ࡖ࡜ࡔࡊࡃࡓࡖࡄࡗࡍ࡙ࡒࡅࡔ࠮ࡊࡖࡔ࡛ࡐ࠮ࡋࡇࡁࠧࡼࡴࡵࠩ㟃"),l1l111l1_ll_,re.DOTALL)
		#if items: l1l11l1lllll_ll_ = items[0]#+l111lll_ll_ (u"ࠪࠪ࡫ࡳࡴ࠾ࡸࡷࡸࠫࡺࡹࡱࡧࡀࡸࡷࡧࡣ࡬ࠨࡷࡰࡦࡴࡧ࠾ࠩ㟄")
	l1lll1l_ll_,l1l1l111l11l_ll_,l1ll11l1ll1l_ll_ = [],[],{}
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡺࡸ࡬ࡠࡧࡱࡧࡴࡪࡥࡥࡡࡩࡱࡹࡥࡳࡵࡴࡨࡥࡲࡥ࡭ࡢࡲࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦࠬ㟅"),html,re.DOTALL)
	if l1lll_ll_: l1lll1l_ll_.append(l1lll_ll_[0])
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡧࡤࡢࡲࡷ࡭ࡻ࡫࡟ࡧ࡯ࡷࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㟆"),html,re.DOTALL)
	if l1lll_ll_: l1lll1l_ll_.append(l1lll_ll_[0])
	if l1lll1l_ll_:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡦ࡮ࡶࡢࡰ࡮ࡹࡴࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㟇"),html,re.DOTALL)
		if l1lll_ll_ and l1lll_ll_!=[l111lll_ll_ (u"ࠧࠨ㟈")]:
			fmt_list = l1lll_ll_[0]
			l1ll111l1l11_ll_ = fmt_list.split(l111lll_ll_ (u"ࠨ࠮ࠪ㟉"))
			for item in l1ll111l1l11_ll_:
				#l1ll1l_ll_(str(l1lll_ll_),item)
				itag,size = item.split(l111lll_ll_ (u"ࠩ࠲ࠫ㟊"))
				l1ll11l1ll1l_ll_[itag] = size
	#l1ll1l_ll_(str(len(l1lll1l_ll_)),l111lll_ll_ (u"ࠪࠫ㟋"))
	for block in l1lll1l_ll_:
		if block==l111lll_ll_ (u"ࠫࠬ㟌"): continue
		lines = block.split(l111lll_ll_ (u"ࠬ࠲ࠧ㟍"))
		for line in lines:
			#xbmc.log(l111lll_ll_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨ㟎"),level=xbmc.LOGNOTICE)
			#xbmc.log(line,level=xbmc.LOGNOTICE)
			line = l1111_ll_(line)
			dict = {}
			items = line.split(l111lll_ll_ (u"ࠧࠧࠨࠪ㟏"))
			for item in items:
				key,value = item.split(l111lll_ll_ (u"ࠨ࠿ࠪ㟐"),1)
				dict[key] = value
			if l111lll_ll_ (u"ࠩࡶ࡭ࡿ࡫ࠧ㟑") not in dict.keys() and dict[l111lll_ll_ (u"ࠪ࡭ࡹࡧࡧࠨ㟒")] in l1ll11l1ll1l_ll_.keys():
				#l1ll1l_ll_(l1ll11l1ll1l_ll_[dict[l111lll_ll_ (u"ࠫ࡮ࡺࡡࡨࠩ㟓")]],l111lll_ll_ (u"ࠬ࠭㟔"))
				dict[l111lll_ll_ (u"࠭ࡳࡪࡼࡨࠫ㟕")] = l1ll11l1ll1l_ll_[dict[l111lll_ll_ (u"ࠧࡪࡶࡤ࡫ࠬ㟖")]]
			l1l1l111l11l_ll_.append(dict)
	l1lll1l_ll_,l1l1l111l1l1_ll_ = [],[]
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࠤࡩࡳࡷࡳࡡࡵࡵࠥ࠾ࡡࡡࠨ࠯ࠬࡂ࠭ࡡࡣࠧ㟗"),html,re.DOTALL)
	if l1lll_ll_: l1lll1l_ll_.append(l1lll_ll_[0])
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࠥࡥࡩࡧࡰࡵ࡫ࡹࡩࡋࡵࡲ࡮ࡣࡷࡷࠧࡀ࡜࡜ࠪ࠱࠮ࡄ࠯࡜࡞ࠩ㟘"),html,re.DOTALL)
	#l1ll1l_ll_(str(l1lll_ll_),l111lll_ll_ (u"ࠪࠫ㟙"))
	#xbmc.log(l1lll_ll_[0], level=xbmc.LOGNOTICE)
	if l1lll_ll_: l1lll1l_ll_.append(l1lll_ll_[0])
	for block in l1lll1l_ll_:
		block = block.replace(l111lll_ll_ (u"ࠫࠫࠬࠧ㟚"),l111lll_ll_ (u"ࠬࠬࠧ㟛"))
		block = block.replace(l111lll_ll_ (u"࠭࠽ࠣࠩ㟜"),l111lll_ll_ (u"ࠧ࠾ࠩ㟝")).replace(l111lll_ll_ (u"ࠨࠤࠥࠫ㟞"),l111lll_ll_ (u"ࠩࠥࠫ㟟"))
		block = block.replace(l111lll_ll_ (u"ࠪ࠾ࡹࡸࡵࡦࠩ㟠"),l111lll_ll_ (u"ࠫ࠿࡚ࡲࡶࡧࠪ㟡")).replace(l111lll_ll_ (u"ࠬࡀࡦࡢ࡮ࡶࡩࠬ㟢"),l111lll_ll_ (u"࠭࠺ࡇࡣ࡯ࡷࡪ࠭㟣"))
		if l111lll_ll_ (u"ࠧ࡜ࠩ㟤") not in block: block = l111lll_ll_ (u"ࠨ࡝ࠪ㟥")+block+l111lll_ll_ (u"ࠩࡠࠫ㟦")
		block = eval(block)
		#l1ll1l_ll_(str(type(block)),l111lll_ll_ (u"ࠪࠫ㟧"))
		#xbmc.log(str(block), level=xbmc.LOGNOTICE)
		#l1ll1l_ll_(str(block[l111lll_ll_ (u"ࠫࡺࡸ࡬ࠨ㟨")]),str(block[l111lll_ll_ (u"ࠬ࡯ࡴࡢࡩࠪ㟩")]))
		for dict in block:
			dict[l111lll_ll_ (u"࠭ࡩࡵࡣࡪࠫ㟪")] = str(dict[l111lll_ll_ (u"ࠧࡪࡶࡤ࡫ࠬ㟫")])
			dict[l111lll_ll_ (u"ࠨࡶࡼࡴࡪ࠭㟬")] = dict[l111lll_ll_ (u"ࠩࡰ࡭ࡲ࡫ࡔࡺࡲࡨࠫ㟭")].replace(l111lll_ll_ (u"ࠪࡁࠬ㟮"),l111lll_ll_ (u"ࠫࡂࠨࠧ㟯"))+l111lll_ll_ (u"ࠬࠨࠧ㟰")
			if l111lll_ll_ (u"࠭ࡦࡱࡵࠪ㟱") in dict.keys(): dict[l111lll_ll_ (u"ࠧࡧࡲࡶࠫ㟲")] = str(dict[l111lll_ll_ (u"ࠨࡨࡳࡷࠬ㟳")])
			if l111lll_ll_ (u"ࠩࡤࡹࡩ࡯࡯ࡔࡣࡰࡴࡱ࡫ࡒࡢࡶࡨࠫ㟴") in dict.keys(): dict[l111lll_ll_ (u"ࠪࡥࡺࡪࡩࡰࡡࡶࡥࡲࡶ࡬ࡦࡡࡵࡥࡹ࡫ࠧ㟵")] = str(dict[l111lll_ll_ (u"ࠫࡦࡻࡤࡪࡱࡖࡥࡲࡶ࡬ࡦࡔࡤࡸࡪ࠭㟶")])
			if l111lll_ll_ (u"ࠬࡧࡵࡥ࡫ࡲࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ㟷") in dict.keys(): dict[l111lll_ll_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ㟸")] = str(dict[l111lll_ll_ (u"ࠧࡢࡷࡧ࡭ࡴࡉࡨࡢࡰࡱࡩࡱࡹࠧ㟹")])
			if l111lll_ll_ (u"ࠨࡹ࡬ࡨࡹ࡮ࠧ㟺") in dict.keys(): dict[l111lll_ll_ (u"ࠩࡶ࡭ࡿ࡫ࠧ㟻")] = str(dict[l111lll_ll_ (u"ࠪࡻ࡮ࡪࡴࡩࠩ㟼")])+l111lll_ll_ (u"ࠫࡽ࠭㟽")+str(dict[l111lll_ll_ (u"ࠬ࡮ࡥࡪࡩ࡫ࡸࠬ㟾")])
			if l111lll_ll_ (u"࠭ࡩ࡯࡫ࡷࡖࡦࡴࡧࡦࠩ㟿") in dict.keys(): dict[l111lll_ll_ (u"ࠧࡪࡰ࡬ࡸࠬ㠀")] = dict[l111lll_ll_ (u"ࠨ࡫ࡱ࡭ࡹࡘࡡ࡯ࡩࡨࠫ㠁")][l111lll_ll_ (u"ࠩࡶࡸࡦࡸࡴࠨ㠂")]+l111lll_ll_ (u"ࠪ࠱ࠬ㠃")+dict[l111lll_ll_ (u"ࠫ࡮ࡴࡩࡵࡔࡤࡲ࡬࡫ࠧ㠄")][l111lll_ll_ (u"ࠬ࡫࡮ࡥࠩ㠅")]
			if l111lll_ll_ (u"࠭ࡩ࡯ࡦࡨࡼࡗࡧ࡮ࡨࡧࠪ㠆") in dict.keys(): dict[l111lll_ll_ (u"ࠧࡪࡰࡧࡩࡽ࠭㠇")] = dict[l111lll_ll_ (u"ࠨ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࠬ㠈")][l111lll_ll_ (u"ࠩࡶࡸࡦࡸࡴࠨ㠉")]+l111lll_ll_ (u"ࠪ࠱ࠬ㠊")+dict[l111lll_ll_ (u"ࠫ࡮ࡴࡤࡦࡺࡕࡥࡳ࡭ࡥࠨ㠋")][l111lll_ll_ (u"ࠬ࡫࡮ࡥࠩ㠌")]
			if l111lll_ll_ (u"࠭ࡡࡷࡧࡵࡥ࡬࡫ࡂࡪࡶࡵࡥࡹ࡫ࠧ㠍") in dict.keys(): dict[l111lll_ll_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㠎")] = dict[l111lll_ll_ (u"ࠨࡣࡹࡩࡷࡧࡧࡦࡄ࡬ࡸࡷࡧࡴࡦࠩ㠏")]
			if l111lll_ll_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㠐") in dict.keys() and dict[l111lll_ll_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㠑")]>111222333: del dict[l111lll_ll_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㠒")]
			if l111lll_ll_ (u"ࠬࡹࡩࡨࡰࡤࡸࡺࡸࡥࡄ࡫ࡳ࡬ࡪࡸࠧ㠓") in dict.keys():
				cipher = dict[l111lll_ll_ (u"࠭ࡳࡪࡩࡱࡥࡹࡻࡲࡦࡅ࡬ࡴ࡭࡫ࡲࠨ㠔")].split(l111lll_ll_ (u"ࠧࠧࠩ㠕"))
				for item in cipher:
					key,value = item.split(l111lll_ll_ (u"ࠨ࠿ࠪ㠖"),1)
					dict[key] = l1111_ll_(value)
			#if l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㠗") in dict.keys(): dict[l111lll_ll_ (u"ࠪࡹࡷࡲࠧ㠘")] = l1111_ll_(dict[l111lll_ll_ (u"ࠫࡺࡸ࡬ࠨ㠙")])
			l1l1l111l1l1_ll_.append(dict)
	url_list,l1l11lll11ll_ll_,l1l11lll1l11_ll_,l1l11lll11l1_ll_ = [],[],[],[]
	if l1l1l111l11l_ll_ and l1l1l111l1l1_ll_:
		for l111l11lll_ll_ in l1l1l111l11l_ll_:
			url1 = l111l11lll_ll_[l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩ㠚")][:300]
			#url1 = l1111_ll_(l1111_ll_(l111l11lll_ll_[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪ㠛")]))[:300]
			for l111l11l1l_ll_ in l1l1l111l1l1_ll_:
				l1ll111_ll_ = l111l11l1l_ll_[l111lll_ll_ (u"ࠧࡶࡴ࡯ࠫ㠜")][:300]
				#l1ll111_ll_ = l1111_ll_(l1111_ll_(l111l11l1l_ll_[l111lll_ll_ (u"ࠨࡷࡵࡰࠬ㠝")]))[:300]
				if url1==l1ll111_ll_ and url1 not in url_list:
					url_list.append(url1)
					l111l11lll_ll_.update(l111l11l1l_ll_)
					l1l11lll11ll_ll_.append(l111l11lll_ll_)
	else: l1l11lll11ll_ll_ = l1l1l111l11l_ll_+l1l1l111l1l1_ll_
	l1l11llll11l_ll_ = l111lll_ll_ (u"ࠩࠪ㠞")
	#xbmc.log(str(l1l1l111l11l_ll_),level=xbmc.LOGNOTICE)
	#xbmc.log(str(l1l1l111l1l1_ll_),level=xbmc.LOGNOTICE)
	#xbmc.log(str(l1l11lll11ll_ll_),level=xbmc.LOGNOTICE)
	if l111lll_ll_ (u"ࠪࡷࡵࡃࡳࡪࡩࠪ㠟") in html:
		#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡨ࡯ࡰࡩࡧࡵࠫ㠠"),str(html))
		#l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹࡲࡤ࠿ࠥࠬ࠴ࡿࡴࡴ࠱࡭ࡷࡧ࡯࡮࠰ࡲ࡯ࡥࡾ࡫ࡲࡠ࠰࠭ࡃ࠮ࠨࠧ㠡"),html,re.DOTALL)
		# /s/player/6dde7fb4/l1l1llllllll_ll_.l1ll11l111l1_ll_/l1ll11111ll1_ll_/base.js
		# /s/player/6dde7fb4/l1l1llllllll_ll_.l1ll11l111l1_ll_/l1l1l1ll111l_ll_/base.js
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠵ࡳ࠰ࡲ࡯ࡥࡾ࡫ࡲ࠰࡞ࡺ࠮ࡄ࠵ࡰ࡭ࡣࡼࡩࡷࡥࡩࡢࡵ࠱ࡺ࡫ࡲࡳࡦࡶ࠲ࡩࡳࡥ࠮࠯࠱ࡥࡥࡸ࡫࠮࡫ࡵࠬࠦࠬ㠢"),html,re.DOTALL)
		if l1lll_ll_:
			#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡣࡣࡶࡩ࠳ࡰࡳࠨ㠣"),str(l1lll_ll_))
			l1l1ll1111l1_ll_ = l11l11l_ll_[l111lll_ll_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ㠤")][0]+l1lll_ll_[0]
			l1l11llll11l_ll_ = l111ll1_ll_(l11111l1_ll_,l1l1ll1111l1_ll_,l111lll_ll_ (u"ࠩࠪ㠥"),l111lll_ll_ (u"ࠪࠫ㠦"),l111lll_ll_ (u"ࠫࠬ㠧"),l111lll_ll_ (u"ࠬࡘࡅࡔࡑࡏ࡚ࡊࡘࡓ࠮࡛ࡒ࡙࡙࡛ࡂࡆ࠯࠶ࡶࡩ࠭㠨"))
			import youtube_signature.cipher
			import youtube_signature.l1l1lll1l111_ll_
			cipher = youtube_signature.cipher.Cipher()
			cipher._1l1ll1111ll_ll_ = {}
			#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧ㠩"),l1l11llll11l_ll_)
			l1ll111111ll_ll_ = cipher._1ll1l1l1111_ll_(l1l11llll11l_ll_)
			l1l11l1l1l1l_ll_ = str(l1ll111111ll_ll_)
			#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ㠪"),l1l11llll11l_ll_)
	for dict in l1l11lll11ll_ll_:
		#xbmc.log(str(dict),level=xbmc.LOGNOTICE)
		url = dict[l111lll_ll_ (u"ࠨࡷࡵࡰࠬ㠫")]
		if l111lll_ll_ (u"ࠩࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡂ࠭㠬") in url or url.count(l111lll_ll_ (u"ࠪࡷ࡮࡭࠽ࠨ㠭"))>1: l1l11lll1l11_ll_.append(dict)
		elif l1l11llll11l_ll_!=l111lll_ll_ (u"ࠫࠬ㠮") and l111lll_ll_ (u"ࠬࡹࠧ㠯") in dict.keys() and l111lll_ll_ (u"࠭ࡳࡱࠩ㠰") in dict.keys():
			l1ll111111ll_ll_ = eval(l1l11l1l1l1l_ll_)
			l1l1lll1l111_ll_ = youtube_signature.l1l1lll1l111_ll_.l1ll11l1l1ll_ll_(l1ll111111ll_ll_)
			signature = l1l1lll1l111_ll_.execute(dict[l111lll_ll_ (u"ࠧࡴࠩ㠱")])
			#xbmc.log(l111lll_ll_ (u"ࠨࡇࡐࡅࡉ࠿࠹࠺࠻ࠪ㠲")+signature,level=xbmc.LOGNOTICE)
			#xbmc.log(l111lll_ll_ (u"ࠩࡈࡑࡆࡊ࠹࠺࠻࠼ࠫ㠳")+dict[l111lll_ll_ (u"ࠪࡷࠬ㠴")],level=xbmc.LOGNOTICE)
			if signature!=dict[l111lll_ll_ (u"ࠫࡸ࠭㠵")]:
				dict[l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩ㠶")] = url+l111lll_ll_ (u"࠭ࠦࠨ㠷")+dict[l111lll_ll_ (u"ࠧࡴࡲࠪ㠸")]+l111lll_ll_ (u"ࠨ࠿ࠪ㠹")+signature
				l1l11lll1l11_ll_.append(dict)
	for dict in l1l11lll1l11_ll_:
		filetype,codec,l1ll111l11l1_ll_,l1111111l1l_ll_,codecs,bitrate = l111lll_ll_ (u"ࠩࡸࡲࡰࡴ࡯ࡸࡰࠪ㠺"),l111lll_ll_ (u"ࠪࡹࡳࡱ࡮ࡰࡹࡱࠫ㠻"),l111lll_ll_ (u"ࠫࡺࡴ࡫࡯ࡱࡺࡲࠬ㠼"),l111lll_ll_ (u"࡛ࠬ࡮࡬ࡰࡲࡻࡳ࠭㠽"),l111lll_ll_ (u"࠭ࠧ㠾"),0
		try:
			l1l11lll1ll1_ll_ = dict[l111lll_ll_ (u"ࠧࡵࡻࡳࡩࠬ㠿")]
			#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㡀"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤ࡚ࠥࡹࡱࡧ࠽࡟ࠬ㡁")+l1l11lll1ll1_ll_+l111lll_ll_ (u"ࠪࡡࠬ㡂"))
			l1l11lll1ll1_ll_ = l1l11lll1ll1_ll_.replace(l111lll_ll_ (u"ࠫ࠰࠭㡃"),l111lll_ll_ (u"ࠬ࠭㡄"))
			items = re.findall(l111lll_ll_ (u"࠭ࠨ࠯ࠬࡂ࠭࠴࠮࠮ࠫࡁࠬ࠿࠳࠰࠿ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㡅"),l1l11lll1ll1_ll_,re.DOTALL)
			l1111111l1l_ll_,filetype,codecs = items[0]
			l1ll1111ll1l_ll_ = codecs.split(l111lll_ll_ (u"ࠧ࠭ࠩ㡆"))
			codec = l111lll_ll_ (u"ࠨࠩ㡇")
			for item in l1ll1111ll1l_ll_: codec += item.split(l111lll_ll_ (u"ࠩ࠱ࠫ㡈"))[0]+l111lll_ll_ (u"ࠪ࠰ࠬ㡉")
			codec = codec.strip(l111lll_ll_ (u"ࠫ࠱࠭㡊"))
			if l111lll_ll_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭㡋") in dict.keys(): bitrate = str(int(dict[l111lll_ll_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㡌")])/1024)+l111lll_ll_ (u"ࠧ࡬ࡤࡳࡷࠥࠦࠧ㡍")
			else: bitrate = l111lll_ll_ (u"ࠨࠩ㡎")
			if l1111111l1l_ll_==l111lll_ll_ (u"ࠩࡷࡩࡽࡺࠧ㡏"): continue
			elif l111lll_ll_ (u"ࠪ࠰ࠬ㡐") in l1l11lll1ll1_ll_:
				l1111111l1l_ll_ = l111lll_ll_ (u"ࠫࡆ࠱ࡖࠨ㡑")
				l1ll111l11l1_ll_ = filetype+l111lll_ll_ (u"ࠬࠦࠠࠨ㡒")+bitrate+dict[l111lll_ll_ (u"࠭ࡳࡪࡼࡨࠫ㡓")].split(l111lll_ll_ (u"ࠧࡹࠩ㡔"))[1]
			elif l1111111l1l_ll_==l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㡕"):
				l1111111l1l_ll_ = l111lll_ll_ (u"࡙ࠩ࡭ࡩ࡫࡯ࠨ㡖")
				l1ll111l11l1_ll_ = bitrate+dict[l111lll_ll_ (u"ࠪࡷ࡮ࢀࡥࠨ㡗")].split(l111lll_ll_ (u"ࠫࡽ࠭㡘"))[1]+l111lll_ll_ (u"ࠬࠦࠠࠨ㡙")+dict[l111lll_ll_ (u"࠭ࡦࡱࡵࠪ㡚")]+l111lll_ll_ (u"ࠧࡧࡲࡶࠫ㡛")+l111lll_ll_ (u"ࠨࠢࠣࠫ㡜")+filetype
			elif l1111111l1l_ll_==l111lll_ll_ (u"ࠩࡤࡹࡩ࡯࡯ࠨ㡝"):
				l1111111l1l_ll_ = l111lll_ll_ (u"ࠪࡅࡺࡪࡩࡰࠩ㡞")
				l1ll111l11l1_ll_ = bitrate+str(int(dict[l111lll_ll_ (u"ࠫࡦࡻࡤࡪࡱࡢࡷࡦࡳࡰ࡭ࡧࡢࡶࡦࡺࡥࠨ㡟")])/1000)+l111lll_ll_ (u"ࠬࡱࡨࡻࠢࠣࠫ㡠")+dict[l111lll_ll_ (u"࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ㡡")]+l111lll_ll_ (u"ࠧࡤࡪࠪ㡢")+l111lll_ll_ (u"ࠨࠢࠣࠫ㡣")+filetype
		except:
			l1l11l1lll1_ll_ = traceback.format_exc()
			sys.stderr.write(l1l11l1lll1_ll_)
			#pass
		if l111lll_ll_ (u"ࠩࡧࡹࡷࡃࠧ㡤") in dict[l111lll_ll_ (u"ࠪࡹࡷࡲࠧ㡥")]: duration = round(0.5+float(dict[l111lll_ll_ (u"ࠫࡺࡸ࡬ࠨ㡦")].split(l111lll_ll_ (u"ࠬࡪࡵࡳ࠿ࠪ㡧"),1)[1].split(l111lll_ll_ (u"࠭ࠦࠨ㡨"),1)[0]))
		elif l111lll_ll_ (u"ࠧࡢࡲࡳࡶࡴࡾࡄࡶࡴࡤࡸ࡮ࡵ࡮ࡎࡵࠪ㡩") in dict.keys(): duration = round(0.5+float(dict[l111lll_ll_ (u"ࠨࡣࡳࡴࡷࡵࡸࡅࡷࡵࡥࡹ࡯࡯࡯ࡏࡶࠫ㡪")])/1000)
		else: duration = l111lll_ll_ (u"ࠩ࠳ࠫ㡫")
		if l111lll_ll_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㡬") not in dict.keys(): bitrate = int(dict[l111lll_ll_ (u"ࠫࡸ࡯ࡺࡦࠩ㡭")].split(l111lll_ll_ (u"ࠬࡾࠧ㡮"))[1])
		else: bitrate = int(dict[l111lll_ll_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㡯")])
		if l111lll_ll_ (u"ࠧࡪࡰ࡬ࡸࠬ㡰") not in dict.keys(): dict[l111lll_ll_ (u"ࠨ࡫ࡱ࡭ࡹ࠭㡱")] = l111lll_ll_ (u"ࠩ࠳࠱࠵࠭㡲")
		dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㡳")] = l1111111l1l_ll_+l111lll_ll_ (u"ࠫ࠿ࠦࠠࠨ㡴")+l1ll111l11l1_ll_+l111lll_ll_ (u"ࠬࠦࠠࠩࠩ㡵")+codec+l111lll_ll_ (u"࠭ࠬࠨ㡶")+dict[l111lll_ll_ (u"ࠧࡪࡶࡤ࡫ࠬ㡷")]+l111lll_ll_ (u"ࠨࠫࠪ㡸")
		dict[l111lll_ll_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ㡹")] = l1ll111l11l1_ll_.split(l111lll_ll_ (u"ࠪࠤࠬ㡺"))[0].split(l111lll_ll_ (u"ࠫࡰࡨࡰࡴࠩ㡻"))[0]
		dict[l111lll_ll_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㡼")] = l1111111l1l_ll_
		dict[l111lll_ll_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ㡽")] = filetype
		dict[l111lll_ll_ (u"ࠧࡤࡱࡧࡩࡨࡹࠧ㡾")] = codecs
		dict[l111lll_ll_ (u"ࠨࡦࡸࡶࡦࡺࡩࡰࡰࠪ㡿")] = duration
		dict[l111lll_ll_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㢀")] = bitrate
		l1l11lll11l1_ll_.append(dict)
	l1l1lllll1ll_ll_,l1l1ll111l1l_ll_,l1ll11ll1lll_ll_,l1ll11lllll1_ll_,l1l11l11lll1_ll_ = [],[],[],[],[]
	l1ll1111llll_ll_,l1l1l1111l1l_ll_,l1l1l11l1111_ll_,l1ll1111ll11_ll_,l1l11ll11l11_ll_ = [],[],[],[],[]
	if l1l1ll1l1l1l_ll_!=l111lll_ll_ (u"ࠪࠫ㢁"):
		dict = {}
		dict[l111lll_ll_ (u"ࠫࡹࡿࡰࡦ࠴ࠪ㢂")] = l111lll_ll_ (u"ࠬࡇࠫࡗࠩ㢃")
		dict[l111lll_ll_ (u"࠭ࡦࡪ࡮ࡨࡸࡾࡶࡥࠨ㢄")] = l111lll_ll_ (u"ࠧ࡮ࡲࡧࠫ㢅")
		dict[l111lll_ll_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧ㢆")] = dict[l111lll_ll_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㢇")]+l111lll_ll_ (u"ࠪ࠾ࠥࠦࠧ㢈")+dict[l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㢉")]+l111lll_ll_ (u"ࠬࠦࠠࠨ㢊")+l111lll_ll_ (u"࠭ฯใหࠣหํะ่ๆษอ๎่๐ษࠨ㢋")
		dict[l111lll_ll_ (u"ࠧࡶࡴ࡯ࠫ㢌")] = l1l1ll1l1l1l_ll_
		dict[l111lll_ll_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㢍")] = l111lll_ll_ (u"ࠩ࠳ࠫ㢎") # for l1llllll11_ll_ l1l1ll1l1l1l_ll_ any number will l1ll1l11lll1_ll_ l1l11ll1ll11_ll_ sort order
		dict[l111lll_ll_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㢏")] = 20
		l1l11lll11l1_ll_.append(dict)
	if l1l1lll11111_ll_!=l111lll_ll_ (u"ࠫࠬ㢐"):
		l1l11l11llll_ll_,l1l1l1l1ll1l_ll_ = l11l1l1l_ll_(l1l1lll11111_ll_)
		l1l1ll1lll1l_ll_ = zip(l1l11l11llll_ll_,l1l1l1l1ll1l_ll_)
		for title,link in l1l1ll1lll1l_ll_:
			dict = {}
			dict[l111lll_ll_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㢑")] = l111lll_ll_ (u"࠭ࡁࠬࡘࠪ㢒")
			dict[l111lll_ll_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㢓")] = l111lll_ll_ (u"ࠨ࡯࠶ࡹ࠽࠭㢔")
			dict[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㢕")] = link
			#if l111lll_ll_ (u"ࠪࡆ࡜ࡀࠠࠨ㢖") in title: dict[l111lll_ll_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㢗")] = title.split(l111lll_ll_ (u"ࠬࠦࠧ㢘"))[1].split(l111lll_ll_ (u"࠭࡫ࡣࡲࡶࠫ㢙"))[0]
			#if l111lll_ll_ (u"ࠧࡓࡧࡶ࠾ࠥ࠭㢚") in title: dict[l111lll_ll_ (u"ࠨࡳࡸࡥࡱ࡯ࡴࡺࠩ㢛")] = title.split(l111lll_ll_ (u"ࠩࡕࡩࡸࡀࠠࠨ㢜"))[1]
			if l111lll_ll_ (u"ࠪ࡯ࡧࡶࡳࠨ㢝") in title: dict[l111lll_ll_ (u"ࠫࡧ࡯ࡴࡳࡣࡷࡩࠬ㢞")] = title.split(l111lll_ll_ (u"ࠬࡱࡢࡱࡵࠪ㢟"))[0].rsplit(l111lll_ll_ (u"࠭ࠠࠨ㢠"))[-1]
			else: dict[l111lll_ll_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㢡")] = 10
			quality = title.rsplit(l111lll_ll_ (u"ࠨࠢࠪ㢢"))[-1]
			if quality.isdigit(): dict[l111lll_ll_ (u"ࠩࡴࡹࡦࡲࡩࡵࡻࠪ㢣")] = quality
			else: dict[l111lll_ll_ (u"ࠪࡵࡺࡧ࡬ࡪࡶࡼࠫ㢤")] = l111lll_ll_ (u"ࠫ࠵࠶࠰࠱ࠩ㢥")
			if title==l111lll_ll_ (u"ࠬ࠳࠱ࠨ㢦"): dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㢧")] = dict[l111lll_ll_ (u"ࠧࡵࡻࡳࡩ࠷࠭㢨")]+l111lll_ll_ (u"ࠨ࠼ࠣࠤࠬ㢩")+dict[l111lll_ll_ (u"ࠩࡩ࡭ࡱ࡫ࡴࡺࡲࡨࠫ㢪")]+l111lll_ll_ (u"ࠪࠤࠥ࠭㢫")+l111lll_ll_ (u"ࠫิ่ษࠡษ๋ฮํ๋วห์ๆ๎ฮ࠭㢬")
			else: dict[l111lll_ll_ (u"ࠬࡺࡩࡵ࡮ࡨࠫ㢭")] = dict[l111lll_ll_ (u"࠭ࡴࡺࡲࡨ࠶ࠬ㢮")]+l111lll_ll_ (u"ࠧ࠻ࠢࠣࠫ㢯")+dict[l111lll_ll_ (u"ࠨࡨ࡬ࡰࡪࡺࡹࡱࡧࠪ㢰")]+l111lll_ll_ (u"ࠩࠣࠤࠬ㢱")+dict[l111lll_ll_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㢲")]+l111lll_ll_ (u"ࠫࡰࡨࡰࡴࠢࠣࠫ㢳")+dict[l111lll_ll_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭㢴")]
			l1l11lll11l1_ll_.append(dict)
	l1l11lll11l1_ll_ = sorted(l1l11lll11l1_ll_, reverse=True, key=lambda key: int(key[l111lll_ll_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㢵")]))
	if not l1l11lll11l1_ll_:
		l111111l1l1_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡶࡷࡦ࡭ࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ㢶"),html,re.DOTALL)
		l111111lll1_ll_ = re.findall(l111lll_ll_ (u"ࠨࠤࡳࡰࡦࡿࡥࡳࡇࡵࡶࡴࡸࡍࡦࡵࡶࡥ࡬࡫ࡒࡦࡰࡧࡩࡷ࡫ࡲࠣ࠼࡟ࡿࠧࡹࡵࡣࡴࡨࡥࡸࡵ࡮ࠣ࠼࡟ࡿࠧࡸࡵ࡯ࡵࠥ࠾ࡡࡡ࡜ࡼࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㢷"),html,re.DOTALL)
		l1l1llll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࠥࡴࡱࡧࡹࡦࡴࡈࡶࡷࡵࡲࡎࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠤ࠽ࡠࢀࠨࡲࡦࡣࡶࡳࡳࠨ࠺ࡼࠤࡶ࡭ࡲࡶ࡬ࡦࡖࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ㢸"),html,re.DOTALL)
		if l111111l1l1_ll_ or l111111lll1_ll_ or l1l1llll1lll_ll_:
			if l111111l1l1_ll_: message = l111111l1l1_ll_[0]
			elif l111111lll1_ll_: message = l111111lll1_ll_[0]
			elif l1l1llll1lll_ll_: message = l1l1llll1lll_ll_[0]
			l1ll1l11111l_ll_ = message.replace(l111lll_ll_ (u"ࠪࡠࡳ࠭㢹"),l111lll_ll_ (u"ࠫࠬ㢺")).strip(l111lll_ll_ (u"ࠬࠦࠧ㢻"))
			l1ll11llllll_ll_ = l111lll_ll_ (u"࠭็ัษࠣห้็๊ะ์๋ࠤๆ๐็ࠡ็ื็้ฯ้ࠠไาࠤ๏้่็ࠢ฽๎ึࠦๅๅษษ้๊ࠥศฺุࠣห้๋ำหะา้๏์ࠠฤ๊ࠣ฾๏ืࠠๆฬ๋ๅึࠦวๅฤ้ࠫ㢼")
			l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊๎โฺ๋ࠢห้๋ศา็ฯࠫ㢽"),l1ll1l11111l_ll_,l1ll11llllll_ll_)
			return l111lll_ll_ (u"ࠨࡇࡵࡶࡴࡸ࠺ࠡࡔࡨࡷࡴࡲࡶࡦࡴࠣ࡝ࡔ࡛ࡔࡖࡄࡈࠤࡋࡧࡩ࡭ࡧࡧ࠾ࠥ࠭㢾")+l1ll1l11111l_ll_,[],[]
		else: return l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤ࡞ࡕࡕࡕࡗࡅࡉࠥࡌࡡࡪ࡮ࡨࡨࠬ㢿"),[],[]
	l1ll1l1111ll_ll_,l1l11ll1l1l1_ll_,l1ll1l111l1l_ll_ = [],[],[]
	for dict in l1l11lll11l1_ll_:
		#l1ll1l_ll_(dict[l111lll_ll_ (u"ࠪࡧࡴࡪࡥࡤࡵࠪ㣀")],l111lll_ll_ (u"ࠫࠬ㣁"))
		if dict[l111lll_ll_ (u"ࠬࡺࡹࡱࡧ࠵ࠫ㣂")]==l111lll_ll_ (u"࠭ࡖࡪࡦࡨࡳࠬ㣃"):
			l1l1lllll1ll_ll_.append(dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㣄")])
			l1ll1111llll_ll_.append(dict)
		elif dict[l111lll_ll_ (u"ࠨࡶࡼࡴࡪ࠸ࠧ㣅")]==l111lll_ll_ (u"ࠩࡄࡹࡩ࡯࡯ࠨ㣆"):
			l1l1ll111l1l_ll_.append(dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ㣇")])
			l1l1l1111l1l_ll_.append(dict)
		elif dict[l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㣈")]==l111lll_ll_ (u"ࠬࡳࡰࡥࠩ㣉"):
			title = dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㣊")].replace(l111lll_ll_ (u"ࠧࡂ࡙࠭࠾ࠥࠦࠧ㣋"),l111lll_ll_ (u"ࠨࠩ㣌"))
			if l111lll_ll_ (u"ࠩࡥ࡭ࡹࡸࡡࡵࡧࠪ㣍") not in dict.keys(): bitrate = 0
			else: bitrate = dict[l111lll_ll_ (u"ࠪࡦ࡮ࡺࡲࡢࡶࡨࠫ㣎")]
			l1ll1l1111ll_ll_.append([dict,{},title,bitrate])
		else:
			title = dict[l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㣏")].replace(l111lll_ll_ (u"ࠬࡇࠫࡗ࠼ࠣࠤࠬ㣐"),l111lll_ll_ (u"࠭ࠧ㣑"))
			if l111lll_ll_ (u"ࠧࡣ࡫ࡷࡶࡦࡺࡥࠨ㣒") not in dict.keys(): bitrate = 0
			else: bitrate = dict[l111lll_ll_ (u"ࠨࡤ࡬ࡸࡷࡧࡴࡦࠩ㣓")]
			l1ll1l1111ll_ll_.append([dict,{},title,bitrate])
			l1ll11ll1lll_ll_.append(title)
			l1l1l11l1111_ll_.append(dict)
		l1l1lll1l11l_ll_ = True
		if l111lll_ll_ (u"ࠩࡦࡳࡩ࡫ࡣࡴࠩ㣔") in dict.keys():
			if l111lll_ll_ (u"ࠪࡥࡻ࠶ࠧ㣕") in dict[l111lll_ll_ (u"ࠫࡨࡵࡤࡦࡥࡶࠫ㣖")]: l1l1lll1l11l_ll_ = False
			elif l1ll1l111l1_ll_<18:
				if l111lll_ll_ (u"ࠬࡧࡶࡤࠩ㣗") not in dict[l111lll_ll_ (u"࠭ࡣࡰࡦࡨࡧࡸ࠭㣘")] and l111lll_ll_ (u"ࠧ࡮ࡲ࠷ࡥࠬ㣙") not in dict[l111lll_ll_ (u"ࠨࡥࡲࡨࡪࡩࡳࠨ㣚")]: l1l1lll1l11l_ll_ = False
		if dict[l111lll_ll_ (u"ࠩࡷࡽࡵ࡫࠲ࠨ㣛")]==l111lll_ll_ (u"࡚ࠪ࡮ࡪࡥࡰࠩ㣜") and dict[l111lll_ll_ (u"ࠫ࡮ࡴࡩࡵࠩ㣝")]!=l111lll_ll_ (u"ࠬ࠶࠭࠱ࠩ㣞") and l1l1lll1l11l_ll_==True:
			l1l11l11lll1_ll_.append(dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬ㣟")])
			l1l11ll11l11_ll_.append(dict)
		elif dict[l111lll_ll_ (u"ࠧࡵࡻࡳࡩ࠷࠭㣠")]==l111lll_ll_ (u"ࠨࡃࡸࡨ࡮ࡵࠧ㣡") and dict[l111lll_ll_ (u"ࠩ࡬ࡲ࡮ࡺࠧ㣢")]!=l111lll_ll_ (u"ࠪ࠴࠲࠶ࠧ㣣") and l1l1lll1l11l_ll_==True:
			l1ll11lllll1_ll_.append(dict[l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪ㣤")])
			l1ll1111ll11_ll_.append(dict)
	for l1l1ll1l1l11_ll_ in l1ll1111ll11_ll_:
		l1ll1l11l111_ll_ = l1l1ll1l1l11_ll_[l111lll_ll_ (u"ࠬࡨࡩࡵࡴࡤࡸࡪ࠭㣥")]
		for l1l1llll1l1l_ll_ in l1l11ll11l11_ll_:
			l1ll1l1l11l1_ll_ = l1l1llll1l1l_ll_[l111lll_ll_ (u"࠭ࡢࡪࡶࡵࡥࡹ࡫ࠧ㣦")]
			bitrate = l1ll1l1l11l1_ll_+l1ll1l11l111_ll_
			title = l1l1llll1l1l_ll_[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭㣧")].replace(l111lll_ll_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠢࠪ㣨"),l111lll_ll_ (u"ࠩࡰࡴࡩࠦࠠࠨ㣩"))
			title = title.replace(l1l1llll1l1l_ll_[l111lll_ll_ (u"ࠪࡪ࡮ࡲࡥࡵࡻࡳࡩࠬ㣪")]+l111lll_ll_ (u"ࠫࠥࠦࠧ㣫"),l111lll_ll_ (u"ࠬ࠭㣬"))
			title = title.replace(str(int(l1ll1l1l11l1_ll_/1024))+l111lll_ll_ (u"࠭࡫ࡣࡲࡶࠫ㣭"),str(int(bitrate/1024))+l111lll_ll_ (u"ࠧ࡬ࡤࡳࡷࠬ㣮"))
			title = title+l111lll_ll_ (u"ࠨࠪࠪ㣯")+l1l1ll1l1l11_ll_[l111lll_ll_ (u"ࠩࡷ࡭ࡹࡲࡥࠨ㣰")].split(l111lll_ll_ (u"ࠪࠬࠬ㣱"),1)[1]
			l1ll1l1111ll_ll_.append([l1l1llll1l1l_ll_,l1l1ll1l1l11_ll_,title,bitrate])
	l1ll1l1111ll_ll_ = sorted(l1ll1l1111ll_ll_, reverse=True, key=lambda key: int(key[3]))
	for l1l1llll1l1l_ll_,l1l1ll1l1l11_ll_,title,bitrate in l1ll1l1111ll_ll_:
		l1ll1111111l_ll_ = l1l1llll1l1l_ll_[l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㣲")]
		if l111lll_ll_ (u"ࠬ࡬ࡩ࡭ࡧࡷࡽࡵ࡫ࠧ㣳") in l1l1ll1l1l11_ll_.keys():
			l1ll1111111l_ll_ = l111lll_ll_ (u"࠭࡭ࡱࡦࠪ㣴")
			#l1ll1111111l_ll_ = l1ll1111111l_ll_+l1l1ll1l1l11_ll_[l111lll_ll_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㣵")]
		if l1ll1111111l_ll_ not in l1ll1l111l1l_ll_:
			l1ll1l111l1l_ll_.append(l1ll1111111l_ll_)
			l1l11ll1l1l1_ll_.append([l1l1llll1l1l_ll_,l1l1ll1l1l11_ll_,title,bitrate])
	#l1l11ll1l1l1_ll_ = sorted(l1l11ll1l1l1_ll_, reverse=True, key=lambda key: int(key[3]))
	l1l11l1ll1l1_ll_,l1ll111llll1_ll_,shift = [],[],0
	#if l1l1ll1l1l1l_ll_!=l111lll_ll_ (u"ࠨࠩ㣶"):
	#	l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ࠩࡰࡴࡩࠦี้ำฬࠤํ฻่หࠢาๆฮࠦว้ฬ๋้ฬะ๊ไ์ฬࠫ㣷")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠪࡨࡦࡹࡨࠨ㣸"))
	#	shift = 1
	owner = re.findall(l111lll_ll_ (u"ࠫࠧࡵࡷ࡯ࡧࡵࠦ࠿࠴ࠪࡀࠤࡷࡩࡽࡺࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡻࡲ࡭ࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ㣹"),html,re.DOTALL)
	if owner:
		shift += 1
		title = l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡐ࡙ࡑࡉࡗࡀࠠࠡࠩ㣺")+owner[0][0]+l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠨ㣻")
		link = owner[0][1]
		l1l11l1ll1l1_ll_.append(title)
		l1ll111llll1_ll_.append(link)
	for l1l1llll1l1l_ll_,l1l1ll1l1l11_ll_,title,bitrate in l1l11ll1l1l1_ll_:
		l1l11l1ll1l1_ll_.append(title) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠧࡩ࡫ࡪ࡬ࡪࡹࡴࠨ㣼"))
	if l1ll1l1111ll_ll_: l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ࠨื๋ีฮ่ࠦึ๊อࠤัฺ๋๊ࠢส่๊ะ่โำࠪ㣽")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠩࡤࡰࡱ࠭㣾"))
	if l1ll11ll1lll_ll_: l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ูࠪํืษุ๊ࠡ์ฯࠦๅฮั๋ำฮࠦวๅัๅอࠬ㣿")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠫࡲࡻࡸࡦࡦࠪ㤀"))
	if l1l11l11lll1_ll_: l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ࠬࡳࡰࡥࠢส๊ฯࠦสฯฬสีࠥีโสࠢสฺ่๎ัส๋ࠢำ็ฯࠠศๆุ์ฯ࠭㤁")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"࠭࡭ࡱࡦࠪ㤂"))
	if l1l1lllll1ll_ll_: l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ࠧึ๊ิอࠥ็โุࠢหำํ์ࠠึ๊อࠫ㤃")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㤄"))
	if l1l1ll111l1l_ll_: l1l11l1ll1l1_ll_.append(l111lll_ll_ (u"ุࠩ์ฯࠦแใูࠣฬิ๎ๆࠡื๋ีฮ࠭㤅")) ; l1ll111llll1_ll_.append(l111lll_ll_ (u"ࠪࡥࡺࡪࡩࡰࠩ㤆"))
	l1ll11llll11_ll_ = False
	while True:
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠫฬิสาࠢส่๋๎ูࠡษ็้๋อำษ࠼ࠪ㤇"), l1l11l1ll1l1_ll_)
		if selection==-1: return l111lll_ll_ (u"ࠬ࠭㤈"),[],[]
		if selection==0:
			link = l1ll111llll1_ll_[selection]
			return l111lll_ll_ (u"࠭ࡒࡆࡖࡘࡖࡓࡥࡔࡐࡡ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㤉"),[],[link]
		choice = l1ll111llll1_ll_[selection]
		l1l1llllll11_ll_ = l1l11l1ll1l1_ll_[selection]
		if choice==l111lll_ll_ (u"ࠧࡥࡣࡶ࡬ࠬ㤊"):
			l111ll1l1ll_ll_ = l1l1ll1l1l1l_ll_
			break
		elif choice in [l111lll_ll_ (u"ࠨࡣࡸࡨ࡮ࡵࠧ㤋"),l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ㤌"),l111lll_ll_ (u"ࠪࡱࡺࡾࡥࡥࠩ㤍")]:
			if choice==l111lll_ll_ (u"ࠫࡲࡻࡸࡦࡦࠪ㤎"): l1111ll_ll_,l1l1lll11l1l_ll_ = l1ll11ll1lll_ll_,l1l1l11l1111_ll_
			elif choice==l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ㤏"): l1111ll_ll_,l1l1lll11l1l_ll_ = l1l1lllll1ll_ll_,l1ll1111llll_ll_
			elif choice==l111lll_ll_ (u"࠭ࡡࡶࡦ࡬ࡳࠬ㤐"): l1111ll_ll_,l1l1lll11l1l_ll_ = l1l1ll111l1l_ll_,l1l1l1111l1l_ll_
			selection = l1l1111_ll_(l111lll_ll_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭㤑"), l1111ll_ll_)
			if selection!=-1:
				l111ll1l1ll_ll_ = l1l1lll11l1l_ll_[selection][l111lll_ll_ (u"ࠨࡷࡵࡰࠬ㤒")]
				l1l1llllll11_ll_ = l1111ll_ll_[selection]
				break
		elif choice==l111lll_ll_ (u"ࠩࡰࡴࡩ࠭㤓"):
			selection = l1l1111_ll_(l111lll_ll_ (u"ࠪหำะัࠡัๅอࠥอไึ๊ิอࠥอไๆ่สือฯ࠺ࠨ㤔"), l1l11l11lll1_ll_)
			if selection!=-1:
				l1l1llllll11_ll_ = l1l11l11lll1_ll_[selection]
				l1l11l1lll11_ll_ = l1ll1111llll_ll_[selection]
				selection = l1l1111_ll_(l111lll_ll_ (u"ࠫฬิสาࠢาๆฮࠦวๅื๋ฮࠥอไๆ่สือฯ࠺ࠨ㤕"), l1ll11lllll1_ll_)
				if selection!=-1:
					l1l1llllll11_ll_ += l111lll_ll_ (u"ࠬࠦࠫࠡࠩ㤖")+l1ll11lllll1_ll_[selection]
					l1l1lll111ll_ll_ = l1l1l1111l1l_ll_[selection]
					l1ll11llll11_ll_ = True
					break
		elif choice==l111lll_ll_ (u"࠭ࡡ࡭࡮ࠪ㤗"):
			l1l1l11ll1l1_ll_,l1l11l11l11l_ll_,l1l11llll1l1_ll_,l1ll11lll111_ll_ = zip(*l1ll1l1111ll_ll_)
			selection = l1l1111_ll_(l111lll_ll_ (u"ࠧศะอีࠥอไๆๆไࠤฬ๊ๅ็ษึฬ࠿࠭㤘"), l1l11llll1l1_ll_)
			if selection!=-1:
				l1l1llllll11_ll_ = l1l11llll1l1_ll_[selection]
				l1l11l1lll11_ll_ = l1l1l11ll1l1_ll_[selection]
				if l111lll_ll_ (u"ࠨ࡯ࡳࡨࠬ㤙") in l1l11llll1l1_ll_[selection] and l1l11l1lll11_ll_[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㤚")]!=l1l1ll1l1l1l_ll_:
					l1l1lll111ll_ll_ = l1l11l11l11l_ll_[selection]
					l1ll11llll11_ll_ = True
				else: l111ll1l1ll_ll_ = l1l11l1lll11_ll_[l111lll_ll_ (u"ࠪࡹࡷࡲࠧ㤛")]
				break
		elif choice==l111lll_ll_ (u"ࠫ࡭࡯ࡧࡩࡧࡶࡸࠬ㤜"):
			l1l1l11ll1l1_ll_,l1l11l11l11l_ll_,l1l11llll1l1_ll_,l1ll11lll111_ll_ = zip(*l1l11ll1l1l1_ll_)
			l1l11l1lll11_ll_ = l1l1l11ll1l1_ll_[selection-shift]
			if l111lll_ll_ (u"ࠬࡳࡰࡥࠩ㤝") in l1l11llll1l1_ll_[selection-shift] and l1l11l1lll11_ll_[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪ㤞")]!=l1l1ll1l1l1l_ll_:
				l1l1lll111ll_ll_ = l1l11l11l11l_ll_[selection-shift]
				l1ll11llll11_ll_ = True
			else: l111ll1l1ll_ll_ = l1l11l1lll11_ll_[l111lll_ll_ (u"ࠧࡶࡴ࡯ࠫ㤟")]
			l1l1llllll11_ll_ = l1l11llll1l1_ll_[selection-shift]
			break
	if not l1ll11llll11_ll_: l1l1l1ll1111_ll_ = l111ll1l1ll_ll_
	else: l1l1l1ll1111_ll_ = l111lll_ll_ (u"ࠨࡘ࡬ࡨࡪࡵ࠺ࠡࠩ㤠")+l1l11l1lll11_ll_[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㤡")]+l111lll_ll_ (u"ࠪࠤ࠰ࠦࡁࡶࡦ࡬ࡳ࠿ࠦࠧ㤢")+l1l1lll111ll_ll_[l111lll_ll_ (u"ࠫࡺࡸ࡬ࠨ㤣")]
	#l1ll1l_ll_(l1l1l1ll1111_ll_,l1l1llllll11_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㤤"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡓࡰࡦࡿࡩ࡯ࡩࠣࡗࡪࡲࡥࡤࡶࡨࡨࠥࠦࠠࡇ࡫࡯ࡩ࠿࡛ࠦࠡࠩ㤥")+l1l1llllll11_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭㤦")+l1l1l1ll1111_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫ㤧"))
	if l1ll11llll11_ll_:
		#xbmc.log(l1l11l1lll11_ll_[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㤨")],level=xbmc.LOGNOTICE)
		#xbmc.log(l1l1lll111ll_ll_[l111lll_ll_ (u"ࠪࡹࡷࡲࠧ㤩")],level=xbmc.LOGNOTICE)
		l1ll11l1l11l_ll_ = int(l1l11l1lll11_ll_[l111lll_ll_ (u"ࠫࡩࡻࡲࡢࡶ࡬ࡳࡳ࠭㤪")])
		l1l1l1lllll1_ll_ = int(l1l1lll111ll_ll_[l111lll_ll_ (u"ࠬࡪࡵࡳࡣࡷ࡭ࡴࡴࠧ㤫")])
		if l1ll11l1l11l_ll_>l1l1l1lllll1_ll_: duration = str(l1ll11l1l11l_ll_)
		else: duration = str(l1l1l1lllll1_ll_)
		#duration = str(l1ll11l1l11l_ll_) if l1ll11l1l11l_ll_>l1l1l1lllll1_ll_ else str(l1l1l1lllll1_ll_)
		l1ll11ll1l11_ll_ = l111lll_ll_ (u"࠭࠼ࡀࡺࡰࡰࠥࡼࡥࡳࡵ࡬ࡳࡳࡃࠢ࠲࠰࠳ࠦࠥ࡫࡮ࡤࡱࡧ࡭ࡳ࡭࠽ࠣࡗࡗࡊ࠲࠾ࠢࡀࡀ࡟ࡲࠬ㤬")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠧ࠽ࡏࡓࡈࠥࡾ࡭࡭ࡰࡶ࠾ࡽࡹࡩ࠾ࠤ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡷ࠴࠰ࡲࡶ࡬࠵࠲࠱࠲࠴࠳࡝ࡓࡌࡔࡥ࡫ࡩࡲࡧ࠭ࡪࡰࡶࡸࡦࡴࡣࡦࠤࠣࡼࡲࡲ࡮ࡴ࠿ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡪࡡࡴࡪ࠽ࡷࡨ࡮ࡥ࡮ࡣ࠽ࡱࡵࡪ࠺࠳࠲࠴࠵ࠧࠦࡸ࡮࡮ࡱࡷ࠿ࡾ࡬ࡪࡰ࡮ࡁࠧ࡮ࡴࡵࡲ࠽࠳࠴ࡽࡷࡸ࠰ࡺ࠷࠳ࡵࡲࡨ࠱࠴࠽࠾࠿࠯ࡹ࡮࡬ࡲࡰࠨࠠࡹࡵ࡬࠾ࡸࡩࡨࡦ࡯ࡤࡐࡴࡩࡡࡵ࡫ࡲࡲࡂࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀࡳࡤࡪࡨࡱࡦࡀ࡭ࡱࡦ࠽࠶࠵࠷࠱ࠡࡪࡷࡸࡵࡀ࠯࠰ࡵࡷࡥࡳࡪࡡࡳࡦࡶ࠲࡮ࡹ࡯࠯ࡱࡵ࡫࠴࡯ࡴࡵࡨ࠲ࡔࡺࡨ࡬ࡪࡥ࡯ࡽࡆࡼࡡࡪ࡮ࡤࡦࡱ࡫ࡓࡵࡣࡱࡨࡦࡸࡤࡴ࠱ࡐࡔࡊࡍ࠭ࡅࡃࡖࡌࡤࡹࡣࡩࡧࡰࡥࡤ࡬ࡩ࡭ࡧࡶ࠳ࡉࡇࡓࡉ࠯ࡐࡔࡉ࠴ࡸࡴࡦࠥࠤࡲ࡯࡮ࡃࡷࡩࡪࡪࡸࡔࡪ࡯ࡨࡁࠧࡖࡔ࠲࠰࠸ࡗࠧࠦ࡭ࡦࡦ࡬ࡥࡕࡸࡥࡴࡧࡱࡸࡦࡺࡩࡰࡰࡇࡹࡷࡧࡴࡪࡱࡱࡁࠧࡖࡔࠨ㤭")+duration+l111lll_ll_ (u"ࠨࡕࠥࠤࡹࡿࡰࡦ࠿ࠥࡷࡹࡧࡴࡪࡥࠥࠤࡵࡸ࡯ࡧ࡫࡯ࡩࡸࡃࠢࡶࡴࡱ࠾ࡲࡶࡥࡨ࠼ࡧࡥࡸ࡮࠺ࡱࡴࡲࡪ࡮ࡲࡥ࠻࡫ࡶࡳ࡫࡬࠭࡮ࡣ࡬ࡲ࠿࠸࠰࠲࠳ࠥࡂࡡࡴࠧ㤮")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠩ࠿ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭㤯")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠪࡀࡆࡪࡡࡱࡶࡤࡸ࡮ࡵ࡮ࡔࡧࡷࠤ࡮ࡪ࠽ࠣ࠲ࠥࠤࡲ࡯࡭ࡦࡖࡼࡴࡪࡃࠢࡷ࡫ࡧࡩࡴ࠵ࠧ㤰")+l1l11l1lll11_ll_[l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦࡶࡼࡴࡪ࠭㤱")]+l111lll_ll_ (u"ࠬࠨࠠࡴࡷࡥࡷࡪ࡭࡭ࡦࡰࡷࡅࡱ࡯ࡧ࡯࡯ࡨࡲࡹࡃࠢࡵࡴࡸࡩࠧࡄ࡜࡯ࠩ㤲")# l1l1ll11ll1l_ll_=l111lll_ll_ (u"ࠨ࠱ࠣ㤳") l1ll11ll111l_ll_=l111lll_ll_ (u"ࠢࡵࡴࡸࡩࠧ㤴") default=l111lll_ll_ (u"ࠣࡶࡵࡹࡪࠨ㤵")>\l1l1ll1l11l1_ll_ (u"ࠩࠍࠍࠎࡳࡰࡥࠢ࠮ࡁࠥ࠭㤶")<l1ll1l11l11l_ll_ l1l1l111ll11_ll_=l111lll_ll_ (u"ࠥࡹࡷࡴ࠺࡮ࡲࡨ࡫࠿ࡊࡁࡔࡊ࠽ࡶࡴࡲࡥ࠻࠴࠳࠵࠶ࠨ㤷") value=l111lll_ll_ (u"ࠦࡲࡧࡩ࡯ࠤ㤸")/>\l1l1ll1l11l1_ll_ (u"ࠬࠐࠉࠊ࡯ࡳࡨࠥ࠱࠽ࠡࠩ㤹")<l1l1l11lllll_ll_ id=l111lll_ll_ (u"ࠨࠧࠬࡸ࡬ࡨࡪࡵࡄࡊࡅࡗ࡟ࠬ࡯ࡴࡢࡩࠪࡡ࠰࠭ࠢ㤺") codecs=l111lll_ll_ (u"ࠢࠨ࠭ࡹ࡭ࡩ࡫࡯ࡅࡋࡆࡘࡠ࠭ࡣࡰࡦࡨࡧࡸ࠭࡝ࠬࠩࠥ㤻") l1l11llllll1_ll_=l111lll_ll_ (u"ࠣ࠳ࠥ㤼") l1ll1l11l1ll_ll_=l111lll_ll_ (u"ࠤࠪ࠯ࡸࡺࡲࠩࡸ࡬ࡨࡪࡵࡄࡊࡅࡗ࡟ࠬࡨࡩࡵࡴࡤࡸࡪ࠭࡝ࠪ࠭ࠪࠦ㤽") width=l111lll_ll_ (u"ࠥࠫ࠰ࡼࡩࡥࡧࡲࡈࡎࡉࡔ࡜ࠩࡶ࡭ࡿ࡫ࠧ࡞࠰ࡶࡴࡱ࡯ࡴࠩࠩࡻࠫ࠮ࡡ࠰࡞࠭ࠪࠦ㤾") height=l111lll_ll_ (u"ࠦࠬ࠱ࡶࡪࡦࡨࡳࡉࡏࡃࡕ࡝ࠪࡷ࡮ࢀࡥࠨ࡟࠱ࡷࡵࡲࡩࡵࠪࠪࡼࠬ࠯࡛࠲࡟࠮ࠫࠧ㤿") l1ll1l11llll_ll_=l111lll_ll_ (u"ࠧ࠭ࠫࡷ࡫ࡧࡩࡴࡊࡉࡄࡖ࡞ࠫ࡫ࡶࡳࠨ࡟࠮ࠫࠧ㥀")>\l1l1ll1l11l1_ll_ (u"࠭ࠊࠊࠋࡰࡴࡩࠦࠫ࠾ࠢࠪ㥁")<l1l1l1l11ll1_ll_>l111lll_ll_ (u"ࠧࠬࡸ࡬ࡨࡪࡵࡄࡊࡅࡗ࡟ࠬ㥂")l1ll111lll11_ll_ (u"ࠨ࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬ㥃")&l111lll_ll_ (u"ࠩ࠯ࠫ㥄")&amp;l111lll_ll_ (u"ࠪ࠭࠰࠭㥅")</l1l1l1l11ll1_ll_>\l1l1ll1l11l1_ll_ (u"ࠫࠏࠏࠉ࡮ࡲࡧࠤ࠰ࡃࠠࠨ㥆")<l1l1ll11l111_ll_ l1l1lllllll1_ll_=l111lll_ll_ (u"ࠧ࠭ࠫࡷ࡫ࡧࡩࡴࡊࡉࡄࡖ࡞ࠫ࡮ࡴࡤࡦࡺࠪࡡ࠰࠭ࠢ㥇")>\l1l1ll1l11l1_ll_ (u"࠭ࠣࠡ࡫ࡱࡨࡪࡾࡒࡢࡰࡪࡩࡊࡾࡡࡤࡶࡀࠦࡹࡸࡵࡦࠤࡁࡠࡳ࠭㥈")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠧ࠽ࡋࡱ࡭ࡹ࡯ࡡ࡭࡫ࡽࡥࡹ࡯࡯࡯ࠢࡵࡥࡳ࡭ࡥ࠾ࠤࠪ㥉")+l1l11l1lll11_ll_[l111lll_ll_ (u"ࠨ࡫ࡱ࡭ࡹ࠭㥊")]+l111lll_ll_ (u"ࠩࠥࠤ࠴ࡄ࡜࡯ࠩ㥋")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠪࡀ࠴࡙ࡥࡨ࡯ࡨࡲࡹࡈࡡࡴࡧࡁࡠࡳ࠭㥌")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠫࡁ࠵ࡒࡦࡲࡵࡩࡸ࡫࡮ࡵࡣࡷ࡭ࡴࡴ࠾࡝ࡰࠪ㥍")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠬࡂ࠯ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺ࠾࡝ࡰࠪ㥎")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"࠭࠼ࡂࡦࡤࡴࡹࡧࡴࡪࡱࡱࡗࡪࡺࠠࡪࡦࡀࠦ࠶ࠨࠠ࡮࡫ࡰࡩ࡙ࡿࡰࡦ࠿ࠥࡥࡺࡪࡩࡰ࠱ࠪ㥏")+l1l1lll111ll_ll_[l111lll_ll_ (u"ࠧࡧ࡫࡯ࡩࡹࡿࡰࡦࠩ㥐")]+l111lll_ll_ (u"ࠨࠤࠣࡷࡺࡨࡳࡦࡩࡰࡩࡳࡺࡁ࡭࡫ࡪࡲࡲ࡫࡮ࡵ࠿ࠥࡸࡷࡻࡥࠣࡀ࡟ࡲࠬ㥑")# l1l1ll11ll1l_ll_=l111lll_ll_ (u"ࠤ࠴ࠦ㥒") l1ll11ll111l_ll_=l111lll_ll_ (u"ࠥࡸࡷࡻࡥࠣ㥓") default=l111lll_ll_ (u"ࠦࡹࡸࡵࡦࠤ㥔")>\l1l1ll1l11l1_ll_ (u"ࠬࠐࠉࠊ࡯ࡳࡨࠥ࠱࠽ࠡࠩ㥕")<l1ll1l11l11l_ll_ l1l1l111ll11_ll_=l111lll_ll_ (u"ࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡆࡄࡗࡍࡀࡲࡰ࡮ࡨ࠾࠷࠶࠱࠲ࠤ㥖") value=l111lll_ll_ (u"ࠢ࡮ࡣ࡬ࡲࠧ㥗")/>\l1l1ll1l11l1_ll_ (u"ࠨࠌࠌࠍࡲࡶࡤࠡ࠭ࡀࠤࠬ㥘")<l1l1l11lllll_ll_ id=l111lll_ll_ (u"ࠤࠪ࠯ࡦࡻࡤࡪࡱࡇࡍࡈ࡚࡛ࠨ࡫ࡷࡥ࡬࠭࡝ࠬࠩࠥ㥙") codecs=l111lll_ll_ (u"ࠥࠫ࠰ࡧࡵࡥ࡫ࡲࡈࡎࡉࡔ࡜ࠩࡦࡳࡩ࡫ࡣࡴࠩࡠ࠯ࠬࠨ㥚") l1ll1l11l1ll_ll_=l111lll_ll_ (u"ࠦ࠶࠹࠰࠵࠹࠸ࠦ㥛")>\l1l1ll1l11l1_ll_ (u"ࠬࠐࠉࠊ࡯ࡳࡨࠥ࠱࠽ࠡࠩ㥜")<l1l1l1l1l111_ll_ l1l1l111ll11_ll_=l111lll_ll_ (u"ࠨࡵࡳࡰ࠽ࡱࡵ࡫ࡧ࠻ࡦࡤࡷ࡭ࡀ࠲࠴࠲࠳࠷࠿࠹࠺ࡢࡷࡧ࡭ࡴࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡤࡱࡱࡪ࡮࡭ࡵࡳࡣࡷ࡭ࡴࡴ࠺࠳࠲࠴࠵ࠧ㥝") value=l111lll_ll_ (u"ࠢࠨ࠭ࡤࡹࡩ࡯࡯ࡅࡋࡆࡘࡠ࠭ࡡࡶࡦ࡬ࡳࡤࡩࡨࡢࡰࡱࡩࡱࡹࠧ࡞࠭ࠪࠦ㥞")/>\l1l1ll1l11l1_ll_ (u"ࠨࠌࠌࠍࡲࡶࡤࠡ࠭ࡀࠤࠬ㥟")<l1l1l1l11ll1_ll_>l111lll_ll_ (u"ࠩ࠮ࡥࡺࡪࡩࡰࡆࡌࡇ࡙ࡡࠧ㥠")l1ll111lll11_ll_ (u"ࠪࡡ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧ㥡")&l111lll_ll_ (u"ࠫ࠱࠭㥢")&amp;l111lll_ll_ (u"ࠬ࠯ࠫࠨ㥣")</l1l1l1l11ll1_ll_>\l1l1ll1l11l1_ll_ (u"࠭ࠊࠊࠋࡰࡴࡩࠦࠫ࠾ࠢࠪ㥤")<l1l1ll11l111_ll_ l1l1lllllll1_ll_=l111lll_ll_ (u"ࠢࠨ࠭ࡤࡹࡩ࡯࡯ࡅࡋࡆࡘࡠ࠭ࡩ࡯ࡦࡨࡼࠬࡣࠫࠨࠤ㥥")>\l1l1ll1l11l1_ll_ (u"ࠨࠥࠣ࡭ࡳࡪࡥࡹࡔࡤࡲ࡬࡫ࡅࡹࡣࡦࡸࡂࠨࡴࡳࡷࡨࠦࡃࡢ࡮ࠨ㥦")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠩ࠿ࡍࡳ࡯ࡴࡪࡣ࡯࡭ࡿࡧࡴࡪࡱࡱࠤࡷࡧ࡮ࡨࡧࡀࠦࠬ㥧")+l1l1lll111ll_ll_[l111lll_ll_ (u"ࠪ࡭ࡳ࡯ࡴࠨ㥨")]+l111lll_ll_ (u"ࠫࠧࠦ࠯࠿࡞ࡱࠫ㥩")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠬࡂ࠯ࡔࡧࡪࡱࡪࡴࡴࡃࡣࡶࡩࡃࡢ࡮ࠨ㥪")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"࠭࠼࠰ࡔࡨࡴࡷ࡫ࡳࡦࡰࡷࡥࡹ࡯࡯࡯ࡀ࡟ࡲࠬ㥫")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠧ࠽࠱ࡄࡨࡦࡶࡴࡢࡶ࡬ࡳࡳ࡙ࡥࡵࡀ࡟ࡲࠬ㥬")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠨ࠾࠲ࡔࡪࡸࡩࡰࡦࡁࡠࡳ࠭㥭")
		l1ll11ll1l11_ll_ += l111lll_ll_ (u"ࠩ࠿࠳ࡒࡖࡄ࠿࡞ࡱࠫ㥮")
		#xbmc.log(l1ll11ll1l11_ll_,level=xbmc.LOGNOTICE)
		l111lll_ll_ (u"ࠥࠦࠧࠐࠉࠊ࡯ࡳࡨ࡫ࡵ࡬ࡥࡧࡵࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡾࡢ࡮ࡥ࠱ࡸࡷࡧ࡮ࡴ࡮ࡤࡸࡪࡖࡡࡵࡪࠫࠫࡸࡶࡥࡤ࡫ࡤࡰ࠿࠵࠯ࡵࡧࡰࡴࠬ࠯ࠬࡢࡦࡧࡳࡳࡥࡩࡥࠫࠍࠍࠎ࡯ࡦࠡࡰࡲࡸࠥࡵࡳ࠯ࡲࡤࡸ࡭࠴ࡥࡹ࡫ࡶࡸࡸ࠮࡭ࡱࡦࡩࡳࡱࡪࡥࡳࠫ࠽ࠎࠎࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬ࡬࡯࡭ࡦࡨࡶࠥࡪ࡯ࡦࡵࠣࡲࡴࡺࠠࡦࡺࡶ࡭ࡹ࠭ࠬࠨࠩࠬࠎࠎࠏࠉࡪ࡯ࡳࡳࡷࡺࠠࡹࡤࡰࡧࡻ࡬ࡳࠋࠋࠌࠍࡽࡨ࡭ࡤࡸࡩࡷ࠳ࡳ࡫ࡥ࡫ࡵࠬࡲࡶࡤࡧࡱ࡯ࡨࡪࡸࠩࠋࠋࠌࡱࡵࡪࡦࡪ࡮ࡨࠤࡂࠦ࡯ࡴ࠰ࡳࡥࡹ࡮࠮࡫ࡱ࡬ࡲ࠭ࡳࡰࡥࡨࡲࡰࡩ࡫ࡲ࠭࡫ࡧ࠯ࠬ࠴࡭ࡱࡦࠪ࠭ࠏࠏࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࡲࡶࡤࡧ࡫࡯ࡩ࠱ࡳࡰࡥࠫࠍࠍࠎࠩࡷࡪࡶ࡫ࠤࡴࡶࡥ࡯ࠪࡰࡴࡩ࡬ࡩ࡭ࡧ࠯ࠫࡼ࠭ࠩࠡࡣࡶࠤ࡫࡯࡬ࡦ࠼ࠣࡪ࡮ࡲࡥ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡮ࡲࡧ࠭ࠏࠏࠉࠤ࡯ࡳࡨ࡫࡯࡬ࡦࠢࡀࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡲ࡯ࡤࡣ࡯࡬ࡴࡹࡴ࠻࠷࠸࠴࠺࠻࠯ࠨ࠭࡬ࡨ࠰࠭࠮࡮ࡲࡧࠫࠏࠏࠉࠣࠤࠥ㥯")
		import BaseHTTPServer,httplib
		class l1l1llll11l1_ll_(BaseHTTPServer.HTTPServer):
			#l1ll11ll1l11_ll_ = l111lll_ll_ (u"ࠫࡲࡶࡤࠡ࠿ࠣࡹࡸ࡫ࡤࠡࡹ࡫ࡩࡳࠦ࡮ࡰࡶࠣࡹࡸ࡯࡮ࡨࠢࡢࡣ࡮ࡴࡩࡵࡡࡢࠫ㥰")
			def __init__(self,port=l111lll_ll_ (u"ࠬ࠻࠵࠱࠷࠸ࠫ㥱"),l1ll11ll1l11_ll_=l111lll_ll_ (u"࠭࡭ࡱࡦࠣࡁࠥ࡬ࡲࡰ࡯ࠣࡣࡤ࡯࡮ࡪࡶࡢࡣࠬ㥲")):
				BaseHTTPServer.HTTPServer.__init__(self,(l111lll_ll_ (u"ࠧ࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶࠪ㥳"),port), l1l11lll1l1l_ll_)
				self.port = port
				self.l1ll11ll1l11_ll_ = l1ll11ll1l11_ll_
				#print(l111lll_ll_ (u"ࠨࡵࡨࡶࡻ࡫ࡲࠡ࡫ࡶࠤࡺࡶࠠ࡯ࡱࡺࠤࡱ࡯ࡳࡵࡧࡱ࡭ࡳ࡭ࠠࡰࡰࠣࡴࡴࡸࡴ࠻ࠢࠪ㥴")+str(port))
			def start(self):
				self.threads = l11ll11lll_ll_(False)
				self.threads.start_new_thread(1,self.l1l1l1l1l11l_ll_)
			def l1l1l1l1l11l_ll_(self):
				#print(l111lll_ll_ (u"ࠩࡶࡩࡷࡼࡩ࡯ࡩࠣࡶࡪࡷࡵࡦࡵࡷࡷࠥࡹࡴࡢࡴࡷࡩࡩ࠭㥵"))
				self.l1l11ll11111_ll_ = True
				#counter = 0
				while self.l1l11ll11111_ll_:
					#counter += 1
					#print(l111lll_ll_ (u"ࠪࡶࡺࡴ࡮ࡪࡰࡪࠤࡦࠦࡳࡪࡰࡪࡰࡪࠦࡨࡢࡰࡧࡰࡪࡥࡲࡦࡳࡸࡩࡸࡺࠨࠪࠢࡱࡳࡼࡀࠠࠨ㥶")+str(counter)+l111lll_ll_ (u"ࠫࠬ㥷"))
					#settimeout l1ll1l11l1_ll_ not l1lll11111_ll_ l1l1l1ll1ll1_ll_ to error message if it l1ll11ll1111_ll_ l1lll1l1l11l_ll_ http request
					#self.socket.settimeout(10) # default is 60 seconds (it will l1l1l1l1l11l_ll_ one request l111l1lll1l_ll_ 60 seconds)
					self.handle_request()
				#print(l111lll_ll_ (u"ࠬࡹࡥࡳࡸ࡬ࡲ࡬ࠦࡲࡦࡳࡸࡩࡸࡺࡳࠡࡵࡷࡳࡵࡶࡥࡥ࡞ࡱࠫ㥸"))
			def stop(self):
				self.l1l11ll11111_ll_ = False
				self.l1l1lll1lll1_ll_()	# needed to force self.handle_request() to l1l1l1l1l11l_ll_ l1ll1llll11_ll_ last request
			def shutdown(self):
				self.stop()
				self.socket.close()
				self.server_close()
				time.sleep(1)
				#print(l111lll_ll_ (u"࠭ࡳࡦࡴࡹࡩࡷࠦࡩࡴࠢࡧࡳࡼࡴࠠ࡯ࡱࡺࡠࡳ࠭㥹"))
			def load(self,l1ll11ll1l11_ll_):
				self.l1ll11ll1l11_ll_ = l1ll11ll1l11_ll_
			def l1l1lll1lll1_ll_(self):
				conn = httplib.HTTPConnection(l111lll_ll_ (u"ࠧ࡭ࡱࡦࡥࡱ࡮࡯ࡴࡶ࠽ࠫ㥺")+str(self.port))
				conn.request(l111lll_ll_ (u"ࠣࡊࡈࡅࡉࠨ㥻"), l111lll_ll_ (u"ࠤ࠲ࠦ㥼"))
		class l1l11lll1l1l_ll_(BaseHTTPServer.BaseHTTPRequestHandler):
			def do_GET(self):
				#print(l111lll_ll_ (u"ࠪࡨࡴ࡯࡮ࡨࠢࡊࡉ࡙ࠦࠠࠨ㥽")+self.path)
				self.send_response(200)
				self.send_header(l111lll_ll_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲ࡺࡹࡱࡧࠪ㥾"), l111lll_ll_ (u"ࠬࡺࡥࡹࡶ࠲ࡴࡱࡧࡩ࡯ࠩ㥿"))
				self.end_headers()
				#self.l1l1l1111l11_ll_.write(self.path+l111lll_ll_ (u"࠭࡜࡯ࠩ㦀"))
				self.l1l1l1111l11_ll_.write(self.server.l1ll11ll1l11_ll_)
				if self.path==l111lll_ll_ (u"ࠧ࠰ࡵ࡫ࡹࡹࡪ࡯ࡸࡰࠪ㦁"): self.server.shutdown()
			def do_HEAD(s):
				#print(l111lll_ll_ (u"ࠨࡦࡲ࡭ࡳ࡭ࠠࡉࡇࡄࡈࠥࠦࠧ㦂")+self.path)
				s.send_response(200)
				s.end_headers()
		httpd = l1l1llll11l1_ll_(55055,l1ll11ll1l11_ll_)
		#httpd.load(l1ll11ll1l11_ll_)
		httpd.start()
		# http://localhost:55055/shutdown
		l111ll1l1ll_ll_ = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡯ࡳࡨࡧ࡬ࡩࡱࡶࡸ࠿࠻࠵࠱࠷࠸࠳ࡾࡵࡵࡵࡷࡥࡩ࠳ࡳࡰࡥࠩ㦃")
	else: httpd = l111lll_ll_ (u"ࠪࠫ㦄")
	if l111ll1l1ll_ll_!=l111lll_ll_ (u"ࠫࠬ㦅"): return l111lll_ll_ (u"ࠬ࠭㦆"),[l111lll_ll_ (u"࠭ࠧ㦇")],[[l111ll1l1ll_ll_,l1l11l1lllll_ll_,httpd]]
	return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢ࡜ࡓ࡚࡚ࡕࡃࡇࠣࡊࡦ࡯࡬ࡦࡦࠪ㦈"),[],[]
def l1l1ll1llll1_ll_(url):
	# l1ll1l1l_ll_://l1ll111111l1_ll_.l1lll1l11_ll_/l1l1l1lll1ll_ll_
	headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㦉") : l111lll_ll_ (u"ࠩࠪ㦊") }
	#url = url.replace(l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ㦋"),l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ㦌"))
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭㦍"),headers,l111lll_ll_ (u"࠭ࠧ㦎"),l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰࡚ࡎࡊࡂࡐࡄ࠰࠵ࡸࡺࠧ㦏"))
	items = re.findall(l111lll_ll_ (u"ࠨࡨ࡬ࡰࡪࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠭࡮ࡤࡦࡪࡲ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࡽࠫ࡟ࢁࠬ㦐"),html,re.DOTALL)
	items = set(items)
	items = sorted(items, reverse=True, key=lambda key: key[2])
	l1l11l11llll_ll_,l1111ll_ll_,l1l1l1l1ll1l_ll_,l1l111l_ll_ = [],[],[],[]
	if items:
		for link,dummy,label in items:
			link = link.replace(l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻ࠩ㦑"),l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ㦒"))
			if l111lll_ll_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪ㦓") in link:
				l1l11l11llll_ll_,l1l1l1l1ll1l_ll_ = l11l1l1l_ll_(link)
				#l1ll1l_ll_(str(l1l111l_ll_),str(l1l1l1l1ll1l_ll_))
				l1l111l_ll_ = l1l111l_ll_ + l1l1l1l1ll1l_ll_
				if l1l11l11llll_ll_[0]==l111lll_ll_ (u"ࠬ࠳࠱ࠨ㦔"): l1111ll_ll_.append(l111lll_ll_ (u"࠭ำ๋ำไีࠥิวึࠩ㦕")+l111lll_ll_ (u"ࠧࠡࠢࠣࡱ࠸ࡻ࠸ࠨ㦖"))
				else:
					for title in l1l11l11llll_ll_:
						l1111ll_ll_.append(l111lll_ll_ (u"ࠨีํีๆืࠠฯษุࠫ㦗")+l111lll_ll_ (u"ࠩࠣࠤࠥ࠭㦘")+title)
			else:
				title = l111lll_ll_ (u"ࠪื๏ืแาࠢัหฺ࠭㦙")+l111lll_ll_ (u"ࠫࠥࠦࠠ࡮ࡲ࠷ࠤࠥࠦࠧ㦚")+label
				l1l111l_ll_.append(link)
				l1111ll_ll_.append(title)
		return l111lll_ll_ (u"ࠬ࠭㦛"),l1111ll_ll_,l1l111l_ll_
	else: return l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡘࡌࡈࡇࡕࡂࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㦜"),[],[]
def	l1l11lll111l_ll_(url):
	# l1ll1l1l_ll_://l1l11l1ll111_ll_.in/l1ll1l111111_ll_
	#xbmc.log(url)
	url = url.replace(l111lll_ll_ (u"ࠧࡦ࡯ࡥࡩࡩ࠳ࠧ㦝"),l111lll_ll_ (u"ࠨࠩ㦞"))
	url = url.replace(l111lll_ll_ (u"ࠩ࠱࡬ࡹࡳ࡬ࠨ㦟"),l111lll_ll_ (u"ࠪࠫ㦠"))
	id = url.split(l111lll_ll_ (u"ࠫ࠴࠭㦡"))[3]
	#l1ll1l_ll_(url,id)
	headers = { l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ㦢"):l111lll_ll_ (u"࠭ࠧ㦣") , l111lll_ll_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭㦤"):l111lll_ll_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪࠧ㦥") }
	payload = { l111lll_ll_ (u"ࠩ࡬ࡨࠬ㦦"):id , l111lll_ll_ (u"ࠪࡳࡵ࠭㦧"):l111lll_ll_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠸ࠧ㦨") }
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡖࡏࡔࡖࠪ㦩"),url,payload,headers,l111lll_ll_ (u"࠭ࠧ㦪"),l111lll_ll_ (u"ࠧࠨ㦫"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡝ࡌࡉࡍࡇࡖࡌࡆࡘࡉࡏࡉ࠰࠵ࡸࡺࠧ㦬"))
	html = response.content
	#l1ll1l_ll_(url,html)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ㦭"),l111lll_ll_ (u"ࠪ࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯ࠪ㦮"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ㦯"),html)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㦰"),l111lll_ll_ (u"࠭࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠳࠭࠮࠯࠰࠱࠲࠭㦱"))
	items = re.findall(l111lll_ll_ (u"ࠧࡥ࡫ࡵࡩࡨࡺ࡟࡭࡫ࡱ࡯࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㦲"),html,re.DOTALL)
	if items: return l111lll_ll_ (u"ࠨࠩ㦳"),[l111lll_ll_ (u"ࠩࠪ㦴")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡞ࡆࡊࡎࡈࡗࡍࡇࡒࡊࡐࡊࠤࡋࡧࡩ࡭ࡧࡧࠫ㦵"),[],[]
def l1l11ll1111l_ll_(url):
	# l1ll1l1l_ll_://l1l1llll1ll1_ll_.co/video/play/l1l1l1l11l11_ll_
	headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ㦶") : l111lll_ll_ (u"ࠬ࠭㦷") }
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"࠭ࠧ㦸"),headers,l111lll_ll_ (u"ࠧࠨ㦹"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱ࡌࡕࡖࡊࡆ࠰࠵ࡸࡺࠧ㦺"))
	items = re.findall(l111lll_ll_ (u"ࠩࡶࡳࡺࡸࡣࡦࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㦻"),html,re.DOTALL)
	l1l11l11llll_ll_,l1111ll_ll_,l1l111l_ll_ = [],[],[],[]
	if items:
		link = items[0]
		if l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩ㦼") in link:
			l1l11l11llll_ll_,l1l111l_ll_ = l11l1l1l_ll_(link)
			if l1l11l11llll_ll_[0]==l111lll_ll_ (u"ࠫ࠲࠷ࠧ㦽"): l1111ll_ll_.append(l111lll_ll_ (u"ู๊ࠬาใิࠤำอีࠨ㦾")+l111lll_ll_ (u"࠭ࠠࠡࠢࡰ࠷ࡺ࠾ࠧ㦿"))
			else:
				for title in l1l11l11llll_ll_:
					l1111ll_ll_.append(l111lll_ll_ (u"ࠧิ์ิๅึࠦฮศืࠪ㧀")+l111lll_ll_ (u"ࠨࠢࠣࠤࠬ㧁")+title)
		else:
			title = l111lll_ll_ (u"ࠩึ๎ึ็ัࠡะสูࠬ㧂")+l111lll_ll_ (u"ࠪࠤࠥࠦ࡭ࡱ࠶ࠪ㧃")
			l1111ll_ll_.append(title)
			l1l111l_ll_.append(link)
		return l111lll_ll_ (u"ࠫࠬ㧄"),l1111ll_ll_,l1l111l_ll_
	else: return l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡘࡥࡴࡱ࡯ࡺࡪࡸࠠࡈࡑ࡙ࡍࡉࠦࡆࡢ࡫࡯ࡩࡩ࠭㧅"),[],[]
	# l1ll1l1l_ll_://l1ll11111l1l_ll_.l1l1llll1ll1_ll_.co/stream/229.l1111111_ll_
#####################################################
#    l1l11l1ll11l_ll_ l1ll111l1ll1_ll_ l1l1l11ll11l_ll_
#    16-06-2019
#####################################################
def l1l1lllll111_ll_(url):
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"࠭ࠧ㧆"),l111lll_ll_ (u"ࠧࠨ㧇"),l111lll_ll_ (u"ࠨࠩ㧈"),l111lll_ll_ (u"ࠩࡕࡉࡘࡕࡌࡗࡇࡕࡗ࠲ࡇࡒࡂࡄࡏࡓࡆࡊࡓ࠮࠳ࡶࡸࠬ㧉"))
	items = re.findall(l111lll_ll_ (u"ࠪࡧࡴࡲ࡯ࡳ࠿ࠥࡶࡪࡪࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㧊"),html,re.DOTALL)
	if items: return l111lll_ll_ (u"ࠫࠬ㧋"),[l111lll_ll_ (u"ࠬ࠭㧌")],[ items[0] ]
	else: return l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡃࡕࡅࡇࡒࡏࡂࡆࡖࠤࡋࡧࡩ࡭ࡧࡧࠫ㧍"),[],[]
def l1l1ll1lllll_ll_(url):
	return l111lll_ll_ (u"ࠧࠨ㧎"),[l111lll_ll_ (u"ࠨࠩ㧏")],[ url ]
def l1ll111ll11l_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࠪ㧐"))
	server = url.split(l111lll_ll_ (u"ࠪ࠳ࠬ㧑"))
	basename = l111lll_ll_ (u"ࠫ࠴࠭㧒").join(server[0:3])
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠬ࠭㧓"),l111lll_ll_ (u"࠭ࠧ㧔"),l111lll_ll_ (u"ࠧࠨ㧕"),l111lll_ll_ (u"ࠨࡔࡈࡗࡔࡒࡖࡆࡔࡖ࠱࡟ࡏࡐࡑ࡛ࡖࡌࡆࡘࡅ࠮࠳ࡶࡸࠬ㧖"))
	items = re.findall(l111lll_ll_ (u"ࠩࡧࡰࡧࡻࡴࡵࡱࡱࡠࠬࡢࠩ࠯ࡪࡵࡩ࡫ࠦ࠽ࠡࠤࠫ࠲࠯ࡅࠩࠣࠢ࡟࠯ࠥࡢࠨࠩ࠰࠭ࡃ࠮ࠦ࡜ࠦࠢࠫ࠲࠯ࡅࠩࠡ࡞࠮ࠤ࠭࠴ࠪࡀࠫࠣࡠࠪࠦࠨ࠯ࠬࡂ࠭ࡡ࠯ࠠ࡝࠭ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ㧗"),html,re.DOTALL)
	#l1ll1l_ll_(url,str(var))
	if items:
		l1lllllll1l1_ll_,l11111111l1_ll_,l11111111ll_ll_,l1ll11ll1l1l_ll_,l1ll11ll1ll1_ll_,l1ll11ll11ll_ll_ = items[0]
		var = int(l11111111l1_ll_) % int(l11111111ll_ll_) + int(l1ll11ll1l1l_ll_) % int(l1ll11ll1ll1_ll_)
		url = basename + l1lllllll1l1_ll_ + str(var) + l1ll11ll11ll_ll_
		return l111lll_ll_ (u"ࠪࠫ㧘"),[l111lll_ll_ (u"ࠫࠬ㧙")],[url]
	else: return l111lll_ll_ (u"ࠬࡋࡲࡳࡱࡵ࠾ࠥࡠࡉࡑࡒ࡜ࡗࡍࡇࡒࡆࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡋࡧࡩ࡭ࡧࡧࠫ㧚"),[],[]
def l1ll111l1lll_ll_(url):
	url = url.replace(l111lll_ll_ (u"࠭ࡥ࡮ࡤࡨࡨ࠲࠭㧛"),l111lll_ll_ (u"ࠧࠨ㧜"))
	url = url.replace(l111lll_ll_ (u"ࠨ࠰࡫ࡸࡲࡲࠧ㧝"),l111lll_ll_ (u"ࠩࠪ㧞"))
	id = url.split(l111lll_ll_ (u"ࠪ࠳ࠬ㧟"))[-1]
	headers = { l111lll_ll_ (u"ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪ㧠") : l111lll_ll_ (u"ࠬࡧࡰࡱ࡮࡬ࡧࡦࡺࡩࡰࡰ࠲ࡼ࠲ࡽࡷࡸ࠯ࡩࡳࡷࡳ࠭ࡶࡴ࡯ࡩࡳࡩ࡯ࡥࡧࡧࠫ㧡") }
	payload = { l111lll_ll_ (u"ࠨࡩࡥࠤ㧢"):id , l111lll_ll_ (u"ࠢࡰࡲࠥ㧣"):l111lll_ll_ (u"ࠣࡦࡲࡻࡳࡲ࡯ࡢࡦ࠵ࠦ㧤") }
	request = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠩࡓࡓࡘ࡚ࠧ㧥"), url, payload, headers, False,l111lll_ll_ (u"ࠪࠫ㧦"),l111lll_ll_ (u"ࠫࡗࡋࡓࡐࡎ࡙ࡉࡗ࡙࠭ࡎࡒ࠷࡙ࡕࡒࡏࡂࡆ࠰࠵ࡸࡺࠧ㧧"))
	url = request.headers[l111lll_ll_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ㧨")]
	if url!=l111lll_ll_ (u"࠭ࠧ㧩"): return l111lll_ll_ (u"ࠧࠨ㧪"),[l111lll_ll_ (u"ࠨࠩ㧫")],[ url ]
	else: return l111lll_ll_ (u"ࠩࡈࡶࡷࡵࡲ࠻ࠢࡕࡩࡸࡵ࡬ࡷࡧࡵࠤࡒࡖ࠴ࡖࡒࡏࡓࡆࡊࠠࡇࡣ࡬ࡰࡪࡪࠧ㧬"),[],[]
def l1l11l11ll11_ll_(url):
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠪࠫ㧭"),l111lll_ll_ (u"ࠫࠬ㧮"),l111lll_ll_ (u"ࠬ࠭㧯"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯࡚ࡍࡓ࡚ࡖࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ㧰"))
	items = re.findall(l111lll_ll_ (u"ࠧ࡮ࡲ࠷࠾ࠥࡢ࡛࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩࠪ㧱"),html,re.DOTALL)
	if items: return l111lll_ll_ (u"ࠨࠩ㧲"),[l111lll_ll_ (u"ࠩࠪ㧳")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥ࡝ࡉࡏࡖ࡙ࡐࡎ࡜ࡅࠡࡈࡤ࡭ࡱ࡫ࡤࠨ㧴"),[],[]
def l1ll111lll1l_ll_(url):
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠫࠬ㧵"),l111lll_ll_ (u"ࠬ࠭㧶"),l111lll_ll_ (u"࠭ࠧ㧷"),l111lll_ll_ (u"ࠧࡓࡇࡖࡓࡑ࡜ࡅࡓࡕ࠰ࡅࡗࡉࡈࡊࡘࡈ࠱࠶ࡹࡴࠨ㧸"))
	items = re.findall(l111lll_ll_ (u"ࠨࡵࡲࡹࡷࡩࡥࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㧹"),html,re.DOTALL)
	#logging.warning(l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡩࡨࡪࡸࡨ࠲ࡴࡸࡧࠨ㧺") + items[0])
	if items:
		url = url = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡦࡸࡣࡩ࡫ࡹࡩ࠳ࡵࡲࡨࠩ㧻") + items[0]
		return l111lll_ll_ (u"ࠫࠬ㧼"),[l111lll_ll_ (u"ࠬ࠭㧽")],[ url ]
	else: return l111lll_ll_ (u"࠭ࡅࡳࡴࡲࡶ࠿ࠦࡒࡦࡵࡲࡰࡻ࡫ࡲࠡࡃࡕࡇࡍࡏࡖࡆࠢࡉࡥ࡮ࡲࡥࡥࠩ㧾"),[],[]
def l1ll1l1l111l_ll_(url):
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠧࠨ㧿"),l111lll_ll_ (u"ࠨࠩ㨀"),l111lll_ll_ (u"ࠩࠪ㨁"),l111lll_ll_ (u"ࠪࡖࡊ࡙ࡏࡍࡘࡈࡖࡘ࠳ࡐࡖࡄࡏࡍࡈ࡜ࡉࡅࡇࡒࡌࡔ࡙ࡔ࠮࠳ࡶࡸࠬ㨂"))
	items = re.findall(l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠣࠦ࠭࠴ࠪࡀࠫࠥࠫ㨃"),html,re.DOTALL)
	#l1ll1l_ll_(str(items),html)
	if items: return l111lll_ll_ (u"ࠬ࠭㨄"),[l111lll_ll_ (u"࠭ࠧ㨅")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠧࡆࡴࡵࡳࡷࡀࠠࡓࡧࡶࡳࡱࡼࡥࡳࠢࡓ࡙ࡇࡒࡉࡄࡘࡌࡈࡊࡕࡈࡐࡕࡗࠤࡋࡧࡩ࡭ࡧࡧࠫ㨆"),[],[]
def l1l1lll1ll11_ll_(url):
	#url = url.replace(l111lll_ll_ (u"ࠨࡧࡰࡦࡪࡪ࠭ࠨ㨇"),l111lll_ll_ (u"ࠩࠪ㨈"))
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠪࠫ㨉"),l111lll_ll_ (u"ࠫࠬ㨊"),l111lll_ll_ (u"ࠬ࠭㨋"),l111lll_ll_ (u"࠭ࡒࡆࡕࡒࡐ࡛ࡋࡒࡔ࠯ࡈࡗ࡙ࡘࡅࡂࡏ࠰࠵ࡸࡺࠧ㨌"))
	items = re.findall(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴࠦࡰࡳࡧ࡯ࡳࡦࡪ࠮ࠫࡁࡶࡶࡨࡃ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㨍"),html,re.DOTALL)
	#l1ll1l_ll_(items[0],items[0])
	if items: return l111lll_ll_ (u"ࠨࠩ㨎"),[l111lll_ll_ (u"ࠩࠪ㨏")],[ items[0] ]
	else: return l111lll_ll_ (u"ࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡖࡪࡹ࡯࡭ࡸࡨࡶࠥࡋࡓࡕࡔࡈࡅࡒࠦࡆࡢ࡫࡯ࡩࡩ࠭㨐"),[],[]
l111lll_ll_ (u"ࠦࠧࠨࠊࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠏࠩࠠࠡࠢࠣࡒࡔ࡚ࠠࡘࡑࡕࡏࡎࡔࡇࠡࡃࡑ࡝ࡒࡕࡒࡆࠌࠦࠤࠥࠦࠠ࠱࠴࠰ࡊࡊࡈ࠭࠳࠲࠵࠵ࠏࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠦࠧࠨࠩࠣࠤࠥࠍࠎࠏࠐࠊࠣࠤࠥ㨑")