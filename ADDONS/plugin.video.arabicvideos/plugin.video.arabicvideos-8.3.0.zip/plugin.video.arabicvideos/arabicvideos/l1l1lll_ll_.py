# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ਠ") : l111lll_ll_ (u"ࠪࠫਡ") }
l1ll_ll_=l111lll_ll_ (u"ࠫࡆࡑࡗࡂࡏࠪਢ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡥࡁࡌ࡙ࡢࠫਣ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
#l1l11_ll_ = [l111lll_ll_ (u"࠭แ๋ๆ่ࠫਤ"),l111lll_ll_ (u"ࠧไๆํฬࠬਥ"),l111lll_ll_ (u"ࠨษ็฽ึ฼ࠠศๆสือ๎ู๋ࠩਦ"),l111lll_ll_ (u"่ࠩืึำ๊สࠩਧ"),l111lll_ll_ (u"ุ้ࠪือ๋้ࠪਨ"),l111lll_ll_ (u"ࠫฬเๆ๋หࠪ਩"),l111lll_ll_ (u"ࠬอูๅษ้ࠫਪ"),l111lll_ll_ (u"࠭ไใษฤࠫਫ")]
#proxy = l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࡨࡵࡶࡳࡷ࠿࠵࠯࠲࠷࠼࠲࠷࠶࠳࠯࠺࠺࠲࠶࠹࠰࠻࠵࠴࠶࠽࠭ਬ")
#proxy = l111lll_ll_ (u"ࠨࡾࡿࡑࡾࡖࡲࡰࡺࡼ࡙ࡷࡲ࠽ࠨਭ")+l11llll1_ll_[6][1]
proxy = l111lll_ll_ (u"ࠩࠪਮ")
l11lll1_ll_ = [l111lll_ll_ (u"ࠪฬึอๅอࠩਯ"),l111lll_ll_ (u"ࠫศู๊ศสࠪਰ"),l111lll_ll_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭਱"),l111lll_ll_ (u"࠭วๅลฯ๋ืฯࠠศๆ็์า๐ษࠨਲ"),l111lll_ll_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬਲ਼"),l111lll_ll_ (u"ࠨสิห๊าࠠศๆอู๊๐ๅࠨ਴"),l111lll_ll_ (u"ࠩส่฾อศࠡไอห้࠭ਵ"),l111lll_ll_ (u"ࠪห้฿วษࠢส่่๋ศ๋๊อีࠥࡖࡃࠨਸ਼"),l111lll_ll_ (u"ࠫฬ๊ศาษ่ะࠬ਷"),l111lll_ll_ (u"่๊ࠬศ็ฬࠤ฾ัๅศ่ࠪਸ"),l111lll_ll_ (u"࠭วๅล็฽ฬฮࠧਹ"),l111lll_ll_ (u"ࠧศๆ่์็฿ࠠศๆๅำ๏๋ࠧ਺"),l111lll_ll_ (u"ࠨษู๎ๆࠦอะ์ฮห๐࠭਻"),l111lll_ll_ (u"ࠩส่็ืว็ࠢส่่ื๊ๆ਼ࠩ"),l111lll_ll_ (u"ࠪหุ๊วๆ์สฮࠥ๎ࠠศ่สุ๏ีࠧ਽"),l111lll_ll_ (u"ࠫฬ๊ใหสࠣ์ࠥอไศสะหะ࠭ਾ"),l111lll_ll_ (u"ࠬอไึ๊ิࠤํࠦวๅะ็ๅ๏อสࠨਿ")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==240: results = l11l1ll_ll_(url)
	elif mode==241: results = l1l11l1_ll_(url,text)
	elif mode==242: results = l1l11ll_ll_(url)
	elif mode==243: results = l11_ll_(url)
	elif mode==244: results = l1111l1_ll_(url,l111lll_ll_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙࡟ࡠࡡࠪੀ")+text)
	elif mode==245: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࡣࡤࡥࠧੁ")+text)
	elif mode==246: results = l1ll1lll_ll_(url)
	elif mode==247: results = l11lll1l_ll_(url)
	elif mode==248: results = l11l1ll1_ll_()
	elif mode==249: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll1_ll_():
	l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫੂ"),l111lll_ll_ (u"๊ࠩิฬࠦวๅ็๋ๆ฾ࠦࠢฤๅ๋ห๊ࠦวๅฮา๎ิࠨࠠโ์ࠣฬ฾฼ࠠศๆฦั๏อๆࠡใํ๋ࠥ์ฺ่่๊ࠢࠥอไฮฮหࠤ฻ีࠠศๆหีฬ๋ฬࠡ࠰ࠣ์์ึวࠡ์ึฬอࠦๅีๅ็อࠥ็๊ࠡฬื฾๏๊ࠠศๆไ๎ิ๐่่ษอࠤ࠳ࠦ็ั้ࠣห้๋ิไๆฬࠤุฮศ่ษ้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅลุ่๏่่ࠦ์ࠣฮ฽ํั๊ࠡอาฯ็๊ࠡสุ์ึฯฺࠠึ๋หห๐ษࠨ੃"))
	return
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ੄")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬ੅"):
		#l11l1ll1_ll_()
		#l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ੆"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪੇ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡉࡊࡋࡌࡆࡇ࡟ࠪੈ")+l111lll_ll_ (u"ࠨ็฼่ํ๋ษࠡ็๊้ฮࠦฬะษࠪ੉")+l111lll_ll_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ੊"),l111lll_ll_ (u"ࠪࠫੋ"),248)
		#l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩੌ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ੍"),l111lll_ll_ (u"࠭ࠧ੎"),9999)
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ੏"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ੐"),l111lll_ll_ (u"ࠩࠪੑ"),249,l111lll_ll_ (u"ࠪࠫ੒"),l111lll_ll_ (u"ࠫࠬ੓"),l111lll_ll_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ੔"))
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭੕"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ੖")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨใ็ฮึࠦๅฮัาࠫ੗"),l1ll1l1_ll_,246)
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ੘"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧਖ਼")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫๆ๊สาࠢๆห๊๊ࠧਗ਼"),l1ll1l1_ll_,247)
		l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪਜ਼"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩੜ"),l111lll_ll_ (u"ࠧࠨ੝"),9999)
	#l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨਫ਼"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭੟")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้๋า๋ัࠪ੠"),l1ll1l1_ll_,242,l111lll_ll_ (u"ࠫࠬ੡"),l111lll_ll_ (u"ࠬ࠭੢"),l111lll_ll_ (u"࠭࡭ࡰࡴࡨࠫ੣"))
	#l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ੤"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬ੥")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่ฬิศศำࠪ੦"),l1ll1l1_ll_,242,l111lll_ll_ (u"ࠪࠫ੧"),l111lll_ll_ (u"ࠫࠬ੨"),l111lll_ll_ (u"ࠬࡴࡥࡸࡵࠪ੩"))
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ੪"),l1ll1l1_ll_,l111lll_ll_ (u"ࠧࠨ੫"),headers,l111lll_ll_ (u"ࠨࠩ੬"),l111lll_ll_ (u"ࠩࠪ੭"),l111lll_ll_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫ੮"))
	html = response.content
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠫࡷ࡫ࡣࡦࡰࡷࡰࡾ࠳ࡣࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ੯"),html,re.DOTALL)
	if l1ll111_ll_: l1ll111_ll_ = l1ll111_ll_[0]
	else: l1ll111_ll_ = l1ll1l1_ll_
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬੰ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪੱ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศุํๅࠥำฯ๋อสࠫੲ"),l1ll111_ll_,241)
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠨࡂ࡬ࡨࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧੳ"),html,re.DOTALL)
	if l1ll111_ll_: l1ll111_ll_ = l1ll111_ll_[0]
	else: l1ll111_ll_ = l1ll1l1_ll_
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩੴ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧੵ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ๅๆ์ีอࠬ੶"),l1ll111_ll_,241,l111lll_ll_ (u"ࠬ࠭੷"),l111lll_ll_ (u"࠭ࠧ੸"),l111lll_ll_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࠩ੹"))
	if l1111l_ll_==l111lll_ll_ (u"ࠨࠩ੺"): l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ੻"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭੼"),l111lll_ll_ (u"ࠫࠬ੽"),9999)
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧ࡮ࡣ࡬ࡲ࠲ࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯࡯࡭ࡸࡺࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳࡬ࡪࡵࡷࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊ࡫ࡩࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࠼ࠍࠍࠎࡨ࡬ࡰࡥ࡮ࠤࡂࠦࡨࡵ࡯࡯ࡣࡧࡲ࡯ࡤ࡭ࡶ࡟࠵ࡣࠊࠊࠋ࡬ࡸࡪࡳࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠤࡩࡳࡳࡺ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࠰ࡧࡲ࡯ࡤ࡭࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠊࠊࠋࡩࡳࡷࠦ࡬ࡪࡰ࡮࠰ࡹ࡯ࡴ࡭ࡧࠣ࡭ࡳࠦࡩࡵࡧࡰࡷ࠿ࠐࠉࠊࠋ࡬ࡪࠥࡺࡩࡵ࡮ࡨࠤࡳࡵࡴࠡ࡫ࡱࠤ࡮࡭࡮ࡰࡴࡨࡐࡎ࡙ࡔ࠻ࠢࡤࡨࡩࡓࡥ࡯ࡷࡌࡸࡪࡳࠨࠨࡨࡲࡰࡩ࡫ࡲࠨ࠮ࡰࡩࡳࡻ࡟࡯ࡣࡰࡩ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠵࠸࠶࠯ࠊࠊࠋ࡬ࡪࠥࡽࡥࡣࡵ࡬ࡸࡪࡃ࠽ࠨࠩ࠽ࠤࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡰ࡮ࡴ࡫ࠨ࠮ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ࠬࠨࠩ࠯࠽࠾࠿࠹ࠪࠌࠌࠦࠧࠨ੾")
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ੿"),l1ll111_ll_,l111lll_ll_ (u"ࠧࠨ઀"),headers,l111lll_ll_ (u"ࠨࠩઁ"),l111lll_ll_ (u"ࠩࠪં"),l111lll_ll_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡐࡉࡓ࡛࠭࠳ࡰࡧࠫઃ"))
	l1l111l1_ll_ = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦ࡭࡫ࡡࡥࡧࡵ࠱ࡹ࡯ࡴ࡭ࡧ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ࠲ࡁ࠵ࡤࡪࡸࡁࠫ઄"),l1l111l1_ll_,re.DOTALL)
	if l1lll_ll_:
		for link,title,block in l1lll_ll_:
			if l111lll_ll_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡃࠧઅ") not in block: continue
			if title not in l11lll1_ll_: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭આ"),l1l1l1l_ll_+title,link,241)
			items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ઇ"),block,re.DOTALL)
			for l11ll1ll_ll_,l11ll111_ll_ in items:
				l11lll11_ll_ = unescapeHTML(l11ll1ll_ll_)
				if title in [l111lll_ll_ (u"ࠨ็ึุ่๊วหࠩઈ"),l111lll_ll_ (u"ࠩฦๅ้อๅࠨઉ")]: l11l1lll_ll_ = title+l111lll_ll_ (u"ࠪࠤࠬઊ")+l11ll111_ll_
				else: l11l1lll_ll_ = l11ll111_ll_
				if l11ll111_ll_ not in l11lll1_ll_: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫઋ"),l1l1l1l_ll_+l11l1lll_ll_,l11lll11_ll_,241)
			if l1111l_ll_==l111lll_ll_ (u"ࠬ࠭ઌ"): l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫઍ"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ઎"),l111lll_ll_ (u"ࠨࠩએ"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡦࡥࡹ࡫ࡧࡰࡴ࡬ࡩࡸ࠳ࡢࡰࡺࠫ࠲࠯ࡅࠩ࠽ࡨࡲࡳࡹ࡫ࡲࠨઐ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ઑ"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			if title not in l11lll1_ll_: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ઒"),l1l1l1l_ll_+title,link,241)
	return
def l1ll1lll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠬ࠭ઓ")):
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"࠭ࠧઔ"),headers,l111lll_ll_ (u"ࠧࠨક"),l111lll_ll_ (u"ࠨࡃࡎ࡛ࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩખ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠨ࠯ࠬࡂ࠭ࡁࡴࡡࡷࠩગ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪઘ"),block,re.DOTALL)
		for link,title in items:
			if title not in l11lll1_ll_:
				title = title+l111lll_ll_ (u"๋ࠫࠥี็ใฬࠫઙ")
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬચ"),l1l1l1l_ll_+title,link,245)
		if l1111l_ll_==l111lll_ll_ (u"࠭ࠧછ"): l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬજ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫઝ"),l111lll_ll_ (u"ࠩࠪઞ"),9999)
	return html
def l11lll1l_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫટ")):
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬઠ"),headers,l111lll_ll_ (u"ࠬ࠭ડ"),l111lll_ll_ (u"࠭ࡁࡌ࡙ࡄࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧઢ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢ࡮ࡧࡱࡹ࠭࠴ࠪࡀࠫ࠿ࡲࡦࡼࠧણ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡷࡩࡽࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨત"),block,re.DOTALL)
		for link,title in items:
			if title not in l11lll1_ll_:
				title = title+l111lll_ll_ (u"้ࠩࠣๆ๊สาหࠪથ")
				l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪદ"),l1l1l1l_ll_+title,link,244)
		if l1111l_ll_==l111lll_ll_ (u"ࠫࠬધ"): l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪન"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ઩"),l111lll_ll_ (u"ࠧࠨપ"),9999)
	return html
def l1l11l1_ll_(url,type=l111lll_ll_ (u"ࠨࠩફ")):
	#l1ll1l_ll_(url,type)
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠩࠪબ"),headers,True,l111lll_ll_ (u"ࠪࡅࡐ࡝ࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ભ"))
	if type==l111lll_ll_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭મ"): l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹࡷࡪࡲࡨࡶ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲࠩ࠰࠭ࡃ࠮ࡹࡷࡪࡲࡨࡶ࠲ࡨࡵࡵࡶࡲࡲ࠲ࡶࡲࡦࡸࠪય"),html,re.DOTALL)
	else: l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹࠨࠨ࠯ࠬࡂ࠭ࡲࡧࡩ࡯࠯ࡩࡳࡴࡺࡥࡳࠩર"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡦࡰࡦࡹࡳ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡹ࡫ࡸࡵ࠯ࡺ࡬࡮ࡺࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ઱"),block,re.DOTALL)
		for img,link,title in items:
			if l111lll_ll_ (u"ࠨࡦࡤࡸࡦ࠳ࡳࡳࡥࠪલ") in img: img = img.split(l111lll_ll_ (u"ࠩࡧࡥࡹࡧ࠭ࡴࡴࡦࡁࠧ࠭ળ"))[1]
			if l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ઴") in link or l111lll_ll_ (u"ࠫ࠴ࡹࡨࡰࡹࡶ࠳ࠬવ") in link:
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬશ"),l1l1l1l_ll_+title,link,242,img)
			elif l111lll_ll_ (u"࠭࠯ࡱࡴࡲ࡫ࡷࡧ࡭ࡴ࠱ࠪષ") not in link and l111lll_ll_ (u"ࠧ࠰ࡩࡤࡱࡪࡹ࠯ࠨસ") not in link:
				l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧહ"),l1l1l1l_ll_+title,link,243,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ઺"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬ઻"),block,re.DOTALL)
		for link,title in items:
			if title==l111lll_ll_ (u"ࠫࠫࡲࡳࡢࡳࡸࡳࡀ઼࠭"): title = l111lll_ll_ (u"ูࠬวษไฬࠫઽ")
			if title==l111lll_ll_ (u"࠭ࠦࡳࡵࡤࡵࡺࡵ࠻ࠨા"): title = l111lll_ll_ (u"ࠧๅษะๆฮ࠭િ")
			link = unescapeHTML(link)
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨી"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨુ")+title,link,241)
	return
def l1lll1_ll_(search):
	# l1ll1l1l_ll_://l11lllll_ll_.net/search?q=%l1l11111_ll_%l1ll11l1_ll_%l1l11111_ll_%l1lll1ll_ll_%l1l11111_ll_%l1ll1111_ll_
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠪࠫૂ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠫࠬૃ"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠬࠦࠧૄ"),l111lll_ll_ (u"࠭ࠥ࠳࠲ࠪૅ"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨࡀࡳࡀࠫ૆")+l1llll1_ll_
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࡕࡈࡅࡗࡉࡈࡠࡃࡎࡓࡆࡓࠧે"))
	results = l1l11l1_ll_(url)
	return
def l1l11ll_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࡈࡔࡎ࡙ࡏࡅࡇࡖࡣࡆࡑࡗࡂࡏࠪૈ"))
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠪࠫૉ"),headers,True,l111lll_ll_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩ૊"))
	if l111lll_ll_ (u"ࠬ࠳ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨો") not in html:
		img = xbmc.getInfoLabel(l111lll_ll_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡋࡦࡳࡳ࠭ૌ"))
		l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ્࠭"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨำสฬ฼ࠦวๅฬื฾๏๊ࠧ૎"),url,243,img)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࠰ࡩࡵ࡯ࡳࡰࡦࡨࡷࠧࡄࠨ࠯ࠬࡂ࠭ࡨࡵ࡬࠮࡮ࡪ࠱࠽࠭૏"),html,re.DOTALL)
		block = l1lll_ll_[0]
		episodes = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩૐ"),block,re.DOTALL)
		for link,title,img in episodes:
			if l111lll_ll_ (u"ࠫฬ๊อๅไสฮࠬ૑") in title or l111lll_ll_ (u"๋่ࠬศี่ࠤฬิั๊ࠩ૒") in title: continue
			if l111lll_ll_ (u"࠭࠯ࡴࡧࡵ࡭ࡪࡹ࠯ࠨ૓") in link: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ૔"),l1l1l1l_ll_+title,link,242,img)
			else: l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ૕"),l1l1l1l_ll_+title,link,243,img)
	return
def l11_ll_(url):
	#l11l1ll1_ll_()
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#with open(l111lll_ll_ (u"ࠩࡖ࠾ࡡࡢࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ૖"), l111lll_ll_ (u"ࠪࡻࠬ૗")) as f: f.write(html)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠫࠬ૘"),headers,True,l111lll_ll_ (u"ࠬࡇࡋࡘࡃࡐ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭૙"))
	l1llll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡢࡦࡪࡩ࠳࠰࠿࠿࠰࠭ࡃ࠭ࡢࡷࠫࠫ࠱࠮ࡄࡂࠧ૚"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	l11ll11l_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡭࡫ࡁࡀࡦࠦࡨࡳࡧࡩࡁࠧࠩࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ૛"),html,re.DOTALL)
	#l11ll11l_ll_ = ([l111lll_ll_ (u"ࠨࠩ૜"),l111lll_ll_ (u"ࠩࠪ૝")],[l111lll_ll_ (u"ࠪࠫ૞"),l111lll_ll_ (u"ࠫࠬ૟")])
	l1l111l_ll_,l1111ll_ll_,l1lll1l_ll_,qualities = [],[],[],[]
	if l11ll11l_ll_:
		filetype = l111lll_ll_ (u"ࠬࡳࡰ࠵ࠩૠ")
		for l11ll1l1_ll_,quality in l11ll11l_ll_:
			l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡴࡢࡤ࠰ࡧࡴࡴࡴࡦࡰࡷࠤࡶࡻࡡ࡭࡫ࡷࡽࠧࠦࡩࡥ࠿ࠥࠫૡ")+l11ll1l1_ll_+l111lll_ll_ (u"ࠧࠣ࠰࠭ࡃࡁ࠵ࡤࡪࡸࡁ࠲ࡡࡹࠪ࠽࠱ࡧ࡭ࡻࡄࠧૢ"),html,re.DOTALL)
			block = l1lll_ll_[0]
			l1lll1l_ll_.append(block)
			qualities.append(quality)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡳࡸࡥࡱ࡯ࡴࡪࡧࡶࠬ࠳࠰࠿ࠪ࠾࡫࠷࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨૣ"),html,re.DOTALL)
		block,filename = l1lll_ll_[0]
		l11l11_ll_ = [l111lll_ll_ (u"ࠩࡽ࡭ࡵ࠭૤"),l111lll_ll_ (u"ࠪࡶࡦࡸࠧ૥"),l111lll_ll_ (u"ࠫࡹࡾࡴࠨ૦"),l111lll_ll_ (u"ࠬࡶࡤࡧࠩ૧"),l111lll_ll_ (u"࠭ࡨࡵ࡯ࠪ૨"),l111lll_ll_ (u"ࠧࡵࡣࡵࠫ૩"),l111lll_ll_ (u"ࠨ࡫ࡶࡳࠬ૪"),l111lll_ll_ (u"ࠩ࡫ࡸࡲࡲࠧ૫")]
		filetype = filename.rsplit(l111lll_ll_ (u"ࠪ࠲ࠬ૬"),1)[1].strip(l111lll_ll_ (u"ࠫࠥ࠭૭"))
		if filetype in l11l11_ll_:
			l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ૮"),l111lll_ll_ (u"࠭วๅ็็ๅ๊๊ࠥิࠢไ๎ิ๐่๊ࠡ็หࠥ฻่หࠩ૯"))
			return
		l1lll1l_ll_.append(block)
		qualities.append(l111lll_ll_ (u"ࠧࠨ૰"))
	for i in range(len(l1lll1l_ll_)):
		links = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡬ࡧࡴࡴ࠭ࠩ࠰࠭ࡃ࠮ࠨࠧ૱"),l1lll1l_ll_[i],re.DOTALL)
		for link,icon in links:
			if l111lll_ll_ (u"ࠩࡷࡳࡷࡸࡥ࡯ࡶࠪ૲") in icon: continue
			#elif l111lll_ll_ (u"ࠪࡴࡱࡧࡹࠨ૳") in icon: continue
			elif l111lll_ll_ (u"ࠫࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭૴") in icon: type = l111lll_ll_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ૵")
			elif l111lll_ll_ (u"࠭ࡰ࡭ࡣࡼࠫ૶") in icon: type = l111lll_ll_ (u"ࠧࡸࡣࡷࡧ࡭࠭૷")
			else: type = l111lll_ll_ (u"ࠨࡷࡱ࡯ࡳࡵࡷ࡯ࠩ૸")
			#title = qualities[i]+l111lll_ll_ (u"้้ࠩࠣ็ࠠࠨૹ")+type
			#l1111ll_ll_.append(title)
			link = link+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࡣࡤ࠭ૺ")+type+l111lll_ll_ (u"ࠫࡤࡥ࡟ࡠࠩૻ")+qualities[i]+l111lll_ll_ (u"ࠬࡥ࡟ࡢ࡭ࡺࡥࡲ࠭ૼ")
			l1l111l_ll_.append(link)
	#selection = l1l1111_ll_(l111lll_ll_ (u"࠭ࡔࡆࡕࡗࠫ૽"),l1111ll_ll_)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠧࡕࡇࡖࡘࠬ૾"),l1l111l_ll_)
	import l1_ll_
	l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ૿"))
	return
def l1111l1_ll_(url,filter):
	filter = filter.replace(l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ଀"),l111lll_ll_ (u"ࠪࠫଁ"))
	#l1ll1l_ll_(filter,url)
	l1l1ll1l_ll_ = [l111lll_ll_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࠬଂ"),l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧଃ"),l111lll_ll_ (u"࠭ࡹࡦࡣࡵࠫ଄"),l111lll_ll_ (u"ࠧࡳࡣࡷ࡭ࡳ࡭ࠧଅ")]
	if l111lll_ll_ (u"ࠨࡁࠪଆ") in url: url = url.split(l111lll_ll_ (u"ࠩࡂࠫଇ"))[0]
	type,filter = filter.split(l111lll_ll_ (u"ࠪࡣࡤࡥࠧଈ"),1)
	if filter==l111lll_ll_ (u"ࠫࠬଉ"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"ࠬ࠭ଊ"),l111lll_ll_ (u"࠭ࠧଋ")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"ࠧࡠࡡࡢࠫଌ"))
	if type==l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬ଍"):
		if l1l1ll1l_ll_[0]+l111lll_ll_ (u"ࠩࡀࠫ଎") not in l1l1l1ll_ll_: category = l1l1ll1l_ll_[0]
		for i in range(len(l1l1ll1l_ll_[0:-1])):
			if l1l1ll1l_ll_[i]+l111lll_ll_ (u"ࠪࡁࠬଏ") in l1l1l1ll_ll_: category = l1l1ll1l_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠫࠫ࠭ଐ")+category+l111lll_ll_ (u"ࠬࡃ࠰ࠨ଑")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"࠭ࠦࠨ଒")+category+l111lll_ll_ (u"ࠧ࠾࠲ࠪଓ")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"ࠨࠨࠪଔ"))+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭କ")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠪࠪࠬଖ"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠫࡦࡲ࡬ࠨଗ"))
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠬࡅࠧଘ")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"࠭ࡆࡊࡎࡗࡉࡗ࡙ࠧଙ"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡹࡥࡱࡻࡥࡴࠩଚ"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"ࠨࠩଛ"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠩࡤࡰࡱ࠭ଜ"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠪࠫଝ"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"ࠫࡄ࠭ଞ")+l1l1l1l1_ll_
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬଟ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭รู้สี่ࠥวว็ฬࠤฬ๊แ๋ัํ์ࠥอไห์ࠣฮ๊ࠦวฯฬํหึํวࠨଠ"),l1ll111_ll_,241,l111lll_ll_ (u"ࠧࠨଡ"),l111lll_ll_ (u"ࠨ࠳ࠪଢ"))
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩଣ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪࠤࡠࡡࠠࠡࠢࠪତ")+l1l1111l_ll_+l111lll_ll_ (u"ࠫࠥࠦࠠ࡞࡟ࠪଥ"),l1ll111_ll_,241,l111lll_ll_ (u"ࠬ࠭ଦ"),l111lll_ll_ (u"࠭࠱ࠨଧ"))
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬନ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ଩"),l111lll_ll_ (u"ࠩࠪପ"),9999)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠪࠫଫ"),headers,True,l111lll_ll_ (u"ࠫࡆࡑࡗࡂࡏ࠰ࡊࡎࡒࡔࡆࡔࡖࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ବ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡦࡰࡴࡰࠤ࡮ࡪࠨ࠯ࠬࡂ࠭ࡁ࠵ࡦࡰࡴࡰࡂࠬଭ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l11111l_ll_ = re.findall(l111lll_ll_ (u"࠭࠼ࡴࡧ࡯ࡩࡨࡺ࠮ࠫࡁࡱࡥࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡃ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡸ࡫࡬ࡦࡥࡷࡂࠬମ"),block,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨଯ"),str(l11111l_ll_))
	dict = {}
	for l1lllll1_ll_,name,block in l11111l_ll_:
		#name = name.replace(l111lll_ll_ (u"ࠨ࠯࠰ࠫର"),l111lll_ll_ (u"ࠩࠪ଱"))
		items = re.findall(l111lll_ll_ (u"ࠪࡀࡴࡶࡴࡪࡱࡱࠬ࠳࠰࠿ࠪࡀࠫ࠲࠯ࡅࠩ࠽ࠩଲ"),block,re.DOTALL)
		if l111lll_ll_ (u"ࠫࡂ࠭ଳ") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠬࡉࡁࡕࡇࡊࡓࡗࡏࡅࡔࠩ଴"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࡢࡣࡤ࠭ଵ")+l1l1llll_ll_)
				return
			else:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧଶ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ะ๊๐ูࠨଷ"),l1ll111_ll_,241,l111lll_ll_ (u"ࠩࠪସ"),l111lll_ll_ (u"ࠪ࠵ࠬହ"))
				else: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ଺"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไอ็ํ฽ࠬ଻"),l1ll111_ll_,245,l111lll_ll_ (u"଼࠭ࠧ"),l111lll_ll_ (u"ࠧࠨଽ"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩା"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠩࠩࠫି")+l1lllll1_ll_+l111lll_ll_ (u"ࠪࡁ࠵࠭ୀ")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠫࠫ࠭ୁ")+l1lllll1_ll_+l111lll_ll_ (u"ࠬࡃ࠰ࠨୂ")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪୃ")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧୄ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ะ๊๐ูࠡ࠼ࠣࠫ୅")+name,l1ll111_ll_,244,l111lll_ll_ (u"ࠩࠪ୆"),l111lll_ll_ (u"ࠪࠫେ"),l1l1llll_ll_+l111lll_ll_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭ୈ"))
		dict[l1lllll1_ll_] = {}
		for value,option in items:
			if option in l11lll1_ll_: continue
			if l111lll_ll_ (u"ࠬࡼࡡ࡭ࡷࡨࠫ୉") not in value: value = option
			else: value = re.findall(l111lll_ll_ (u"࠭ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ୊"),value,re.DOTALL)[0]
			dict[l1lllll1_ll_][value] = option
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠧࠧࠩୋ")+l1lllll1_ll_+l111lll_ll_ (u"ࠨ࠿ࠪୌ")+option
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"୍ࠩࠩࠫ")+l1lllll1_ll_+l111lll_ll_ (u"ࠪࡁࠬ୎")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ୏")+l1ll1l11_ll_
			title = option+l111lll_ll_ (u"ࠬࠦ࠺ࠡࠩ୐")#+dict[l1lllll1_ll_][l111lll_ll_ (u"࠭࠰ࠨ୑")]
			title = option+l111lll_ll_ (u"ࠧࠡ࠼ࠣࠫ୒")+name
			if type==l111lll_ll_ (u"ࠨࡈࡌࡐ࡙ࡋࡒࡔࠩ୓"): l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ୔"),l1l1l1l_ll_+title,url,244,l111lll_ll_ (u"ࠪࠫ୕"),l111lll_ll_ (u"ࠫࠬୖ"),l1llll1l_ll_+l111lll_ll_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧୗ"))
			elif type==l111lll_ll_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ୘") and l1l1ll1l_ll_[-2]+l111lll_ll_ (u"ࠧ࠾ࠩ୙") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠨࡣ࡯ࡰࠬ୚"))
				l11ll1_ll_ = url+l111lll_ll_ (u"ࠩࡂࠫ୛")+l1l11ll1_ll_
				l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪଡ଼"),l1l1l1l_ll_+title,l11ll1_ll_,241,l111lll_ll_ (u"ࠫࠬଢ଼"),l111lll_ll_ (u"ࠬ࠷ࠧ୞"))
			else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ୟ"),l1l1l1l_ll_+title,url,245,l111lll_ll_ (u"ࠧࠨୠ"),l111lll_ll_ (u"ࠨࠩୡ"),l1llll1l_ll_)
	return
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠩࡕࡉࡈࡕࡎࡔࡖࡕ࡙ࡈ࡚࡟ࡇࡋࡏࡘࡊࡘࠠ࠲࠳ࠪୢ"))
	# mode==l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤࡼࡡ࡭ࡷࡨࡷࠬୣ")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ୤")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"ࠬࡧ࡬࡭ࠩ୥")					all filters (l1l11l11_ll_ empty filter)
	#filters = filters.replace(l111lll_ll_ (u"࠭࠽ࠧࠩ୦"),l111lll_ll_ (u"ࠧ࠾࠲ࠩࠫ୧"))
	filters = filters.strip(l111lll_ll_ (u"ࠨࠨࠪ୨"))
	l1l1ll11_ll_ = {}
	if l111lll_ll_ (u"ࠩࡀࠫ୩") in filters:
		items = filters.split(l111lll_ll_ (u"ࠪࠪࠬ୪"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"ࠫࡂ࠭୫"))
			l1l1ll11_ll_[var] = value
	l1llll11_ll_ = l111lll_ll_ (u"ࠬ࠭୬")
	l1lll1l1_ll_ = [l111lll_ll_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴࠧ୭"),l111lll_ll_ (u"ࠧࡤࡣࡷࡩ࡬ࡵࡲࡺࠩ୮"),l111lll_ll_ (u"ࠨࡴࡤࡸ࡮ࡴࡧࠨ୯"),l111lll_ll_ (u"ࠩࡼࡩࡦࡸࠧ୰"),l111lll_ll_ (u"ࠪࡰࡦࡴࡧࡶࡣࡪࡩࠬୱ"),l111lll_ll_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ୲"),l111lll_ll_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭୳")]
	for key in l1lll1l1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"࠭࠰ࠨ୴")
		#if l111lll_ll_ (u"ࠧࠦࠩ୵") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪ୶") and value!=l111lll_ll_ (u"ࠩ࠳ࠫ୷"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠪࠤ࠰ࠦࠧ୸")+value
		elif mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡦࡪ࡮ࡷࡩࡷࡹࠧ୹") and value!=l111lll_ll_ (u"ࠬ࠶ࠧ୺"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"࠭ࠦࠨ୻")+key+l111lll_ll_ (u"ࠧ࠾ࠩ୼")+value
		elif mode==l111lll_ll_ (u"ࠨࡣ࡯ࡰࠬ୽"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠩࠩࠫ୾")+key+l111lll_ll_ (u"ࠪࡁࠬ୿")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠫࠥ࠱ࠠࠨ஀"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠬࠬࠧ஁"))
	#l1llll11_ll_ = l1llll11_ll_.replace(l111lll_ll_ (u"࠭࠽࠱ࠩஂ"),l111lll_ll_ (u"ࠧ࠾ࠩஃ"))
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠨࡔࡈࡇࡔࡔࡓࡕࡔࡘࡇ࡙ࡥࡆࡊࡎࡗࡉࡗࠦ࠲࠳ࠩ஄"))
	return l1llll11_ll_