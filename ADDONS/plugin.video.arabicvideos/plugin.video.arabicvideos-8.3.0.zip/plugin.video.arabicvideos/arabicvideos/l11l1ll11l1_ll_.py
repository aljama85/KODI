# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"࠭ࡍࡐࡘࡖ࠸࡚࠭⺺")
l1l1l1l_ll_=l111lll_ll_ (u"ࠧࡠࡏ࡙ࡊࡤ࠭⺻")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ࠨษ้์ฬ฿ࠠศใ็ห๊࠭⺼"),l111lll_ll_ (u"ࠩฯ์ิอสࠡษไ่ฬ๋ࠧ⺽")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==380: results = l11l1ll_ll_(url)
	elif mode==381: results = l1l11l1_ll_(url,text)
	elif mode==382: results = l11_ll_(url)
	elif mode==383: results = l1l11ll_ll_(url)
	elif mode==389: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ⺾")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬ⺿"):
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻀"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭⻁"),l111lll_ll_ (u"ࠧࠨ⻂"),389,l111lll_ll_ (u"ࠨࠩ⻃"),l111lll_ll_ (u"ࠩࠪ⻄"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ⻅"))
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ⻆"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⻇"),l111lll_ll_ (u"࠭ࠧ⻈"),9999)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⻉"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็้๊๐าสࠩ⻊"),l1ll1l1_ll_,381,l111lll_ll_ (u"ࠩࠪ⻋"),l111lll_ll_ (u"ࠪࠫ⻌"),l111lll_ll_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⻍"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⻎"),l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅฮส๊อ๐ษࠨ⻏"),l1ll1l1_ll_,381,l111lll_ll_ (u"ࠧࠨ⻐"),l111lll_ll_ (u"ࠨࠩ⻑"),l111lll_ll_ (u"ࠩࡶ࡭ࡩ࡫ࡲࠨ⻒"))
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ⻓"),l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬ⻔"),l111lll_ll_ (u"ࠬ࠭⻕"),l111lll_ll_ (u"࠭ࠧ⻖"),l111lll_ll_ (u"ࠧࠨ⻗"),l111lll_ll_ (u"ࠨࡏࡒ࡚ࡘ࠺ࡕ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ⻘"))
	html = response.content
	items = re.findall(l111lll_ll_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⻙"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⻚"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ⻛")+l1l1l1l_ll_+title,l1ll1l1_ll_,381,l111lll_ll_ (u"ࠬ࠭⻜"),l111lll_ll_ (u"࠭ࠧ⻝"),l111lll_ll_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⻞")+str(seq))
	block = l111lll_ll_ (u"ࠨࠩ⻟")
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡰࡩࡳࡻࠢࠩ࠰࠭ࡃ࠮࡯ࡤ࠾ࠤࡦࡳࡳࡺࡥ࡯ࡧࡧࡳࡷࠨࠧ⻠"),html,re.DOTALL)
	if l1lll_ll_: block += l1lll_ll_[0]
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷ࡮ࡪࡥࡣࡣࡵࠬ࠳࠰࠿ࠪࡣࡶ࡭ࡩ࡫ࠧ⻡"),html,re.DOTALL)
	if l1lll_ll_: block += l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⻢"),block,re.DOTALL)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ⻣"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⻤"),l111lll_ll_ (u"ࠧࠨ⻥"),9999)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l111lll_ll_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨ⻦"):
			if first:
				title = l111lll_ll_ (u"ࠩส่ฬ็ไศ็ࠣࠫ⻧")+title
				first = False
			else: title = l111lll_ll_ (u"ࠪห้๋ำๅี็หฯࠦࠧ⻨")+title
		if title not in l11lll1_ll_:
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⻩"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ⻪")+l1l1l1l_ll_+title,link,381)
	return html
def l1l11l1_ll_(url,type):
	#l1ll1l_ll_(url,type)
	#l1l1l1111_ll_(html)
	block,items = [],[]
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ⻫"),url,l111lll_ll_ (u"ࠧࠨ⻬"),l111lll_ll_ (u"ࠨࠩ⻭"),l111lll_ll_ (u"ࠩࠪ⻮"),l111lll_ll_ (u"ࠪࠫ⻯"),l111lll_ll_ (u"ࠫࡒࡕࡖࡔ࠶ࡘ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨ⻰"))
	html = response.content
	if type==l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ⻱"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡳࡦࡣࡵࡧ࡭࠳ࡰࡢࡩࡨࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡶ࡭ࡩ࡫ࡢࡢࡴࠪ⻲"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠧࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⻳"),block,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠨࡵ࡬ࡨࡪࡸࠧ⻴"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡺ࡭ࡩ࡭ࡥࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠭⻵"),html,re.DOTALL)
		block = l1lll_ll_[0]
		z = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬ⻶"),block,re.DOTALL)
		l1l111l_ll_,l1l11ll11_ll_,l1111ll_ll_ = zip(*z)
		items = zip(l1l11ll11_ll_,l1l111l_ll_,l1111ll_ll_)
	elif type==l111lll_ll_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭⻷"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡯ࡤ࠾ࠤࡶࡰ࡮ࡪࡥࡳ࠯ࡰࡳࡻ࡯ࡥࡴ࠯ࡷࡺࡸ࡮࡯ࡸࡵࠥࠬ࠳࠰࠿ࠪ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⻸"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⻹"),block,re.DOTALL)
	elif l111lll_ll_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ⻺") in type:
		seq = int(type[-1:])
		html = html.replace(l111lll_ll_ (u"ࠨ࠾࡫ࡩࡦࡪࡥࡳࡀࠪ⻻"),l111lll_ll_ (u"ࠩ࠿ࡩࡳࡪ࠾࠽ࡵࡷࡥࡷࡺ࠾ࠨ⻼"))
		html = html.replace(l111lll_ll_ (u"ࠪࡀࡩ࡯ࡶࠡࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡬ࡨࡪࡨࡡࡳࠩ⻽"),l111lll_ll_ (u"ࠫࡁ࡫࡮ࡥࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࠨ⻾"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡳࡵࡣࡵࡸࡃ࠮࠮ࠫࡁࠬࡀࡪࡴࡤ࠿ࠩ⻿"),html,re.DOTALL)
		block = l1lll_ll_[seq]
		if seq==2: items = re.findall(l111lll_ll_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ⼀"),block,re.DOTALL)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࠨࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࢀࡸ࡯ࡤࡦࡤࡤࡶ࠮࠭⼁"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0][0]
			if l111lll_ll_ (u"ࠨ࠱ࡦࡳࡱࡲࡥࡤࡶ࡬ࡳࡳ࠵ࠧ⼂") in url:
				items = re.findall(l111lll_ll_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ⼃"),block,re.DOTALL)
			elif l111lll_ll_ (u"ࠪ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠭⼄") in url:
				items = re.findall(l111lll_ll_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࠥࡸ࡮ࡺ࡬ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⼅"),block,re.DOTALL)
	if not items and block:
		items = re.findall(l111lll_ll_ (u"ࠬ࡯࡭ࡨࠢࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ⼆"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for img,link,title in items:
		if l111lll_ll_ (u"࠭ࡳࡦࡴ࡬ࡩࠬ⼇") in title:
			title = re.findall(l111lll_ll_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡷࡪࡸࡩࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ⼈"),title,re.DOTALL)
			title = title[0][1]#+l111lll_ll_ (u"ࠨࠢ࠰ࠤࠬ⼉")+title[0][0]
			if title in l1ll11ll_ll_: continue
			l1ll11ll_ll_.append(title)
			title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟ࠨ⼊")+title
		l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡢ࠭࠴ࠪࡀࠫ࠿ࠫ⼋"),title,re.DOTALL)
		if l11ll111_ll_: title = l11ll111_ll_[0]
		title = unescapeHTML(title)
		if l111lll_ll_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ⼌") in link: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⼍"),l1l1l1l_ll_+title,link,383,img)
		elif l111lll_ll_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥࡴ࠱ࠪ⼎") in link: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⼏"),l1l1l1l_ll_+title,link,383,img)
		elif l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯ࡵ࠲ࠫ⼐") in link: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼑"),l1l1l1l_ll_+title,link,383,img)
		elif l111lll_ll_ (u"ࠪ࠳ࡨࡵ࡬࡭ࡧࡦࡸ࡮ࡵ࡮࠰ࠩ⼒") in link: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ⼓"),l1l1l1l_ll_+title,link,381,img)
		else: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ⼔"),l1l1l1l_ll_+title,link,382,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥ࠲࠯ࡅࡐࡢࡩࡨࠤ࠭࠴ࠪࡀࠫࠣࡳ࡫ࠦࠨ࠯ࠬࡂ࠭ࡁ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ⼕"),html,re.DOTALL)
	if l1lll_ll_:
		current = l1lll_ll_[0][0]
		last = l1lll_ll_[0][1]
		block = l1lll_ll_[0][2]
		items = re.findall(l111lll_ll_ (u"ࠢࡩࡴࡨࡪࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠤ⼖"),block,re.DOTALL)
		for link,title in items:
			if title==l111lll_ll_ (u"ࠨࠩ⼗") or title==last: continue
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⼘"),l1l1l1l_ll_+l111lll_ll_ (u"ูࠪๆำษࠡࠩ⼙")+title,link,381,l111lll_ll_ (u"ࠫࠬ⼚"),l111lll_ll_ (u"ࠬ࠭⼛"),type)
		#if title==last:
		link = link.replace(l111lll_ll_ (u"࠭࠯ࡱࡣࡪࡩ࠴࠭⼜")+title+l111lll_ll_ (u"ࠧ࠰ࠩ⼝"),l111lll_ll_ (u"ࠨ࠱ࡳࡥ࡬࡫࠯ࠨ⼞")+last+l111lll_ll_ (u"ࠩ࠲ࠫ⼟"))
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⼠"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬิัࠡืไัฮࠦࠧ⼡")+last,link,381,l111lll_ll_ (u"ࠬ࠭⼢"),l111lll_ll_ (u"࠭ࠧ⼣"),type)
	return
def l1l11ll_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ⼤"),url,l111lll_ll_ (u"ࠨࠩ⼥"),l111lll_ll_ (u"ࠩࠪ⼦"),l111lll_ll_ (u"ࠪࠫ⼧"),l111lll_ll_ (u"ࠫࠬ⼨"),l111lll_ll_ (u"ࠬࡓࡏࡗࡕ࠷࡙࠲ࡋࡐࡊࡕࡒࡈࡊ࡙࠭࠲ࡵࡷࠫ⼩"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ⼪"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_,False):
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⼫"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ุ้๊ำๅࠢ็่่ฮวา๋ࠢห้๋ศา็ฯࠤ๊์ู่ࠩ⼬"),l111lll_ll_ (u"ࠩࠪ⼭"),9999)
		return
	if l111lll_ll_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧ⼮") in url or l111lll_ll_ (u"ࠫ࠴ࡺࡶࡴࡪࡲࡻࡸ࠵ࠧ⼯") in url:
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬ࠭ࠧࡤ࡮ࡤࡷࡸࡃࠧࡪࡶࡨࡱࠬࡄ࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨࠩࠪ⼰"),html,re.DOTALL)
		if l1ll111_ll_:
			l1ll111_ll_ = l1ll111_ll_[1]
			l1l11ll_ll_(l1ll111_ll_)
			return
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࠧࠨࡥ࡯ࡥࡸࡹ࠽ࠨࡧࡳ࡭ࡸࡵࡤࡪࡱࡶࠫ࠭࠴ࠪࡀࠫ࡬ࡨࡂࠨࡣࡢࡵࡷࠦࠬ࠭ࠧ⼱"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࠨࠩࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࡦࡰࡦࡹࡳ࠾ࠩࡱࡹࡲ࡫ࡲࡢࡰࡧࡳࠬࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠾ࠩ࠰࠭ࡃ࠮ࡂࠧࠨࠩ⼲"),block,re.DOTALL)
		for img,episode,link,name in items:
			title = episode+l111lll_ll_ (u"ࠨࠢ࠽ࠤࠬ⼳")+name+l111lll_ll_ (u"ࠩࠣห้ำไใหࠪ⼴")
			l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ⼵"),l1l1l1l_ll_+title,link,382)
	return
def l11_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ⼶"),url,l111lll_ll_ (u"ࠬ࠭⼷"),l111lll_ll_ (u"࠭ࠧ⼸"),l111lll_ll_ (u"ࠧࠨ⼹"),l111lll_ll_ (u"ࠨࠩ⼺"),l111lll_ll_ (u"ࠩࡐࡓ࡛࡙࠴ࡖ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ⼻"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡇࠥࡸࡡࡵࡧࡧࠦ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ⼼"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	l1l111l_ll_ = []
	# watch links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠦࠧࠨࡩࡥ࠿ࠪࡴࡱࡧࡹࡦࡴ࠰ࡳࡵࡺࡩࡰࡰ࠰࠵ࠬ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠫࠦࡸ࡮ࡥࡢࡦࡨࡶࠧࢂࠧࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ࠩࠣࠤࠥ⼽"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0][0]
		items = re.findall(l111lll_ll_ (u"ࠧࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠪࡷࡪࡸࡶࡦࡴࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦ⼾"),block,re.DOTALL)
		for link,title in items:
			link = link+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ⼿")+title+l111lll_ll_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ⽀")
			l1l111l_ll_.append(link)
	# download links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡴࡨࡱࡴࡪࡡ࡭ࠤࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡳࡧࡰࡳࡩࡧ࡬࠮ࡥ࡯ࡳࡸ࡫ࠢࠨ⽁"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡢࡣࡤࡪ࡬ࡠࡩࡧࡶ࡮ࡼࡥ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭⽂"),block,re.DOTALL)
		for link,title in items:
			link = l1ll1l1_ll_+link
			link = link+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ⽃")+title+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨ⽄")
			l1l111l_ll_.append(link)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ⽅"), l1l111l_ll_)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⽆"),l111lll_ll_ (u"ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐็ࠡใํำ๏๎ࠧ⽇"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ⽈"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠩࠪ⽉"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠪࠫ⽊"): return
	search = search.replace(l111lll_ll_ (u"ࠫࠥ࠭⽋"),l111lll_ll_ (u"ࠬ࠱ࠧ⽌"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡀࡵࡀࠫ⽍")+search
	l1l11l1_ll_(url,l111lll_ll_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧ⽎"))
	return