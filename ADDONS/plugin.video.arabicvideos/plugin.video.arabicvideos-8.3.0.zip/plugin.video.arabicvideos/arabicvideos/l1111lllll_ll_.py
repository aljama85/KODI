# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠬࡏࡐࡕࡘࠪᯆ")
l1l1l1l_ll_=l111lll_ll_ (u"࠭࡟ࡊࡒࡗࡣࠬᯇ")
def l111l1l_ll_(mode,url,text,type):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᯈ"),l111lll_ll_ (u"ࠨࡵࡷࡥࡷࡺࠧᯉ"))
	if   mode==230: results = l11l1ll_ll_()
	elif mode==231: results = l1llll111ll_ll_()
	elif mode==232: results = l1lllllll11_ll_(True)
	elif mode==233: results = l1lllll1l11_ll_(url,text)
	elif mode==234: results = l11ll1l11l_ll_(url,text)
	elif mode==235: results = l11_ll_(url,type)
	elif mode==236: results = l1llll1lll1_ll_(True)
	elif mode==237: results = l111111ll1_ll_(True)
	elif mode==238: results = l111ll11l1_ll_(url,text)
	elif mode==239: results = l1lll1_ll_(text)
	elif mode==280: results = l1lllll1lll_ll_()
	elif mode==281: results = l1llll11l11_ll_()
	else: results = False
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᯊ"),l111lll_ll_ (u"ࠪࡩࡳࡪࠧᯋ"))
	return results
def l11l1ll_ll_():
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯌ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᯍ")+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦๅๅใสฮࠥࡏࡐࡕࡘࠪᯎ"),l111lll_ll_ (u"ࠧࠨᯏ"),239,l111lll_ll_ (u"ࠨࠩᯐ"),l111lll_ll_ (u"ࠩࠪᯑ"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧᯒ"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯓ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᯔ")+l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࠤ็อฦๆหࠣว็ูวๆࠢส่ๅ࠭ᯕ"),l111lll_ll_ (u"ࠧࠨᯖ"),165,l111lll_ll_ (u"ࠨࠩᯗ"),l111lll_ll_ (u"ࠩࠪᯘ"),l111lll_ll_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪᯙ"))
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩᯚ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᯛ"),l111lll_ll_ (u"࠭ࠧᯜ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᯝ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡍࡕ࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᯞ")+l111lll_ll_ (u"ࠩๅ๊ํอสࠡ็ุ๊ๆฯࠧᯟ"),l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅࠩᯠ"),233)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᯡ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᯢ")+l111lll_ll_ (u"࠭รโๆส้๋ࠥี็ใฬࠫᯣ"),l111lll_ll_ (u"ࠧࡗࡑࡇࡣࡒࡕࡖࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬᯤ"),233)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᯥ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡎࡖࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠ᯦ࠫ")+l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤ๊฻ๆโหࠪᯧ"),l111lll_ll_ (u"࡛ࠫࡕࡄࡠࡕࡈࡖࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩᯨ"),233)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᯩ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡋࡓࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᯪ")+l111lll_ll_ (u"ࠧโ์า๎ํํวห่ࠢะ์๎ไสࠩᯫ"),l111lll_ll_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧᯬ"),233)
	#l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᯭ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡏࡐࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᯮ")+l111lll_ll_ (u"ࠫ็์่ศฬ้ࠣัํ่ๅหࠪᯯ"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫᯰ"),233)
	l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫᯱ"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟᯲ࠪ"),l111lll_ll_ (u"ࠨ᯳ࠩ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᯴"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡏࡐࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᯵")+l111lll_ll_ (u"ࠫ็์่ศฬฺ้ࠣ์แส๋้ࠢึะศสࠩ᯶"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᯷"),233)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᯸"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡌࡔ࡙ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ᯹")+l111lll_ll_ (u"ࠨลไ่ฬ๋ࠠๆื้ๅฮ่ࠦๆำอฬฮ࠭᯺"),l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᯻"),233)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᯼"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡉࡑࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᯽")+l111lll_ll_ (u"๋ࠬำๅี็หฯࠦๅึ่ไอࠥ๎ๅาฬหอࠬ᯾"),l111lll_ll_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫ᯿"),233)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᰀ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡍࡕ࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᰁ")+l111lll_ll_ (u"ࠩไ๎ิ๐่่ษอࠤ๊า็้ๆฬࠤํ๋ัหสฬࠫᰂ"),l111lll_ll_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᰃ"),233)
	#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰄ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᰅ")+l111lll_ll_ (u"࠭โ็๊สฮ๋ࠥฬ่๊็อࠬᰆ"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡓࡐࡔࡗࡉࡉ࠭ᰇ"),233)
	l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭ᰈ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᰉ"),l111lll_ll_ (u"ࠪࠫᰊ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᰋ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᰌ")+l111lll_ll_ (u"࠭วๅไ้์ฬะࠠศๆฦู้๐ษࠡสา์๋ࠦส฻์ํีࠬᰍ"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤࡕࡒࡊࡉࡌࡒࡆࡒ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨᰎ"),233)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰏ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡎࡖࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᰐ")+l111lll_ll_ (u"ࠪห้็๊ะ์๋๋ฬะࠠศๆฦู้๐ษࠡสา์๋ࠦส฻์ํีࠬᰑ"),l111lll_ll_ (u"࡛ࠫࡕࡄࡠࡑࡕࡍࡌࡏࡎࡂࡎࡢࡋࡗࡕࡕࡑࡇࡇࠫᰒ"),233)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪᰓ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰔ"),l111lll_ll_ (u"ࠧࠨᰕ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᰖ"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡎࡖࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᰗ")+l111lll_ll_ (u"ࠪๆ๋๎วหู่๋ࠢ็ษࠡ็้ࠤศูๅศศ๊หࠥ๎ๅาฬหอࠬᰘ"),l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡉࡖࡔࡓ࡟ࡏࡃࡐࡉࡤ࡙ࡏࡓࡖࡈࡈࠬᰙ"),233)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰚ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡋࡓࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᰛ")+l111lll_ll_ (u"ࠧโ์า๎ํํวหู่๋ࠢ็ษࠡ็้ࠤศูๅศศ๊หࠥ๎ๅาฬหอࠬᰜ"),l111lll_ll_ (u"ࠨࡘࡒࡈࡤࡌࡒࡐࡏࡢࡒࡆࡓࡅࡠࡕࡒࡖ࡙ࡋࡄࠨᰝ"),233)
	l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᰞ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᰟ"),l111lll_ll_ (u"ࠫࠬᰠ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᰡ"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡋࡓࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨᰢ")+l111lll_ll_ (u"ࠧใ่๋หฯࠦๅึ่ไอ๋ࠥๆࠡลๅืฬ๋็ศ๋้ࠢึะศสࠩᰣ"),l111lll_ll_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪᰤ"),233)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᰥ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡏࡐࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᰦ")+l111lll_ll_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦๅึ่ไอ๋ࠥๆࠡลๅืฬ๋็ศ๋้ࠢึะศสࠩᰧ"),l111lll_ll_ (u"ࠬ࡜ࡏࡅࡡࡉࡖࡔࡓ࡟ࡈࡔࡒ࡙ࡕࡥࡓࡐࡔࡗࡉࡉ࠭ᰨ"),233)
	l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫᰩ"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᰪ"),l111lll_ll_ (u"ࠨࠩᰫ"),9999)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᰬ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡏࡐࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬᰭ")+l111lll_ll_ (u"ࠫอืวๆฮࠣห้่ๆ้ษอࠤ࠭าฯ้ๆࠣๅ็฽ࠩࠨᰮ"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡉࡕࡍ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᰯ"),233)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᰰ"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡌࡔ࡙ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩᰱ")+l111lll_ll_ (u"ࠨลิุ๏็ࠠศๆๅ๊ํอสࠡๆ็ว๏อๅࠡษ็้ฬ฼๊สࠩᰲ"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡕࡋࡐࡉࡘࡎࡉࡇࡖࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᰳ"),233)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᰴ"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡉࡑࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ᰵ")+l111lll_ll_ (u"ࠬษัี์ไࠤอืวๆฮࠣห้่ๆ้ษอࠤ้๊ร๋ษ่ࠤฬ๊ๅศุํอࠬᰶ"),l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊ᰷ࠧ"),233)
	l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᰸"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᰹"),l111lll_ll_ (u"ࠩࠪ᰺"),9999)
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ᰻"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࡉࡑࡖࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭᰼")+l111lll_ll_ (u"ࠬหึศใฬࠤศ๎ࠠห฼ํ๎ึࠦวีฬิห่ࠦࡉࡑࡖ࡙ࠫ᰽"),l111lll_ll_ (u"࠭ࠧ᰾"),231)
	l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᰿"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡍࡕ࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ᱀")+l111lll_ll_ (u"ࠩ฼ำิࠦแ๋ัํ์์อสࠡࡋࡓࡘ࡛࠭᱁"),l111lll_ll_ (u"ࠪࠫ᱂"),281)
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ᱃"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡊࡒࡗࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ᱄")+l111lll_ll_ (u"࠭แฮืࠣหูะัศๅࠣࡍࡕ࡚ࡖࠨ᱅"),l111lll_ll_ (u"ࠧࠨ᱆"),236)
	l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭᱇"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡎࡖࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᱈")+l111lll_ll_ (u"ࠪะ้ฮࠠๆๆไหฯࠦࡉࡑࡖ࡙ࠫ᱉"),l111lll_ll_ (u"ࠫࠬ᱊"),232)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ᱋"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡋࡓࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ᱌")+l111lll_ll_ (u"ࠧๆีะࠤ๊๊แศฬࠣࡍࡕ࡚ࡖࠨᱍ"),l111lll_ll_ (u"ࠨࠩᱎ"),237)
	l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᱏ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡏࡐࡕࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ᱐")+l111lll_ll_ (u"ࠫฯเ๊๋ำࠣࡍࡕ࡚ࡖࠡࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ᱑"),l111lll_ll_ (u"ࠬ࠭᱒"),280)
	return
l11l1111ll_ll_ = [l111lll_ll_ (u"࠭ࡁࡍࡎࠪ᱓"),l111lll_ll_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࠬ᱔"),l111lll_ll_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭᱕")
		,l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡍࡐࡘࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧ᱖"),l111lll_ll_ (u"࡚ࠪࡔࡊ࡟ࡎࡑ࡙ࡍࡊ࡙࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨ᱗"),l111lll_ll_ (u"ࠫࡉ࡛ࡍࡎ࡛ࠪ᱘")
		,l111lll_ll_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ᱙"),l111lll_ll_ (u"࠭ࡖࡐࡆࡢࡊࡗࡕࡍࡠࡐࡄࡑࡊࡥࡓࡐࡔࡗࡉࡉ࠭ᱚ"),l111lll_ll_ (u"ࠧࡗࡑࡇࡣࡋࡘࡏࡎࡡࡊࡖࡔ࡛ࡐࡠࡕࡒࡖ࡙ࡋࡄࠨᱛ")
		,l111lll_ll_ (u"ࠨࡎࡌ࡚ࡊࡥࡁࡓࡅࡋࡍ࡛ࡋࡄࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᱜ"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡆࡒࡊࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᱝ"),l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࡠࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᱞ"),l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪᱟ")
		,l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭ᱠ"),l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡣࡋࡘࡏࡎࡡࡑࡅࡒࡋ࡟ࡔࡑࡕࡘࡊࡊࠧᱡ"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᱢ"),l111lll_ll_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡌࡘࡏࡖࡒࡢࡗࡔࡘࡔࡆࡆࠪᱣ")
		,l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨᱤ"),l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࡠࡗࡑࡏࡓࡕࡗࡏࡡࡖࡓࡗ࡚ࡅࡅࠩᱥ"),l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࠪᱦ"),l111lll_ll_ (u"ࠬ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇࡣࡘࡕࡒࡕࡇࡇࠫᱧ")]
def l1llll1lll1_ll_(l11111l11l_ll_=True):
	#if not l11111111l_ll_(True): return
	ok,status = False,l111lll_ll_ (u"࠭ࠧᱨ")
	l1ll11l11_ll_ = settings.getSetting(l111lll_ll_ (u"ࠧࡪࡲࡷࡺ࠳ࡻࡳࡦࡴࡤ࡫ࡪࡴࡴࠨᱩ"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࡅࡋࡉࡈࡑ࡟ࡂࡅࡆࡓ࡚ࡔࡔࠡ࠳ࠪᱪ"),l111lll_ll_ (u"ࠩ࡞ࠫᱫ")+l1ll11l11_ll_+l111lll_ll_ (u"ࠪࡡࠬᱬ"))
	l1lllll111l_ll_ = settings.getSetting(l111lll_ll_ (u"ࠫ࡮ࡶࡴࡷ࠰ࡸࡶࡱ࠭ᱭ"))
	headers = {l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩᱮ"):l1ll11l11_ll_}
	username = re.findall(l111lll_ll_ (u"࠭ࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠪ࠱࠮ࡄ࠯ࠦࠨᱯ"),l1lllll111l_ll_+l111lll_ll_ (u"ࠧࠧࠩᱰ"),re.DOTALL)
	password = re.findall(l111lll_ll_ (u"ࠨࡲࡤࡷࡸࡽ࡯ࡳࡦࡀࠬ࠳࠰࠿ࠪࠨࠪᱱ"),l1lllll111l_ll_+l111lll_ll_ (u"ࠩࠩࠫᱲ"),re.DOTALL)
	if username and password:
		username = username[0]
		password = password[0]
		l1lllll1l1l_ll_ = l1lllll111l_ll_.split(l111lll_ll_ (u"ࠪ࠳ࠬᱳ"))
		server = l1lllll1l1l_ll_[0]+l111lll_ll_ (u"ࠫ࠴࠵ࠧᱴ")+l1lllll1l1l_ll_[2]
		settings.setSetting(l111lll_ll_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬᱵ"),username)
		settings.setSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡵࡧࡳࡴࡹࡲࡶࡩ࠭ᱶ"),password)
		settings.setSetting(l111lll_ll_ (u"ࠧࡪࡲࡷࡺ࠳ࡹࡥࡳࡸࡨࡶࠬᱷ"),server)
		url = server+l111lll_ll_ (u"ࠨ࠱ࡳࡰࡦࡿࡥࡳࡡࡤࡴ࡮࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭ᱸ")+username+l111lll_ll_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ᱹ")+password
		response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧᱺ"),url,l111lll_ll_ (u"ࠫࠬᱻ"),headers,False,False,l111lll_ll_ (u"ࠬࡏࡐࡕࡘ࠰ࡇࡍࡋࡃࡌࡡࡄࡇࡈࡕࡕࡏࡖ࠰࠵ࡸࡺࠧᱼ"))
		html = response.content
		if response.succeeded:
			l1lllll11l1_ll_,l1llll1llll_ll_,l1llll1111l_ll_,l1111l11l1_ll_ = 0,l111lll_ll_ (u"࠭ࠧᱽ"),l111lll_ll_ (u"ࠧࠨ᱾"),l111lll_ll_ (u"ࠨࠩ᱿")
			try:
				dict = l111ll1lll_ll_(html)
				status = dict[l111lll_ll_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬᲀ")][l111lll_ll_ (u"ࠪࡷࡹࡧࡴࡶࡵࠪᲁ")]
				ok = True
				l1llll1llll_ll_ = dict[l111lll_ll_ (u"ࠫࡸ࡫ࡲࡷࡧࡵࡣ࡮ࡴࡦࡰࠩᲂ")][l111lll_ll_ (u"ࠬࡺࡩ࡮ࡧࡢࡲࡴࡽࠧᲃ")]
			except: pass
			if l1llll1llll_ll_:
				struct = time.strptime(l1llll1llll_ll_,l111lll_ll_ (u"࡚࠭ࠥ࠯ࠨࡱ࠲ࠫࡤࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪᲄ"))
				timestamp = int(time.mktime(struct))
				l1lllll11l1_ll_ = int(now-timestamp)
				# l1lllllll1l_ll_ to the l1llll1l1ll_ll_ l111ll1ll1_ll_ hour with 15 minutes error range
				l1lllll11l1_ll_ = int((l1lllll11l1_ll_+900)/1800)*1800
				struct = time.localtime(int(dict[l111lll_ll_ (u"ࠧࡶࡵࡨࡶࡤ࡯࡮ࡧࡱࠪᲅ")][l111lll_ll_ (u"ࠨࡥࡵࡩࡦࡺࡥࡥࡡࡤࡸࠬᲆ")]))
				l1llll1111l_ll_ = time.strftime(l111lll_ll_ (u"ࠩࠨ࡝࠲ࠫ࡭࠮ࠧࡧࠤࠥࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧᲇ"),struct)
				struct = time.localtime(int(dict[l111lll_ll_ (u"ࠪࡹࡸ࡫ࡲࡠ࡫ࡱࡪࡴ࠭ᲈ")][l111lll_ll_ (u"ࠫࡪࡾࡰࡠࡦࡤࡸࡪ࠭Ᲊ")]))
				l1111l11l1_ll_ = time.strftime(l111lll_ll_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪࠠࠡࠧࡋ࠾ࠪࡓ࠺ࠦࡕࠪᲊ"),struct)
			settings.setSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡹ࡯࡭ࡦࡵࡷࡥࡲࡶࠧ᲋"),str(now))
			settings.setSetting(l111lll_ll_ (u"ࠧࡪࡲࡷࡺ࠳ࡺࡩ࡮ࡧࡧ࡭࡫࡬ࠧ᲌"),str(l1lllll11l1_ll_))
			if ok and l11111l11l_ll_:
				l111l111l1_ll_ = l111lll_ll_ (u"ࠨ࡞ࡵࡠࡳ࠭᲍")
				max = dict[l111lll_ll_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬ᲎")][l111lll_ll_ (u"ࠪࡱࡦࡾ࡟ࡤࡱࡱࡲࡪࡩࡴࡪࡱࡱࡷࠬ᲏")]
				l1111lll1l_ll_ = dict[l111lll_ll_ (u"ࠫࡺࡹࡥࡳࡡ࡬ࡲ࡫ࡵࠧᲐ")][l111lll_ll_ (u"ࠬࡧࡣࡵ࡫ࡹࡩࡤࡩ࡯࡯ࡵࠪᲑ")]
				l111l11l11_ll_ = dict[l111lll_ll_ (u"࠭ࡵࡴࡧࡵࡣ࡮ࡴࡦࡰࠩᲒ")][l111lll_ll_ (u"ࠧࡪࡵࡢࡸࡷ࡯ࡡ࡭ࠩᲓ")]
				parts = l1lllll111l_ll_.split(l111lll_ll_ (u"ࠨࠨࠪᲔ"),1)
				message = parts[0]+l111l111l1_ll_+l111lll_ll_ (u"ࠩࠩࠫᲕ")+parts[1]+l111l111l1_ll_
				message += l111l111l1_ll_+l111lll_ll_ (u"ࠪࡗࡹࡧࡴࡶࡵ࠽ࠤࠥ࠭Ზ")+l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᲗ")+status+l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲘ")
				message += l111l111l1_ll_+l111lll_ll_ (u"࠭ࡔࡳ࡫ࡤࡰ࠿ࠦࠠࠡࠢࠪᲙ")+l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᲚ")+str(l111l11l11_ll_==l111lll_ll_ (u"ࠨ࠳ࠪᲛ"))+l111lll_ll_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫᲜ")
				message += l111l111l1_ll_+l111lll_ll_ (u"ࠪࡇࡷ࡫ࡡࡵࡧࡧࠤࠥࡇࡴ࠻ࠢࠣࠫᲝ")+l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣࠧᲞ")+l1llll1111l_ll_+l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲟ")
				message += l111l111l1_ll_+l111lll_ll_ (u"࠭ࡅࡹࡲ࡬ࡶࡾࠦࡄࡢࡶࡨ࠾ࠥࠦࠧᲠ")+l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᲡ")+l1111l11l1_ll_+l111lll_ll_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᲢ")
				message += l111l111l1_ll_+l111lll_ll_ (u"ࠩࡆࡳࡳࡴࡥࡤࡶ࡬ࡳࡳࡹࠠࠡࠢࠫࠤࡆࡩࡴࡪࡸࡨࠤ࠴ࠦࡍࡢࡺ࡬ࡱࡺࡳࠠࠪࠢ࠽ࠤࠥ࠭Უ")+l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠭Ფ")+l1111lll1l_ll_+l111lll_ll_ (u"ࠫࠥ࠵ࠠࠨᲥ")+max+l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᲦ")
				message += l111l111l1_ll_+l111lll_ll_ (u"࠭ࡁ࡭࡮ࡲࡻࡪࡪࠠࡐࡷࡷࡴࡺࡺࡳ࠻ࠢࠣࠤࠬᲧ")+l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪᲨ")+l111lll_ll_ (u"ࠣࠢ࠯ࠤࠧᲩ").join(dict[l111lll_ll_ (u"ࠩࡸࡷࡪࡸ࡟ࡪࡰࡩࡳࠬᲪ")][l111lll_ll_ (u"ࠪࡥࡱࡲ࡯ࡸࡧࡧࡣࡴࡻࡴࡱࡷࡷࡣ࡫ࡵࡲ࡮ࡣࡷࡷࠬᲫ")])+l111lll_ll_ (u"ࠫࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭Წ")
				l1llllll11l_ll_ = l111lll_ll_ (u"ࠬࠨࡳࡦࡴࡹࡩࡷࡥࡩ࡯ࡨࡲࠦ࠿࠭Ჭ")+html.split(l111lll_ll_ (u"࠭ࠢࡴࡧࡵࡺࡪࡸ࡟ࡪࡰࡩࡳࠧࡀࠧᲮ"))[1]
				l1llllll11l_ll_ = l1llllll11l_ll_.replace(l111lll_ll_ (u"ࠧ࠻ࠩᲯ"),l111lll_ll_ (u"ࠨ࠼ࠣࠫᲰ")).replace(l111lll_ll_ (u"ࠩ࠯ࠫᲱ"),l111lll_ll_ (u"ࠪ࠰ࠥ࠭Ჲ")).replace(l111lll_ll_ (u"ࠫࢂࢃࠧᲳ"),l111lll_ll_ (u"ࠬࢃࠧᲴ"))
				message += l111l111l1_ll_+l111l111l1_ll_+l1llllll11l_ll_
				if status==l111lll_ll_ (u"࠭ࡁࡤࡶ࡬ࡺࡪ࠭Ჵ"): l11l1l1ll_ll_(l111lll_ll_ (u"ࠧศๆสุฯืวไࠢํ฽๊๊ࠠษั๋๊๋ࠥิศๅ็ࠫᲶ"),message)
				else: l11l1l1ll_ll_(l111lll_ll_ (u"ࠨ์หำํࠦร็๊๊ࠢฬ้ࠠๆึๆ่ฮࠦแ๋ࠢส่ฬฺสาษๆࠫᲷ"),message)
	if l1lllll111l_ll_ and ok and status==l111lll_ll_ (u"ࠩࡄࡧࡹ࡯ࡶࡦࠩᲸ"):
		l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᲹ"),l111lll_ll_ (u"ࠫ࠳ࠦࠠࠡࡅ࡫ࡩࡨࡱࡩ࡯ࡩࠣࡍࡕ࡚ࡖࠡࡗࡕࡐࠥࠦࠠ࡜ࠢࡌࡔ࡙࡜ࠠࡢࡥࡦࡳࡺࡴࡴࠡ࡫ࡶࠤࡔࡑࠠ࡞ࠢࠣࠤࡠࠦࠧᲺ")+l1lllll111l_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠨ᲻"))
		succeeded = True
	else:
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ᲼"),l111lll_ll_ (u"ࠧࡄࡪࡨࡧࡰ࡯࡮ࡨࠢࡌࡔ࡙࡜ࠠࡖࡔࡏࠤ࡛ࠥࠦࠡࡆࡲࡩࡸࠦ࡮ࡰࡶࠣࡻࡴࡸ࡫ࠡ࡟ࠣࠤࠥࡡࠠࠨᲽ")+l1lllll111l_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫᲾ"))
		if l11111l11l_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠩไัฺࠦวีฬิห่ࠦࡉࡑࡖ࡙ࠫᲿ"),l111lll_ll_ (u"ࠪีฬฮืࠡษืฮึอใࠡࡋࡓࡘ࡛ࠦวๅาํࠤ็๋สࠡษ้ฮࠥฮลืษไฮ์ࠦลๅ๋ࠣห้ฮั็ษ่ะ๊ࠥวࠡ์฼้้ࠦร้ࠢส่ึอศุࠢ฽๎ึࠦๅ้ฮ๋ำࠥ็๊ࠡษ็ฬึ์วๆฮࠣ࠲ࠥษะ่สࠣษ้๏ࠠใษษ้ฮࠦวีฬิห่ࠦࡉࡑࡖ࡙ࠤํ่ๅࠡสศฺฬ็ษࠡำสฬ฼ࠦࡉࡑࡖ࡙ࠤัี๊ะࠢฦ์่ࠥๅࠡสศู้ออࠡษ็ีฬฮืࠡษ็ๆิ๐ๅࠨ᳀"))
		succeeded = False
	return succeeded
def l1lllll1l11_ll_(l1111ll1l1_ll_,l111ll1111_ll_,l1111l_ll_=l111lll_ll_ (u"ࠫࠬ᳁")):
	if l1111l_ll_==l111lll_ll_ (u"ࠬ࠭᳂"): show = True
	else: show = False
	if not l11111111l_ll_(show): return
	results = l1llll11l1l_ll_(l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣࡌࡘࡏࡖࡒࡖࠫ᳃"),[l1111ll1l1_ll_,l111ll1111_ll_,l1111l_ll_])
	if results: l11l11lll_ll_[:] = l11l11lll_ll_+results ; return
	else: l1111111ll_ll_ = l11l11lll_ll_[:] ; l11l11lll_ll_[:] = []
	streams = l1111llll1_ll_(l111lll_ll_ (u"ࠧࡊࡒࡗ࡚ࡤ࠭᳄")+l1111ll1l1_ll_+l111lll_ll_ (u"ࠨ࠰ࡧࡥࡹ࠭᳅"))
	groups,unique,l1111111l1_ll_ = [],[],[]
	for dict in streams:
		groups.append(dict[l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰࠨ᳆")])
		l1111111l1_ll_.append(dict[l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠧ᳇")])
	z = zip(groups,l1111111l1_ll_)
	z = sorted(z, reverse=False, key=lambda key: key[0])
	if l111lll_ll_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡊࡘࡉࡆࡕࡢࡣࠬ᳈") in l111ll1111_ll_: l111l1111l_ll_,l1llll1ll11_ll_ = l111ll1111_ll_.split(l111lll_ll_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘࡋࡒࡊࡇࡖࡣࡤ࠭᳉"))
	else: l111l1111l_ll_,l1llll1ll11_ll_ = l111ll1111_ll_,l111lll_ll_ (u"࠭ࠧ᳊")
	#l1ll1l_ll_(l1111ll1l1_ll_,l111ll1111_ll_)
	l1lll1lll1l_ll_ = l1l1l1l_ll_
	if len(z)>0:
		for group,img in z:
			if l1111l_ll_!=l111lll_ll_ (u"ࠧࠨ᳋"):
				if l111lll_ll_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡇࡕࡍࡊ࡙࡟ࡠࠩ᳌") in group: l1lll1lll1l_ll_ = l111lll_ll_ (u"ࠩࡖࡉࡗࡏࡅࡔࠩ᳍")
				elif l111lll_ll_ (u"ࠪࠥࠦࡥ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡡࠤࠥࠬ᳎") in group: l1lll1lll1l_ll_ = l111lll_ll_ (u"࡚ࠫࡔࡋࡏࡑ࡚ࡒࠬ᳏")
				elif l111lll_ll_ (u"ࠬࡒࡉࡗࡇࠪ᳐") in l1111ll1l1_ll_: l1lll1lll1l_ll_ = l111lll_ll_ (u"࠭ࡌࡊࡘࡈࠫ᳑")
				else: l1lll1lll1l_ll_ = l111lll_ll_ (u"ࠧࡗࡋࡇࡉࡔ࡙ࠧ᳒")
				l1lll1lll1l_ll_ = l111lll_ll_ (u"ࠨ࠮࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ᳓")+l1lll1lll1l_ll_+l111lll_ll_ (u"ࠩ࠽ࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ᳔࠭")
			if l111lll_ll_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡉࡗࡏࡅࡔࡡࡢ᳕ࠫ") in group: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group.split(l111lll_ll_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡊࡘࡉࡆࡕࡢࡣ᳖ࠬ"))
			else: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group,l111lll_ll_ (u"᳗ࠬ࠭")
			if l111ll1111_ll_==l111lll_ll_ (u"᳘࠭ࠧ"):
				if l111l1l1ll_ll_ in unique: continue
				unique.append(l111l1l1ll_ll_)
				if l111lll_ll_ (u"ࠧࡓࡃࡑࡈࡔࡓ᳙ࠧ") in l1111l_ll_: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᳚"),l1lll1lll1l_ll_+l111l1l1ll_ll_,l1111ll1l1_ll_,167,img,l111lll_ll_ (u"ࠩࠪ᳛"),group)
				elif l111lll_ll_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡉࡗࡏࡅࡔࡡࡢ᳜ࠫ") in group: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵ᳝ࠫ"),l1lll1lll1l_ll_+l111l1l1ll_ll_,l1111ll1l1_ll_,233,l111lll_ll_ (u"᳞ࠬ࠭"),l111lll_ll_ (u"᳟࠭ࠧ"),group)
				else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᳠"),l1lll1lll1l_ll_+l111l1l1ll_ll_,l1111ll1l1_ll_,234,l111lll_ll_ (u"ࠨࠩ᳡"),l111lll_ll_ (u"᳢ࠩࠪ"),group)
			elif l111lll_ll_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡉࡗࡏࡅࡔࡡࡢ᳣ࠫ") in group and l111l1l1ll_ll_==l111l1111l_ll_:
				if l1lll1ll11l_ll_ in unique: continue
				unique.append(l1lll1ll11l_ll_)
				if l111lll_ll_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡢ᳤ࠥࠦ࠭") in l1lll1ll11l_ll_: img = l111lll_ll_ (u"᳥ࠬ࠭")
				if l111lll_ll_ (u"࠭ࡒࡂࡐࡇࡓࡒ᳦࠭") in l1111l_ll_: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ᳧ࠧ"),l1lll1lll1l_ll_+l1lll1ll11l_ll_,l1111ll1l1_ll_,167,img,l111lll_ll_ (u"ࠨ᳨ࠩ"),group)
				else: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᳩ"),l1lll1lll1l_ll_+l1lll1ll11l_ll_,l1111ll1l1_ll_,234,img,l111lll_ll_ (u"ࠪࠫᳪ"),group)
	else:
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩᳫ"),l1lll1lll1l_ll_+l111lll_ll_ (u"ࠬํะ่ࠢส่็อฦๆหࠣษ๊อࠠโษิ฾ฮࠦร้ࠢ฽๎ึࠦๅ้ฮ๋ำฮ࠭ᳬ"),l111lll_ll_ (u"᳭࠭ࠧ"),9999)
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬᳮ"),l1lll1lll1l_ll_+l111lll_ll_ (u"ࠨล๋ࠤฬ๊ฮะ็ฬࠤ฿๐ัࠡ็๋ะํีษࠡใํࠤฬฺสาษๆ็ࠬᳯ"),l111lll_ll_ (u"ࠩࠪᳰ"),9999)
		l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨᳱ"),l1lll1lll1l_ll_+l111lll_ll_ (u"ࠫศ๎ࠠาษห฻ࠥࡏࡐࡕࡘࠣห้ึ๊ࠡล้ฮࠥษึโฬ๊ࠤ฿๐ัࠡืะ๎า࠭ᳲ"),l111lll_ll_ (u"ࠬ࠭ᳳ"),9999)
	l1111l1lll_ll_(l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣࡌࡘࡏࡖࡒࡖࠫ᳴"),[l1111ll1l1_ll_,l111ll1111_ll_,l1111l_ll_],l11l11lll_ll_,l11l111l11_ll_)
	l11l11lll_ll_[:] = l1111111ll_ll_+l11l11lll_ll_
	return
def l11ll1l11l_ll_(l1111ll1l1_ll_,l111ll1111_ll_):
	#l1ll1l_ll_(l1111ll1l1_ll_,l111ll1111_ll_)
	if not l11111111l_ll_(True): return
	#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧᳵ"),l111lll_ll_ (u"ࠨࡤࡨࡪࡴࡸࡥࠡࡆࡄࡘࡆࡈࡁࡔࡇࠪᳶ"))
	results = l1llll11l1l_ll_(l111lll_ll_ (u"ࠩࡌࡔ࡙࡜࡟ࡊࡖࡈࡑࡘ࠭᳷"),[l1111ll1l1_ll_,l111ll1111_ll_])
	if results: l11l11lll_ll_[:] = l11l11lll_ll_+results ; return
	else: l1111111ll_ll_ = l11l11lll_ll_[:] ; l11l11lll_ll_[:] = []
	streams = l1111llll1_ll_(l111lll_ll_ (u"ࠪࡍࡕ࡚ࡖࡠࠩ᳸")+l1111ll1l1_ll_+l111lll_ll_ (u"ࠫ࠳ࡪࡡࡵࠩ᳹"))
	#l1ll1l_ll_(l1111ll1l1_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠ࠼ࠪᳺ")+l111ll1111_ll_,str(len(streams)))
	if l111lll_ll_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡅࡓࡋࡈࡗࡤࡥࠧ᳻") in l111ll1111_ll_: l111l1111l_ll_,l1llll1ll11_ll_ = l111ll1111_ll_.split(l111lll_ll_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡆࡔࡌࡉࡘࡥ࡟ࠨ᳼"))
	else: l111l1111l_ll_,l1llll1ll11_ll_ = l111ll1111_ll_,l111lll_ll_ (u"ࠨࠩ᳽")
	#l1ll1l_ll_(l111l1111l_ll_,l1llll1ll11_ll_)
	for dict in streams:
		#if l111lll_ll_ (u"ࠩࡈࡋࠥ࠳ࠠࠨ᳾") in dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩ᳿")]: l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫᴀ"),l111lll_ll_ (u"ࠬ࠷࠱࠲࠳࠴࠵ࠬᴁ")+str(dict))
		group = dict[l111lll_ll_ (u"࠭ࡧࡳࡱࡸࡴࠬᴂ")]
		if l111lll_ll_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡆࡔࡌࡉࡘࡥ࡟ࠨᴃ") in group: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group.split(l111lll_ll_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡇࡕࡍࡊ࡙࡟ࡠࠩᴄ"))
		else: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group,l111lll_ll_ (u"ࠩࠪᴅ")
		l1111l1111_ll_ = (l111lll_ll_ (u"ࠪࡋࡗࡕࡕࡑࡇࡇࠫᴆ") in l1111ll1l1_ll_ or l1111ll1l1_ll_==l111lll_ll_ (u"ࠫࡆࡒࡌࠨᴇ")) and group==l111ll1111_ll_
		l111l1llll_ll_ = (l111lll_ll_ (u"ࠬࡍࡒࡐࡗࡓࡉࡉ࠭ᴈ") not in l1111ll1l1_ll_ and l1111ll1l1_ll_!=l111lll_ll_ (u"࠭ࡁࡍࡎࠪᴉ")) and l111l1l1ll_ll_==l111l1111l_ll_
		if l1111l1111_ll_ or l111l1llll_ll_:
			#if l111lll_ll_ (u"ࠧࡆࡉࠣ࠱ࠥ࠭ᴊ") in dict[l111lll_ll_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᴋ")]: l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩᴌ"),l111lll_ll_ (u"ࠪ࠶࠷࠸࠲࠳࠴ࠪᴍ")+str(dict))
			title = dict[l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪᴎ")]
			url = dict[l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩᴏ")]
			img = dict[l111lll_ll_ (u"࠭ࡩ࡮ࡩࠪᴐ")]
			context = dict[l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨᴑ")]
			if   l111lll_ll_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪᴒ")  in l1111ll1l1_ll_: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᴓ"),l1l1l1l_ll_+title,url,238,img,l111lll_ll_ (u"ࠪࠫᴔ"),l111lll_ll_ (u"ࠫࡆࡘࡃࡉࡋ࡙ࡉࡉ࠭ᴕ"))
			elif l111lll_ll_ (u"ࠬࡋࡐࡈࠩᴖ") 		 in l1111ll1l1_ll_: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᴗ"),l1l1l1l_ll_+title,url,238,img,l111lll_ll_ (u"ࠧࠨᴘ"),l111lll_ll_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪᴙ"))
			elif l111lll_ll_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬᴚ") in l1111ll1l1_ll_: l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᴛ"),l1l1l1l_ll_+title,url,238,img,l111lll_ll_ (u"ࠫࠬᴜ"),l111lll_ll_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨᴝ"))
			elif l111lll_ll_ (u"࠭ࡌࡊࡘࡈࠫᴞ") 	 in l1111ll1l1_ll_: l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡹࡩࠬᴟ"),l1l1l1l_ll_+title,url,235,img,l111lll_ll_ (u"ࠨࠩᴠ"),l111lll_ll_ (u"ࠩࠪᴡ"),context)
			else: l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᴢ"),l1l1l1l_ll_+title,url,235,img)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡔ࡛ࡔࠨᴣ"),str(l11l11lll_ll_))
	l1111l1lll_ll_(l111lll_ll_ (u"ࠬࡏࡐࡕࡘࡢࡍ࡙ࡋࡍࡔࠩᴤ"),[l1111ll1l1_ll_,l111ll1111_ll_],l11l11lll_ll_,l11l111l11_ll_)
	l11l11lll_ll_[:] = l1111111ll_ll_+l11l11lll_ll_
	return
def l111ll11l1_ll_(url,function):
	l1ll11l11_ll_ = settings.getSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡺࡹࡥࡳࡣࡪࡩࡳࡺࠧᴥ"))
	headers = {l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫᴦ"):l1ll11l11_ll_}
	if not l11111111l_ll_(True): return
	timestamp = settings.getSetting(l111lll_ll_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩᴧ"))
	if timestamp==l111lll_ll_ (u"ࠩࠪᴨ") or now-int(timestamp)>24*l11111ll11_ll_:
		ok = l1llll1lll1_ll_(False)
		if not ok: return
	l1lllll11l1_ll_ = int(settings.getSetting(l111lll_ll_ (u"ࠪ࡭ࡵࡺࡶ࠯ࡶ࡬ࡱࡪࡪࡩࡧࡨࠪᴩ")))
	server = settings.getSetting(l111lll_ll_ (u"ࠫ࡮ࡶࡴࡷ࠰ࡶࡩࡷࡼࡥࡳࠩᴪ"))
	username = settings.getSetting(l111lll_ll_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲ࡯ࡣࡰࡩࠬᴫ"))
	password = settings.getSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡵࡧࡳࡴࡹࡲࡶࡩ࠭ᴬ"))
	l1lllll1l1l_ll_ = url.split(l111lll_ll_ (u"ࠧ࠰ࠩᴭ"))
	stream_id = l1lllll1l1l_ll_[-1].replace(l111lll_ll_ (u"ࠨ࠰ࡷࡷࠬᴮ"),l111lll_ll_ (u"ࠩࠪᴯ")).replace(l111lll_ll_ (u"ࠪ࠲ࡲ࠹ࡵ࠹ࠩᴰ"),l111lll_ll_ (u"ࠫࠬᴱ"))
	#l1ll1l_ll_(str(l1lllll11l1_ll_),str(timestamp))
	if function==l111lll_ll_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨᴲ"): l111llll11_ll_ = l111lll_ll_ (u"࠭ࡧࡦࡶࡢࡷ࡭ࡵࡲࡵࡡࡨࡴ࡬࠭ᴳ")
	else: l111llll11_ll_ = l111lll_ll_ (u"ࠧࡨࡧࡷࡣࡸ࡯࡭ࡱ࡮ࡨࡣࡩࡧࡴࡢࡡࡷࡥࡧࡲࡥࠨᴴ")
	l1lllllllll_ll_ = server+l111lll_ll_ (u"ࠨ࠱ࡳࡰࡦࡿࡥࡳࡡࡤࡴ࡮࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭ᴵ")+username+l111lll_ll_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ᴶ")+password+l111lll_ll_ (u"ࠪࠪࡦࡩࡴࡪࡱࡱࡁࠬᴷ")+l111llll11_ll_+l111lll_ll_ (u"ࠫࠫࡹࡴࡳࡧࡤࡱࡤ࡯ࡤ࠾ࠩᴸ")+stream_id
	html = l111ll1_ll_(l1l11lll_ll_,l1lllllllll_ll_,l111lll_ll_ (u"ࠬ࠭ᴹ"),headers,l111lll_ll_ (u"࠭ࠧᴺ"),l111lll_ll_ (u"ࠧࡊࡒࡗ࡚࠲ࡋࡐࡈࡡࡌࡘࡊࡓࡓ࠮࠴ࡱࡨࠬᴻ"))
	l1111l1ll1_ll_ = l111ll1lll_ll_(html)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩᴼ"),str(l1111l1ll1_ll_))
	#with open(l111lll_ll_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࡫ࡳࡸࡻ࠴ࡴࡹࡶࠪᴽ"),l111lll_ll_ (u"ࠪࡻࠬᴾ")) as f: f.write(html)
	l1llll1l11l_ll_ = l1111l1ll1_ll_[l111lll_ll_ (u"ࠫࡪࡶࡧࡠ࡮࡬ࡷࡹ࡯࡮ࡨࡵࠪᴿ")]
	l111111lll_ll_ = []
	if function in [l111lll_ll_ (u"ࠬࡇࡒࡄࡊࡌ࡚ࡊࡊࠧᵀ"),l111lll_ll_ (u"࠭ࡔࡊࡏࡈࡗࡍࡏࡆࡕࠩᵁ")]:
		for dict in l1llll1l11l_ll_:
			if dict[l111lll_ll_ (u"ࠧࡩࡣࡶࡣࡦࡸࡣࡩ࡫ࡹࡩࠬᵂ")]==1:
				l111111lll_ll_.append(dict)
				if function in [l111lll_ll_ (u"ࠨࡖࡌࡑࡊ࡙ࡈࡊࡈࡗࠫᵃ")]: break
		if not l111111lll_ll_: return
		l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᵄ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢอไๆๆไหฯࠦวๅล๋่๏ࠦศ่า๊ࠤฬ๊โศศ่อ่ࠥฯࠡๆสࠤฯ฿ๅๅ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᵅ"),l111lll_ll_ (u"ࠫࠬᵆ"),9999)
		if function in [l111lll_ll_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨᵇ")]:
			l111llll1l_ll_ = 2
			l1llll1ll1l_ll_ = l111llll1l_ll_*l11111ll11_ll_
			l111111lll_ll_ = []
			l11l11111l_ll_ = int(int(dict[l111lll_ll_ (u"࠭ࡳࡵࡣࡵࡸࡤࡺࡩ࡮ࡧࡶࡸࡦࡳࡰࠨᵈ")])/l1llll1ll1l_ll_)*l1llll1ll1l_ll_
			l111l1l11l_ll_ = now+l1llll1ll1l_ll_
			l1llll111l1_ll_ = int((l111l1l11l_ll_-l11l11111l_ll_)/l11111ll11_ll_)
			for count in range(l1llll111l1_ll_):
				if count>=6:
					if count%l111llll1l_ll_!=0: continue
					duration = l1llll1ll1l_ll_
				else: duration = l1llll1ll1l_ll_/2
				l111111l1l_ll_ = l11l11111l_ll_+count*l11111ll11_ll_
				dict = {}
				dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᵉ")] = l111lll_ll_ (u"ࠨࠩᵊ")
				struct = time.localtime(l111111l1l_ll_-l1lllll11l1_ll_-l11111ll11_ll_)
				dict[l111lll_ll_ (u"ࠩࡶࡸࡦࡸࡴࠨᵋ")] = time.strftime(l111lll_ll_ (u"ࠪࠩ࡞࠳ࠥ࡮࠯ࠨࡨ࠿ࠫࡈ࠻ࠧࡐ࠾࡙ࠪࠧᵌ"),struct)
				dict[l111lll_ll_ (u"ࠫࡸࡺࡡࡳࡶࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᵍ")] = str(l111111l1l_ll_)
				dict[l111lll_ll_ (u"ࠬࡹࡴࡰࡲࡢࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᵎ")] = str(l111111l1l_ll_+duration)
				l111111lll_ll_.append(dict)
	elif function in [l111lll_ll_ (u"࠭ࡓࡉࡑࡕࡘࡤࡋࡐࡈࠩᵏ"),l111lll_ll_ (u"ࠧࡇࡗࡏࡐࡤࡋࡐࡈࠩᵐ")]: l111111lll_ll_ = l1llll1l11l_ll_
	if function==l111lll_ll_ (u"ࠨࡈࡘࡐࡑࡥࡅࡑࡉࠪᵑ") and len(l111111lll_ll_)>0: l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧᵒ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢํะ่ࠢๅหห๋ษࠡสิห๊าࠠศๆๅ๊ํอสࠡࠪฯำํ๊ࠠโไฺ࠭ๅࡡ࠯ࡄࡑࡏࡓࡗࡣࠧᵓ"),l111lll_ll_ (u"ࠫࠬᵔ"),9999)
	#l1lll1lll11_ll_ = [l111lll_ll_ (u"࡙ࠬࡡࡵࠩᵕ"), l111lll_ll_ (u"࠭ࡓࡶࡰࠪᵖ"), l111lll_ll_ (u"ࠧࡎࡱࡱࠫᵗ"), l111lll_ll_ (u"ࠨࡖࡸࡩࠬᵘ"), l111lll_ll_ (u"࡚ࠩࡩࡩ࠭ᵙ") , l111lll_ll_ (u"ࠪࡘ࡭ࡻࠧᵚ"), l111lll_ll_ (u"ࠫࡋࡸࡩࠨᵛ")]
	#l1lllll11ll_ll_ = [l111lll_ll_ (u"ูࠬศหࠩᵜ"), l111lll_ll_ (u"࠭รฮัࠪᵝ"), l111lll_ll_ (u"ࠧฤอ้๎๋࠭ᵞ"), l111lll_ll_ (u"ࠨอ็หะอมࠨᵟ"), l111lll_ll_ (u"ࠩฦีอ฿วยࠩᵠ"), l111lll_ll_ (u"ࠪา๊๐ำࠨᵡ"), l111lll_ll_ (u"ࠫัู๋สࠩᵢ")]
	l111111l11_ll_ = []
	img = xbmc.getInfoLabel(l111lll_ll_ (u"ࠬࡒࡩࡴࡶࡌࡸࡪࡳ࠮ࡊࡥࡲࡲࠬᵣ"))
	for dict in l111111lll_ll_:
		title = base64.b64decode(dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬᵤ")])
		l111111l1l_ll_ = int(dict[l111lll_ll_ (u"ࠧࡴࡶࡤࡶࡹࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩᵥ")])
		l111ll111l_ll_ = int(dict[l111lll_ll_ (u"ࠨࡵࡷࡳࡵࡥࡴࡪ࡯ࡨࡷࡹࡧ࡭ࡱࠩᵦ")])
		l111l1ll11_ll_ = str(int((l111ll111l_ll_-l111111l1l_ll_+59)/60))
		l11l111ll1_ll_ = dict[l111lll_ll_ (u"ࠩࡶࡸࡦࡸࡴࠨᵧ")].replace(l111lll_ll_ (u"ࠪࠤࠬᵨ"),l111lll_ll_ (u"ࠫ࠿࠭ᵩ"))
		#struct = time.gmtime(l111111l1l_ll_-l1lllll11l1_ll_+time.altzone-3600)
		#l11l111ll1_ll_ = time.strftime(l111lll_ll_ (u"࡙ࠬࠫ࠮ࠧࡰ࠱ࠪࡪ࠺ࠦࡊ࠽ࠩࡒࡀࠥࡔࠩᵪ"),struct)
		struct = time.localtime(l111111l1l_ll_-l11111ll11_ll_)
		time_string = time.strftime(l111lll_ll_ (u"࠭ࠥࡉ࠼ࠨࡑࠬᵫ"),struct)
		l111l1ll1l_ll_ = time.strftime(l111lll_ll_ (u"ࠧࠦࡣࠪᵬ"),struct)
		#l1llllll111_ll_ = l1lll1lll11_ll_.index(l111l1ll1l_ll_)
		#l111lll1ll_ll_ = l1lllll11ll_ll_[l1llllll111_ll_]
		#title = l111lll_ll_ (u"ࠨโࠣࠫᵭ")+title+l111lll_ll_ (u"ࠩࠣࠤ࠭࠭ᵮ")+l111l1ll11_ll_+l111lll_ll_ (u"ࠪำ็࠯ࠠࠨᵯ")+time_string+l111lll_ll_ (u"ࠫࠥ࠭ᵰ")+l111lll1ll_ll_
		if function==l111lll_ll_ (u"࡙ࠬࡈࡐࡔࡗࡣࡊࡖࡇࠨᵱ"): title = l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡈࡉࡊࡋ࠶࠰࡞ࠩᵲ")+time_string+l111lll_ll_ (u"ࠧࠡโࠣࠫᵳ")+title+l111lll_ll_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪᵴ")
		elif function==l111lll_ll_ (u"ࠩࡗࡍࡒࡋࡓࡉࡋࡉࡘࠬᵵ"): title = l111l1ll1l_ll_+l111lll_ll_ (u"ࠪࠤࠬᵶ")+time_string+l111lll_ll_ (u"ࠫࠥ࠮ࠧᵷ")+l111l1ll11_ll_+l111lll_ll_ (u"ࠬࡳࡩ࡯ࠫࠪᵸ")
		else: title = l111l1ll1l_ll_+l111lll_ll_ (u"࠭ࠠࠨᵹ")+time_string+l111lll_ll_ (u"ࠧࠡࠪࠪᵺ")+l111l1ll11_ll_+l111lll_ll_ (u"ࠨ࡯࡬ࡲ࠮ࠦࠠࠡࠩᵻ")+title+l111lll_ll_ (u"ࠩࠣไࠬᵼ")
		if function in [l111lll_ll_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬᵽ"),l111lll_ll_ (u"ࠫࡋ࡛ࡌࡍࡡࡈࡔࡌ࠭ᵾ"),l111lll_ll_ (u"࡚ࠬࡉࡎࡇࡖࡌࡎࡌࡔࠨᵿ")]:
			l1llll11ll1_ll_ = server+l111lll_ll_ (u"࠭࠯ࡵ࡫ࡰࡩࡸ࡮ࡩࡧࡶ࠲ࠫᶀ")+username+l111lll_ll_ (u"ࠧ࠰ࠩᶁ")+password+l111lll_ll_ (u"ࠨ࠱ࠪᶂ")+l111l1ll11_ll_+l111lll_ll_ (u"ࠩ࠲ࠫᶃ")+l11l111ll1_ll_+l111lll_ll_ (u"ࠪ࠳ࠬᶄ")+stream_id+l111lll_ll_ (u"ࠫ࠳ࡳ࠳ࡶ࠺ࠪᶅ")
			if function==l111lll_ll_ (u"ࠬࡌࡕࡍࡎࡢࡉࡕࡍࠧᶆ"): l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫᶇ"),l1l1l1l_ll_+title,l1llll11ll1_ll_,9999,img)
			else: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᶈ"),l1l1l1l_ll_+title,l1llll11ll1_ll_,235,img)
		l111111l11_ll_.append(title)
	if function==l111lll_ll_ (u"ࠨࡕࡋࡓࡗ࡚࡟ࡆࡒࡊࠫᶉ") and l111111l11_ll_: selection = l1111ll11l_ll_(l111111l11_ll_)
	return l111111l11_ll_
def l11_ll_(url,type):
	l1ll11l11_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩ࡬ࡴࡹࡼ࠮ࡶࡵࡨࡶࡦ࡭ࡥ࡯ࡶࠪᶊ"))
	if l1ll11l11_ll_!=l111lll_ll_ (u"ࠪࠫᶋ"): url = url+l111lll_ll_ (u"ࠫࢁ࡛ࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵ࠿ࠪᶌ")+l1ll11l11_ll_
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋ࡬ࡪࠥࡺࡹࡱࡧࡀࡁࠬࡲࡩࡷࡧࠪ࠾ࠏࠏࠉࡹࡤࡰࡧ࠳ࡖ࡬ࡢࡻࡨࡶ࠭࠯࠮ࡱ࡮ࡤࡽ࠭ࡻࡲ࡭ࠫࠍࠍࠎࡸࡡ࡯ࡦࡲࡱࡓࡻ࡭ࡣࡧࡵࠤࡂࠦࡳࡵࡴࠫࡶࡦࡴࡤࡰ࡯࠱ࡶࡦࡴࡤࡳࡣࡱ࡫ࡪ࠮࠱࠲࠳࠴࠵࠶࠷࠱࠲࠳࠴࠵࠱࠿࠹࠺࠻࠼࠽࠾࠿࠹࠺࠻࠼࠭࠮ࠐࠉࠊࡷࡵࡰ࠷ࠦ࠽ࠡࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡻࡼ࠴ࡧࡰࡱࡪࡰࡪ࠳ࡡ࡯ࡣ࡯ࡽࡹ࡯ࡣࡴ࠰ࡦࡳࡲ࠵ࡣࡰ࡮࡯ࡩࡨࡺ࠿ࡷ࠿࠴ࠪࡹ࡯ࡤ࠾ࡗࡄ࠱࠶࠸࠷࠱࠶࠸࠵࠵࠺࠭࠶ࠨࡦ࡭ࡩࡃࠧࠬࡦࡸࡱࡲࡿࡃ࡭࡫ࡨࡲࡹࡏࡄࠩ࠵࠵࠭࠰࠭ࠦࡵ࠿ࡨࡺࡪࡴࡴࠧࡵࡦࡁࡪࡴࡤࠧࡧࡦࡁࠬ࠱ࡡࡥࡦࡲࡲࡤࡼࡥࡳࡵ࡬ࡳࡳ࠱ࠧࠧࡣࡹࡁࠬ࠱ࡡࡥࡦࡲࡲࡤࡼࡥࡳࡵ࡬ࡳࡳ࠱ࠧࠧࡣࡱࡁࡆࡘࡁࡃࡋࡆࡣ࡛ࡏࡄࡆࡑࡖࠪࡪࡧ࠽ࠨ࠭ࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠫࠨࠨࡽࡁࠬ࠱ࡲࡢࡰࡧࡳࡲࡔࡵ࡮ࡤࡨࡶࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࠫࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠸ࠬࠨࠩ࠯ࠫࠬ࠲ࡔࡳࡷࡨ࠰ࡋࡧ࡬ࡴࡧ࠯ࠫࡎࡖࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࡃࡇࡈࡤ࡚ࡏࡠࡎࡄࡗ࡙ࡥࡖࡊࡆࡈࡓࡤࡌࡉࡍࡇࡖࠬ࠮ࠐࠉࡦ࡮ࡶࡩ࠿ࠐࠉࠣࠤࠥᶍ")
	l111lll1_ll_(url,l1ll_ll_,type)
	return
def l1lllll1lll_ll_():
	l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩᶎ"),l111lll_ll_ (u"ࠧหฯำ๎ึࠦๅ่็ࠣ์์อๅࠡฮาหࠥ࠴๋ࠠำฯํࠥ฿ฯๆࠢอ฾๏๐ั่ࠢศิฬࠦใ็ฬ่ࠣฬࠦสฺำไࠤ๊อ่๊ࠠࠣ࠲ฺ่ࠥࠦั่ࠤฯเ๊๋ำ๊ࠤส๊วࠡ฻้ำࠥอไืำ๋ีฮࠦวๅไุ์๎ࠦ࠮ࠡษ็ัฬาษࠡๆ๊ิฬࠦวๅฬ฽๎๏ื่ࠠ์ࠣๅ็฽ࠠฦาสࠤ฼๊ศห่๊่ࠢࠦิาๅฬࠤࡎࡖࡔࡗࠢฦ๊ࠥะูๆๆ๋ࠣีอࠠศๆอ฾๏๐ัࠡ࠰ࠣ์ๆ่ืࠡ฻้ำ๊อࠠหีอาิ๋ࠠฯั่อࠥࡏࡐࡕࡘࠣฮาะวอࠢࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦฮศืࠪᶏ"))
	l1ll11l11_ll_ = settings.getSettingString(l111lll_ll_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࠩᶐ"))
	answer = l1llll1111_ll_(l1ll11l11_ll_,l111lll_ll_ (u"๊ࠩิฬࠦ็้ࠢࡌࡔ࡙࡜ࠠࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠤฬ๊ๅิฮ็ࠤๆ๐ࠠศๆหี๋อๅอࠢ࠱ࠤ์๊ࠠหำํำࠥะูะ์็๋ࠥษๅࠡฬิ๎ิࠦลฺษาฮ์ࠦลๅ๋ࠣ์฻฿๊สࠢส่ฯัศ๋ฬࠣห้ษีๅ์ࠣ์ฬ๊ส๋ࠢอๆึ๐ศศࠢอ๊ฬูศࠡฮ่๎฾ࠦิาๅสฮࠥࡏࡐࡕࡘࠣรࠦ࠭ᶑ"),l111lll_ll_ (u"ࠪࠫᶒ"),l111lll_ll_ (u"ࠫࠬᶓ"),l111lll_ll_ (u"ࠬอำหะาห๊ࠦวๅลุ่๏࠭ᶔ"),l111lll_ll_ (u"࠭สฺัํ่ࠥอไใัํ้ࠬᶕ"))
	if answer: l1ll11l11_ll_ = l1ll1_ll_(l111lll_ll_ (u"ࠧฤๅอฬࠥࡏࡐࡕࡘ࡙ࠣࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠠอัํำࠬᶖ"),l1ll11l11_ll_,True)
	else: l1ll11l11_ll_ = l111lll_ll_ (u"ࠨࡗࡱ࡯ࡳࡵࡷ࡯ࠩᶗ")
	if l1ll11l11_ll_==l111lll_ll_ (u"ࠩࠣࠫᶘ"):
		l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᶙ"),l111lll_ll_ (u"ࠫ฿๐ัࠡ็ึ้ํำࠠฤีอาิอๅࠡใิห฿ࠦไ้ฯา๋ࠥษ่ࠡ฻าอࠥ็ัศ฼สฮ๊่ࠥฮั๊หࠥ࠴࠮࠯ࠢํะอࠦลๆษࠣฮึ้็ࠡใสี฿ࠦสๆษ่หࠥษ่ࠡวูหๆฯࠠฮำไࠤศ๎ࠠฤ์ุࠣ๏ࠦยฯำ้ࠣ฾ํวࠨᶚ"))
		return
	answer = l1llll1111_ll_(l1ll11l11_ll_,l111lll_ll_ (u"ࠬํไࠡฬิ๎ิࠦวิฬัำฬ๋่ࠠาสࠤࡎࡖࡔࡗࠢࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹࠦศะๆสࠤ๊์ࠠࠡษ็ๆิ๐ๅࠡมࠪᶛ"),l111lll_ll_ (u"࠭ࠧᶜ"),l111lll_ll_ (u"ࠧࠨᶝ"),l111lll_ll_ (u"ࠨๅ็หࠬᶞ"),l111lll_ll_ (u"้ࠩ฽๊࠭ᶟ"))
	if not answer:
		l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ᶠ"),l111lll_ll_ (u"ࠫฯ๋ࠠศๆศ่฿อมࠨᶡ"))
		return
	settings.setSetting(l111lll_ll_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹ࠭ᶢ"),l1ll11l11_ll_)
	l1lllllll11_ll_(True)
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡁࡅࡆࡢ࡙ࡘࡋࡒࡂࡉࡈࡒ࡙ࠦ࠲ࠨᶣ"),l111lll_ll_ (u"ࠧ࡜ࠩᶤ")+l1ll11l11_ll_+l111lll_ll_ (u"ࠨ࡟ࠪᶥ"))
	return
def l1llll111ll_ll_():
	answer = l1llll1111_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶦ"),l111lll_ll_ (u"ࠪห้ฮั็ษ่ะࠥ๐อหษฯࠤฬฺสาษๆࠤࡎࡖࡔࡗ่๊ࠢࠥ์ฺ่ࠢิหอ฽ࠠศๆอั๊๐ไࠡ࡯࠶ࡹ๋ࠥๆࠡลํࠤูืใสࠢࡌࡔ࡙࡜้ࠠษ็วๆ฼ไࠡล้ࠤ๏ำส้์ࠣห้ืวษูࠣๅ๏ࠦๆ่ษํฮ์ูࠦๅ๋๋ࠣีํࠠศๆๆ่๊อส࡝ࡰ࡟ࡶࠫࡺࡹࡱࡧࡀࡱ࠸ࡻ࡟ࡱ࡮ࡸࡷࡡࡴ࡜ࡳ้็ࠤฯื๊ะࠢอ฾๏๐ัࠡษ็ีฬฮืࠡษ็ฦ๋ࠦฟࠨᶧ"),l111lll_ll_ (u"ࠫࠬᶨ"),l111lll_ll_ (u"ࠬ࠭ᶩ"),l111lll_ll_ (u"࠭ใๅษࠪᶪ"),l111lll_ll_ (u"ࠧ็฻่ࠫᶫ"))
	if not answer: return
	l1lllll111l_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡵࡳ࡮ࠪᶬ"))
	if l1lllll111l_ll_!=l111lll_ll_ (u"ࠩࠪᶭ"):
		answer = l1llll1111_ll_(l1lllll111l_ll_,l111lll_ll_ (u"๋ࠪีอ่๊ࠠࠣีฬฮืࠡࡋࡓࡘ࡛ࠦวๅ็ึะ้ࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳࠴࠮้ࠡ็ࠤฯื๊ะࠢอ฽ิ๐ไ่ࠢฦ้ࠥะั๋ัࠣ็ฯอศสࠢิหอ฽ࠠอัํำࠥลࠡࠨᶮ"),l111lll_ll_ (u"ࠫࠬᶯ"),l111lll_ll_ (u"ࠬ࠭ᶰ"),l111lll_ll_ (u"࠭ใหษหอࠥาฯ๋ัࠪᶱ"),l111lll_ll_ (u"ࠧห฻า๎้ࠦวๅไา๎๊࠭ᶲ"))
		if not answer: l1lllll111l_ll_ = l111lll_ll_ (u"ࠨࠩᶳ")
	l1lllll111l_ll_ = l1ll1_ll_(l111lll_ll_ (u"ࠩส็ฯฮࠠาษห฻ࠥࡏࡐࡕࡘࠣ็ฬ๋ไศࠩᶴ"),l1lllll111l_ll_)
	if l1lllll111l_ll_==l111lll_ll_ (u"ࠪࠫᶵ"): return
	else:
		answer = l1llll1111_ll_(l1lllll111l_ll_,l111lll_ll_ (u"ࠫ์๊ࠠหำํำࠥอำหะาห๊ࠦ็ัษࠣห้ืวษูࠣฬิ๊วࠡ็้ࠤฬ๊ัศสฺࠤฬ๊โะ์่ࠤฤ࠭ᶶ"),l111lll_ll_ (u"ࠬ࠭ᶷ"),l111lll_ll_ (u"࠭ࠧᶸ"),l111lll_ll_ (u"ࠧไๆสࠫᶹ"),l111lll_ll_ (u"ࠨ่฼้ࠬᶺ"))
		if not answer:
			l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬᶻ"),l111lll_ll_ (u"ࠪฮ๊ࠦวๅว็฾ฬวࠧᶼ"))
			return
	settings.setSetting(l111lll_ll_ (u"ࠫ࡮ࡶࡴࡷ࠰ࡸࡶࡱ࠭ᶽ"),l1lllll111l_ll_)
	settings.setSetting(l111lll_ll_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡸ࡮ࡳࡥࡴࡶࡤࡱࡵ࠭ᶾ"),l111lll_ll_ (u"࠭ࠧᶿ"))
	settings.setSetting(l111lll_ll_ (u"ࠧࡪࡲࡷࡺ࠳ࡺࡩ࡮ࡧࡧ࡭࡫࡬ࠧ᷀"),l111lll_ll_ (u"ࠨࠩ᷁"))
	settings.setSetting(l111lll_ll_ (u"ࠩ࡬ࡴࡹࡼ࠮ࡶࡵࡨࡶࡳࡧ࡭ࡦ᷂ࠩ"),l111lll_ll_ (u"ࠪࠫ᷃"))
	settings.setSetting(l111lll_ll_ (u"ࠫ࡮ࡶࡴࡷ࠰ࡳࡥࡸࡹࡷࡰࡴࡧࠫ᷄"),l111lll_ll_ (u"ࠬ࠭᷅"))
	settings.setSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡸ࡫ࡲࡷࡧࡵࠫ᷆"),l111lll_ll_ (u"ࠧࠨ᷇"))
	l1ll11l11_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡵࡴࡧࡵࡥ࡬࡫࡮ࡵࠩ᷈"))
	if l1ll11l11_ll_==l111lll_ll_ (u"ࠩࠪ᷉"): settings.setSetting(l111lll_ll_ (u"ࠪ࡭ࡵࡺࡶ࠯ࡷࡶࡩࡷࡧࡧࡦࡰࡷ᷊ࠫ"),l111lll_ll_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࠬ᷋"))
	l111111l1_ll_ = l1llll1111_ll_(l1lllll111l_ll_,l111lll_ll_ (u"ࠬะๅࠡฬ฽๎ึࠦัศสฺࠤฬฺสาษๆࠤࡎࡖࡔࡗࠢศ่๎ࠦ็ัษࠣห้ืวษูࠣห้าฯ๋ัࠣ࠲࠳࠴่ࠠๆࠣฮึ๐ฯࠡใะูࠥํะศࠢส่ึอศุࠢส่ว์ࠠภࠩ᷌"),l111lll_ll_ (u"࠭ࠧ᷍"),l111lll_ll_ (u"ࠧࠨ᷎"),l111lll_ll_ (u"ࠨๅ็ห᷏ࠬ"),l111lll_ll_ (u"้ࠩ฽๊᷐࠭"))
	if l111111l1_ll_: ok = l1llll1lll1_ll_(True)
	l1lllllll11_ll_(True)
	return
def l1lll1_ll_(search=l111lll_ll_ (u"ࠪࠫ᷑")):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if l1ll11_ll_:
		#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ᷒"),l111lll_ll_ (u"ࠬ࠭ᷓ"))
		if not l11111111l_ll_(True): return
		if search==l111lll_ll_ (u"࠭ࠧᷔ"): search = l1ll1_ll_()
		if search==l111lll_ll_ (u"ࠧࠨᷕ"): return
		l111l111ll_ll_ = [l111lll_ll_ (u"ࠨษ็็้࠭ᷖ"),l111lll_ll_ (u"ࠩๅ๊ํอสࠨᷗ"),l111lll_ll_ (u"ࠪวๆ๊วๆࠩᷘ"),l111lll_ll_ (u"ู๊ࠫไิๆสฮࠬᷙ"),l111lll_ll_ (u"ࠬษฮา๋ࠪᷚ")]
		l111l1lll1_ll_ = [l111lll_ll_ (u"࠭ࡁࡍࡎࠪᷛ"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᷜ"),l111lll_ll_ (u"ࠨࡘࡒࡈࡤࡓࡏࡗࡋࡈࡗࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ᷝ"),l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡓࡆࡔࡌࡉࡘࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᷞ"),l111lll_ll_ (u"࡚ࠪࡔࡊ࡟ࡖࡐࡎࡒࡔ࡝ࡎࡠࡉࡕࡓ࡚ࡖࡅࡅࡡࡖࡓࡗ࡚ࡅࡅࠩᷟ")]
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᷠ"), l111l111ll_ll_)
		if selection == -1: return
		l1111ll1l1_ll_ = l111l1lll1_ll_[selection]
	else:
		if not l11111111l_ll_(False): return
		l1111ll1l1_ll_ = l111lll_ll_ (u"ࠬࡇࡌࡍࠩᷡ")
	streams = l1111llll1_ll_(l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣࠬᷢ")+l1111ll1l1_ll_+l111lll_ll_ (u"ࠧ࠯ࡦࡤࡸࠬᷣ"))
	l1llll11lll_ll_ = search.lower()
	l1lllll1ll1_ll_ = []
	for dict in streams:
		title = dict[l111lll_ll_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧᷤ")]
		group = dict[l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰࠨᷥ")]
		img = dict[l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠧᷦ")]
		if l111lll_ll_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡊࡘࡉࡆࡕࡢࡣࠬᷧ") in group: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group.split(l111lll_ll_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘࡋࡒࡊࡇࡖࡣࡤ࠭ᷨ"))
		else: l111l1l1ll_ll_,l1lll1ll11l_ll_ = group,l111lll_ll_ (u"࠭ࠧᷩ")
		if l1lll1ll11l_ll_!=l111lll_ll_ (u"ࠧࠨᷪ"): l11ll111_ll_ = l111l1l1ll_ll_+l111lll_ll_ (u"ࠨࠢࡿࢀࠥ࠭ᷫ")+l1lll1ll11l_ll_
		else: l11ll111_ll_ = l111l1l1ll_ll_
		if l1llll11lll_ll_ in group.lower():
			if l1llll11lll_ll_ in l111l1l1ll_ll_.lower() and l111l1l1ll_ll_ not in l1lllll1ll1_ll_:
				l1lllll1ll1_ll_.append(l111l1l1ll_ll_)
				if l1llll11lll_ll_ in l111l1l1ll_ll_.lower(): l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᷬ"),l1l1l1l_ll_+l111l1l1ll_ll_,l1111ll1l1_ll_,234,img,l111lll_ll_ (u"ࠪࠫᷭ"),group)
			if l1llll11lll_ll_ in l1lll1ll11l_ll_.lower() and l1lll1ll11l_ll_ not in l1lllll1ll1_ll_:
				l1lllll1ll1_ll_.append(l1lll1ll11l_ll_)
				if l1llll11lll_ll_ in l1lll1ll11l_ll_.lower(): l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᷮ"),l1l1l1l_ll_+l1lll1ll11l_ll_,l1111ll1l1_ll_,234,img,l111lll_ll_ (u"ࠬ࠭ᷯ"),group)
		elif l1llll11lll_ll_ in title.lower():
			url = dict[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪᷰ")]
			l11ll111_ll_ = l11ll111_ll_+l111lll_ll_ (u"ࠧࠡࡾࡿࠤࠬᷱ")+title
			if l111lll_ll_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪᷲ") in group: l11ll111_ll_ = l111lll_ll_ (u"ࠩࠤࠥࡤࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡠࠣࠤࠫᷳ")
			l1lll11l1l_ll_ = re.findall(l111lll_ll_ (u"ࠪࠬࡡ࠴ࡡࡷ࡫ࡿࡠ࠳ࡳࡰ࠵ࡾ࡟࠲ࡲࡱࡶࡽ࡞࠱ࡪࡱࡼࡼ࡝࠰ࡰࡴ࠸࠯ࠨࡽ࡞ࡂ࠲࠯ࡅࡼ࠰࡞ࡂ࠲࠯ࡅࡼ࡝ࡾ࠱࠮ࡄ࠯ࠦࠧࠩᷴ"),url.lower()+l111lll_ll_ (u"ࠫࠫࠬࠧ᷵"),re.DOTALL|re.IGNORECASE)
			if l1lll11l1l_ll_:
				l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ᷶"),l1l1l1l_ll_+title,url,235,img)
			else: l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡸࡨ᷷ࠫ"),l1l1l1l_ll_+title,url,235,img)
	l11l11lll_ll_[:] = sorted(l11l11lll_ll_, reverse=False, key=lambda key: key[1])
	return
def l1111ll11_ll_(title):
	title = title.replace(l111lll_ll_ (u"᷸ࠧࠡࠢࠪ"),l111lll_ll_ (u"ࠨ᷹ࠢࠪ")).replace(l111lll_ll_ (u"ࠩࠣࠤ᷺ࠬ"),l111lll_ll_ (u"ࠪࠤࠬ᷻")).replace(l111lll_ll_ (u"ࠫࠥࠦࠧ᷼"),l111lll_ll_ (u"᷽ࠬࠦࠧ"))
	title = title.replace(l111lll_ll_ (u"࠭ࡼࡽࠩ᷾"),l111lll_ll_ (u"ࠧࡽ᷿ࠩ")).replace(l111lll_ll_ (u"ࠨࡡࡢࡣࠬḀ"),l111lll_ll_ (u"ࠩ࠽ࠫḁ")).replace(l111lll_ll_ (u"ࠪ࠱࠲࠭Ḃ"),l111lll_ll_ (u"ࠫ࠲࠭ḃ"))
	title = title.replace(l111lll_ll_ (u"ࠬࡡ࡛ࠨḄ"),l111lll_ll_ (u"࡛࠭ࠨḅ")).replace(l111lll_ll_ (u"ࠧ࡞࡟ࠪḆ"),l111lll_ll_ (u"ࠨ࡟ࠪḇ"))
	title = title.replace(l111lll_ll_ (u"ࠩࠫࠬࠬḈ"),l111lll_ll_ (u"ࠪࠬࠬḉ")).replace(l111lll_ll_ (u"ࠫ࠮࠯ࠧḊ"),l111lll_ll_ (u"ࠬ࠯ࠧḋ"))
	title = title.replace(l111lll_ll_ (u"࠭࠼࠽ࠩḌ"),l111lll_ll_ (u"ࠧ࠽ࠩḍ")).replace(l111lll_ll_ (u"ࠨࡀࡁࠫḎ"),l111lll_ll_ (u"ࠩࡁࠫḏ"))
	#title = title.strip(l111lll_ll_ (u"ࠪࠤࠬḐ")).strip(l111lll_ll_ (u"ࠫࢁ࠭ḑ")).strip(l111lll_ll_ (u"ࠬ࠳ࠧḒ")).strip(l111lll_ll_ (u"࠭࠺ࠨḓ")).strip(l111lll_ll_ (u"ࠧࠩࠩḔ")).strip(l111lll_ll_ (u"ࠨ࡝ࠪḕ"))
	return title
l111lll_ll_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡖࡔࡑࡏࡔࡠࡐࡄࡑࡊ࠮ࡴࡪࡶ࡯ࡩ࠮ࡀࠊࠊ࡫ࡩࠤࡹ࡯ࡴ࡭ࡧࡀࡁࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧ࠻ࠢࡵࡩࡹࡻࡲ࡯ࠢࡷ࡭ࡹࡲࡥࠋࠋ࡯ࡳࡼ࡫ࡳࡵ࠮࡯ࡥࡳ࡭ࠠ࠾ࠢ࠼࠽࠾࠿ࠬࠨࠩࠍࠍ࡫࡯ࡲࡴࡶࠣࡁࠥࡺࡩࡵ࡮ࡨ࡟࠵ࡀ࠲࡞ࠌࠌࡷࡪࡶࡡࡳࡣࡷࡳࡷࡹࠠ࠾ࠢ࡞ࠫࠥ࠭ࠬࠨ࠼ࠪ࠰ࠬ࠳ࠧ࠭ࠩࡿࠫ࠱࠭࡝ࠨ࠮ࠪ࠭ࠬ࠲ࠧࠤࠩ࠯ࠫ࠳࠭ࠬࠨ࠮ࠪ࠰ࠬࠪࠧ࠭ࠤࠪࠦ࠱࠭ࠡࠨ࠮ࠪࡄࠬ࠲ࠧࠦࠩ࠯ࠫࠫ࠭ࠬࠨࠬࠪ࠰ࠬࡤࠧ࡞ࠌࠌ࡭࡫ࠦࠠࠡࡨ࡬ࡶࡸࡺ࡛࠱࡟ࡀࡁࠬ࠮ࠧ࠻ࠢࡶࡩࡵࡧࡲࡢࡶࡲࡶࡸࠦ࠽ࠡ࡝ࠪ࠭ࠬࡣࠊࠊࡧ࡯࡭࡫ࠦࡦࡪࡴࡶࡸࡠ࠶࡝࠾࠿ࠪ࡟ࠬࡀࠠࡴࡧࡳࡥࡷࡧࡴࡰࡴࡶࠤࡂ࡛ࠦࠨ࡟ࠪࡡࠏࠏࡥ࡭࡫ࡩࠤ࡫࡯ࡲࡴࡶ࡞࠴ࡢࡃ࠽ࠨ࠾ࠪ࠾ࠥࡹࡥࡱࡣࡵࡥࡹࡵࡲࡴࠢࡀࠤࡠ࠭࠾ࠨ࡟ࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡳࡦࡲࡤࡶࡦࡺ࡯ࡳࡵ࠽ࠎࠎࠏࡰࡰࡵ࡬ࡸ࡮ࡵ࡮ࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࡝࠵࠾ࡢ࠴ࡦࡪࡰࡧࠬ࡮࠯ࠊࠊࠋࠦࡴࡴࡹࡩࡵ࡫ࡲࡲࠥࡃࠠࡵ࡫ࡷࡰࡪࡡ࠱࠻࡟࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠧ࠭ࠩࠪ࠭࠳࡬ࡩ࡯ࡦࠫ࡭࠮ࠐࠉࠊ࡫ࡩࠤࡵࡵࡳࡪࡶ࡬ࡳࡳࡄ࠽࠱ࠢࡤࡲࡩࠦࡰࡰࡵ࡬ࡸ࡮ࡵ࡮࠽࠿࡯ࡳࡼ࡫ࡳࡵ࠼ࠍࠍࠎࠏ࡬ࡰࡹࡨࡷࡹࠦ࠽ࠡࡲࡲࡷ࡮ࡺࡩࡰࡰࠍࠍࠎࠏࡳࡦࡲࠣࡁࠥ࡯ࠊࠊ࡫ࡩࠤࡱࡵࡷࡦࡵࡷࡁࡂ࠿࠹࠺࠻࠽ࠤࡱࡧ࡮ࡨࠢࡀࠤࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧࠋࠋ࡬ࡪࠥࡲࡡ࡯ࡩࡀࡁࠬ࠭࠺ࠋࠋࠌࡲࡦࡳࡥ࠲࠮ࡱࡥࡲ࡫࠲ࠡ࠿ࠣࡸ࡮ࡺ࡬ࡦ࡝࠵࠾ࡢ࠴ࡳࡱ࡮࡬ࡸ࠭ࡹࡥࡱ࠮࠴࠭ࠏࠏࠉ࡭ࡣࡱ࡫ࠥࡃࠠࡧ࡫ࡵࡷࡹ࠱࡮ࡢ࡯ࡨ࠵࠰ࡹࡥࡱ࠰ࡶࡸࡷ࡯ࡰࠩࠩࠣࠫ࠮ࠐࠉࠊࠥࡷ࡭ࡹࡲࡥࠡ࠿ࠣࡪ࡮ࡸࡳࡵ࠭ࠪࠤࠬ࠱ࡳࡦࡲ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯ࠫࠨࠢࠪ࠯ࡳࡧ࡭ࡦ࠴ࠍࠍࠎࠩࡴࡪࡶ࡯ࡩࠥࡃࠠࡵ࡫ࡷࡰࡪ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࠢࠣࠫ࠱࠭ࠠࠨࠫ࠱ࡶࡪࡶ࡬ࡢࡥࡨࠬࠬࠦࠠࠨ࠮ࠪࠤࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠡ࡮ࡤࡲ࡬࠲ࡴࡪࡶ࡯ࡩࠏࠨࠢࠣḖ")
def l1llll11111_ll_(title):
	if len(title)<3: return title,title
	lang,sep = l111lll_ll_ (u"ࠪࠫḗ"),l111lll_ll_ (u"ࠫࠬḘ")
	l11ll111_ll_ = title
	first = title[:1]
	rest = title[1:]
	if   first==l111lll_ll_ (u"ࠬ࠮ࠧḙ"): sep = l111lll_ll_ (u"࠭ࠩࠨḚ")
	elif first==l111lll_ll_ (u"ࠧ࡜ࠩḛ"): sep = l111lll_ll_ (u"ࠨ࡟ࠪḜ")
	elif first==l111lll_ll_ (u"ࠩ࠿ࠫḝ"): sep = l111lll_ll_ (u"ࠪࡂࠬḞ")
	elif first==l111lll_ll_ (u"ࠫࢁ࠭ḟ"): sep = l111lll_ll_ (u"ࠬࢂࠧḠ")
	if (sep and sep in rest):
		l1lll1lllll_ll_,l1lll1llll1_ll_ = rest.split(sep,1)
		lang = l1lll1lllll_ll_
		l11ll111_ll_ = first+l1lll1lllll_ll_+sep+l111lll_ll_ (u"࠭ࠠࠨḡ")+l1lll1llll1_ll_
	elif title.count(l111lll_ll_ (u"ࠧࡽࠩḢ"))>=2:
		l1lll1lllll_ll_,l1lll1llll1_ll_ = title.split(l111lll_ll_ (u"ࠨࡾࠪḣ"),1)
		lang = l1lll1lllll_ll_
		l11ll111_ll_ = l1lll1lllll_ll_+l111lll_ll_ (u"ࠩࠣࢀࠬḤ")+l1lll1llll1_ll_
	else:
		sep = re.findall(l111lll_ll_ (u"ࠪࡢࡡࡽࡻ࠳ࡿࠫࠤࢁࡢ࠺ࡽ࡞࠰ࢀࡡࢂࡼ࡝࡟ࡿࡠ࠮ࢂ࡜ࠤࡾ࡟࠲ࢁࡢࠬࡽ࡞ࠧࢀࡡ࠭ࡼ࡝ࠣࡿࡠࡅࢂ࡜ࠦࡾ࡟ࠪࢁࡢࠪࡽ࡞ࡡ࠭ࠬḥ"),title,re.DOTALL)
		if not sep: sep = re.findall(l111lll_ll_ (u"ࠫࡣࡢࡷࡼ࠵ࢀࠬࠥࢂ࡜࠻ࡾ࡟࠱ࢁࡢࡼࡽ࡞ࡠࢀࡡ࠯ࡼ࡝ࠥࡿࡠ࠳ࢂ࡜࠭ࡾ࡟ࠨࢁࡢࠧࡽ࡞ࠤࢀࡡࡆࡼ࡝ࠧࡿࡠࠫࢂ࡜ࠫࡾ࡟ࡢ࠮࠭Ḧ"),title,re.DOTALL)
		if not sep: sep = re.findall(l111lll_ll_ (u"ࠬࡤ࡜ࡸࡽ࠷ࢁ࠭ࠦࡼ࡝࠼ࡿࡠ࠲ࢂ࡜ࡽࡾ࡟ࡡࢁࡢࠩࡽ࡞ࠦࢀࡡ࠴ࡼ࡝࠮ࡿࡠࠩࢂ࡜ࠨࡾ࡟ࠥࢁࡢࡀࡽ࡞ࠨࢀࡡࠬࡼ࡝ࠬࡿࡠࡣ࠯ࠧḧ"),title,re.DOTALL)
		if sep:
			l1lll1lllll_ll_,l1lll1llll1_ll_ = title.split(sep[0],1)
			lang = l1lll1lllll_ll_
			l11ll111_ll_ = l1lll1lllll_ll_+l111lll_ll_ (u"࠭ࠠࠨḨ")+sep[0]+l111lll_ll_ (u"ࠧࠡࠩḩ")+l1lll1llll1_ll_
	l11ll111_ll_ = l11ll111_ll_.replace(l111lll_ll_ (u"ࠨࠢࠣࠤࠬḪ"),l111lll_ll_ (u"ࠩࠣࠫḫ")).replace(l111lll_ll_ (u"ࠪࠤࠥ࠭Ḭ"),l111lll_ll_ (u"ࠫࠥ࠭ḭ"))
	lang = lang.replace(l111lll_ll_ (u"ࠬࠦࠠࠨḮ"),l111lll_ll_ (u"࠭ࠠࠨḯ"))
	if lang==l111lll_ll_ (u"ࠧࠨḰ"): lang = l111lll_ll_ (u"ࠨࠣࠤࡣࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥ࡟ࠢࠣࠪḱ")
	return lang,l11ll111_ll_
def l1lllllll11_ll_(l1111l1l11_ll_=True):
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡆࡖࡊࡇࡔࡆࡡࡖࡘࡗࡋࡁࡎࡕࠣ࠵ࠬḲ"),l111lll_ll_ (u"ࠪ࡟ࠬḳ")+l1ll11l11_ll_+l111lll_ll_ (u"ࠫࡢ࠭Ḵ"))
	l1ll11l11_ll_ = settings.getSettingString(l111lll_ll_ (u"ࠬ࡯ࡰࡵࡸ࠱ࡹࡸ࡫ࡲࡢࡩࡨࡲࡹ࠭ḵ"))
	l1lllll111l_ll_ = settings.getSetting(l111lll_ll_ (u"࠭ࡩࡱࡶࡹ࠲ࡺࡸ࡬ࠨḶ"))
	headers = {l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫḷ"):l1ll11l11_ll_}
	ok = l1llll1lll1_ll_(False)
	if not ok:
		l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫḸ"),l111lll_ll_ (u"ࠩไุ้ࠦศิฯหࠤ๊๊แศฬࠣࡍࡕ࡚ࡖࠡ࠰ࠣวาะๅศๆࠣีฬฮืࠡࡋࡓࡘฺ๋࡛ࠦำูࠣา๐อࠡล๋ࠤฬ์สࠡๆ่ࠤฯูสฯั่ࠤุอศใษࠣาิ๋ษࠡࡋࡓࡘ࡛ࠦวๅ็๋ะํีษࠡสส่อืๆศ็ฯࠤ࠳ࠦ็ั้ࠣห้ิฯๆหࠣฮาะวอࠢสุฯืวไ่ࠢำๆ๎ูุ๊ࠡั๏ำ้ࠠ์ฯฬࠥษๆࠡฬู๎ๆํࠠษ่ไื่ࠦไๅสิ๊ฬ๋ฬࠡสสืฯิฯศ็ࠣๆฬฬๅสࠢࡌࡔ࡙࡜ࠠศๆ่์ั๎ฯสࠢห๋ีอࠠศๆหี๋อๅอࠩḹ"))
		if l1lllll111l_ll_==l111lll_ll_ (u"ࠪࠫḺ"): l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩḻ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡐࡲࠤࡎࡖࡔࡗࠢࡘࡖࡑࠦࡦࡰࡷࡱࡨࠥࡺ࡯ࠡࡦࡲࡻࡳࡲ࡯ࡢࡦࠣࡍࡕ࡚ࡖࠡࡨ࡬ࡰࡪࡹࠧḼ"))
		else: l1111l1l_ll_(l111lll_ll_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫḽ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡸࡴࠦࡤࡰࡹࡱࡰࡴࡧࡤࠡࡋࡓࡘ࡛ࠦࡦࡪ࡮ࡨࡷࠬḾ"))
		return
	#l1ll11l_ll_(l111lll_ll_ (u"ࠨࡋࡓࡘ࡛࠭ḿ"),l111lll_ll_ (u"ࠩฯ่อࠦๅๅใสฮࠥาฯ๋ัฬࠫṀ"))
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠪࡷࡹࡧࡲࡵࠩṁ"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫṂ"),l111lll_ll_ (u"ࠬࡋࡍࡂࡆࠣ࠵࠶࠷ࠧṃ"))
	if l1111l1l11_ll_:
		l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩṄ"),l111lll_ll_ (u"ฺࠧ็็๎ฮࠦฬๅส้้ࠣ็วหࠢࡌࡔ࡙࡜ࠠอัํำฮࠦโะࠢอัฯอฬࠡ฻าอࠥีโศศๅࠤ࠳ࠦ็ๅࠢอี๏ีࠠฤ่ࠣฮั๊ศࠡษ็้้็วหࠢส่ว์ࠠภࠩṅ"),l111lll_ll_ (u"ࠨࠩṆ"),l111lll_ll_ (u"ࠩࠪṇ"),l111lll_ll_ (u"ࠪ็้อࠧṈ"),l111lll_ll_ (u"๋ࠫ฿ๅࠨṉ"))
		if not l111111l1_ll_:
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠬࡹࡴࡰࡲࠪṊ"))
			return
	l1111l111_ll_ = l11111l11_ll_()
	l1111l111_ll_.create(l111lll_ll_ (u"࠭ฬๅส้้ࠣ็วหࠢࡌࡔ࡙࡜ࠠอัํำฮ࠭ṋ"),l111lll_ll_ (u"ࠧอๆหࠤฬ๊ๅๅใࠣห้ืฦ๋ีํࠤ࠭อไๆๆไࠤ็ี๋ࠠๅ๋๊้ࠥศ๋ำࠣ์็ี๋ࠠฯอหัࠦศฺุࠣห้๎โหࠫࠪṌ"))
	l11l1111l1_ll_ = l111lll_ll_ (u"ࠨࠩṍ")
	l11111lll_ll_ = 1024*1024
	chunksize = 1*l11111lll_ll_
	import requests
	response = requests.get(l1lllll111l_ll_,headers=headers,stream=True)
	filesize = int(response.headers[l111lll_ll_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡐࡪࡴࡧࡵࡪࠪṎ")])
	l111111ll_ll_ = int(1+filesize/l11111lll_ll_)
	l1llll111l_ll_ = int(filesize/chunksize)
	i = 0
	t1 = time.time()-30
	if 1:
		for chunk in response.iter_content(chunk_size=chunksize):
			i = i+1
			#if i==2: break
			if l1111l111_ll_.iscanceled():
				response.close()
				return
			l1lll1l1l1_ll_ = time.time()
			l1lll11lll_ll_ = l1lll1l1l1_ll_-t1
			l1lll1l11l_ll_ = l1lll11lll_ll_/i
			l1lllll11l_ll_ = l1lll1l11l_ll_*(l1llll111l_ll_+1)
			l1lll1ll1l_ll_ = l1lllll11l_ll_-l1lll11lll_ll_
			#l1111l111_ll_.update(0+int(35*i/l1llll111l_ll_),l111lll_ll_ (u"ࠪะ้ฮࠠศๆ่่ๆࠦวๅำษ๎ุ๐࠺࠮ࠢส่ัุมࠡำๅ้ࠬṏ"),str(i*chunksize/l11111lll_ll_)+l111lll_ll_ (u"ࠫ࠴࠭Ṑ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠬࠦࡍࡃࠢࠣࠤࠥ๎โห่ࠢฮอ่๊࠻ࠢࠪṑ")+time.strftime(l111lll_ll_ (u"ࠨࠥࡉ࠼ࠨࡑ࠿ࠫࡓࠣṒ"),time.gmtime(l1lll1ll1l_ll_))+l111lll_ll_ (u"ࠧࠡโࠪṓ"))
			l1111l111_ll_.update(0+int(35*i/l1llll111l_ll_),l111lll_ll_ (u"ࠨฮ็ฬࠥอไๆๆไࠤฬ๊ัว์ึ๎࠿࠳ࠠศๆฯึฦࠦัใ็ࠪṔ"),str(i*chunksize/l11111lll_ll_)+l111lll_ll_ (u"ࠩ࠲ࠫṕ")+str(l111111ll_ll_)+l111lll_ll_ (u"ࠪࠤࡒࡈࠧṖ"))
			l11l1111l1_ll_ = l11l1111l1_ll_+chunk
	else:
		with open(l1111l111l_ll_,l111lll_ll_ (u"ࠫࡷࡨࠧṗ")) as f: l11l1111l1_ll_ = f.read()
	with open(l1111l111l_ll_,l111lll_ll_ (u"ࠬࡽࡢࠨṘ")) as f: f.write(l11l1111l1_ll_)
	del response,f
	#l1llll1l1l1_ll_ = l111lll_ll_ (u"࠭ࡩࡱࡶࡹࡣࠬṙ")+str(int(now))+l111lll_ll_ (u"ࠧࡠ࠰ࡰ࠷ࡺ࠭Ṛ")
	#l111lll11l_ll_ = os.path.join(l1lll11ll1_ll_,l1llll1l1l1_ll_)
	#return
	#l1ll1l_ll_(l1lllll111l_ll_,l11l1111l1_ll_)
	l111lll_ll_ (u"ࠣࠤࠥࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤ࡮ࡲࡷࡪ࠮ࠩࠋࠋࡦ࡬ࡺࡴ࡫ࡴࡡࡦࡳࡺࡴࡴࠡ࠿ࠣࡪ࡮ࡲࡥࡴ࡫ࡽࡩ࠴ࡓࡥࡨࡣࡅࡽࡹ࡫ࠊࠊࡦࡨࡪࠥ࡭ࡥࡵࡡࡦ࡬ࡺࡴ࡫ࠩࡵࡷࡥࡷࡺࠩ࠻ࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡥࡳ࡭ࡥࠨ࠼ࠪࡦࡾࡺࡥࡴ࠿ࠨࡷ࠲ࠫࡳࠨࠧࠫࡷࡹࡧࡲࡵ࠮ࡶࡸࡦࡸࡴࠬࡏࡨ࡫ࡦࡈࡹࡵࡧࠬࢁࠏࠏࠉࡳࡧࡶࡴࡴࡴࡳࡦࠢࡀࠤࡷ࡫ࡱࡶࡧࡶࡸࡸ࠴ࡧࡦࡶࠫ࡭ࡵࡺࡶࡖࡔࡏ࠰࡭࡫ࡡࡥࡧࡵࡷࡂ࡮ࡥࡢࡦࡨࡶࡸ࠯ࠊࠊࠋࡦ࡬ࡺࡴ࡫ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠊࡴࡨࡸࡺࡸ࡮ࠡࡥ࡫ࡹࡳࡱࠊࠊࡥ࡫ࡹࡳࡱࠠ࠾ࠢࡪࡩࡹࡥࡣࡩࡷࡱ࡯࠭࠶ࠩࠋࠋࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭࠭ࠧ࠭ࡵࡷࡶ࠭ࡲࡥ࡯ࠪࡦ࡬ࡺࡴ࡫ࠪࠫࠬࠎࠎࡳࡹࡵࡪࡵࡩࡦࡪࠠ࠾ࠢࡆࡹࡸࡺ࡯࡮ࡖ࡫ࡶࡪࡧࡤࠩࠫࠍࠍ࡫ࡵࡲࠡ࡫ࠣ࡭ࡳࠦࡣࡩࡷࡱ࡯ࡸࡥࡣࡰࡷࡱࡸ࠿ࠐࠉࠊ࡯ࡼࡸ࡭ࡸࡥࡢࡦ࠱ࡷࡹࡧࡲࡵࡡࡱࡩࡼࡥࡴࡩࡴࡨࡥࡩ࠮ࡩ࠭ࡩࡨࡸࡤࡩࡨࡶࡰ࡮࠰࡮࠰ࡍࡦࡩࡤࡆࡾࡺࡥࠪࠌࠌࡧࡴࡻ࡮ࡵࠢࡀࠤ࠵ࠐࠉࡸࡪ࡬ࡰࡪࠦࡣࡰࡷࡱࡸࡁࡃࡣࡩࡷࡱ࡯ࡸࡥࡣࡰࡷࡱࡸ࠿ࠐࠉࠊࡶ࡬ࡱࡪ࠴ࡳ࡭ࡧࡨࡴ࠭࠷࠰࠱࠲ࠬࠎࠎࠏࡣࡰࡷࡱࡸࠥࡃࠠ࡭ࡧࡱࠬࡲࡿࡴࡩࡴࡨࡥࡩ࠴ࡦࡪࡰ࡬ࡷ࡭࡫ࡤࡍࡋࡖࡘ࠮ࠐࠉࠊ࡫ࡩࠤࡵࡊࡩࡢ࡮ࡲ࡫࠳࡯ࡳࡤࡣࡱࡧࡪࡲࡥࡥࠪࠬ࠾ࠥࡸࡥࡵࡷࡵࡲࠏࠏࠉࡱࡆ࡬ࡥࡱࡵࡧ࠯ࡷࡳࡨࡦࡺࡥࠩ࠲࠮࡭ࡳࡺࠨ࠴࠷࠭ࡧࡴࡻ࡮ࡵ࠱ࡦ࡬ࡺࡴ࡫ࡴࡡࡦࡳࡺࡴࡴࠪ࠮ࠪะ้ฮࠠศๆ่่ๆࠦวๅำษ๎ุ๐࠺࠮ࠢส่ัุมࠡำๅ้ࠬ࠲ࡳࡵࡴࠫࡧࡴࡻ࡮ࡵࠫ࠮ࠫ࠴࠭ࠫࡴࡶࡵࠬࡨ࡮ࡵ࡯࡭ࡶࡣࡨࡵࡵ࡯ࡶࠬ࠯ࠬࠦࡍࡃࠩࠬࠎࠎࠩ࡭ࡺࡶ࡫ࡶࡪࡧࡤ࠯ࡹࡤ࡭ࡹࡥࡦࡪࡰ࡬ࡷ࡭࡯࡮ࡨࡡࡤࡰࡱࡥࡴࡩࡴࡨࡥࡩࡹࠨࠪࠌࠌࡪࡴࡸࠠࡪࡦࠣ࡭ࡳࠦࡣࡩࡷࡱ࡯ࡸࡥࡣࡰࡷࡱࡸ࠿ࠐࠉࠊࡥ࡫ࡹࡳࡱࠠ࠾ࠢࡰࡽࡹ࡮ࡲࡦࡣࡧ࠲ࡷ࡫ࡳࡶ࡮ࡷࡷࡉࡏࡃࡕ࡝࡬ࡨࡢࠐࠉࠊ࡯࠶ࡹࡤࡺࡥࡹࡶࠣࡁࠥࡳ࠳ࡶࡡࡷࡩࡽࡺࠫࡤࡪࡸࡲࡰࠐࠉࠣࠤࠥṛ")
	if l1111l111_ll_.iscanceled(): return
	l1111l111_ll_.update(35,l111lll_ll_ (u"ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊ส࠼࠰ࠤฬ๊ๅๅใࠣี็๋ࠧṜ"),l111lll_ll_ (u"ࠪ࠵࠴࠹ࠧṝ"))
	l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠫࠧࡺࡶࡨ࠯ࠪṞ"),l111lll_ll_ (u"ࠬࠨࠠࡵࡸࡪ࠱ࠬṟ"))
	l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"࠭๎ࠨṠ"),l111lll_ll_ (u"ࠧࠨṡ")).replace(l111lll_ll_ (u"ࠨํࠪṢ"),l111lll_ll_ (u"ࠩࠪṣ")).replace(l111lll_ll_ (u"ࠪ๓ࠬṤ"),l111lll_ll_ (u"ࠫࠬṥ")).replace(l111lll_ll_ (u"ࠬ๒ࠧṦ"),l111lll_ll_ (u"࠭ࠧṧ"))
	l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠧ๒ࠩṨ"),l111lll_ll_ (u"ࠨࠩṩ")).replace(l111lll_ll_ (u"ࠩ๓ࠫṪ"),l111lll_ll_ (u"ࠪࠫṫ")).replace(l111lll_ll_ (u"ࠫ๒࠭Ṭ"),l111lll_ll_ (u"ࠬ࠭ṭ")).replace(l111lll_ll_ (u"࠭๒ࠨṮ"),l111lll_ll_ (u"ࠧࠨṯ"))
	l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠨࡩࡵࡳࡺࡶ࠭ࡵ࡫ࡷࡰࡪࡃࠧṰ"),l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰ࠾ࠩṱ"))
	l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠪࡸࡻ࡭࠭ࠨṲ"),l111lll_ll_ (u"ࠫࠬṳ"))
	#l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠬ࡭ࡲࡰࡷࡳࡁࠧࡇࡒࠡࡾࠣࡍࡘࡒࡁࡎࡋࡆࠦࠬṴ"),l111lll_ll_ (u"࠭ࡧࡳࡱࡸࡴࡂࠨࠢࠨṵ"))
	username = settings.getSetting(l111lll_ll_ (u"ࠧࡪࡲࡷࡺ࠳ࡻࡳࡦࡴࡱࡥࡲ࡫ࠧṶ"))
	password = settings.getSetting(l111lll_ll_ (u"ࠨ࡫ࡳࡸࡻ࠴ࡰࡢࡵࡶࡻࡴࡸࡤࠨṷ"))
	server = settings.getSetting(l111lll_ll_ (u"ࠩ࡬ࡴࡹࡼ࠮ࡴࡧࡵࡺࡪࡸࠧṸ"))
	l1111ll1ll_ll_,l111lll1l1_ll_ = [],[]
	url = server+l111lll_ll_ (u"ࠪ࠳ࡵࡲࡡࡺࡧࡵࡣࡦࡶࡩ࠯ࡲ࡫ࡴࡄࡻࡳࡦࡴࡱࡥࡲ࡫࠽ࠨṹ")+username+l111lll_ll_ (u"ࠫࠫࡶࡡࡴࡵࡺࡳࡷࡪ࠽ࠨṺ")+password+l111lll_ll_ (u"ࠬࠬࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡢࡷࡪࡸࡩࡦࡵࡢࡧࡦࡺࡥࡨࡱࡵ࡭ࡪࡹࠧṻ")
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"࠭ࠧṼ"),headers,l111lll_ll_ (u"ࠧࠨṽ"),l111lll_ll_ (u"ࠨࡋࡓࡘ࡛࠳ࡃࡓࡇࡄࡘࡊࡥࡓࡕࡔࡈࡅࡒ࡙࠭࠳ࡰࡧࠫṾ"))
	if l1111l111_ll_.iscanceled(): return
	l1111l111_ll_.update(40,l111lll_ll_ (u"ࠩฯ่อࠦวๅ็็ๅฬะࠠศๆฮห๋๎๊ส࠼࠰ࠤฬ๊ๅๅใࠣี็๋ࠧṿ"),l111lll_ll_ (u"ࠪ࠶࠴࠹ࠧẀ"))
	l111ll1l11_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶࡾࡥ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ẁ"),html,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭Ẃ"),l111lll_ll_ (u"࠭ࠧẃ"))
	for group in l111ll1l11_ll_:
		group = group.replace(l111lll_ll_ (u"ࠧ࡝࠱ࠪẄ"),l111lll_ll_ (u"ࠨ࠱ࠪẅ")).decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪẆ")).encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨẇ"))
		l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠫ࡬ࡸ࡯ࡶࡲࡀࠦࠬẈ")+group+l111lll_ll_ (u"ࠬࠨࠧẉ"),l111lll_ll_ (u"࠭ࡧࡳࡱࡸࡴࡂࠨ࡟ࡠࡋࡓࡘ࡛࡙ࡅࡓࡋࡈࡗࡤࡥࠧẊ")+group+l111lll_ll_ (u"ࠧࠣࠩẋ"))
	url = server+l111lll_ll_ (u"ࠨ࠱ࡳࡰࡦࡿࡥࡳࡡࡤࡴ࡮࠴ࡰࡩࡲࡂࡹࡸ࡫ࡲ࡯ࡣࡰࡩࡂ࠭Ẍ")+username+l111lll_ll_ (u"ࠩࠩࡴࡦࡹࡳࡸࡱࡵࡨࡂ࠭ẍ")+password+l111lll_ll_ (u"ࠪࠪࡦࡩࡴࡪࡱࡱࡁ࡬࡫ࡴࡠࡸࡲࡨࡤࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴࠩẎ")
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬẏ"),headers,l111lll_ll_ (u"ࠬ࠭Ẑ"),l111lll_ll_ (u"࠭ࡉࡑࡖ࡙࠱ࡈࡘࡅࡂࡖࡈࡣࡘ࡚ࡒࡆࡃࡐࡗ࠲࠹ࡲࡥࠩẑ"))
	l1111l111_ll_.update(45,l111lll_ll_ (u"ࠧอๆหࠤฬ๊ๅๅใสฮࠥอไฬษ้์๏ฯ࠺࠮ࠢส่๊๊แࠡำๅ้ࠬẒ"),l111lll_ll_ (u"ࠨ࠵࠲࠷ࠬẓ"))
	l1llll1l111_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࡣࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫẔ"),html,re.DOTALL)
	for group in l1llll1l111_ll_:
		group = group.replace(l111lll_ll_ (u"ࠪࡠ࠴࠭ẕ"),l111lll_ll_ (u"ࠫ࠴࠭ẖ")).decode(l111lll_ll_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭ẗ")).encode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠻ࠫẘ"))
		l11l1111l1_ll_ = l11l1111l1_ll_.replace(l111lll_ll_ (u"ࠧࡨࡴࡲࡹࡵࡃࠢࠨẙ")+group+l111lll_ll_ (u"ࠨࠤࠪẚ"),l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰ࠾ࠤࡢࡣࡒࡕࡖࡊࡇࡖࡣࡤ࠭ẛ")+group+l111lll_ll_ (u"ࠪࠦࠬẜ"))
	url = server+l111lll_ll_ (u"ࠫ࠴ࡶ࡬ࡢࡻࡨࡶࡤࡧࡰࡪ࠰ࡳ࡬ࡵࡅࡵࡴࡧࡵࡲࡦࡳࡥ࠾ࠩẝ")+username+l111lll_ll_ (u"ࠬࠬࡰࡢࡵࡶࡻࡴࡸࡤ࠾ࠩẞ")+password+l111lll_ll_ (u"࠭ࠦࡢࡥࡷ࡭ࡴࡴ࠽ࡨࡧࡷࡣࡱ࡯ࡶࡦࡡࡶࡸࡷ࡫ࡡ࡮ࡵࠪẟ")
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠧࠨẠ"),headers,l111lll_ll_ (u"ࠨࠩạ"),l111lll_ll_ (u"ࠩࡌࡔ࡙࡜࠭ࡄࡔࡈࡅ࡙ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓ࠮࠶ࡷ࡬ࠬẢ"))
	l1llllllll1_ll_ = re.findall(l111lll_ll_ (u"ࠪࠦࡳࡧ࡭ࡦࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵࡸࡢࡥࡷࡩࡨࡪࡸࡨࠦ࠿࠮࠮ࠫࡁࠬ࠰ࠬả"),html,re.DOTALL)
	for name,l11111ll1l_ll_ in l1llllllll1_ll_:
		if l11111ll1l_ll_==l111lll_ll_ (u"ࠫ࠶࠭Ấ"): l1111ll1ll_ll_.append(name)
	l1111ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࠨ࡮ࡢ࡯ࡨࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡨࡴ࡬ࡥࡣࡩࡣࡱࡲࡪࡲ࡟ࡪࡦࠥ࠾࠭࠴ࠪࡀࠫ࠯ࠫấ"),html,re.DOTALL)
	for name,l1lll1ll1l1_ll_ in l1111ll111_ll_:
		if l1lll1ll1l1_ll_!=l111lll_ll_ (u"࠭࡮ࡶ࡮࡯ࠫẦ"): l111lll1l1_ll_.append(name)
	lines = re.findall(l111lll_ll_ (u"ࠧࡊࡐࡉࠬ࠳࠰࠿ࠪࠥࡈ࡜࡙࠭ầ"),l11l1111l1_ll_+l111lll_ll_ (u"ࠨࠥࡈ࡜࡙࠭Ẩ"),re.DOTALL)
	del l11l1111l1_ll_,html,l111ll1l11_ll_,l1llll1l111_ll_,l1llllllll1_ll_,l1111ll111_ll_
	l11111l111_ll_ = []
	length = len(lines)
	i = 0
	for line in lines:
		group,title,type = l111lll_ll_ (u"ࠩࠪẩ"),l111lll_ll_ (u"ࠪࠫẪ"),l111lll_ll_ (u"ࠫࠬẫ")
		dict = {}
		i = i+1
		if l1111l111_ll_.iscanceled(): return
		if i%31==0: l1111l111_ll_.update(50+int(25*i/length),l111lll_ll_ (u"่ࠬัศรฬࠤฬ๊ๅๅใสฮࠥอไอัํำฮࡀ࠭ࠡษ็ๅ๏ี๊้ࠢิๆ๊࠭Ậ"),str(i)+l111lll_ll_ (u"࠭࠯ࠨậ")+str(length))
		line = line.replace(l111lll_ll_ (u"ࠧ࡝ࡴࠪẮ"),l111lll_ll_ (u"ࠨࠩắ")).replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬẰ"),l111lll_ll_ (u"ࠪࠫằ"))
		if l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࠩẲ") not in line: continue
		line,url = line.rsplit(l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪẳ"),1)
		url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࠫẴ")+url
		try:
			line,title = line.rsplit(l111lll_ll_ (u"ࠧࠣ࠮ࠪẵ"),1)
			line = line+l111lll_ll_ (u"ࠨࠤࠪẶ")
		except:
			#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡉࡅࡎࡒࡅࡅࠩặ"),l111lll_ll_ (u"ࠪࡊࡆࡏࡌࡆࡆࠪẸ"))
			try: line,title = line.rsplit(l111lll_ll_ (u"ࠫ࠶࠲ࠧẹ"),1)
			except: title = l111lll_ll_ (u"ࠬ࠭Ẻ")
		dict[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪẻ")] = url
		params = re.findall(l111lll_ll_ (u"ࠧࠡࠪ࠱࠮ࡄ࠯࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨẼ"),line,re.DOTALL)
		for key,value in params:
			key = key.replace(l111lll_ll_ (u"ࠨࠤࠪẽ"),l111lll_ll_ (u"ࠩࠪẾ")).strip(l111lll_ll_ (u"ࠪࠤࠬế"))
			dict[key] = value.strip(l111lll_ll_ (u"ࠫࠥ࠭Ề"))
		dict[l111lll_ll_ (u"ࠬࡵࡲࡨࡡࡷ࡭ࡹࡲࡥࠨề")] = title
		if title==l111lll_ll_ (u"࠭ࠧỂ"):
			if l111lll_ll_ (u"ࠧ࡯ࡣࡰࡩࠬể") in dict.keys() and dict[l111lll_ll_ (u"ࠨࡰࡤࡱࡪ࠭Ễ")]!=l111lll_ll_ (u"ࠩࠪễ"): title = dict[l111lll_ll_ (u"ࠪࡲࡦࡳࡥࠨỆ")]
			else: title = l111lll_ll_ (u"ࠫࠦࠧ࡟ࡠࡗࡑࡏࡓࡕࡗࡏࡡࡢࠥࠦ࠭ệ")
		dict[l111lll_ll_ (u"ࠬࡺࡩࡵ࡮ࡨࠫỈ")] = title.strip(l111lll_ll_ (u"࠭ࠠࠨỉ")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪỊ"),l111lll_ll_ (u"ࠨࠢࠪị")).replace(l111lll_ll_ (u"ࠩࠣࠤࠬỌ"),l111lll_ll_ (u"ࠪࠤࠬọ"))
		if l111lll_ll_ (u"ࠫࡱࡵࡧࡰࠩỎ") in dict.keys():
			dict[l111lll_ll_ (u"ࠬ࡯࡭ࡨࠩỏ")] = dict[l111lll_ll_ (u"࠭࡬ࡰࡩࡲࠫỐ")]
			del dict[l111lll_ll_ (u"ࠧ࡭ࡱࡪࡳࠬố")]
		else: dict[l111lll_ll_ (u"ࠨ࡫ࡰ࡫ࠬỒ")] = l111lll_ll_ (u"ࠩࠪồ")
		if l111lll_ll_ (u"ࠪ࡫ࡷࡵࡵࡱࠩỔ") in dict.keys() and dict[l111lll_ll_ (u"ࠫ࡬ࡸ࡯ࡶࡲࠪổ")]!=l111lll_ll_ (u"ࠬ࠭Ỗ"): group = dict[l111lll_ll_ (u"࠭ࡧࡳࡱࡸࡴࠬỗ")]
		else: group = l111lll_ll_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡥࠡࠢࠩỘ")
		dict[l111lll_ll_ (u"ࠨࡱࡵ࡫ࡤ࡭ࡲࡰࡷࡳࠫộ")] = group
		l1lll11l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩࠫࡠ࠳ࡧࡶࡪࡾ࡟࠲ࡲࡶ࠴ࡽ࡞࠱ࡱࡰࡼࡼ࡝࠰ࡩࡰࡻࢂ࡜࠯࡯ࡳ࠷࠮࠮ࡼ࡝ࡁ࠱࠮ࡄࢂ࠯࡝ࡁ࠱࠮ࡄࢂ࡜ࡽ࠰࠭ࡃ࠮ࠬࠦࠨỚ"),url.lower()+l111lll_ll_ (u"ࠪࠪࠫ࠭ớ"),re.DOTALL|re.IGNORECASE)
		context = l111lll_ll_ (u"ࠫࠬỜ")
		if l1lll11l1l_ll_ or l111lll_ll_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘࡋࡒࡊࡇࡖࡣࡤ࠭ờ") in group or l111lll_ll_ (u"࠭࡟ࡠࡏࡒ࡚ࡎࡋࡓࡠࡡࠪỞ") in group:
			type = l111lll_ll_ (u"ࠧࡗࡑࡇࠫở")
			if l111lll_ll_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡇࡕࡍࡊ࡙࡟ࡠࠩỠ") in group: type = type+l111lll_ll_ (u"ࠩࡢࡗࡊࡘࡉࡆࡕࠪỡ")
			elif l111lll_ll_ (u"ࠪࡣࡤࡓࡏࡗࡋࡈࡗࡤࡥࠧỢ") in group: type = type+l111lll_ll_ (u"ࠫࡤࡓࡏࡗࡋࡈࡗࠬợ")
			else: type = type+l111lll_ll_ (u"ࠬࡥࡕࡏࡍࡑࡓ࡜ࡔࠧỤ")
			group = group.replace(l111lll_ll_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡅࡓࡋࡈࡗࡤࡥࠧụ"),l111lll_ll_ (u"ࠧࠨỦ")).replace(l111lll_ll_ (u"ࠨࡡࡢࡑࡔ࡜ࡉࡆࡕࡢࡣࠬủ"),l111lll_ll_ (u"ࠩࠪỨ"))
		else:
			type = l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࠨứ")
			if group==l111lll_ll_ (u"ࠫࠬỪ"): type = type+l111lll_ll_ (u"ࠬࡥࡕࡏࡍࡑࡓ࡜ࡔࠧừ")
			if title in l111lll1l1_ll_: context = context+l111lll_ll_ (u"࠭࡟ࡆࡒࡊࠫỬ")
			if title in l1111ll1ll_ll_: context = context+l111lll_ll_ (u"ࠧࡠࡃࡕࡇࡍࡏࡖࡆࡆࠪử")
			type = type+context
		#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨỮ"),l111lll_ll_ (u"ࠩࡈࡑࡆࡊࠠ࠳࠴࠵࠶ࠥࠦ࠮ࠡࠢࠪữ")+str(i*2)+l111lll_ll_ (u"ࠪࠤࠥ࠴ࠠࠡࠩỰ")+group)
		dict[l111lll_ll_ (u"ࠫࡹࡿࡰࡦࠩự")] = type
		dict[l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭Ỳ")] = context
		group = group.strip(l111lll_ll_ (u"࠭ࠠࠨỳ")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪỴ"),l111lll_ll_ (u"ࠨࠢࠪỵ")).replace(l111lll_ll_ (u"ࠩࠣࠤࠬỶ"),l111lll_ll_ (u"ࠪࠤࠬỷ"))
		if type==l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡘࡒࡐࡔࡏࡘࡐࠪỸ"): group = l111lll_ll_ (u"ࠬࠧࠡࡠࡡࡘࡒࡐࡔࡏࡘࡐࡢࡣࠦࠧࠧỹ")
		elif type==l111lll_ll_ (u"࠭ࡖࡐࡆࡢ࡙ࡓࡑࡎࡐ࡙ࡑࠫỺ"): group = l111lll_ll_ (u"ࠧࠢࠣࡢࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤࡥࠡࠢࠩỻ")
		elif type==l111lll_ll_ (u"ࠨࡘࡒࡈࡤ࡙ࡅࡓࡋࡈࡗࠬỼ"):
			series_title = re.findall(l111lll_ll_ (u"ࠩࠫ࠲࠯ࡅࠩࠡ࡝ࡖࡷࡢࡢࡤࠬࠢ࠮࡟ࡊ࡫࡝࡝ࡦ࠮ࠫỽ"),dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩỾ")],re.DOTALL)
			if series_title: group = group+l111lll_ll_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡊࡘࡉࡆࡕࡢࡣࠬỿ")+series_title[0]
			else: group = group+l111lll_ll_ (u"ࠬࡥ࡟ࡊࡒࡗ࡚ࡘࡋࡒࡊࡇࡖࡣࡤ࠭ἀ")+l111lll_ll_ (u"࠭ࠡࠢࡡࡢ࡙ࡓࡑࡎࡐ࡙ࡑࡣࡤࠧࠡࠨἁ")
		#dict[l111lll_ll_ (u"ࠧࡨࡴࡲࡹࡵ࠭ἂ")] = group
		if l111lll_ll_ (u"ࠨ࡫ࡧࠫἃ") in dict.keys(): del dict[l111lll_ll_ (u"ࠩ࡬ࡨࠬἄ")]
		if l111lll_ll_ (u"ࠪࡍࡉ࠭ἅ") in dict.keys(): del dict[l111lll_ll_ (u"ࠫࡎࡊࠧἆ")]
		if l111lll_ll_ (u"ࠬࡴࡡ࡮ࡧࠪἇ") in dict.keys(): del dict[l111lll_ll_ (u"࠭࡮ࡢ࡯ࡨࠫἈ")]
		title = dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭Ἁ")]
		if l111lll_ll_ (u"ࠨ࡞ࡸࠫἊ") in title.lower(): title = title.decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪἋ"))
		title = l1111ll11_ll_(title)
		language,group = l1llll11111_ll_(group)
		country,title = l1llll11111_ll_(title)
		dict[l111lll_ll_ (u"ࠪ࡫ࡷࡵࡵࡱࠩἌ")] = group.upper()
		dict[l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪἍ")] = title.upper()
		dict[l111lll_ll_ (u"ࠬࡩ࡯ࡶࡰࡷࡶࡾ࠭Ἆ")] = country.upper()
		dict[l111lll_ll_ (u"࠭࡬ࡢࡰࡪࡹࡦ࡭ࡥࠨἏ")] = language.upper()
		#if l111lll_ll_ (u"ࠧࡂࡎࠣ࠱ࠥ࠭ἐ") in dict[l111lll_ll_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧἑ")]: dict[l111lll_ll_ (u"ࠩࡷ࡭ࡹࡲࡥࠨἒ")] = dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩἓ")].replace(l111lll_ll_ (u"ࠫࡆࡒࠠ࠮ࠢࠪἔ"),l111lll_ll_ (u"ࠬࡇࡌࠡࠩἕ"))
		#if l111lll_ll_ (u"࠭ࡅࡍࠢ࠰ࠤࠬ἖") in dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭἗")]: dict[l111lll_ll_ (u"ࠨࡶ࡬ࡸࡱ࡫ࠧἘ")] = dict[l111lll_ll_ (u"ࠩࡷ࡭ࡹࡲࡥࠨἙ")].replace(l111lll_ll_ (u"ࠪࡉࡑࠦ࠭ࠡࠩἚ"),l111lll_ll_ (u"ࠫࡊࡒࠠࠨἛ"))
		l11111l111_ll_.append(dict)
	del lines
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬἜ"),l111lll_ll_ (u"࠭ࡅࡎࡃࡇࠤ࠹࠺࠴ࠨἝ"))
	#with open(l111lll_ll_ (u"ࠧࡔ࠼࡟ࡠ࠵࡯ࡰࡵࡸࡨࡱࡦࡪ࠮࡮࠵ࡸࠫ἞"),l111lll_ll_ (u"ࠨࡹࠪ἟")) as f: f.write(str(l11111l111_ll_).replace(l111lll_ll_ (u"ࠤࢀ࠰ࠧἠ"),l111lll_ll_ (u"ࠥࢁࡡࡴࠬࠣἡ")))
	l1111lll11_ll_ = {}
	for type in l11l1111ll_ll_: l1111lll11_ll_[type] = []
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫἢ"),l111lll_ll_ (u"ࠬࡋࡍࡂࡆࠣ࠹࠺࠻ࠠࡄࡔࡈࡅ࡙ࡋࠠࡔࡖࡕࡉࡆࡓࡓࠡࡕࡗࡅࡗ࡚ࠠࡤࡴࡨࡥࡹ࡯࡮ࡨࠢ࠴ࡷࡹࠦࡓࡕࡔࡈࡅࡒ࡙ࠠࡥ࡫ࡦࡸ࡮ࡵ࡮ࡢࡴࡼࠫἣ"))
	if l1111l111_ll_.iscanceled(): return
	l1111l111_ll_.update(75,l111lll_ll_ (u"࠭สึ่ํๅࠥอไๆๆไหฯࠦวๅ฼ํี๋ࠥัหสฬࠫἤ"),l111lll_ll_ (u"ࠧࠡࠩἥ"))
	for dict in l11111l111_ll_:
		type = dict[l111lll_ll_ (u"ࠨࡶࡼࡴࡪ࠭ἦ")]
		l111l11l1l_ll_ = {l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰࠨἧ"):dict[l111lll_ll_ (u"ࠪ࡫ࡷࡵࡵࡱࠩἨ")],l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬἩ"):dict[l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭Ἢ")],l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬἫ"):dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭Ἤ")],l111lll_ll_ (u"ࠨࡷࡵࡰࠬἭ"):dict[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭Ἦ")],l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠧἯ"):dict[l111lll_ll_ (u"ࠫ࡮ࡳࡧࠨἰ")]}
		#if l111lll_ll_ (u"ࠬࡋࡇࠡ࠯ࠣࠫἱ") in dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬἲ")]: l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧἳ"),l111lll_ll_ (u"ࠨࡡࡢࡣ࠿࠭ἴ")+type+l111lll_ll_ (u"ࠩࡢࡣࡤࡀࠠࠡࡡࡢࡣ࠿࠭ἵ")+str(l111l11l1l_ll_))
		if l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࠨἶ") in type:
			l1111lll11_ll_[l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡊࡖࡔ࡛ࡐࡆࡆࠪἷ")].append(l111l11l1l_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭Ἰ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"࠭ࡕࡏࡍࡑࡓ࡜ࡔࠧἹ") in type: l1111lll11_ll_[l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤ࡛ࡎࡌࡐࡒ࡛ࡓ࠭Ἲ")].append(l111l11l1l_ll_)
		elif l111lll_ll_ (u"ࠨࡘࡒࡈࠬἻ") in type:
			l1111lll11_ll_[l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡏࡓࡋࡊࡍࡓࡇࡌࡠࡉࡕࡓ࡚ࡖࡅࡅࠩἼ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"ࠪࡑࡔ࡜ࡉࡆࡕࠪἽ") in type: l1111lll11_ll_[l111lll_ll_ (u"࡛ࠫࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅࠩἾ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"࡙ࠬࡅࡓࡋࡈࡗࠬἿ") in type: l1111lll11_ll_[l111lll_ll_ (u"࠭ࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇࠫὀ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"ࠧࡖࡐࡎࡒࡔ࡝ࡎࠨὁ") in type: l1111lll11_ll_[l111lll_ll_ (u"ࠨࡘࡒࡈࡤ࡛ࡎࡌࡐࡒ࡛ࡓࡥࡇࡓࡑࡘࡔࡊࡊࠧὂ")].append(l111l11l1l_ll_)
	l1111l1l1l_ll_ = sorted(l11111l111_ll_, reverse=False, key=lambda key: key[l111lll_ll_ (u"ࠩࡷ࡭ࡹࡲࡥࠨὃ")].lower())
	del l11111l111_ll_
	if l1111l111_ll_.iscanceled(): return
	l1111l111_ll_.update(80,l111lll_ll_ (u"ࠪฮฺ์๊โࠢส่๊๊แศฬࠣห้๋ัหสฬࠫὄ"))
	for dict in l1111l1l1l_ll_:
		type = dict[l111lll_ll_ (u"ࠫࡹࡿࡰࡦࠩὅ")]
		l111l11lll_ll_ = {l111lll_ll_ (u"ࠬ࡭ࡲࡰࡷࡳࠫ὆"):dict[l111lll_ll_ (u"࠭ࡧࡳࡱࡸࡴࠬ὇")],l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨὈ"):dict[l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩὉ")]+l111lll_ll_ (u"ࠩࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙࠭Ὂ"),l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩὋ"):dict[l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠪὌ")],l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩὍ"):dict[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪ὎")],l111lll_ll_ (u"ࠧࡪ࡯ࡪࠫ὏"):dict[l111lll_ll_ (u"ࠨ࡫ࡰ࡫ࠬὐ")]}
		l111l11l1l_ll_ = {l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰࠨὑ"):dict[l111lll_ll_ (u"ࠪ࡫ࡷࡵࡵࡱࠩὒ")],l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬὓ"):dict[l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡼࡹ࠭ὔ")],l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬὕ"):dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ὖ")],l111lll_ll_ (u"ࠨࡷࡵࡰࠬὗ"):dict[l111lll_ll_ (u"ࠩࡸࡶࡱ࠭὘")],l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠧὙ"):dict[l111lll_ll_ (u"ࠫ࡮ࡳࡧࠨ὚")]}
		l111l11ll1_ll_ = {l111lll_ll_ (u"ࠬ࡭ࡲࡰࡷࡳࠫὛ"):dict[l111lll_ll_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧ὜")],l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡾࡴࠨὝ"):dict[l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫ࡸࡵࠩ὞")],l111lll_ll_ (u"ࠩࡷ࡭ࡹࡲࡥࠨὟ"):dict[l111lll_ll_ (u"ࠪࡸ࡮ࡺ࡬ࡦࠩὠ")],l111lll_ll_ (u"ࠫࡺࡸ࡬ࠨὡ"):dict[l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩὢ")],l111lll_ll_ (u"࠭ࡩ࡮ࡩࠪὣ"):dict[l111lll_ll_ (u"ࠧࡪ࡯ࡪࠫὤ")]}
		l111l1l111_ll_ = {l111lll_ll_ (u"ࠨࡩࡵࡳࡺࡶࠧὥ"):dict[l111lll_ll_ (u"ࠩ࡯ࡥࡳ࡭ࡵࡢࡩࡨࠫὦ")],l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫὧ"):dict[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡻࡸࠬὨ")],l111lll_ll_ (u"ࠬࡺࡩࡵ࡮ࡨࠫὩ"):dict[l111lll_ll_ (u"࠭ࡴࡪࡶ࡯ࡩࠬὪ")],l111lll_ll_ (u"ࠧࡶࡴ࡯ࠫὫ"):dict[l111lll_ll_ (u"ࠨࡷࡵࡰࠬὬ")],l111lll_ll_ (u"ࠩ࡬ࡱ࡬࠭Ὥ"):dict[l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠧὮ")]}
		l1111lll11_ll_[l111lll_ll_ (u"ࠫࡆࡒࡌࠨὯ")].append(dict)
		#l1111lll11_ll_[type].append(l111l11l1l_ll_)
		if l111lll_ll_ (u"ࠬࡒࡉࡗࡇࠪὰ") in type:
			if l111lll_ll_ (u"࠭ࡅࡑࡉࠪά")		in type: l1111lll11_ll_[l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤࡋࡐࡈࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪὲ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"ࠨࡃࡕࡇࡍࡏࡖࡆࡆࠪέ")	in type: l1111lll11_ll_[l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡂࡔࡆࡌࡎ࡜ࡅࡅࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪὴ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"ࠪࡅࡗࡉࡈࡊࡘࡈࡈࠬή")	in type: l1111lll11_ll_[l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡡࡗࡍࡒࡋࡓࡉࡋࡉࡘࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ὶ")].append(l111l11lll_ll_)
			if l111lll_ll_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓ࠭ί")	in type: l1111lll11_ll_[l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡣ࡚ࡔࡋࡏࡑ࡚ࡒࡤ࡙ࡏࡓࡖࡈࡈࠬὸ")].append(l111l11l1l_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࡤࡍࡒࡐࡗࡓࡉࡉࡥࡓࡐࡔࡗࡉࡉ࠭ό")].append(l111l11l1l_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"ࠨࡎࡌ࡚ࡊࡥࡆࡓࡑࡐࡣࡓࡇࡍࡆࡡࡖࡓࡗ࡚ࡅࡅࠩὺ")].append(l111l11ll1_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࡟ࡇࡔࡒࡑࡤࡍࡒࡐࡗࡓࡣࡘࡕࡒࡕࡇࡇࠫύ")].append(l111l1l111_ll_)
		elif l111lll_ll_ (u"࡚ࠪࡔࡊࠧὼ") in type:
			if l111lll_ll_ (u"ࠫࡒࡕࡖࡊࡇࡖࠫώ")		in type: l1111lll11_ll_[l111lll_ll_ (u"ࠬ࡜ࡏࡅࡡࡐࡓ࡛ࡏࡅࡔࡡࡊࡖࡔ࡛ࡐࡆࡆࡢࡗࡔࡘࡔࡆࡆࠪ὾")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"࠭ࡓࡆࡔࡌࡉࡘ࠭὿")		in type: l1111lll11_ll_[l111lll_ll_ (u"ࠧࡗࡑࡇࡣࡘࡋࡒࡊࡇࡖࡣࡌࡘࡏࡖࡒࡈࡈࡤ࡙ࡏࡓࡖࡈࡈࠬᾀ")].append(l111l11l1l_ll_)
			if l111lll_ll_ (u"ࠨࡗࡑࡏࡓࡕࡗࡏࠩᾁ")	in type: l1111lll11_ll_[l111lll_ll_ (u"࡙ࠩࡓࡉࡥࡕࡏࡍࡑࡓ࡜ࡔ࡟ࡈࡔࡒ࡙ࡕࡋࡄࡠࡕࡒࡖ࡙ࡋࡄࠨᾂ")].append(l111l11l1l_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"࡚ࠪࡔࡊ࡟ࡇࡔࡒࡑࡤࡔࡁࡎࡇࡢࡗࡔࡘࡔࡆࡆࠪᾃ")].append(l111l11ll1_ll_)
			l1111lll11_ll_[l111lll_ll_ (u"࡛ࠫࡕࡄࡠࡈࡕࡓࡒࡥࡇࡓࡑࡘࡔࡤ࡙ࡏࡓࡖࡈࡈࠬᾄ")].append(l111l1l111_ll_)
	del l1111l1l1l_ll_
	l1111lll11_ll_[l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡘࡎࡓࡅࡔࡊࡌࡊ࡙ࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᾅ")] = l1111lll11_ll_[l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡣࡆࡘࡃࡉࡋ࡙ࡉࡉࡥࡇࡓࡑࡘࡔࡊࡊ࡟ࡔࡑࡕࡘࡊࡊࠧᾆ")]
	l1111lll11_ll_[l111lll_ll_ (u"ࠧࡅࡗࡐࡑ࡞࠭ᾇ")].append(l111lll_ll_ (u"ࠨࠩᾈ"))
	l111111ll1_ll_(False)
	length = len(l11l1111ll_ll_)
	l11l111l1l_ll_,l11l111111_ll_ = 0,0
	t1 = time.time()-60
	for l1111ll1l1_ll_ in l11l1111ll_ll_: l11l111l1l_ll_ += len(l1111lll11_ll_[l1111ll1l1_ll_])
	#l1111l11ll_ll_ = 360
	for ii in range(length):
		l1111ll1l1_ll_ = l11l1111ll_ll_[length-1-ii]
		if l1111l111_ll_.iscanceled(): return
		l1lll1l1l1_ll_ = time.time()
		l1lll11lll_ll_ = l1lll1l1l1_ll_-t1
		#l11l111111_ll_ += len(l1111lll11_ll_[l1111ll1l1_ll_])
		#l11111lll1_ll_ = l1lll11lll_ll_/l11l111111_ll_
		#l1111l11ll_ll_ = l11111lll1_ll_*l11l111l1l_ll_#*1.25
		#l1lll1ll1l_ll_ = l1111l11ll_ll_-l1lll11lll_ll_
		#l1111l111_ll_.update(85+int(15*ii/length),l111lll_ll_ (u"ࠩอาื๐ๆࠡษ็้้็วห࠼࠰ࠤฬ๊ๅๅใࠣี็๋ࠧᾉ"),l111lll_ll_ (u"ࠪ์็ะࠠๆฬหๆ๏ࡀࠠࠨᾊ")+time.strftime(l111lll_ll_ (u"ࠦࠪࡎ࠺ࠦࡏ࠽ࠩࡘࠨᾋ"),time.gmtime(l1lll1ll1l_ll_))+l111lll_ll_ (u"ࠬࠦࠠࠡࠢࠣࠤࠬᾌ")+str(ii+1)+l111lll_ll_ (u"࠭࠯ࠨᾍ")+str(length))
		l1111l111_ll_.update(85+int(15*ii/length),l111lll_ll_ (u"ࠧหะี๎๋ࠦวๅ็็ๅฬะ࠺࠮ࠢส่๊๊แࠡำๅ้ࠬᾎ"),str(ii+1)+l111lll_ll_ (u"ࠨ࠱ࠪᾏ")+str(length))
		l111lllll1_ll_(l111lll_ll_ (u"ࠩࡌࡔ࡙࡜࡟ࠨᾐ")+l1111ll1l1_ll_+l111lll_ll_ (u"ࠪ࠲ࡩࡧࡴࠨᾑ"),l1111lll11_ll_[l1111ll1l1_ll_])
		del l1111lll11_ll_[l1111ll1l1_ll_]
	del l1111lll11_ll_
	#streams = l1llll11l1l_ll_(l111lll_ll_ (u"ࠫࡎࡖࡔࡗࡡࡏࡍ࡛ࡋ࡟ࡈࡔࡒ࡙ࡕࡋࡄࠨᾒ"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡋࡗࡕࡕࡑࡇࡇࠫᾓ"))
	#for dict in streams:
	#	if l111lll_ll_ (u"࠭ࡅࡈࠢ࠰ࠤࠬᾔ") in dict[l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪ࠭ᾕ")]: l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨᾖ"),l111lll_ll_ (u"ࠩࡀࡁࡂࡃ࠽࠾ࠩᾗ")+str(dict))
	with open(l1llllll1ll_ll_,l111lll_ll_ (u"ࠪࡻࡧ࠭ᾘ")) as f: f.write(l111lll_ll_ (u"ࠫࠬᾙ"))
	l1111l111_ll_.close()
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠬࡹࡴࡰࡲࠪᾚ"))
	l1llllll1l1_ll_ = l1llll11l11_ll_(False)
	l1ll1l_ll_(l111lll_ll_ (u"࠭สๆࠢฯ่อࠦๅๅใสฮࠥࡏࡐࡕࡘࠣะิ๐ฯสࠩᾛ"),l1llllll1l1_ll_)
	return
def l1llll11l11_ll_(show=True):
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡄࡑࡘࡒ࡙࡙ࠧᾜ"),l111lll_ll_ (u"ࠨ࠲࠳࠴࠵࠭ᾝ"))
	if not l11111111l_ll_(show): return l111lll_ll_ (u"ࠩࠪᾞ")
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠪࡷࡹࡧࡲࡵࠩᾟ"))
	l1lllll1111_ll_ = len(l1111llll1_ll_(l111lll_ll_ (u"ࠫࡎࡖࡔࡗࡡࡏࡍ࡛ࡋ࡟ࡖࡐࡎࡒࡔ࡝ࡎ࠯ࡦࡤࡸࠬᾠ")))
	l111l11111_ll_ = len(l1111llll1_ll_(l111lll_ll_ (u"ࠬࡏࡐࡕࡘࡢࡐࡎ࡜ࡅࡠࡉࡕࡓ࡚ࡖࡅࡅ࠰ࡧࡥࡹ࠭ᾡ")))
	l111llllll_ll_ = l1lllll1111_ll_+l111l11111_ll_
	l111ll1l1l_ll_ = len(l1111llll1_ll_(l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣ࡛ࡕࡄࡠࡏࡒ࡚ࡎࡋࡓࡠࡉࡕࡓ࡚ࡖࡅࡅ࠰ࡧࡥࡹ࠭ᾢ")))
	l111ll11ll_ll_ = len(l1111llll1_ll_(l111lll_ll_ (u"ࠧࡊࡒࡗ࡚ࡤ࡜ࡏࡅࡡࡘࡒࡐࡔࡏࡘࡐࡢࡋࡗࡕࡕࡑࡇࡇ࠲ࡩࡧࡴࠨᾣ")))
	episodes = l1111llll1_ll_(l111lll_ll_ (u"ࠨࡋࡓࡘ࡛ࡥࡖࡐࡆࡢࡗࡊࡘࡉࡆࡕࡢࡋࡗࡕࡕࡑࡇࡇ࠲ࡩࡧࡴࠨᾤ"))
	l1l11111l_ll_ = len(episodes)
	l111lll111_ll_ = []
	for dict in episodes:
		group = dict[l111lll_ll_ (u"ࠩࡪࡶࡴࡻࡰࠨᾥ")]
		if l111lll_ll_ (u"ࠪࡣࡤࡏࡐࡕࡘࡖࡉࡗࡏࡅࡔࡡࡢࠫᾦ") in group:
			l11111l1l1_ll_ = group.split(l111lll_ll_ (u"ࠫࡤࡥࡉࡑࡖ࡙ࡗࡊࡘࡉࡆࡕࡢࡣࠬᾧ"))[1]
			if l11111l1l1_ll_ not in l111lll111_ll_: l111lll111_ll_.append(l11111l1l1_ll_)
	l111l1l1l1_ll_ = len(l111lll111_ll_)
	total = l111llllll_ll_+l111ll1l1l_ll_+l1l11111l_ll_+l111ll11ll_ll_
	l1llllll1l1_ll_ = l111lll_ll_ (u"่ࠬๆ้ษอ࠾ࠥ࠭ᾨ")+str(l111llllll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࠣࠤศ็ไศ็࠽ࠤࠬᾩ")+str(l111ll1l1l_ll_)+l111lll_ll_ (u"ࠧ࡝ࡴ࡟ࡲ่ࠥࠦࠠࠡࠢืู้ไศฬ࠽ࠤࠬᾪ")+str(l111l1l1l1_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࠥࠦอๅไสฮ࠿ࠦࠧᾫ")+str(l1l11111l_ll_)+l111lll_ll_ (u"ࠩ࡟ࡶࡡࡴࠠࠡࠢࠣࠤๆ๐ฯ้้สฮ๋ࠥฬ่๊็อ࠿ࠦࠧᾬ")+str(l111ll11ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࠠࠡษ็้ัฺ๋่࠼ࠣࠫᾭ")+str(total)
	if show: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᾮ"),l1llllll1l1_ll_)
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠬࡹࡴࡰࡲࠪᾯ"))
	l111111111_ll_ = l1llllll1l1_ll_.replace(l111lll_ll_ (u"࠭ࠠࠡࠢࠣࠤࠬᾰ"),l111lll_ll_ (u"ࠧࠡࠢ࠱ࠤࠥ࠭ᾱ")).replace(l111lll_ll_ (u"ࠨ࡞ࡵࡠࡳ࠭ᾲ"),l111lll_ll_ (u"ࠩࠪᾳ"))
	l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪᾴ"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡄࡱࡸࡲࡹࡹࠠࡰࡨࠣࡍࡕ࡚ࡖࠡࡸ࡬ࡨࡪࡵࡳࠡࠢࠣࠫ᾵")+l111111111_ll_)
	return l1llllll1l1_ll_
def l111111ll1_ll_(show=True):
	if show:
		l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"๋ࠬำฮ่่ࠢๆอสࠡࡋࡓࡘ࡛࠭ᾶ"),l111lll_ll_ (u"࠭สิฬฺ๎฾ࠦแ๋ࠢฦ๎ࠥ๎โหࠢส่ิิ่ๅࠢศ่๎ࠦโศศ่อࠥࡏࡐࡕࡘࠣ์ั๊ศࠡ็็ๅฬะࠠࡊࡒࡗ࡚ࠥาฯ๋ัฬࠤ࠳࠴่ࠠๆࠣฮึ๐ฯࠡษ็ฦ๋ࠦๅิฯࠣห้๋ไโษอࠤฬ๊โะ์่อࠥอไๆะี๊ฮࠦแ๋ࠢส่อืๆศ็ฯࠤฤࠧࠧᾷ"),l111lll_ll_ (u"ࠧࠨᾸ"),l111lll_ll_ (u"ࠨࠩᾹ"),l111lll_ll_ (u"ࠩๆ่ฬ࠭Ὰ"),l111lll_ll_ (u"๊ࠪ฾๋ࠧΆ"))
		if not l111111l1_ll_: return
		try: os.remove(l1111l111l_ll_)
		except: pass
	try: os.remove(l1llllll1ll_ll_)
	except: pass
	l11111l1ll_ll_(l111lll_ll_ (u"ࠫࡎࡖࡔࡗࡡࡊࡖࡔ࡛ࡐࡔࠩᾼ"))
	l11111l1ll_ll_(l111lll_ll_ (u"ࠬࡏࡐࡕࡘࡢࡍ࡙ࡋࡍࡔࠩ᾽"))
	for l1111ll1l1_ll_ in l11l1111ll_ll_:
		l1lll1ll1ll_ll_(l111lll_ll_ (u"࠭ࡉࡑࡖ࡙ࡣࠬι")+l1111ll1l1_ll_+l111lll_ll_ (u"ࠧ࠯ࡦࡤࡸࠬ᾿"))
	#l11111l1ll_ll_(l111lll_ll_ (u"ࠨࡏࡌࡗࡈ࠭῀"),l111lll_ll_ (u"ࠩࡖࡉࡈ࡚ࡉࡐࡐࡖࡣࡑࡏࡖࡆࠩ῁"))
	#l11111llll_ll_()
	if show: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ῂ"),l111lll_ll_ (u"ࠫฯ๋ࠠๆีะࠤัฺ๋๊่่ࠢๆอสࠡࡋࡓࡘ࡛࠭ῃ"))
	return
def l11111111l_ll_(l1111l1l11_ll_=True):
	list = str(os.listdir(l1lll11ll1_ll_))
	filename = l1llllll1ll_ll_.split(l111lll_ll_ (u"ࠬ࠵ࠧῄ"))[-1].split(l111lll_ll_ (u"࠭࡜࡝ࠩ῅"))[-1]
	if filename in list: return True
	if l1111l1l11_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪῆ"),l111lll_ll_ (u"ࠨษ้ฮࠥฮอศฮฬࠤส๊้ࠡษ็ิ์อศࠡว็ํ่ࠥวว็ฬࠤࡎࡖࡔࡗࠢฮ้ࠥ࠴ࠠฤ๊็หࠥอึ฻ูࠣ฽้๏ࠠࠣวูหๆฯࠠศึอีฬ้ࠠࡊࡒࡗ࡚ࠥอไๆัไ์฾ࠨࠠࠩ็้ࠤศ๐ࠠีำๆอࠥࡏࡐࡕࡘࠬࠤ࠳ࠦหๆࠢฮห๋๐วࠡษู฾฼ูࠦๅ๋ࠣะ้ฮࠠๆๆไหฯࠦࡉࡑࡖ࡙ࠫῇ"))
	return False
l111lll_ll_ (u"ࠤࠥࠦࠏࡪࡥࡧࠢࡖࡅ࡛ࡋ࡟ࡔࡖࡕࡉࡆࡓࡓࡠࡖࡒࡣࡉࡏࡓࡌࠪࡪࡶࡴࡻࡰࡦࡦࡢࡷࡹࡸࡥࡢ࡯ࡶ࠰ࡆࡒࡌࡠࡖ࡜ࡔࡊ࡙ࠩ࠻ࠌࠌ࡫ࡱࡵࡢࡢ࡮ࠣࡷࡪࡺࡴࡪࡰࡪࡷࠏࠏࡦࡪ࡮ࡨࡷࡑࡏࡓࡕࠢࡀࠤࡠࡣࠊࠊࡨ࡬ࡰࡪࡹࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࠬ࡯ࡰࡵࡸࡢࠫ࠰ࡹࡴࡳࠪ࡬ࡲࡹ࠮࡮ࡰࡹࠬ࠭࠰࠭࡟࠯࡯࠶ࡹࠬ࠯ࠊࠊࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣࡁࠥ࠭ࡩࡱࡶࡹࡣࠬ࠱ࡳࡵࡴࠫ࡭ࡳࡺࠨ࡯ࡱࡺ࠭࠮࠱ࠧࡠࡡࡗ࡝ࡕࡋ࡟ࡠ࠰ࡶࡸࡷ࡫ࡡ࡮ࡵࠪࠎࠎࡹࡥࡵࡶ࡬ࡲ࡬ࡹ࠮ࡴࡧࡷࡗࡪࡺࡴࡪࡰࡪࠬࠬ࡯ࡰࡵࡸ࠱ࡪ࡮ࡲࡥࠨ࠮ࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠏࠏࡦࡰࡴࠣࡘ࡞ࡖࡅࠡ࡫ࡱࠤࡆࡒࡌࡠࡖ࡜ࡔࡊ࡙࠺ࠋࠋࠌࡲࡪࡽ࡟ࡴࡶࡵࡩࡦࡳࡳࠡ࠿ࠣࡷࡹࡸࠨࡨࡴࡲࡹࡵ࡫ࡤࡠࡵࡷࡶࡪࡧ࡭ࡴ࡝ࡗ࡝ࡕࡋ࡝ࠪࠌࠌࠍࡳ࡫ࡷࡠࡵࡷࡶࡪࡧ࡭ࡴࠢࡀࠤࡳ࡫ࡷࡠࡵࡷࡶࡪࡧ࡭ࡴ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࢂ࠲ࠧ࠭ࠩࢀ࠰ࡡࡴࠧࠪࠌࠌࠍࡳ࡫ࡷࡠࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣࡁࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡢࡣ࡙࡟ࡐࡆࡡࡢࠫ࠱࠭࡟ࠨ࠭ࡗ࡝ࡕࡋࠫࠨࡡࠪ࠭ࠏࠏࠉࡪࡲࡷࡺࡋ࡯࡬ࡦࠢࡀࠤࡴࡹ࠮ࡱࡣࡷ࡬࠳ࡰ࡯ࡪࡰࠫࡥࡩࡪ࡯࡯ࡥࡤࡧ࡭࡫ࡦࡰ࡮ࡧࡩࡷ࠲࡮ࡦࡹࡢࡪ࡮ࡲࡥ࡯ࡣࡰࡩ࠮ࠐࠉࠊࡨ࡬ࡰࡪࠦ࠽ࠡࡱࡳࡩࡳ࠮ࡩࡱࡶࡹࡊ࡮ࡲࡥ࠭ࠢࠪࡻࡧ࠭ࠩࠋࠋࠌࡪ࡮ࡲࡥ࠯ࡹࡵ࡭ࡹ࡫ࠨ࡯ࡧࡺࡣࡸࡺࡲࡦࡣࡰࡷ࠮ࠐࠉࠊࡨ࡬ࡰࡪ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠊࠊࠋࡩ࡭ࡱ࡫ࡳࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡴࡥࡸࡡࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠭ࠏࠏࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࡍࡕ࡚ࡖࠨ࠮ࠪฮ๊ࠦฬๅส้้ࠣ็วหࠢࡌࡔ࡙࡜ࠠอัํำฮ࠭ࠩࠋࠋࡵࡩࡹࡻࡲ࡯ࠌࠍࡨࡪ࡬ࠠࡈࡇࡗࡣࡘ࡚ࡒࡆࡃࡐࡗࡤࡌࡒࡐࡏࡢࡈࡎ࡙ࡋࠩࡖ࡜ࡔࡊ࠯࠺ࠋࠋࡪࡰࡴࡨࡡ࡭ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶࠎࠎ࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠠ࠾ࠢࡶࡩࡹࡺࡩ࡯ࡩࡶ࠲࡬࡫ࡴࡔࡧࡷࡸ࡮ࡴࡧࠩࠩ࡬ࡴࡹࡼ࠮ࡧ࡫࡯ࡩࠬ࠯ࠊࠊࡨ࡬ࡰࡪࡴࡡ࡮ࡧࠣࡁࠥ࡬ࡩ࡭ࡧࡱࡥࡲ࡫࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࡢࡣ࡙࡟ࡐࡆࡡࡢࠫ࠱࠭࡟ࠨ࠭ࡗ࡝ࡕࡋࠫࠨࡡࠪ࠭ࠏࠏࡩࡱࡶࡹࡊ࡮ࡲࡥࠡ࠿ࠣࡳࡸ࠴ࡰࡢࡶ࡫࠲࡯ࡵࡩ࡯ࠪࡤࡨࡩࡵ࡮ࡤࡣࡦ࡬ࡪ࡬࡯࡭ࡦࡨࡶ࠱࡬ࡩ࡭ࡧࡱࡥࡲ࡫ࠩࠋࠋࡩࠤࡂࠦ࡯ࡱࡧࡱࠬ࡮ࡶࡴࡷࡈ࡬ࡰࡪ࠲ࠧࡳࡤࠪ࠭ࠏࠏࡳࡵࡴࡨࡥࡲࡹ࡟ࡵࡧࡻࡸࠥࡃࠠࡧ࠰ࡵࡩࡦࡪࠨࠪࠌࠌࡷࡹࡸࡥࡢ࡯ࡶࠤࡂࠦࡅࡗࡃࡏࠬࡸࡺࡲࡦࡣࡰࡷࡤࡺࡥࡹࡶࠬࠎࠎࡸࡥࡵࡷࡵࡲࠥࡹࡴࡳࡧࡤࡱࡸࠐࠢࠣࠤῈ")