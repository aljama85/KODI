# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࡯࠱ࡴࡦࡴࡥࡵ࠰ࡦࡳ࠳࡯࡬ࠨㅎ")
headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭ㅏ") : l111lll_ll_ (u"ࠪࠫㅐ") }
l1ll_ll_ = l111lll_ll_ (u"ࠫࡕࡇࡎࡆࡖࠪㅑ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠬࡥࡐࡏࡖࡢࠫㅒ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,page,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==30: results = l11l1ll_ll_(url)
	elif mode==31: results = CATEGORIES(url,l111lll_ll_ (u"࠭࠳ࠨㅓ"))
	elif mode==32: results = l11ll1l11l_ll_(url)
	elif mode==33: results = l11_ll_(url)
	elif mode==35: results = CATEGORIES(url,l111lll_ll_ (u"ࠧ࠲ࠩㅔ"))
	elif mode==36: results = CATEGORIES(url,l111lll_ll_ (u"ࠨ࠴ࠪㅕ"))
	elif mode==37: results = CATEGORIES(url,l111lll_ll_ (u"ࠩ࠷ࠫㅖ"))
	elif mode==38: results = l1ll11ll1_ll_()
	elif mode==39: results = l1lll1_ll_(text,page)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫㅗ")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬㅘ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅙ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ㅚ"),l111lll_ll_ (u"ࠧࠨㅛ"),39,l111lll_ll_ (u"ࠨࠩㅜ"),l111lll_ll_ (u"ࠩࠪㅝ"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧㅞ"))
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩㅟ"),l1111l_ll_+l1l1l1l_ll_+l111lll_ll_ (u"่ࠬๆศห๋้ࠣอࠠๆ่้ࠣํู่ࠡสส๊๏ะࠧㅠ"),l111lll_ll_ (u"࠭ࠧㅡ"),38)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㅢ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬㅣ")+l1l1l1l_ll_+l111lll_ll_ (u"่ࠩืู้ไศฬࠣ์อืวๆฮࠪㅤ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶࠫㅥ"),31)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫㅦ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩㅧ")+l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅ็ึุ่๊วหࠢส่ฬ้หาุ่ࠢฬํฯสࠩㅨ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳࠨㅩ"),37)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㅪ"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ㅫ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪหๆ๊วๆࠢะือࠦวๅ่๋฽ࠬㅬ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬㅭ"),35)
	#l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬㅮ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪㅯ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศใ็ห๊ࠦอิสࠣห้๋ๅฬๆࠪㅰ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴࠩㅱ"),36)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㅲ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧㅳ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬำฯฬࠢส่ฬ็ไศ็ࠪㅴ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵࡭ࡰࡸ࡬ࡩࡸ࠭ㅵ"),32)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㅶ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫㅷ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨ็ึีา๐วหࠩㅸ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡱࡴࡼࡩࡦࡵ࠲࡫ࡪࡴࡲࡦ࠱࠷࠳࠶࠭ㅹ"),32)
	return l111lll_ll_ (u"ࠪࠫㅺ")
def CATEGORIES(url,select=l111lll_ll_ (u"ࠫࠬㅻ")):
	type = url.split(l111lll_ll_ (u"ࠬ࠵ࠧㅼ"))[3]
	#l1ll1l_ll_(type, url)
	if type==l111lll_ll_ (u"࠭ࡳࡦࡴ࡬ࡩࡸ࠭ㅽ"):
		html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠧࠨㅾ"),headers,l111lll_ll_ (u"ࠨࠩㅿ"),l111lll_ll_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩㆀ"))
		if select==l111lll_ll_ (u"ࠪ࠷ࠬㆁ"):
			l1lll_ll_=re.findall(l111lll_ll_ (u"ࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࡎࡧࡱࡹ࠭࠴ࠪࡀࠫࡶࡩࡷ࡯ࡥࡴࡈࡲࡶࡲ࠭ㆂ"),html,re.DOTALL)
			block= l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫㆃ"),block,re.DOTALL)
			for link,name in items:
				if l111lll_ll_ (u"࠭ใๅ์หหฯࠦๅืฯๆอࠬㆄ") in name: continue
				url = l1ll1l1_ll_ + link
				name = name.strip(l111lll_ll_ (u"ࠧࠡࠩㆅ"))
				l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨㆆ"),l1l1l1l_ll_+name,url,32)
		if select==l111lll_ll_ (u"ࠩ࠷ࠫㆇ"):
			l1lll_ll_=re.findall(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡧࡩࡹࡧࡩ࡭ࡵ࠰ࡴࡦࡴࡥ࡭ࠪ࠱࠮ࡄ࠯ࡶ࠿࠾࠲ࡥࡃࡂ࠯ࡥ࡫ࡹࡂࠬㆈ"),html,re.DOTALL)
			block= l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࠨࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡲࡤࡲࡪࡺ࠭ࡪࡰࡩࡳࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㆉ"),block,re.DOTALL)
			for link,img,title in items:
				url = l1ll1l1_ll_ + link
				title = title.strip(l111lll_ll_ (u"ࠬࠦࠧㆊ"))
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㆋ"),l1l1l1l_ll_+title,url,32,img)
		#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࠨㆌ"))
	if type==l111lll_ll_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨㆍ"):
		html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠩࠪㆎ"),headers,l111lll_ll_ (u"ࠪࠫ㆏"),l111lll_ll_ (u"ࠫࡕࡇࡎࡆࡖ࠰ࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࠭࠳ࡰࡧࠫ㆐"))
		if select==l111lll_ll_ (u"ࠬ࠷ࠧ㆑"):
			l1lll_ll_=re.findall(l111lll_ll_ (u"࠭࡭ࡰࡸ࡬ࡩࡸࡍࡥ࡯ࡦࡨࡶ࠭࠴ࠪࡀࠫࡶࡩࡱ࡫ࡣࡵࠩ㆒"),html,re.DOTALL)
			block = l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"ࠧࡰࡲࡷ࡭ࡴࡴ࠾࠽ࡱࡳࡸ࡮ࡵ࡮ࠡࡸࡤࡰࡺ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ㆓"),block,re.DOTALL)
			for value,name in items:
				url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡪࡩࡳࡸࡥ࠰ࠩ㆔") + value
				name = name.strip(l111lll_ll_ (u"ࠩࠣࠫ㆕"))
				l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ㆖"),l1l1l1l_ll_+name,url,32)
		elif select==l111lll_ll_ (u"ࠫ࠷࠭㆗"):
			l1lll_ll_=re.findall(l111lll_ll_ (u"ࠬࡳ࡯ࡷ࡫ࡨࡷࡆࡩࡴࡰࡴࠫ࠲࠯ࡅࠩࡴࡧ࡯ࡩࡨࡺࠧ㆘"),html,re.DOTALL)
			block = l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"࠭࡯ࡱࡶ࡬ࡳࡳࡄ࠼ࡰࡲࡷ࡭ࡴࡴࠠࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ㆙"),block,re.DOTALL)
			for value,name in items:
				name = name.strip(l111lll_ll_ (u"ࠧࠡࠩ㆚"))
				url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠨ࠱ࡰࡳࡻ࡯ࡥࡴ࠱ࡤࡧࡹࡵࡲ࠰ࠩ㆛") + value
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㆜"),l1l1l1l_ll_+name,url,32)
	return
def l11ll1l11l_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫ㆝"))
	type = url.split(l111lll_ll_ (u"ࠫ࠴࠭㆞"))[3]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠬ࠭㆟"),headers,l111lll_ll_ (u"࠭ࠧㆠ"),l111lll_ll_ (u"ࠧࡑࡃࡑࡉ࡙࠳ࡉࡕࡇࡐࡗ࠲࠷ࡳࡵࠩㆡ"))
	if l111lll_ll_ (u"ࠨࡪࡲࡱࡪ࠭ㆢ") in url: type=l111lll_ll_ (u"ࠩࡨࡴ࡮ࡹ࡯ࡥࡧࡶࠫㆣ")
	if type==l111lll_ll_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪㆤ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡹࠨ࠯ࠬࡂ࠭ࡵࡧ࡮ࡦࡶ࠰ࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠧㆥ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㆦ"),block,re.DOTALL)
		for link,img,name in items:
			url = l1ll1l1_ll_ + link
			name = name.strip(l111lll_ll_ (u"࠭ࠠࠨㆧ"))
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧㆨ"),l1l1l1l_ll_+name,url,32,img)
	if type==l111lll_ll_ (u"ࠨ࡯ࡲࡺ࡮࡫ࡳࠨㆩ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡤࡨࡻࡈࡡࡳࡏࡤࡶࡸ࠮࠮ࠬࡁࠬࡴࡦࡴࡥࡵ࠯ࡳࡥ࡬࡯࡮ࡢࡶ࡬ࡳࡳ࠭ㆪ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪࡴࡦࡴࡥࡵ࠯ࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄ࠼ࡪ࡯ࡪࠤࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠢࡤࡰࡹࡃࠢࠩ࠰࠮ࡃ࠮ࠨࠧㆫ"),block,re.DOTALL)
		for link,img,name in items:
			name = name.strip(l111lll_ll_ (u"ࠫࠥ࠭ㆬ"))
			url = l1ll1l1_ll_ + link
			l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫㆭ"),l1l1l1l_ll_+name,url,33,img)
	if type==l111lll_ll_ (u"࠭ࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨㆮ"):
		page = url.split(l111lll_ll_ (u"ࠧ࠰ࠩㆯ"))[-1]
		#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࠩㆰ"))
		if page==l111lll_ll_ (u"ࠩ࠴ࠫㆱ"):
			l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡥࡩࡼࡂࡢࡴࡐࡥࡷࡹࠨ࠯࠭ࡂ࠭ࡦࡪࡶࡃࡣࡵࡑࡦࡸࡳࠨㆲ"),html,re.DOTALL)
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠫࡵࡧ࡮ࡦࡶ࠰ࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾࠽࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡶࡡ࡯ࡧࡷ࠱ࡹ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯࡬ࡲ࡫ࡵࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࠬㆳ"),block,re.DOTALL)
			count = 0
			for link,img,episode,title in items:
				count += 1
				if count==10: break
				name = title + l111lll_ll_ (u"ࠬࠦ࠭ࠡࠩㆴ") + episode
				url = l1ll1l1_ll_ + link
				l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬㆵ"),l1l1l1l_ll_+name,url,33,img)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡢࡦࡹࡆࡦࡸࡍࡢࡴࡶ࠲࠯ࡅࡡࡥࡸࡅࡥࡷࡓࡡࡳࡵࠫ࠲࠰ࡅࠩࡱࡣࡱࡩࡹ࠳ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠪㆶ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡲࡤࡲࡪࡺ࠭ࡵࡪࡸࡱࡧࡴࡡࡪ࡮࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠦࡃࡂࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡴࡦࡴࡥࡵ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳࠰࠭ࡃࡵࡧ࡮ࡦࡶ࠰࡭ࡳ࡬࡯ࠣࡀ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠳ࠩㆷ"),block,re.DOTALL)
		for link,img,title,episode in items:
			episode = episode.strip(l111lll_ll_ (u"ࠩࠣࠫㆸ"))
			title = title.strip(l111lll_ll_ (u"ࠪࠤࠬㆹ"))
			name = title + l111lll_ll_ (u"ࠫࠥ࠳ࠠࠨㆺ") + episode
			url = l1ll1l1_ll_ + link
			l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫㆻ"),l1l1l1l_ll_+name,url,33,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡧ࡭ࡻࡳ࡬࡮ࡩ࡯࡯࠯ࡦ࡬ࡪࡼࡲࡰࡰ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠯ࡄ࠯ࡤࡢࡶࡤ࠱ࡷ࡫ࡶࡪࡸࡨ࠱ࡿࡵ࡮ࡦ࡫ࡧࡁࠧ࠺ࠢࠨㆼ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ㆽ"),block,re.DOTALL)
	for link,page in items:
		url = l1ll1l1_ll_ + link
		name = l111lll_ll_ (u"ࠨืไัฮࠦࠧㆾ") + page
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩㆿ"),l1l1l1l_ll_+name,url,32)
	return
def l11_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫ㇀"))
	if l111lll_ll_ (u"ࠫࡸ࡫ࡲࡪࡧࡶࠫ㇁") in url:
		url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠬ࠵ࡳࡦࡴ࡬ࡩࡸ࠵ࡶ࠲࠱ࡶࡩࡷ࡯ࡥࡴࡎ࡬ࡲࡰ࠵ࠧ㇂") + url.split(l111lll_ll_ (u"࠭࠯ࠨ㇃"))[-1]
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠧࠨ㇄"),headers,l111lll_ll_ (u"ࠨࠩ㇅"),l111lll_ll_ (u"ࠩࡓࡅࡓࡋࡔ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪ㇆"))
		items = re.findall(l111lll_ll_ (u"ࠪࡹࡷࡲࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ㇇"),html,re.DOTALL)
		url = items[0]
		url = url.replace(l111lll_ll_ (u"ࠫࡡ࠵ࠧ㇈"),l111lll_ll_ (u"ࠬ࠵ࠧ㇉"))
	else:
		html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"࠭ࠧ㇊"),headers,l111lll_ll_ (u"ࠧࠨ㇋"),l111lll_ll_ (u"ࠨࡒࡄࡒࡊ࡚࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩ㇌"))
		items = re.findall(l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡘࡖࡑࠨࠠࡤࡱࡱࡸࡪࡴࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㇍"),html,re.DOTALL)
		url = items[0]
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࠫ㇎"))
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠫࡻ࡯ࡤࡦࡱࠪ㇏"))
	return
def l1lll1_ll_(search,page):
	#l1ll1l_ll_(search,page)
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠬ࠭㇐"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"࠭ࠧ㇑"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠧࠡࠩ㇒"),l111lll_ll_ (u"ࠨࠧ࠵࠴ࠬ㇓"))
	l1ll1llll11l_ll_ = [ l111lll_ll_ (u"ࠩࡰࡳࡻ࡯ࡥࡴࠩ㇔") , l111lll_ll_ (u"ࠪࡷࡪࡸࡩࡦࡵࠪ㇕")]
	if l1ll11_ll_:
		if page==l111lll_ll_ (u"ࠫࠬ㇖"):
			page = l111lll_ll_ (u"ࠬ࠷ࠧ㇗")
			l11l1lll11_ll_ = [ l111lll_ll_ (u"࠭ศฮอࠣ฽๋ࠦวโๆส้ࠬ㇘") , l111lll_ll_ (u"ࠧษฯฮࠤ฾์ࠠๆี็ื้อสࠨ㇙")]
			selection = l1l1111_ll_(l111lll_ll_ (u"ࠨษัฮึࠦวๅ่๋฽ࠥอไๆ่สือࡀࠧ㇚"), l11l1lll11_ll_)
			if selection == -1 : return
			type = l1ll1llll11l_ll_[selection]
		else: page,type = page.split(l111lll_ll_ (u"ࠩ࠲ࠫ㇛"))
	else: page,type = l111lll_ll_ (u"ࠪ࠵ࠬ㇜"),random.sample(l1ll1llll11l_ll_,1)
	payload = { l111lll_ll_ (u"ࠫࡶࡻࡥࡳࡻࠪ㇝"):l1llll1_ll_ , l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡉࡵ࡭ࡢ࡫ࡱࠫ㇞"):type }
	if page!=l111lll_ll_ (u"࠭࠱ࠨ㇟"): payload[l111lll_ll_ (u"ࠧࡧࡴࡲࡱࠬ㇠")] = page
	data = l1lll11ll_ll_(payload)
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࠩ㇡"),data,headers,l111lll_ll_ (u"ࠩࠪ㇢"),l111lll_ll_ (u"ࠪࡔࡆࡔࡅࡕ࠯ࡖࡉࡆࡘࡃࡉ࠯࠴ࡷࡹ࠭㇣"))
	#xbmc.log(str(html), level=xbmc.LOGNOTICE)
	items=re.findall(l111lll_ll_ (u"ࠫࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࡭࡫ࡱ࡯ࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ㇤"),html,re.DOTALL)
	if items:
		for title,link in items:
			url = l1ll1l1_ll_ + link.replace(l111lll_ll_ (u"ࠬࡢ࠯ࠨ㇥"),l111lll_ll_ (u"࠭࠯ࠨ㇦"))
			if l111lll_ll_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳ࠰ࠩ㇧") in url: l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ㇨"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩไ๎้๋ࠠࠨ㇩")+title,url,33)
			elif l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㇪") in url: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㇫"),l1l1l1l_ll_+l111lll_ll_ (u"๋ࠬำๅี็ࠤࠬ㇬")+title,url+l111lll_ll_ (u"࠭࠯࠲ࠩ㇭"),32)
	count=re.findall(l111lll_ll_ (u"ࠧࠣࡶࡲࡸࡦࡲࠢ࠻ࠪ࠱࠮ࡄ࠯ࡽࠨ㇮"),html,re.DOTALL)
	if count:
		pages = int(  (int(count[0])+9)   /10 )+1
		for l1ll1ll1l_ll_ in range(1,pages):
			l1ll1ll1l_ll_ = str(l1ll1ll1l_ll_)
			if l1ll1ll1l_ll_!=page:
				l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㇯"),l111lll_ll_ (u"ุࠩๅาฯࠠࠨㇰ")+l1ll1ll1l_ll_,l111lll_ll_ (u"ࠪࠫㇱ"),39,l111lll_ll_ (u"ࠫࠬㇲ"),l1ll1ll1l_ll_+l111lll_ll_ (u"ࠬ࠵ࠧㇳ")+type,search)
	#else: l1ll1l_ll_(l111lll_ll_ (u"࠭࡮ࡰࠢࡵࡩࡸࡻ࡬ࡵࡵࠪㇴ"),l111lll_ll_ (u"ࠧๅษࠣฮําฯ่ࠡอหหาࠠๅๆหัะ࠭ㇵ"))
	return
def l1ll11ll1_ll_():
	link = l111lll_ll_ (u"ࠨࡣࡋࡖ࠵ࡩࡄࡰࡸࡏ࠶ࡩࢀࡤࡉࡌ࡯࡝࡜࠶࠰ࡍࡰࡅ࡬ࡧࡳࡖ࠱ࡎࡰࡒࡻࡒ࡭࡭ࡵࡏ࠶࡛ࡱ࡚࠳ࡘࡩ࡝࡜ࡐࡹࡍ࠴࡫࡬ࡧࡍࡆࡖࡘ࡬࠽ࡼࡨࡇࡇ࠷ࡥࡋࡱࢀࡤࡄ࠷ࡷࡑ࠸࡛࠴ࠨㇶ")
	link = base64.b64decode(link)
	l111lll1_ll_(link,l1ll_ll_,l111lll_ll_ (u"ࠩ࡯࡭ࡻ࡫ࠧㇷ"))
	return