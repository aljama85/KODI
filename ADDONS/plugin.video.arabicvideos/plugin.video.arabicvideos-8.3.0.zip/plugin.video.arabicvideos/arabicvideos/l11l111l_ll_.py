# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡺࡴࡪ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰ࠳ࡻ࡯ࡥࡸ࠯࠴࠳ฬ็ไศ็࠰฽ึฮ๊สࠩஅ")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲ࡸࡻ࠴ࡡ࡭ࡣࡵࡥࡧ࠴ࡣࡰ࡯ࠪஆ")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡹࡼ࠱࠯ࡣ࡯ࡥࡷࡧࡢ࠯ࡥࡲࡱࠬஇ")
#l1ll1l1_ll_ = l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡼ࡯ࡥ࠰ࡤࡰࡦࡸࡡࡣ࠰ࡦࡳࡲ࠵ࡩ࡯ࡦࡨࡼ࠳ࡶࡨࡱࠩஈ")
l1ll_ll_ = l111lll_ll_ (u"࠭ࡁࡍࡃࡕࡅࡇ࠭உ")
headers = {l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫஊ"):l111lll_ll_ (u"ࠨࠩ஋")}
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡏࡑࡇ࡟ࠨ஌")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==10: results = l11l1ll_ll_(url)
	elif mode==11: results = l1l11l1_ll_(url)
	elif mode==12: results = l11_ll_(url)
	elif mode==13: results = l1l11ll_ll_(url)
	elif mode==14: results = l1111l11_ll_()
	elif mode==15: results = l1111lll_ll_()
	elif mode==16: results = l1llll11l_ll_()
	elif mode==19: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ஍")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬஎ"):
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬஏ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭ஐ"),l111lll_ll_ (u"ࠧࠨ஑"),19,l111lll_ll_ (u"ࠨࠩஒ"),l111lll_ll_ (u"ࠩࠪஓ"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧஔ"))
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩக"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ஖"),l111lll_ll_ (u"࠭ࠧ஗"),9999)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஘"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬங")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩสาึࠦวๅษูหๆอสࠨச"),l111lll_ll_ (u"ࠪࠫ஛"),14)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫஜ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ஝")+l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋࠭ஞ"),l111lll_ll_ (u"ࠧࠨட"),15)
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠨࠩ஠"),headers,l111lll_ll_ (u"ࠩࠪ஡"),l111lll_ll_ (u"ࠪࡅࡑࡇࡒࡂࡄ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ஢"))
	l1lll_ll_=re.findall(l111lll_ll_ (u"ࠫ࡮ࡪ࠽ࠣࡰࡤࡺ࠲ࡹ࡬ࡪࡦࡨࡶࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪண"),html,re.DOTALL)
	l11l11ll_ll_ = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧத"),l11l11ll_ll_,re.DOTALL)
	for link,title in items:
		link = l1ll1l1_ll_+link
		title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ஥"))
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ஦"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬ஧")+l1l1l1l_ll_+title,link,11)
	if l1111l_ll_==l111lll_ll_ (u"ࠩࠪந"): l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨன"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧப"),l111lll_ll_ (u"ࠬ࠭஫"),9999)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡩࡥ࠿ࠥࡲࡦࡼࡢࡢࡴࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ஬"),html,re.DOTALL)
	l11l1l11_ll_ = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩ஭"),l11l1l11_ll_,re.DOTALL)
	for link,title in items:
		link = l1ll1l1_ll_+link
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨம"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭ய")+l1l1l1l_ll_+title,link,11)
	return html
def l1111lll_ll_():
	#l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪர"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ๅิๆึ่ฬะࠠศๆ฼ีอ๐ษࠨற"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡶࡪࡧࡺ࠱࠽࠵ๅิๆึ่ฬะฺ࠭ำห๎ฮ࠭ல"),11)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ள"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧๆี็ื้อสࠡำฺ่ฬ์ࠠ࠳࠲࠵࠴ࠥลࠡࠨழ"),l111lll_ll_ (u"ࠨࠩவ"),16)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩஶ"),l1l1l1l_ll_+l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤึ๋ึศ่ࠣ࠶࠵࠸࠰ࠨஷ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡼࡩࡦࡹ࠰࠼࠴๋ำๅี็หฯ࠳ัๆุส๊࠲࠸࠰࠳࠲ࠪஸ"),11)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬஹ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅิๆึ่ฬะࠠา็ูห๋ࠦ࠲࠱࠳࠼ࠫ஺"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡴࡤࡱࡦࡪࡡ࡯࠴࠳࠵࠾࠵ๅึำํอࠬ஻"),11)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ஼"),l1l1l1l_ll_+l111lll_ll_ (u"่ࠩืู้ไศฬࠣี๊฼ว็ࠢ࠵࠴࠶࠾ࠧ஽"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡷࡧ࡭ࡢࡦࡤࡲ࠷࠶࠱࠹࠱ู่ึ๐ษࠨா"),11)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫி"),l1l1l1l_ll_+l111lll_ll_ (u"๋ࠬำๅี็หฯࠦัๆุส๊ࠥ࠸࠰࠲࠹ࠪீ"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡳࡣࡰࡥࡩࡧ࡮࠳࠲࠴࠻࠴๋ีา์ฬࠫு"),11)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧூ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨ็ึุ่๊วหࠢิ้฻อๆࠡ࠴࠳࠵࠻࠭௃"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡶࡦࡳࡡࡥࡣࡱ࠶࠵࠷࠶࠰็ุี๏ฯࠧ௄"),11)
	return
def l1111l11_ll_():
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫ௅"),headers,True,l111lll_ll_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡑࡇࡔࡆࡕࡗ࠱࠶ࡹࡴࠨெ"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭ே"),html)
	l1lll_ll_=re.findall(l111lll_ll_ (u"࠭ࡨࡦࡣࡧ࡭ࡳ࡭࠭ࡵࡱࡳࠬ࠳࠰࠿ࠪࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠬை"),html,re.DOTALL)
	block = l1lll_ll_[0]+l1lll_ll_[1]
	items=re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ௉"),block,re.DOTALL)
	for link,img,title in items:
		url = l1ll1l1_ll_ + link
		if l111lll_ll_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨொ") in url: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩோ"),l1l1l1l_ll_+title,url,11,img)
		else: l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩௌ"),l1l1l1l_ll_+title,url,12,img)
	return
def l1l11l1_ll_(url):
	#l1ll1l_ll_(l111lll_ll_ (u"࡙ࠫࡏࡔࡍࡇࡖ்ࠫ"),url)
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ௎"),url,l111lll_ll_ (u"࠭ࠧ௏"),headers,True,True,l111lll_ll_ (u"ࠧࡂࡎࡄࡖࡆࡈ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫௐ"))
	html = response.content
	#with open(l111lll_ll_ (u"ࠨࡕ࠽ࡠࡡ࠶࠰ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪ௑"),l111lll_ll_ (u"ࠩࡺࠫ௒")) as f: f.write(str(html))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰ࠯ࡦࡥࡹ࡫ࡧࡰࡴࡼࠬ࠳࠰࠿ࠪࡴ࡬࡫࡭ࡺ࡟ࡤࡱࡱࡸࡪࡴࡴࠨ௓"),html,re.DOTALL)
	if not l1lll_ll_: return
	block = l1lll_ll_[0]
	found = False
	#items = re.findall(l111lll_ll_ (u"ࠫࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࡟࠺࠸࡝࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ௔"),block,re.DOTALL)
	items = re.findall(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲ࠱ࡧࡵࡸ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࡬ࡹࡺࡰ࠯ࠬࡂ࠭ࠧࠦࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ௕"),block,re.DOTALL)
	l1ll11ll_ll_,l11l1111_ll_ = [],[]
	for link,img,title in items:
		if title==l111lll_ll_ (u"࠭ࠧ௖"): title = link.split(l111lll_ll_ (u"ࠧ࠰ࠩௗ"))[-1].replace(l111lll_ll_ (u"ࠨ࠯ࠪ௘"),l111lll_ll_ (u"ࠩࠣࠫ௙"))
		sequence = re.findall(l111lll_ll_ (u"ࠪࠬࡡࡪࠫࠪࠩ௚"),title,re.DOTALL)
		if sequence: sequence = int(sequence[0])
		else: sequence = l111lll_ll_ (u"ࠫࠬ௛")
		l11l1111_ll_.append([img,link,title,sequence])
	l11l1111_ll_ = sorted(l11l1111_ll_, reverse=True, key=lambda key: key[3])
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠸࠲࠳ࠩ௜"),url)
	for img,link,title,sequence in l11l1111_ll_:
		link = l1ll1l1_ll_ + link
		#l1ll1l_ll_(url,title)
		title = title.replace(l111lll_ll_ (u"࠭ๅีษ๊ำฮࠦๅิๆึ่ࠬ௝"),l111lll_ll_ (u"ࠧๆี็ื้࠭௞"))
		title = title.replace(l111lll_ll_ (u"ࠨ็ืห์ีษࠡษ็ุ้๊ำๅࠩ௟"),l111lll_ll_ (u"ࠩสู่๊ไิๆࠪ௠"))
		title = title.replace(l111lll_ll_ (u"ู้ࠪอ็ะหࠣๅ๏๊ๅࠨ௡"),l111lll_ll_ (u"ࠫๆ๐ไๆࠩ௢"))
		title = title.replace(l111lll_ll_ (u"๋ࠬิศ้าอࠥอไโ์็้ࠬ௣"),l111lll_ll_ (u"࠭วๅใํ่๊࠭௤"))
		title = title.replace(l111lll_ll_ (u"ࠧๆสสุึฯࠠไ๊ส่๏ะ๊ࠨ௥"),l111lll_ll_ (u"ࠨࠩ௦"))
		title = title.replace(l111lll_ll_ (u"ࠩ฼ห้๐ษࠡ฻็ํࠥอไฺำหࠫ௧"),l111lll_ll_ (u"ࠪࠫ௨"))
		title = title.replace(l111lll_ll_ (u"ฺ๊ࠫว่ัฬࠤ๊ฮวีำฬࠫ௩"),l111lll_ll_ (u"ࠬ࠭௪"))
		title = title.replace(l111lll_ll_ (u"࠭ว้่่ࠣฬ๐ๆࠨ௫"),l111lll_ll_ (u"ࠧࠨ௬"))
		title = title.replace(l111lll_ll_ (u"ࠨษ๋๊้อ๊็ࠩ௭"),l111lll_ll_ (u"ࠩࠪ௮"))
		title = title.replace(l111lll_ll_ (u"ࠪฬั๎ฯสࠢ฼ห้๐ษࠨ௯"),l111lll_ll_ (u"ࠫࠬ௰"))
		title = title.replace(l111lll_ll_ (u"ࠬา่ะหࠣ฽ฬ๊๊สࠩ௱"),l111lll_ll_ (u"࠭ࠧ௲"))
		title = title.replace(l111lll_ll_ (u"ࠧษั๋๊ࠥะอๆ์็ࠫ௳"),l111lll_ll_ (u"ࠨࠩ௴"))
		title = title.replace(l111lll_ll_ (u"ࠩ฼่๎ࠦวๅ฻ิฬࠬ௵"),l111lll_ll_ (u"ࠪࠫ௶"))
		title = title.replace(l111lll_ll_ (u"๊ࠫฮวีำฬࠫ௷"),l111lll_ll_ (u"ࠬ࠭௸"))
		title = title.strip(l111lll_ll_ (u"࠭ࠠࠨ௹")).replace(l111lll_ll_ (u"ࠧࠡࠢࠪ௺"),l111lll_ll_ (u"ࠨࠢࠪ௻")).replace(l111lll_ll_ (u"ࠩࠣࠤࠬ௼"),l111lll_ll_ (u"ࠪࠤࠬ௽"))
		title = l111lll_ll_ (u"ࠫࡤࡓࡏࡅࡡࠪ௾")+title
		l11ll111_ll_ = title
		if l111lll_ll_ (u"ࠬ࠵ࡱ࠰ࠩ௿") in url and (l111lll_ll_ (u"࠭วๅฯ็ๆฮ࠭ఀ") in title or l111lll_ll_ (u"ࠧศๆะ่็ํࠧఁ") in title):
			episode = re.findall(l111lll_ll_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫం"),title,re.DOTALL)
			if episode: l11ll111_ll_ = episode[0]
			#if l111lll_ll_ (u"่ࠩืู้ไࠨః") not in l11ll111_ll_: l11ll111_ll_ = l111lll_ll_ (u"ุ้๊ࠪำๅࠢࠪఄ")+l11ll111_ll_
		if l11ll111_ll_ not in l1ll11ll_ll_:
			l1ll11ll_ll_.append(l11ll111_ll_)
			#xbmc.log(l11ll111_ll_, level=xbmc.LOGNOTICE)
			if l111lll_ll_ (u"ࠫ࠴ࡷ࠯ࠨఅ") in url and (l111lll_ll_ (u"ࠬอไฮๆๅอࠬఆ") in title or l111lll_ll_ (u"࠭วๅฯ็ๆ์࠭ఇ") in title):
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧఈ"),l1l1l1l_ll_+l11ll111_ll_,link,13,img)
				found = True
			elif l111lll_ll_ (u"ࠨࡵࡨࡶ࡮࡫ࡳࠨఉ") in link:
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩఊ"),l1l1l1l_ll_+title,link,11,img)
				found = True
			else:
				#if l111lll_ll_ (u"ุ้๊ࠪำๅࠩఋ") not in title and l111lll_ll_ (u"ࠫฬ๊อๅไฬࠫఌ") in title: title = l111lll_ll_ (u"๋ࠬำๅี็ࠤࠬ఍")+title
				l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬఎ"),l1l1l1l_ll_+title,link,12,img)
				found = True
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧ࠴࠵࠶ࠫఏ"),url)
	if found:
		items = re.findall(l111lll_ll_ (u"ࠨࡶࡶࡧࡤ࠹ࡤࡠࡤࡸࡸࡹࡵ࡮ࠡࡴࡨࡨ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࠦࡴࡪࡶ࡯ࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ఐ"),block,re.DOTALL)
		for link,page in items:
			url = l1ll1l1_ll_ + link
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ఑"),l1l1l1l_ll_+page,url,11)
	return
def l1l11ll_ll_(url):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠪࠫఒ"),headers,True,l111lll_ll_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪఓ"))
	series = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠵ࡳࡦࡴ࡬ࡩࡸ࠴ࠪࡀࠫࠥࠫఔ"),html,re.DOTALL)
	l1ll111_ll_ = l1ll1l1_ll_+series[0]
	results = l1l11l1_ll_(l1ll111_ll_)
	return
l111lll_ll_ (u"ࠨࠢࠣࠌࡧࡩ࡫ࠦࡅࡑࡋࡖࡓࡉࡋࡓࡠࡑࡏࡈ࠭ࡻࡲ࡭ࠫ࠽ࠎࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡒࡆࡉࡘࡐࡆࡘ࡟ࡄࡃࡆࡌࡊ࠲ࡵࡳ࡮࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࡕࡴࡸࡩ࠱࠭ࡁࡍࡃࡕࡅࡇ࠳ࡅࡑࡋࡖࡓࡉࡋࡓࡠࡑࡏࡈ࠲࠷ࡳࡵࠩࠬࠎࠎ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡦࡦࡴ࡮ࡦࡴ࠰ࡶ࡮࡭ࡨࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷ࡮ࡩ࠭ࡤࡪࡤࡲࡳ࡫࡬ࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠸ࠧࠪࠌࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࡩࡵࡧࡰࡷࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠬࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࡸࡶࡱ࠲ࠧࡴࡶࡨࡴࠥ࠹ࠧࠪࠌࠌ࡭ࡹ࡫࡭ࡴࠢࡀࠤࡸࡵࡲࡵࡧࡧࠬ࡮ࡺࡥ࡮ࡵ࠯ࠤࡷ࡫ࡶࡦࡴࡶࡩࡂ࡚ࡲࡶࡧ࠯ࠤࡰ࡫ࡹ࠾࡮ࡤࡱࡧࡪࡡࠡ࡭ࡨࡽ࠿ࠦ࡫ࡦࡻ࡞࠵ࡢ࠯ࠊࠊࠥࡱࡥࡲ࡫ࠠ࠾ࠢࡻࡦࡲࡩ࠮ࡨࡧࡷࡍࡳ࡬࡯ࡍࡣࡥࡩࡱ࠮ࠧࡍ࡫ࡶࡸࡎࡺࡥ࡮࠰ࡏࡥࡧ࡫࡬ࠨࠫࠍࠍࠨࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࡷࡵࡰ࠱࠭ࡳࡵࡧࡳࠤ࠹࠭ࠩࠋࠋࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷࠥࡃࠠ࡜࡟ࠍࠍ࡫ࡵࡲࠡ࡫ࡰ࡫࠱ࡲࡩ࡯࡭࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࡪࡨࠣࡸ࡮ࡺ࡬ࡦࠢࡱࡳࡹࠦࡩ࡯ࠢࡤࡰࡱ࡚ࡩࡵ࡮ࡨࡷ࠿ࠐࠉࠊࠋ࡯࡭ࡳࡱࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠰࡛ࡎࡒࡗࡒࡘࡊ࠮࡬ࡪࡰ࡮࠭ࠏࠏࠉࠊࡶ࡬ࡸࡱ࡫ࠠ࠾ࠢࡷ࡭ࡹࡲࡥ࠯ࡵࡷࡶ࡮ࡶࠨࠨࠢࠪ࠭ࠏࠏࠉࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡷ࡫ࡧࡩࡴ࠭ࠬ࡮ࡧࡱࡹࡤࡴࡡ࡮ࡧ࠮ู๊ࠫไิๆࠣࠫ࠰ࡺࡩࡵ࡮ࡨ࠰ࡱ࡯࡮࡬࠮࠴࠶࠱࡯࡭ࡨࠫࠍࠍࠎࠏࡡ࡭࡮ࡗ࡭ࡹࡲࡥࡴ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠧࡉࡏࡁࡍࡑࡊࡣࡔࡑࠨࡶࡴ࡯࠰ࠬࡹࡴࡦࡲࠣ࠹ࠬ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠤࠥࠦక")
def l11_ll_(url):
	#l1ll1l_ll_(url,str(url))
	l1l111l_ll_,l1111ll_ll_,l111l111_ll_ = [],[],[]
	html = l111ll1_ll_(l11111l1_ll_,url,l111lll_ll_ (u"ࠧࠨఖ"),headers,True,l111lll_ll_ (u"ࠨࡃࡏࡅࡗࡇࡂ࠮ࡒࡏࡅ࡞࠳࠱ࡴࡶࠪగ"))
	# l1ll1l1l_ll_://vod.l1lllllll_ll_.l1lll1l11_ll_/l1llll1ll_ll_-_حلقة_1lll1ll1_ll_حكايتي_111l1l1_ll_رمضان_111ll11_ll_
	# l1ll1l1l_ll_://l111l1ll_ll_.l1lllllll_ll_.l1lll1l11_ll_/vod.l1lllll11_ll_?vid=110253
	# l1ll1l1l_ll_://embed.l1lllllll_ll_.l1lll1l11_ll_/video/110272
	# l1ll1l1l_ll_://cdn.l1lllllll_ll_.l1lll1l11_ll_/numeric/130128.l111llll_ll_/playlist.l1111111_ll_
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡸࡶ࠮ࠫࡁࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧఘ"),html,re.DOTALL)
	if l1ll111_ll_:
		l1ll111_ll_ = l1ll111_ll_[0]
		l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠪࠫఙ"),headers,False,l111lll_ll_ (u"ࠫࡆࡒࡁࡓࡃࡅ࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭చ"))
		l11ll1_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹ࡯ࡶࡴࡦࡩࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪఛ"),l1l111l1_ll_,re.DOTALL)
		if l11ll1_ll_:
			l11ll1_ll_ = l11ll1_ll_[0]
			#if l11ll1_ll_.count(l111lll_ll_ (u"࠭ࡨࡵࡶࡳࠫజ"))>1: l11ll1_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࠬఝ")+l11ll1_ll_.split(l111lll_ll_ (u"ࠨࡪࡷࡸࡵ࠭ఞ"),2)[2]
			l1l111l_ll_.append(l11ll1_ll_)
			l1111ll_ll_.append(l111lll_ll_ (u"ࠩึ๎ึ็ัࠡะสูࠥࠦ࡭࠴ࡷ࠻ࠫట"))
	if len(l1l111l_ll_)==0:
		if l111lll_ll_ (u"ࠪ࠳ࡻ࡯ࡥࡸࡘࡨࡨ࡮ࡵ࠯ࠨఠ") not in url: id = re.findall(l111lll_ll_ (u"ࠫ࠳ࡩ࡯࡮࠱ࡹࠬࡠ࠶࠭࠺࡟࠮࠭࠲࠭డ"),url,re.DOTALL)
		else: id = re.findall(l111lll_ll_ (u"ࠬ࠴ࡣࡰ࡯࠲ࡺ࡮࡫ࡷࡗࡧࡧ࡭ࡴ࠵ࠨ࡜࠲࠰࠽ࡢ࠱ࠩ࠰ࠩఢ"),url,re.DOTALL)
		if id:
			id = id[0]
			l1ll111_ll_ = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡢ࡮ࡤࡶࡦࡨࡰ࡭ࡣࡼࡩࡷࡹ࠮ࡢ࡮ࡤࡶࡦࡨ࠮ࡤࡱࡰ࠳ࡻࡵࡤ࠯ࡲ࡫ࡴࡄࡼࡩࡥ࠿ࠪణ")+id
			headers[l111lll_ll_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨత")] = url
			l1l111l1_ll_ = l111ll1_ll_(l11111l1_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩథ"),headers,False,l111lll_ll_ (u"ࠩࡄࡐࡆࡘࡁࡃ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫద"))
			html += l1l111l1_ll_
	if len(l1l111l_ll_)==0:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡴࡱࡧࡹࡦࡴࡌࡲࡸࡺࡡ࡯ࡥࡨ࠲ࡸ࡫ࡴࡶࡲࠫ࠲࠯ࡅࠩࡱࡴ࡬ࡱࡦࡸࡹࠨధ"),html,re.DOTALL)
		for block in l1lll_ll_:
			youtube = re.findall(l111lll_ll_ (u"ࠫ࡫࡯࡬ࡦ࠼ࠥ࠲࠯ࡅࡹࡰࡷࡷࡹ࠳࠰࠿࠾ࠪ࠱࠮ࡄ࠯ࠢࠨన"),block,re.DOTALL)
			l1111ll1_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡬ࡩ࡭ࡧ࠽ࠤࡠࠨ࡜ࠨ࡟ࠫ࠲࠯ࡅ࡭ࡱ࠶ࠬ࡟ࠧࡢࠧ࡞࠰࠭ࡃࡱࡧࡢࡦ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ఩"),block,re.DOTALL)
			l1llll111_ll_ = re.findall(l111lll_ll_ (u"࠭ࡦࡪ࡮ࡨ࠾ࠥࡡࠢ࡝ࠩࡠ࠲࠯ࡅࡶࡪࡦࡨࡳࡩ࡫࡬ࡪࡸࡨࡶࡾ࠴ࠪࡀ࠱ࠫ࠲࠯ࡅࠩ࠰ࠩప"),block,re.DOTALL)
			l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡧ࡫࡯ࡩ࠿࡛ࠦࠣ࡞ࠪࡡ࠭࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝ࠨఫ"),block,re.DOTALL)
			l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠨࠤࡩ࡭ࡱ࡫ࠢ࠻ࠢ࡞ࠦࡡ࠭࡝ࠩ࠰࠭ࡃ࠮ࡡࠢ࡝ࠩࡠࠫబ"),block,re.DOTALL)
			if youtube:
				for l111ll1l_ll_ in youtube:
					#url = l111lll_ll_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨ࠳ࡵࡲࡡࡺ࠱ࡂࡺ࡮ࡪࡥࡰࡡ࡬ࡨࡂ࠭భ")+l111ll1l_ll_
					l1l111l_ll_.append(l111ll1l_ll_)
					l1111ll_ll_.append(l111lll_ll_ (u"้้ࠪ็๋๊ࠠอ๎ํฮࠧమ"))
			elif l1111ll1_ll_:
				for file,label in reversed(l1111ll1_ll_):
					l1l111l_ll_.append(file)
					l1111ll_ll_.append(l111lll_ll_ (u"ุࠫ๐ัโำࠣาฬ฻ࠠࠡ࡯ࡳ࠸ࠥࠦࠧయ")+label)
			elif l1llll111_ll_:
				for id in l1llll111_ll_:
					l111l111_ll_.append(id)
			elif l1lll1lll_ll_:
				for file in l1lll1lll_ll_:
					l1l111l_ll_.append(file)
					l1111ll_ll_.append(l111lll_ll_ (u"ู๊ࠬาใิࠤำอีࠡࠢࡰࡴ࠹࠭ర"))
			elif l1lll1l1l_ll_:
				# l1ll1l1l_ll_://cdn.l1lllllll_ll_.l1lll1l11_ll_/vod,6,15,00/130479.l111llll_ll_.l111l11l_ll_/playlist.l1111111_ll_
				for file in l1lll1l1l_ll_:
					l1lllll1l_ll_,l1llllll1_ll_ = l11l1l1l_ll_(file)
					z = zip(l1lllll1l_ll_,l1llllll1_ll_)
					for label,file in z:
						l1l111l_ll_.append(file)
						l1111ll_ll_.append(l111lll_ll_ (u"࠭ำ๋ำไีࠥิวึࠢࠣࠫఱ")+label)
	if len(l1l111l_ll_)==0:
		id = re.findall(l111lll_ll_ (u"ࠧࡴࡶࡵࡩࡦࡳࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬల"),html,re.DOTALL)
		if id: l111l111_ll_.append(id)
		for id in l111l111_ll_:
			l11ll1_ll_ = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯ࡥࡧ࡯࡭ࡻ࡫ࡲࡺ࠰ࡱࡩࡹ࠵ࠧళ")+id+l111lll_ll_ (u"ࠩ࠲ࡱࡦࡴࡩࡧࡧࡶࡸ࠴ࡼࡩࡥࡧࡲ࠲ࡲࡶࡤࠨఴ")
			l1l111l_ll_.append(l11ll1_ll_)
			l1111ll_ll_.append(l111lll_ll_ (u"ࠪื๏ืแาࠢัหฺࠦࠠ࡮ࡲࡧࠫవ"))
			l11ll1_ll_ = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡼࡩࡥࡧࡲࡨࡪࡲࡩࡷࡧࡵࡽ࠳ࡴࡥࡵ࠱ࠪశ")+id+l111lll_ll_ (u"ࠬ࠵࡭ࡢࡰ࡬ࡪࡪࡹࡴ࠰ࡸ࡬ࡨࡪࡵ࠮࡮࠵ࡸ࠼ࠬష")
			title = l111lll_ll_ (u"࠭ำ๋ำไีࠥิวึࠢࠣࡱ࠸ࡻ࠸ࠨస")
			l1111ll_ll_.append(title)
			l1l111l_ll_.append(l11ll1_ll_)
	l111lll_ll_ (u"ࠢࠣࠤࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࡔࡳࡷࡨ࠰ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠷ࡷࡪࠧࠪࠌࠌࡈࡎࡇࡌࡐࡉࡢࡓࡐ࠮ࡵࡳ࡮࠯ࡷࡹࡸࠨࡩࡶࡰࡰ࠮࠯ࠊࠊ࡫ࡷࡩࡲࡹ࠲ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡔࡈࡗࡔࡒࡕࡕࡋࡒࡒࡂ࠮࠮ࠫࡁࠬ࠰࠳࠰࠿࡝ࡰࠫ࠲࠯ࡅࠩ࡝ࡰࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡭ࡹ࡫࡭ࡴ࠴࠽ࠎࠎࠏࡦࡰࡴࠣࡶࡪࡹ࡯࡭ࡷࡷ࡭ࡴࡴࠬ࡭࡫ࡱ࡯ࠥ࡯࡮ࠡ࡫ࡷࡩࡲࡹ࠲࠻ࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࠧࠡีํีๆืࠠฯษุࠤࠬ࠱ࠧ࡮࠵ࡸ࠼ࠥ࠭ࠫࡳࡧࡶࡳࡱࡻࡴࡪࡱࡱ࠲ࡸࡶ࡬ࡪࡶࠫࠫࡽ࠭ࠩ࡜࠳ࡠࠎࠎࠏࠉ࡭࡫ࡱ࡯ࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡹ࡭ࡩ࡫࡯ࡥࡧ࡯࡭ࡻ࡫ࡲࡺ࠰ࡱࡩࡹ࠵ࠧࠬࡸ࡬ࡨࡪࡵࡤࡦ࡮࡬ࡺࡪࡸࡹࡊࡆ࡞࠴ࡢ࠱ࠧ࠰࡯ࡤࡲ࡮࡬ࡥࡴࡶ࠲ࠫ࠰ࡲࡩ࡯࡭ࠍࠍࠎࠏࡴࡪࡶ࡯ࡩࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪࡷ࡭ࡹࡲࡥࠪࠌࠌࠍࠎࡲࡩ࡯࡭ࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡭࡫ࡱ࡯࠮ࠐࠉࠤ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡳࡧࡶࡴ࠲ࡩ࡯࡯ࡶࡤ࡭ࡳ࡫ࡲ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠤ࡫ࡩࠤ࡮ࡺࡥ࡮ࡵ࠽ࠎࠎࠩࠉࡶࡴ࡯ࠤࡂࠦࡩࡵࡧࡰࡷࡠ࠶࡝ࠋࠋࠦࠍࡱ࡯࡮࡬ࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮ࡵࡳ࡮ࠬࠎࠎࠩࠉࡵ࡫ࡷࡰࡪࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦ๊๊ࠫࠫแࠡษ็ฮูเ๊ๅࠩࠬࠎࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱ࡹࡴࡳࠪ࡯࡭ࡳࡱࡌࡊࡕࡗ࠭࠮ࠐࠉࠤࡷࡵࡰࠥࡃࠠࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣࠣ࠯ࠥ࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠰ࡳ࡬ࡵࡅࡦࡪ࡮ࡨࡁࠬ࠱ࡩࡥࠌࠌࠧ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡘࡅࡈࡗࡏࡅࡗࡥࡃࡂࡅࡋࡉ࠱ࡻࡲ࡭࠮ࠪࠫ࠱࡮ࡥࡢࡦࡨࡶࡸ࠲ࡔࡳࡷࡨ࠰ࠬࡇࡌࡂࡔࡄࡆ࠲ࡖࡌࡂ࡛࠰࠸ࡹ࡮ࠧࠪࠌࠌࠧ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀ࠴࡮࠲࠿࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿࡮ࡲ࠷࠭ࠧ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌࠧ࡮࡬ࠠࡪࡶࡨࡱࡸࡀࠊࠊࠥࠌࡰ࡮ࡴ࡫ࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭࡯ࡴࡦ࡯ࡶ࡟࠵ࡣࠩࠋࠋࠦࠍࡹ࡯ࡴ࡭ࡧࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࠨ็็ๅࠥอไหฯ่๎้࠭ࠩࠋࠋࠥࠦࠧహ")
	if len(l1l111l_ll_)==0:
		#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ఺"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡔ࡯ࠡࡸ࡬ࡨࡪࡵࠠࡧ࡫࡯ࡩࠥ࡬࡯ࡶࡰࡧࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ఻")+url+l111lll_ll_ (u"ࠪࠤࡢ఼࠭"))
		l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧఽ"),l111lll_ll_ (u"๊ࠬวࠡ์๋ะิࠦๅๅใࠣๅ๏ี๊้ࠩా"))
		return
	elif len(l1l111l_ll_)==1:
		selection = 0
		url = l1l111l_ll_[selection]
	else:
		l11l11l1_ll_,l1llll1l1_ll_ = [],[]
		for i in range(0,len(l1l111l_ll_),+1):
			if l1l111l_ll_[i] not in l11l11l1_ll_:
				l11l11l1_ll_.append(l1l111l_ll_[i])
				l1llll1l1_ll_.append(l1111ll_ll_[i])
		selection = l1l1111_ll_(l111lll_ll_ (u"࠭วฯฬิࠤฬ๊ๅๅใࠣห้๋ๆศีห࠾ࠬి"), l1llll1l1_ll_)
		if selection == -1 : return
		url = l11l11l1_ll_[selection]
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࠨీ"))
	if l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࠧు") in url:
		import l1_ll_
		l1_ll_.l11111ll_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨూ"))
	else: l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩృ"))
	return
def l1llll11l_ll_():
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬౄ"),headers,True,l111lll_ll_ (u"ࠬࡇࡌࡂࡔࡄࡆ࠲ࡘࡁࡎࡃࡇࡅࡓ࠳࠱ࡴࡶࠪ౅"))
	l1lll_ll_=re.findall(l111lll_ll_ (u"࠭ࡩࡥ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࡣࡸ࡫ࡣࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡰࡪ࡬ࡴࡠࡥࡲࡲࡹ࡫࡮ࡵࠤࠪె"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items=re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩే"),block,re.DOTALL)
	year = re.findall(l111lll_ll_ (u"ࠨ࠱ࡵࡥࡲࡧࡤࡢࡰࠫ࡟࠵࠳࠹࡞࠭ࠬ࠳ࠬై"),str(items),re.DOTALL)
	year = year[0]
	for link,title in items:
		url = l1ll1l1_ll_ + link
		title = title.strip(l111lll_ll_ (u"ࠩࠣࠫ౉")) + l111lll_ll_ (u"ࠪࠤࠬొ") + year
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫో"),l1l1l1l_ll_+title,url,11)
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠬ࠭ౌ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"్࠭ࠧ"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠧࠡࠩ౎"),l111lll_ll_ (u"ࠨࠧ࠵࠴ࠬ౏"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠤ࠲ࡵ࠴ࠨ౐") + l1llll1_ll_
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪ࠷࠸࠹ࠧ౑"),url)
	results = l1l11l1_ll_(url)
	return