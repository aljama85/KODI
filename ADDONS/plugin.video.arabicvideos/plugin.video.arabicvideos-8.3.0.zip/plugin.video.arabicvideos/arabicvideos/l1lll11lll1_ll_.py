﻿# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#import unicodedata,simplejson
def l111l1l_ll_(mode,l1lll1l11l1_ll_):
	import unicodedata,email.charset
	#import simplejson as json
	#from l1l1l1_ll_ import *
	#l1ll1l_ll_(str(mode),text)
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	l1lll1l11l1_ll_ = text
	if l1lll1l11l1_ll_==l111lll_ll_ (u"ࠬ࠭⁥"): return
	if mode==1:
		try:
			l1lll1l1ll1_ll_ = xbmcgui.getCurrentWindowDialogId()
			l1lll1l1l1l_ll_ = xbmcgui.Window(l1lll1l1ll1_ll_)
			l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
			l1lll1l1l1l_ll_.getControl(311).setLabel(l1lll1l11l1_ll_)
		except: traceback.print_exc(file=sys.stderr)
	elif mode==0:
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"࠭ࡵ࡯࡫ࡦࡳࡩ࡫࡟ࡦࡵࡦࡥࡵ࡫ࠧ⁦"))
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠧࡳࡣࡺࡣࡺࡴࡩࡤࡱࡧࡩࡤ࡫ࡳࡤࡣࡳࡩࠬ⁧"))
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠲࠾ࠧ⁨"))
		l1lll1l1111_ll_=l111lll_ll_ (u"࡛ࠩࠫ⁩")
		check=isinstance(l1lll1l11l1_ll_, unicode)
		if check==True: l1lll1l1111_ll_=l111lll_ll_ (u"࡙ࠪࠬ⁪")
		l1lll11llll_ll_ = str(type(l1lll1l11l1_ll_))+l111lll_ll_ (u"ࠫࠥ࠭⁫")+l1lll1l11l1_ll_+l111lll_ll_ (u"ࠬࠦࠧ⁬")+l1lll1l1111_ll_+l111lll_ll_ (u"࠭ࠠࠨ⁭")
		for i in range(0,len(l1lll1l11l1_ll_),1):
			l1lll11llll_ll_ += hex(ord(l1lll1l11l1_ll_[i])).replace(l111lll_ll_ (u"ࠧ࠱ࡺࠪ⁮"),l111lll_ll_ (u"ࠨࠩ⁯"))+l111lll_ll_ (u"ࠩࠣࠫ⁰")
		l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠭࠹ࠩⁱ"))
		l1lll1l1111_ll_ = l111lll_ll_ (u"ࠫ࡝࠭⁲")
		check=isinstance(l1lll1l11l1_ll_, unicode)
		if check==True: l1lll1l1111_ll_ = l111lll_ll_ (u"࡛ࠬࠧ⁳")
		l1lll1l111l_ll_ = str(type(l1lll1l11l1_ll_))+l111lll_ll_ (u"࠭ࠠࠨ⁴")+l1lll1l11l1_ll_+l111lll_ll_ (u"ࠧࠡࠩ⁵")+l1lll1l1111_ll_+l111lll_ll_ (u"ࠨࠢࠪ⁶")
		for i in range(0,len(l1lll1l11l1_ll_),1):
			l1lll1l111l_ll_ += hex(ord(l1lll1l11l1_ll_[i])).replace(l111lll_ll_ (u"ࠩ࠳ࡼࠬ⁷"),l111lll_ll_ (u"ࠪࠫ⁸"))+l111lll_ll_ (u"ࠫࠥ࠭⁹")
		#l1ll1l_ll_(l1lll11llll_ll_,l1lll1l111l_ll_)
	return
	#for i in range(0,len(l1lll1l11l1_ll_)-2,3):
	#	string=hex(ord(l1lll1l11l1_ll_[i+0]))+l111lll_ll_ (u"ࠬࠦࠠࠨ⁺")+hex(ord(l1lll1l11l1_ll_[i+1]))+l111lll_ll_ (u"࠭ࠠࠡࠩ⁻")+hex(ord(l1lll1l11l1_ll_[i+2]))
	#	l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ⁼"),string)
	#return
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭⁽"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ⁾"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨⁿ"))
	#l1lll1l11l1_ll_ = unicodedata.normalize(l111lll_ll_ (u"ࠫࡓࡌࡋࡅࠩ₀"),l1lll1l11l1_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭₁"),   hex(  unicodedata.combining(l1lll1l11l1_ll_[0])  )   )
	#l1ll1l_ll_(l1lll1l11l1_ll_,   hex(ord(  l1lll1l11l1_ll_[0]  ))   )
	#new = l111lll_ll_ (u"࠭ࠧ₂")
	#for letter in l1lll1l11l1_ll_:
	#	l1ll1l_ll_(l111lll_ll_ (u"ࠧࡎࡱࡧࡩࠥ࠶ࠧ₃"),unicodedata.decomposition(letter) )
	#	new += l111lll_ll_ (u"ࠨ࡞ࡸ࠴ࠬ₄") + hex(ord(letter)).replace(l111lll_ll_ (u"ࠩ࠳ࡼࠬ₅"),l111lll_ll_ (u"ࠪࠫ₆"))
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ₇"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"ࠬ࠭₈")
	#for i in range(len(l1lll1l11l1_ll_)-6,-5,-6):
	#	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧ₉"),str(i))
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1] + l1lll1l11l1_ll_[i+2] + l1lll1l11l1_ll_[i+3] + l1lll1l11l1_ll_[i+4] + l1lll1l11l1_ll_[i+5]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨ₊"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ₋"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ₌"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ₍"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬ₎"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l111lll_ll_ (u"ࠬ࡫࡭ࡢࡦࠪ₏")
	#l1lll1l11ll_ll_ = xbmc.executeJSONRPC(l111lll_ll_ (u"࠭ࡻࠣ࡬ࡶࡳࡳࡸࡰࡤࠤ࠽ࠦ࠷࠴࠰ࠣ࠮ࠥࡱࡪࡺࡨࡰࡦࠥ࠾ࠧࡏ࡮ࡱࡷࡷ࠲ࡘ࡫࡮ࡥࡖࡨࡼࡹࠨࠬࠣࡲࡤࡶࡦࡳࡳࠣ࠼ࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠬₐ")+l1lll1l11l1_ll_+l111lll_ll_ (u"ࠧࠣ࠮ࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾ࠮ࠥ࡭ࡩࠨ࠺࠲ࡿࠪₑ"))
	#simplejson.loads(l1lll1l11ll_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭ₒ"))
	#new = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠩࡸࡲ࡮ࡩ࡯ࡥࡧࡢࡩࡸࡩࡡࡱࡧࠪₓ"))
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫₔ"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬₕ"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"ࠬ࠭ₖ")
	#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧₗ"),l1lll1l11l1_ll_)
	#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.encode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬₘ"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩₙ"),l1lll1l11l1_ll_)
	#new = l111lll_ll_ (u"ࠩࠪₚ")
	#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
	#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
	#l1lll1l11l1_ll_ = new
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫₛ"),l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.replace(l111lll_ll_ (u"ࠫࠥ࠭ₜ"),l111lll_ll_ (u"ࠬ࠭₝"))
		#new = l111lll_ll_ (u"࠭ࠧ₞")
		#for i in range(len(l1lll1l11l1_ll_)-3,-2,-3):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1] + l1lll1l11l1_ll_[i+2]
		#l1lll1l11l1_ll_ = new
		#new = l111lll_ll_ (u"ࠧࠨ₟")
		#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
		#l1lll1l11l1_ll_ = new
		#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩ₠"),l1lll1l11l1_ll_)
		#l1lll1l11l1_ll_ = l1lll1l11l1_ll_.l1lll1l1l11_ll_(l111lll_ll_ (u"ࠩࡸࡸ࡫࠾ࠧ₡"))
		#l1ll1l_ll_(str(ord(l1lll1l11l1_ll_[0]))+l111lll_ll_ (u"ࠪࠤࠬ₢")+str(ord(l1lll1l11l1_ll_[1]))+l111lll_ll_ (u"ࠫࠥ࠭₣")+str(ord(l1lll1l11l1_ll_[2])),str(len(l1lll1l11l1_ll_)))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠬࡓ࡯ࡥࡧࠣ࠴ࠥࡒࡥࡵࡶࡨࡶࡸ࠭₤"),l1lll1l11l1_ll_)
		#new = l111lll_ll_ (u"࠭ࠧ₥")
		#for i in range(len(l1lll1l11l1_ll_)-2,-1,-2):
		#	new += l1lll1l11l1_ll_[i] + l1lll1l11l1_ll_[i+1]
		#l1lll1l11l1_ll_ = new
		#new = l1lll1l11l1_ll_.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬ₦"))
		#new = new.decode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭₧"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ₨"),new )
		#l1lll11llll_ll_ = l111lll_ll_ (u"ࠪࠫ₩")
		#for letter in new:
		#	l1ll1l_ll_(l111lll_ll_ (u"ࠫࡒࡵࡤࡦࠢ࠳ࠫ₪"),unicodedata.decomposition(letter) )
		#	l1lll11llll_ll_ += l111lll_ll_ (u"ࠬࡢࡵࠨ₫") + hex(ord(letter)).replace(l111lll_ll_ (u"࠭ࡸࠨ€"),l111lll_ll_ (u"ࠧࠨ₭"))
		#l1lll11llll_ll_ = l1lll11llll_ll_.decode(l111lll_ll_ (u"ࠨࡷࡱ࡭ࡨࡵࡤࡦࡡࡨࡷࡨࡧࡰࡦࠩ₮"))
		#l1ll1l_ll_(l111lll_ll_ (u"ࠩࡐࡳࡩ࡫ࠠ࠱ࠩ₯"),l1lll11llll_ll_ )
		#new = unicodedata.decomposition(    unichr(   ord(new[1])    )   )
		#new = unicodedata.decomposition(    unichr(   hex(ord(new[1]))    )   )
		#new = l1lll1l1lll_ll_(new)
		#l1lll1l11l1_ll_ = new.encode(l111lll_ll_ (u"ࠪࡹࡹ࡬࠸ࠨ₰"))
		#new = new.decode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ₱")) #.decode(l111lll_ll_ (u"ࠬࡻ࡮ࡪࡥࡲࡨࡪࡥࡥࡴࡥࡤࡴࡪ࠭₲"))
		#l1ll1l_ll_(l111lll_ll_ (u"࠭ࡍࡰࡦࡨࠤ࠵࠭₳"),str(ord(new[2])) ) #unicodedata.decomposition(new.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬ₴")))   )
		#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(new)
		#l1lll1l11l1_ll_ = l1lll1l1lll_ll_(l1lll1l11l1_ll_)
		#method=l111lll_ll_ (u"ࠣࡋࡱࡴࡺࡺ࠮ࡔࡧࡱࡨ࡙࡫ࡸࡵࠤ₵")
		#params=l111lll_ll_ (u"ࠩࡾࠦࡹ࡫ࡸࡵࠤ࠽ࠦࠪࡹࠢ࠭ࠢࠥࡨࡴࡴࡥࠣ࠼ࡩࡥࡱࡹࡥࡾࠩ₶") % l1lll1l11l1_ll_
		#l1lll1l11ll_ll_ = xbmc.executeJSONRPC(l111lll_ll_ (u"ࠪࡿࠧࡰࡳࡰࡰࡵࡴࡨࠨ࠺ࠡࠤ࠵࠲࠵ࠨࠬࠡࠤࡰࡩࡹ࡮࡯ࡥࠤ࠽ࠤࠧࠫࡳࠣ࠮ࠣࠦࡵࡧࡲࡢ࡯ࡶࠦ࠿ࠦࠥࡴ࠮ࠣࠦ࡮ࡪࠢ࠻ࠢ࠴ࢁࠬ₷") % (method, params))