# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠬࡉࡉࡎࡃࡑࡓ࡜࠭ሑ")
l1l1l1l_ll_=l111lll_ll_ (u"࠭࡟ࡄࡏࡑࡣࠬሒ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ࠧใษษ้ฯ๐ࠧሓ")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==300: results = l11l1ll_ll_(url)
	elif mode==301: results = l1l1l11l1_ll_(url)
	elif mode==302: results = l1l11l1_ll_(url)
	elif mode==303: results = l11l11l11_ll_(url)
	elif mode==304: results = l1l11ll_ll_(url)
	elif mode==305: results = l11_ll_(url)
	elif mode==309: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠨࠩሔ")):
	if l1111l_ll_==l111lll_ll_ (u"ࠩࠪሕ"):
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪሖ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫሗ"),l111lll_ll_ (u"ࠬ࠭መ"),309,l111lll_ll_ (u"࠭ࠧሙ"),l111lll_ll_ (u"ࠧࠨሚ"),l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬማ"))
		l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧሜ"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭ም"),l111lll_ll_ (u"ࠫࠬሞ"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩሟ"),l1ll1l1_ll_,l111lll_ll_ (u"࠭ࠧሠ"),l111lll_ll_ (u"ࠧࠨሡ"),l111lll_ll_ (u"ࠨࠩሢ"),l111lll_ll_ (u"ࠩࠪሣ"),l111lll_ll_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ሤ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡁࡻ࡬࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬሥ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫሦ"),block,re.DOTALL)
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"࠭ࠠࠨሧ"))
		if not any(value in title for value in l11lll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧረ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬሩ")+l1l1l1l_ll_+title,link,301)
	return html
def l1l1l11l1_ll_(url):
	seq = 0
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭ሪ"),url,l111lll_ll_ (u"ࠪࠫራ"),l111lll_ll_ (u"ࠫࠬሬ"),l111lll_ll_ (u"ࠬ࠭ር"),l111lll_ll_ (u"࠭ࠧሮ"),l111lll_ll_ (u"ࠧࡄࡋࡐࡅࡓࡕࡗ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭ሯ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࠪ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳࠰࠿࠽࠱ࡶࡩࡨࡺࡩࡰࡰࡁ࠭ࠬሰ"),html,re.DOTALL)
	if l1lll_ll_:
		for block in l1lll_ll_:
			seq += 1
			items = re.findall(l111lll_ll_ (u"ࠩ࠿ࡷࡪࡩࡴࡪࡱࡱࡂ࠳ࡂࡳࡱࡣࡱࡂ࠭࠴ࠪࡀࠫ࠿ࠬ࠳࠰࠿ࠪࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧሱ"),block,re.DOTALL)
			for title,test,link in items:
				if l111lll_ll_ (u"ࠪࡩࡲࡄ࠼ࡢࠩሲ") not in test:
					#l1ll1l_ll_(l111lll_ll_ (u"ࠫࠬሳ"),str(block))
					if block.count(l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩሴ"))>0:
						categories = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬስ"),block,re.DOTALL)
						for link in categories:
							title = link.split(l111lll_ll_ (u"ࠧ࠰ࠩሶ"))[-2]
							l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨሷ"),l1l1l1l_ll_+title,link,301)
						continue
					else: link = url+l111lll_ll_ (u"ࠩࡂࡷࡪࡷࡵࡦࡰࡦࡩࡂ࠭ሸ")+str(seq)
				#l11ll11l1_ll_ = [l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤࠬሹ"),l111lll_ll_ (u"ࠫฬ็ไศ็ࠣࠫሺ"),l111lll_ll_ (u"ࠬฮัศ็ฯࠫሻ"),l111lll_ll_ (u"ู࠭าู๊ࠫሼ"),l111lll_ll_ (u"ࠧไๆํฬฬะࠧሽ"),l111lll_ll_ (u"ࠨษ฽ห๋๏ࠧሾ")]
				#if any(value in title for value in l11ll11l1_ll_):
				if not any(value in title for value in l11lll1_ll_):
					l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩሿ"),l1l1l1l_ll_+title,link,302)
	else: l1l11l1_ll_(url,html)
	return
def l1l11l1_ll_(url,html=l111lll_ll_ (u"ࠪࠫቀ")):
	if html==l111lll_ll_ (u"ࠫࠬቁ"):
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩቂ"),url,l111lll_ll_ (u"࠭ࠧቃ"),l111lll_ll_ (u"ࠧࠨቄ"),l111lll_ll_ (u"ࠨࠩቅ"),l111lll_ll_ (u"ࠩࠪቆ"),l111lll_ll_ (u"ࠪࡇࡎࡓࡁࡏࡑ࡚࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨቇ"))
		html = response.content
	if l111lll_ll_ (u"ࠫࡄࡹࡥࡲࡷࡨࡲࡨ࡫࠽ࠨቈ") in url:
		url,seq = url.split(l111lll_ll_ (u"ࠬࡅࡳࡦࡳࡸࡩࡳࡩࡥ࠾ࠩ቉"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࠨ࠽ࡵࡨࡧࡹ࡯࡯࡯ࡀ࠱࠮ࡄࡂ࠯ࡴࡧࡦࡸ࡮ࡵ࡮࠿ࠫࠪቊ"),html,re.DOTALL)
		block = l1lll_ll_[int(seq)-1]
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࠣࡲࡲࡷࡹࡹࠢࠩ࠰࠭ࡃ࠮ࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫቋ"),html,re.DOTALL)
		block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨ࠾ࡤ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠭࠴ࠪࡀࠫࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧቌ"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for link,data,img in items:
		title = re.findall(l111lll_ll_ (u"ࠩ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡯࡭ࡃ࠴ࠪࡀ࠾࠲ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࡫࡭࠿ࠩቍ"),data,re.DOTALL)
		if title: title = title[0][2].replace(l111lll_ll_ (u"ࠪࡠࡳ࠭቎"),l111lll_ll_ (u"ࠫࠬ቏")).strip(l111lll_ll_ (u"ࠬࠦࠧቐ"))
		if not title or title==l111lll_ll_ (u"࠭ࠧቑ"):
			title = re.findall(l111lll_ll_ (u"ࠧࡵ࡫ࡷࡰࡪࠨ࠾࠯ࠬࡂࡀ࠴࡫࡭࠿ࠪ࠱࠮ࡄ࠯࠼ࠨቒ"),data,re.DOTALL)
			if title: title = title[0].replace(l111lll_ll_ (u"ࠨ࡞ࡱࠫቓ"),l111lll_ll_ (u"ࠩࠪቔ")).strip(l111lll_ll_ (u"ࠪࠤࠬቕ"))
			if not title or title==l111lll_ll_ (u"ࠫࠬቖ"):
				title = re.findall(l111lll_ll_ (u"ࠬࡺࡩࡵ࡮ࡨࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ቗"),data,re.DOTALL)
				title = title[0].replace(l111lll_ll_ (u"࠭࡜࡯ࠩቘ"),l111lll_ll_ (u"ࠧࠨ቙")).strip(l111lll_ll_ (u"ࠨࠢࠪቚ"))
		title = unescapeHTML(title)
		#if title==l111lll_ll_ (u"ࠩࠪቛ"): continue
		if title not in l1ll11ll_ll_:
			l1ll11ll_ll_.append(title)
			l11l1l11_ll_ = link+data+img
			if l111lll_ll_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬቜ") in l11l1l11_ll_ or l111lll_ll_ (u"ู๊ࠫไิๆࠪቝ") in l11l1l11_ll_ or l111lll_ll_ (u"ࠬࠨࡥࡱ࡫ࡶࡳࡩ࡫ࠢࠨ቞") in l11l1l11_ll_:
				if l111lll_ll_ (u"࠭ศาษ่ะࠬ቟") in data: title = l111lll_ll_ (u"ࠧษำ้ห๊าࠠࠨበ")+title
				elif l111lll_ll_ (u"ࠨ็ึุ่๊ࠧቡ") in data or l111lll_ll_ (u"่ࠩ์ุ๋ࠧቢ") in data: title = l111lll_ll_ (u"ุ้๊ࠪำๅࠢࠪባ")+title
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫቤ"),l1l1l1l_ll_+title,link,303,img)
			else: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫብ"),l1l1l1l_ll_+title,link,305,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠦ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩቦ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧ࠽࡮࡬ࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ቧ"),block,re.DOTALL)
		for link,title in items:
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨቨ"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨቩ")+title,link,302)
	return
def l11l11l11_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧቪ"),url,l111lll_ll_ (u"ࠫࠬቫ"),l111lll_ll_ (u"ࠬ࠭ቬ"),l111lll_ll_ (u"࠭ࠧቭ"),l111lll_ll_ (u"ࠧࠨቮ"),l111lll_ll_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡖࡉࡆ࡙ࡏࡏࡕ࠰࠵ࡸࡺࠧቯ"))
	html = response.content
	name = re.findall(l111lll_ll_ (u"ࠩ࠿ࡸ࡮ࡺ࡬ࡦࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷ࡭ࡹࡲࡥ࠿ࠩተ"),html,re.DOTALL)
	name = name[0].replace(l111lll_ll_ (u"ࠪࢀู๊ࠥๆษ๊ࠣฬ๎ࠧቱ"),l111lll_ll_ (u"ࠫࠬቲ")).replace(l111lll_ll_ (u"ࠬࡉࡩ࡮ࡣࠣࡒࡴࡽࠧታ"),l111lll_ll_ (u"࠭ࠧቴ")).strip(l111lll_ll_ (u"ࠧࠡࠩት")).replace(l111lll_ll_ (u"ࠨࠢࠣࠫቶ"),l111lll_ll_ (u"ࠩࠣࠫቷ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࠦࡸ࡫ࡡࡴࡱࡱࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧቸ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪቹ"),block,re.DOTALL)
		for link,title in items:
			title = name+l111lll_ll_ (u"ࠬࠦࠧቺ")+title.replace(l111lll_ll_ (u"࠭࡜࡯ࠩቻ"),l111lll_ll_ (u"ࠧࠨቼ")).strip(l111lll_ll_ (u"ࠨࠢࠪች"))
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩቾ"),l1l1l1l_ll_+title,link,304)
	return
def l1l11ll_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧቿ"),url,l111lll_ll_ (u"ࠫࠬኀ"),l111lll_ll_ (u"ࠬ࠭ኁ"),l111lll_ll_ (u"࠭ࠧኂ"),l111lll_ll_ (u"ࠧࠨኃ"),l111lll_ll_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠶ࡹࡴࠨኄ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࠥࡨࡪࡺࡡࡪ࡮ࡶࠦ࠭࠴ࠪࡀࠫࠥࡶࡪࡲࡡࡵࡧࡧࠦࠬኅ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩኆ"),block,re.DOTALL)
	for link,img,title in items:
		title = title.replace(l111lll_ll_ (u"ࠫࡡࡴࠧኇ"),l111lll_ll_ (u"ࠬ࠭ኈ")).strip(l111lll_ll_ (u"࠭ࠠࠨ኉"))
		l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ኊ"),l1l1l1l_ll_+title,link,305,img)
	return
def l11_ll_(url):
	l111lll_ll_ (u"ࠣࠤࠥࠎࠎࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡸࡶࡱ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨࠫࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࡴࡨࡨ࡮ࡸࡥࡤࡶࡢࡰ࡮ࡴ࡫ࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡵ࡫࡭ࡳ࡫ࠢࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࡷ࡫ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡲࡦࡦ࡬ࡶࡪࡩࡴࡠ࡮࡬ࡲࡰࡡ࠰࡞ࠌࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡗࡍࡕࡒࡕࡡࡆࡅࡈࡎࡅ࠭ࠩࡊࡉ࡙࠭ࠬࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠬࠨࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࡃࡊࡏࡄࡒࡔ࡝࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩࠬࠎࠎࡸࡥࡥ࡫ࡵࡩࡨࡺ࡟ࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠍࠍࡨࡵ࡯࡬࡫ࡨࡷࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡴࡱࡩࡦࡵ࠱࡫ࡪࡺ࡟ࡥ࡫ࡦࡸ࠭࠯ࠊࠊࡒࡋࡔࡘࡋࡓࡔࡋࡇࠤࡂࠦࡣࡰࡱ࡮࡭ࡪࡹ࡛ࠨࡒࡋࡔࡘࡋࡓࡔࡋࡇࠫࡢࠐࠉࡷࡧࡵ࡭࡫ࡿ࡟࡭࡫ࡱ࡯ࠥࡃࠠࡳࡧ࠱ࡪ࡮ࡴࡤࡢ࡮࡯ࠬࠧ࡮ࡲࡦࡨࠣࡁࠥ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨࠬࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭ࠣࡁࠥࡼࡥࡳ࡫ࡩࡽࡤࡲࡩ࡯࡭࡞࠴ࡢࠐࠉࡩࡧࡤࡨࡪࡸࡳࠡ࠿ࠣࡿࠬࡘࡥࡧࡧࡵࡩࡷ࠭࠺ࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱࠬࠨࡅࡲࡳࡰ࡯ࡥࠨ࠼ࠪࡔࡍࡖࡓࡆࡕࡖࡍࡉࡃࠧࠬࡒࡋࡔࡘࡋࡓࡔࡋࡇࢁࠏࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡍࡅࡕࠩ࠯ࡺࡪࡸࡩࡧࡻࡢࡰ࡮ࡴ࡫࠭ࠩࠪ࠰࡭࡫ࡡࡥࡧࡵࡷ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬࡉࡉࡎࡃࡑࡓ࡜࠳ࡐࡍࡃ࡜࠱࠸ࡸࡤࠨࠫࠍࠍࡻ࡫ࡲࡪࡨࡼࡣ࡭ࡺ࡭࡭ࠢࡀࠤࡷ࡫ࡳࡱࡱࡱࡷࡪ࠴ࡣࡰࡰࡷࡩࡳࡺࠊࠊࠥࡤࡨࡤࡲࡩ࡯࡭ࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪ࡭ࡩࡃࠢࡢࡦࠥࠤࡹࡧࡲࡨࡧࡷࡁࠧࡥࡢ࡭ࡣࡱ࡯ࠧࠦࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ࠲ࡶࡦࡴ࡬ࡪࡾࡥࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠦࡥࡩࡥ࡬ࡪࡰ࡮ࠤࡂࠦࡡࡥࡡ࡯࡭ࡳࡱ࡛࠱࡟ࠍࠍࠨࡸࡥࡴࡲࡲࡲࡸ࡫ࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡖࡊࡗࡕࡆࡕࡗࡗࡤࡉࡁࡄࡊࡈࡈ࡙࠭ࡈࡐࡔࡗࡣࡈࡇࡃࡉࡇ࠯ࠫࡌࡋࡔࠨ࠮ࡤࡨࡤࡲࡩ࡯࡭࠯ࠫࠬ࠲ࠧࠨ࠮ࠪࠫ࠱࠭ࠧ࠭ࠩࡆࡍࡒࡇࡎࡐ࡙࠰ࡔࡑࡇ࡙࠮࠶ࡷ࡬ࠬ࠯ࠊࠊࠥࡤࡨࡤ࡮ࡴ࡮࡮ࠣࡁࠥࡸࡥࡴࡲࡲࡲࡸ࡫࠮ࡤࡱࡱࡸࡪࡴࡴࠋࠋࡸࡶࡱ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࠣࡦࡲࡻࡳࡲ࡯ࡢࡦࡥࡸࡳࠨࠠࡴࡶࡼࡰࡪࡃࠢࡥ࡫ࡶࡴࡱࡧࡹ࠻ࠢࡱࡳࡳ࡫࠻ࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮ࡹࡩࡷ࡯ࡦࡺࡡ࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࡻࡲ࡭࠴ࠣࡁࠥࡻࡲ࡭࠴࡞࠴ࡢ࠱ࠧ࠰ࠩࠍࠍ࡭࡫ࡡࡥࡧࡵࡷࠥࡃࠠࡼࠩࡕࡩ࡫࡫ࡲࡦࡴࠪ࠾ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡷࡦࡤ࠱ࡧ࡮ࡳࡡࡷ࡫ࡧࡷ࠳ࡲࡩࡷࡧ࠲ࠫࢂࠐࠉࠣࠤࠥኋ")
	l1ll111_ll_ = url+l111lll_ll_ (u"ࠩࡺࡥࡹࡩࡨࡪࡰࡪ࠳ࠬኌ")
	server = l1ll1l111_ll_(l1ll111_ll_)
	headers = {l111lll_ll_ (u"ࠪࡖࡪ࡬ࡥࡳࡧࡵࠫኍ"):server}
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ኎"),l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭኏"),headers,l111lll_ll_ (u"࠭ࠧነ"),l111lll_ll_ (u"ࠧࠨኑ"),l111lll_ll_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘ࠯ࡓࡐࡆ࡟࠭࠶ࡶ࡫ࠫኒ"))
	l1l111l1_ll_ = response.content
	l1l111l_ll_ = []
	# download links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࠥࡨࡴࡽ࡮࡭ࡱࡤࡨࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡹࡥࡤࡶ࡬ࡳࡳࡄࠧና"),l1l111l1_ll_,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࠵ࡩ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡣࡁࠫኔ"),block,re.DOTALL)
	for link,title in items:
		title = title.replace(l111lll_ll_ (u"ࠫࡡࡴࠧን"),l111lll_ll_ (u"ࠬ࠭ኖ")).strip(l111lll_ll_ (u"࠭ࠠࠨኗ"))
		quality = re.findall(l111lll_ll_ (u"ࠧ࡝ࡦ࡟ࡨࡡࡪࠫࠨኘ"),title,re.DOTALL)
		if quality:
			quality = l111lll_ll_ (u"ࠨࡡࡢࡣࡤ࠭ኙ")+quality[0]
			title = l111lll_ll_ (u"ࠩࡦ࡭ࡲࡧ࡮ࡰࡹࠪኚ")
		else: quality = l111lll_ll_ (u"ࠪࠫኛ")
		l11ll1ll_ll_ = link+l111lll_ll_ (u"ࠫࡄࡴࡡ࡮ࡧࡧࡁࠬኜ")+title+l111lll_ll_ (u"ࠬࡥ࡟ࡥࡱࡺࡲࡱࡵࡡࡥࠩኝ")+quality
		l1l111l_ll_.append(l11ll1ll_ll_)
	# watch links
	link = re.findall(l111lll_ll_ (u"࠭ࡡ࡫ࡣࡻࡠ࠭ࢁࡵࡳ࡮࠽ࠤࠧ࠮࠮ࠫࡁࠬࠦࠬኞ"),l1l111l1_ll_,re.DOTALL)[0]
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࠣࡹࡤࡸࡨ࡮ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬኟ"),l1l111l1_ll_,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨࡦࡤࡸࡦ࠳ࡩ࡯ࡦࡨࡼࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡦࡤࡸࡦ࠳ࡩࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵࡬ࡪࡀࠪአ"),block,re.DOTALL)
	for index,id,title in items:
		title = title.replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬኡ"),l111lll_ll_ (u"ࠪࠫኢ")).strip(l111lll_ll_ (u"ࠫࠥ࠭ኣ"))
		title = title.replace(l111lll_ll_ (u"ࠬࡉࡩ࡮ࡣࠣࡒࡴࡽࠧኤ"),l111lll_ll_ (u"࠭ࡃࡪ࡯ࡤࡒࡴࡽࠧእ"))
		l11ll1ll_ll_ = link+l111lll_ll_ (u"ࠧࡀࡣࡦࡸ࡮ࡵ࡮࠾ࡵࡺ࡭ࡹࡩࡨࠧ࡫ࡱࡨࡪࡾ࠽ࠨኦ")+index+l111lll_ll_ (u"ࠨࠨ࡬ࡨࡂ࠭ኧ")+id+l111lll_ll_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪከ")+title+l111lll_ll_ (u"ࠪࡣࡤࡽࡡࡵࡥ࡫ࠫኩ")
		l1l111l_ll_.append(l11ll1ll_ll_)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩኪ"),l1l111l_ll_)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨካ"),l111lll_ll_ (u"࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭ኬ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ክ"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠨࠩኮ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠩࠪኯ"): return
	search = search.replace(l111lll_ll_ (u"ࠪࠤࠬኰ"),l111lll_ll_ (u"ࠫ࠰࠭኱"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠬ࠵࠿ࡴ࠿ࠪኲ")+search
	l1l11l1_ll_(url)
	return