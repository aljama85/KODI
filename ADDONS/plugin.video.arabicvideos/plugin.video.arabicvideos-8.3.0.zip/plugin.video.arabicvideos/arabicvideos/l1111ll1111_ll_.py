# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
#import l1l1l1_ll_
#l1l1l1_ll_.l111l1l_ll_()
l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⧍"),l111lll_ll_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽ࠨ⧎"))
l1ll_ll_ = l111lll_ll_ (u"ࠧࡎࡃࡌࡒࠬ⧏")
if not os.path.exists(l1lll11ll1_ll_): os.makedirs(l1lll11ll1_ll_)
if not os.path.exists(l1l1lll11l1_ll_):
	l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ⧐"),l111lll_ll_ (u"ࠩࠣࠤ࠳ࠦࠠࡏࡧࡺࠤࡆࡸࡡࡣ࡫ࡦࠤ࡛࡯ࡤࡦࡱࡶࠤࡻ࡫ࡲࡴ࡫ࡲࡲࠥ࡯࡮ࡴࡶࡤࡰࡱ࡫ࡤࠡࠢ࠱ࠤࠥࡶࡡࡵࡪ࠽ࠤࡠࠦࠧ⧑")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠪࠤࡢ࠭⧒"))
	l1ll1l_ll_(l111lll_ll_ (u"ࠫอืๆศ็ฯࠤ฾๋วะࠢ็่ๆ๐ฯ๋๊๊หฯࠦวๅ฻ิฬ๏ฯࠧ⧓"),l111lll_ll_ (u"ࠬะๅࠡฬะำ๏ัࠠษำ้ห๊าฺࠠ็สำ๊ࠥไโ์า๎ํํวหࠢส่฾ืศ๋หࠣษ้๏ࠠศๆศูิอัࠡษ็ะิ๐ฯࠡ࠰ࠣวํࠦสๆ่ࠢืาࠦวๅๅสุࠥอไๆ๊ฯ์ิࠦแ๋ࠢส่อืๆศ็ฯࠤ࠳ࠦำ๋ไ๋้ࠥอไษำ้ห๊าࠠศๆล๊ࠥฮศฺุࠣห้็อ้ืสฮ๊ࠥึๆษ้ࠤ฾๋ไࠡษ็ฬึ์วๆฮࠣฬฺ๎ัสุࠢั๏ำษ๊่ࠡฮ่อๅๅหࠪ⧔"))
	import l1l111ll111_ll_
	l1l111ll111_ll_.l1111ll1lll_ll_()
	l11111llll_ll_()
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	conn.close()
	l1l111ll111_ll_.l1111lll111_ll_()
	#l1ll11l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩ⧕"),l111lll_ll_ (u"ࠧโฯุࠤฬ฼วโษอࠤࡦࡪࡡࡱࡶ࡬ࡺࡪࠦࠫࠡࡴࡷࡱࡵ࠭⧖"))
	#l1ll11l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⧗"),l111lll_ll_ (u"ࠩไัฺࠦๅฯิ้ࠤ฾๋วะࠩ⧘"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫ⧙"),str(l1111ll1l11_ll_))
	l11llllllll_ll_(False)
	l1ll11llll1_ll_(False)
	l1l111ll111_ll_.l1l111lll1l_ll_(True)
	l1l111ll111_ll_.l11l1l1l1l1_ll_()
	#l1111ll1l11_ll_ = l1111lllll_ll_.l11111111l_ll_(False)
	#if l1111ll1l11_ll_:
	l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⧚"),l111lll_ll_ (u"ࠬหะศࠢๆ๊ฯࠦสิฬัำ๊ࠦฮะ็ฬࠤࡎࡖࡔࡗࠢส่๊๎ฬ้ัฬࠤๆ๐่ࠠาสࠤฬ๊ศา่ส้ัࠦแิ๊ไࠤ๏่่ๆࠢส่อืๆศ็ฯࠤฬ๊ย็ࠢฦ์ฯ๎ๅศฬํ็๏อࠠษฮ็ฬ๋ࠥไโษอࠤࡎࡖࡔࡗࠢฯำ๏ีษࠨ⧛"))
	import l1111lllll_ll_
	l1111lllll_ll_.l1lllllll11_ll_(False)
type,l11ll1l1ll1_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,l1l1111111_ll_ = l11lllllll_ll_()
l11l1ll1ll1_ll_ = int(mode)
l1l11lll11l_ll_ = int(l11l1ll1ll1_ll_%10)
l1l111lll11_ll_ = int(l11l1ll1ll1_ll_/10)
#message += l111lll_ll_ (u"࠭࡜࡯ࠩ⧜")+l111lll_ll_ (u"ࠧࡍࡣࡥࡩࡱࡀ࡛ࠨ⧝")+l1l1l_ll_+l111lll_ll_ (u"ࠨ࡟ࠣࠤࠥࡖࡡࡵࡪ࠽࡟ࠬ⧞")+l11l1l1_ll_+l111lll_ll_ (u"ࠩࡠࠫ⧟")
if l11l1ll1ll1_ll_==260: message = l111lll_ll_ (u"ࠪࠤࠥ࡜ࡥࡳࡵ࡬ࡳࡳࡀࠠ࡜ࠢࠪ⧠")+l11l1lll11l_ll_+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࡍࡲࡨ࡮ࡀࠠ࡜ࠢࠪ⧡")+l11ll11lll1_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⧢")
else:
	l1l1lll1111_ll_ = l1l1l_ll_.replace(l111lll_ll_ (u"࠭ࠠࠡࠢࠪ⧣"),l111lll_ll_ (u"ࠧࠡࠢࠪ⧤")).replace(l111lll_ll_ (u"ࠨࠢࠣࠤࠬ⧥"),l111lll_ll_ (u"ࠩࠣࠤࠬ⧦")).replace(l111lll_ll_ (u"ࠪࠤࠥࠦࠧ⧧"),l111lll_ll_ (u"ࠫࠥࠦࠧ⧨"))
	l1ll11l1lll_ll_ = l11l1l1_ll_.replace(l111lll_ll_ (u"ࠬࠦࠠࠡࠩ⧩"),l111lll_ll_ (u"࠭ࠠࠡࠩ⧪")).replace(l111lll_ll_ (u"ࠧࠡࠢࠣࠫ⧫"),l111lll_ll_ (u"ࠨࠢࠣࠫ⧬")).replace(l111lll_ll_ (u"ࠩࠣࠤࠥ࠭⧭"),l111lll_ll_ (u"ࠪࠤࠥ࠭⧮"))
	message = l111lll_ll_ (u"ࠫࠥࠦࡌࡢࡤࡨࡰ࠿࡛ࠦࠡࠩ⧯")+l1l1lll1111_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࡐࡳࡩ࡫࠺ࠡ࡝ࠣࠫ⧰")+mode+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࡔࡦࡺࡨ࠻ࠢ࡞ࠤࠬ⧱")+l1ll11l1lll_ll_+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⧲")
if l1l1111111_ll_ not in [l111lll_ll_ (u"ࠨࠩ⧳"),l111lll_ll_ (u"ࠩ࠴ࠫ⧴"),l111lll_ll_ (u"ࠪ࠶ࠬ⧵"),l111lll_ll_ (u"ࠫ࠸࠭⧶"),l111lll_ll_ (u"ࠬ࠺ࠧ⧷"),l111lll_ll_ (u"࠭࠵ࠨ⧸")]:
	message = message+l111lll_ll_ (u"ࠧࠡࠢࠣ࠲ࠥࠦࡆࡢࡸࡲࡹࡷ࡯ࡴࡦ࠼ࠣ࡟ࠥ࠭⧹")+l1l1111111_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫ⧺")
l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ⧻"),l111111l_ll_(l1ll_ll_)+message)
#l1ll1l_ll_(l111lll_ll_ (u"ࠪ࡟ࠬ⧼")+l11l1l1_ll_+l111lll_ll_ (u"ࠫࡢ࠭⧽"),l111lll_ll_ (u"ࠬࡡࠧ⧾")+mode+l111lll_ll_ (u"࠭࡝ࠨ⧿"))
#l1ll1l_ll_(l111lll_ll_ (u"ࠧ࡜ࠩ⨀")+l1l1l_ll_+l111lll_ll_ (u"ࠨ࡟ࠪ⨁"),l111lll_ll_ (u"ࠩ࡞ࠫ⨂")+l11l1l1_ll_+l111lll_ll_ (u"ࠪࡡࠬ⨃"))
l1111ll11ll_ll_ = l1l111lll11_ll_==16 and l11l1ll1ll1_ll_ not in [160,165]
l1111ll11l1_ll_ = l1l111lll11_ll_==16 and l111lll_ll_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ⨄") in text
l1ll111l1l1_ll_ = l11l1ll1ll1_ll_ in [19,29,39,49,59,69,79,99,119,139,149,209,229,239,249,259,309,319,329]
l1l11l1l111_ll_ = l1l111lll11_ll_ in [1,2,3,4,5,6,7,9,11,13,14,20,22,24,25,30,31,32]
l1l111111l1_ll_ = l1l111lll11_ll_==23 and text!=l111lll_ll_ (u"ࠬ࠭⨅")
l1111l1lll1_ll_ = False# l1l111lll11_ll_==14 and l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⨆") in text
#l1ll1l_ll_(l11ll11ll11_ll_,str(l1l1l11l1ll_ll_))
if l1l1111111_ll_ not in [l111lll_ll_ (u"ࠧࠨ⨇"),l111lll_ll_ (u"ࠨ࠳ࠪ⨈"),l111lll_ll_ (u"ࠩ࠵ࠫ⨉"),l111lll_ll_ (u"ࠪ࠷ࠬ⨊"),l111lll_ll_ (u"ࠫ࠹࠭⨋"),l111lll_ll_ (u"ࠬ࠻ࠧ⨌")]:
	import l11llllll1_ll_
	l11llllll1_ll_.l1l111l11l_ll_(l1l1111111_ll_)
	#l111lll_ll_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠥ⨍") l1l1lll111l_ll_ l1l1llll11l_ll_ l1l1111l11l_ll_ is no l1l1l11l1ll_ll_ number to l1l1111llll_ll_ for l1lll111l1l_ll_ directory
	#l111lll_ll_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠥ⨎") l1l1lll111l_ll_ to open a l11l1llll1_ll_ list l1ll11l1l1l_ll_ l1ll1111l1l_ll_ l11ll11ll11_ll_
	#xbmc.executebuiltin(l111lll_ll_ (u"ࠣࡅࡲࡲࡹࡧࡩ࡯ࡧࡵ࠲࡚ࡶࡤࡢࡶࡨࠬࠧ⨏")+sys.argv[0]+l11ll11ll11_ll_.split(l111lll_ll_ (u"ࠩࠩࡪࡦࡼ࡯ࡶࡴ࡬ࡸࡪࡃࠧ⨐"))[0]+l111lll_ll_ (u"ࠥ࠭ࠧ⨑"))
	#l1ll1l_ll_(text,mode)
	xbmc.executebuiltin(l111lll_ll_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡓࡧࡩࡶࡪࡹࡨࠣ⨒"))
	l1l111l1l11_ll_(l111lll_ll_ (u"ࠬࡓࡁࡊࡐ࠰ࡑࡆࡏࡎ࠮࠳ࡶࡸࠬ⨓"),False)
if l11l1ll1ll1_ll_==266:
	import l11l1l1ll1l_ll_
	l11l1l1ll1l_ll_.l11l111l11l_ll_(text)
	xbmc.executebuiltin(l111lll_ll_ (u"ࠨࡃࡰࡰࡷࡥ࡮ࡴࡥࡳ࠰ࡕࡩ࡫ࡸࡥࡴࡪࠥ⨔"))
	l1l111l1l11_ll_(l111lll_ll_ (u"ࠧࡎࡃࡌࡒ࠲ࡓࡁࡊࡐ࠰࠶ࡳࡪࠧ⨕"),False)
l1lll11l111_ll_ = xbmc.getInfoLabel(l111lll_ll_ (u"ࠨࡎ࡬ࡷࡹࡏࡴࡦ࡯࠱ࡊࡴࡲࡤࡦࡴࡓࡥࡹ࡮ࠧ⨖"))
l1lll11l111_ll_ = l1111_ll_(l1lll11l111_ll_)
if l11l1ll1ll1_ll_==262:
	if l111lll_ll_ (u"ࠩࡷࡩࡽࡺ࠽ࠨ⨗") in l1lll11l111_ll_:
		search = l1lll11l111_ll_.split(l111lll_ll_ (u"ࠪࡸࡪࡾࡴ࠾ࠩ⨘"))[1]
		if l111lll_ll_ (u"ࠫࠫ࠭⨙") in search: search = search.split(l111lll_ll_ (u"ࠬࠬࠧ⨚"))[0]
		search = search.replace(l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ⨛"),l111lll_ll_ (u"ࠧࠨ⨜"))
	else: search = l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ⨝")
	#l1ll1l_ll_(search,l111lll_ll_ (u"ࠩࠪ⨞"))
	results = l1lll1111ll_ll_(type,l11ll1l1ll1_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,search,l1l1111111_ll_)
elif l1ll111l1l1_ll_ or l1111ll11ll_ll_:
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⨟"),path)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⨠"),l11ll11ll11_ll_)
	if l111lll_ll_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ⨡") in l1lll11l111_ll_:
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭⨢"),l111lll_ll_ (u"ࠧࠡࠢ࠱ࠤࠥ࡝ࡲࡪࡶ࡬ࡲ࡬ࠦ࡬ࡢࡵࡷࠤࡲ࡫࡮ࡶࠢࠣ࠲ࠥࠦࡰࡢࡶ࡫࠾ࠥࡡࠠࠨ⨣")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠨࠢࡠࠫ⨤"))
		results = l1lll1111ll_ll_(type,l11ll1l1ll1_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,l1l1111111_ll_)
		l1l1111l1l_ll_ = str(l11l11lll_ll_)
		with open(l1111l1llll_ll_,l111lll_ll_ (u"ࠩࡺࠫ⨥")) as f: f.write(l1l1111l1l_ll_)
	else:
		l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ⨦"),l111lll_ll_ (u"ࠫࠥࠦ࠮ࠡࠢࡕࡩࡦࡪࡩ࡯ࡩࠣࡰࡦࡹࡴࠡ࡯ࡨࡲࡺࠦࠠ࠯ࠢࠣࡴࡦࡺࡨ࠻ࠢ࡞ࠤࠬ⨧")+l11ll11ll11_ll_+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⨨"))
		with open(l1111l1llll_ll_,l111lll_ll_ (u"࠭ࡲࠨ⨩")) as f: l11lll1l1l_ll_ = f.read()
		l11l11lll_ll_[:] = eval(l11lll1l1l_ll_)
else: results = l1lll1111ll_ll_(type,l11ll1l1ll1_ll_,l1lll11111l_ll_,mode,l11lllll1l1_ll_,l1l11l11111_ll_,text,l1l1111111_ll_)
#l1ll1l_ll_(l11ll11ll11_ll_,str(l11l1ll1ll1_ll_))
if l1l1l11l1ll_ll_>-1:
	if type==l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⨪") and l1l1l_ll_!=l111lll_ll_ (u"ࠨ࠰࠱ࠫ⨫") and (l1l11l1l111_ll_ or l1l111111l1_ll_): l1l1l11llll_ll_()
	l1111ll1ll1_ll_ = l11l1ll1ll1_ll_ in [114,204,244,254] and text!=l111lll_ll_ (u"ࠩࠪ⨬")
	l1111ll111l_ll_ = l11l1ll1ll1_ll_ in [266]
	# l11lll1111l_ll_ defaults
	succeeded,updateListing,cacheToDisc = True,False,True
	if l11l11lll_ll_:
		l11ll1ll1l1_ll_ = []
		for l11lll1l11_ll_ in l11l11lll_ll_:
			l1l1111lll1_ll_ = l1ll1ll1lll_ll_(l11lll1l11_ll_)
			l11ll1ll1l1_ll_.append(l1l1111lll1_ll_)
		l11lllll11l_ll_ = xbmcplugin.addDirectoryItems(l1l1l11l1ll_ll_,l11ll1ll1l1_ll_)
	if type==l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⨭") or l1ll111l1l1_ll_ or l1111ll11l1_ll_: succeeded = True
	else: succeeded = False
	# updateListing = True => l1ll1l1111l_ll_ this list is l11l1l11l11_ll_ and will be l1ll1l11ll1_ll_ by the next list
	# updateListing = False => l1ll1l1111l_ll_ this list is l1ll1l1ll1l_ll_ and the new list will generate new l11l1llll1_ll_
	if l1111ll1ll1_ll_ or l1111ll111l_ll_ or l1111ll11l1_ll_ or l1111l1lll1_ll_:
		updateListing = True
	else: updateListing = False
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⨮"),str(succeeded)+l111lll_ll_ (u"ࠬࠦࠠࠨ⨯")+str(updateListing)+l111lll_ll_ (u"࠭ࠠࠡࠩ⨰")+str(cacheToDisc))
	xbmcplugin.endOfDirectory(l1l1l11l1ll_ll_,succeeded,updateListing,cacheToDisc)
	#l1111ll1l1l_ll_ = l1l111lll11_ll_ in [12,24,33,43,53,63,74,82,92,105,112,123,134,143,182,202,212,223,243,252]
	#l1ll1l_ll_(str(succeeded),str(updateListing),str(cacheToDisc))
	#l1ll1l_ll_(l11ll11ll11_ll_,str(l1l1l11l1ll_ll_))
#l1ll1l_ll_(str(l1l1l11l1ll_ll_),l11ll11ll11_ll_)