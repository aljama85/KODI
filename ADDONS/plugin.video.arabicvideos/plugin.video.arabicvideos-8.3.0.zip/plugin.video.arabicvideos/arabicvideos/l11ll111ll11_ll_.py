# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll11l_ll_(l111lll_ll_ (u"࠭ࡔࡆࡕࡗࠫ䆴"),l111lll_ll_ (u"ࠧࡕࡇࡖࡘࠬ䆵"))
#url = l111lll_ll_ (u"ࠨࡅ࠽ࡠࡡࡖ࡯ࡳࡶࡤࡦࡱ࡫ࠠࡑࡴࡲ࡫ࡷࡧ࡭ࡴ࡞࡟ࡏࡔࡊࡉࡠࡸ࠴࠼ࡤ࠼࠴ࡣ࡫ࡷࡠࡡࡑ࡯ࡥ࡫࡟ࡠࡵࡵࡲࡵࡣࡥࡰࡪࡥࡤࡢࡶࡤࡠࡡࡩࡡࡤࡪࡨࡠࡡࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵ࡟ࡠ࡫࡯࡬ࡦࡡ࠳࠼࠾࠼࡟ࡔࡊ࡙ࡣื๐วาหࡢห้ืำ้ๆࡢห้ษูู็ࡢฺࠬ࠯࡟ࠩลหหีื࡟ศๆะ่ํอฬ๋ࠫ࠱ࡱࡵ࠹ࠧ䆶")
#url = l111lll_ll_ (u"ࠩࡦ࠾ࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ䆷")
#url = l111lll_ll_ (u"ࠪࡇ࠿ࡢ࡜ࡕࡇࡐࡔࡡࡢࡴࡦ࡯ࡳࡠࡡࡧࡳࡥࡨ࠱ࡱࡵ࠹ࠧ䆸")
#url = l111lll_ll_ (u"ࠫࡈࡀ࡜࡝ࡖࡈࡑࡕࡢ࡜ࡵࡧࡰࡴࡡࡢࡡࡢࠢࡥࡦࡡࡢࡡࡴࡦࡩ࠲ࡲࡶ࠳ࠨ䆹")
url = l111lll_ll_ (u"ࠬࡉ࠺࡝࡞ࡗࡉࡒࡖ࡜࡝ࡶࡨࡱࡵࡢ࡜ࡢࡣࠣࡦࡧࡢ࡜โฯุ࠲ࡲࡶ࠳ࠨ䆺")
url = l111lll_ll_ (u"࠭ࡃ࠻࡞࡟ࡘࡊࡓࡐ࡝࡞ࡷࡩࡲࡶ࡜࡝ࡣࡤࠤࡧࡨ࡜࡝ࡨ࡬ࡰࡪࡥ࠴࠹࠵࠷ࡣࡘࡎࡖࡠิํหึฯ࡟ศๆิืํ๊࡟ศๆฦ฽฽๋࡟ࠩืࠬࡣ࠭ษศศาิࡣฬ๊อๅ๊สะ๏࠯࠮࡮ࡲ࠶ࠫ䆻")
#url = url.decode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬ䆼"))
xbmc.Player().play(url)