# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
l111lll_ll_ (u"ࠥࠦࠧࠐࠊࠡࠢࠣࠤࡈࡵࡰࡺࡴ࡬࡫࡭ࡺࠠࠩࡅࠬࠤ࠷࠶࠱࠵࠯࠵࠴࠶࠼ࠠࡣࡴࡲࡱ࡮ࡾࠠࠩࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠪࠌࠣࠤࠥࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࠫࡇ࠮ࠦ࠲࠱࠳࠹࠱࠷࠶࠱࠹ࠢࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡻࡲࡹࡹࡻࡢࡦࠌࠍࠤࠥࠦࠠࡔࡒࡇ࡜࠲ࡒࡩࡤࡧࡱࡷࡪ࠳ࡉࡥࡧࡱࡸ࡮࡬ࡩࡦࡴ࠽ࠤࡌࡖࡌ࠮࠴࠱࠴࠲ࡵ࡮࡭ࡻࠍࠤࠥࠦࠠࡔࡧࡨࠤࡑࡏࡃࡆࡐࡖࡉࡘ࠵ࡇࡑࡎ࠰࠶࠳࠶࠭ࡰࡰ࡯ࡽࠥ࡬࡯ࡳࠢࡰࡳࡷ࡫ࠠࡪࡰࡩࡳࡷࡳࡡࡵ࡫ࡲࡲ࠳ࠐࠢࠣࠤ䢜")
import re
class Cipher(object):
    def _1ll1l1l1111_ll_(self, l11l11llllll_ll_):
        l11llllll11_ll_ = self._11l1l11l1l1_ll_(l11l11llllll_ll_)
        if not l11llllll11_ll_:
            raise Exception(l111lll_ll_ (u"ࠫࡘ࡯ࡧ࡯ࡣࡷࡹࡷ࡫ࠠࡧࡷࡱࡧࡹ࡯࡯࡯ࠢࡱࡳࡹࠦࡦࡰࡷࡱࡨࠬ䢝"))
        _11l1l111111_ll_ = self._11l1l1111ll_ll_(l11llllll11_ll_, l11l11llllll_ll_)
        l11l11llll1l_ll_ = _11l1l111111_ll_[0].replace(l111lll_ll_ (u"ࠬࡢ࡮ࠨ䢞"), l111lll_ll_ (u"࠭ࠧ䢟")).split(l111lll_ll_ (u"ࠧ࠭ࠩ䢠"))
        l11l11lll1l1_ll_ = _11l1l111111_ll_[1].replace(l111lll_ll_ (u"ࠨ࡞ࡱࠫ䢡"), l111lll_ll_ (u"ࠩࠪ䢢")).split(l111lll_ll_ (u"ࠪ࠿ࠬ䢣"))
        l1ll111111ll_ll_ = {l111lll_ll_ (u"ࠫࡦࡩࡴࡪࡱࡱࡷࠬ䢤"): []}
        for line in l11l11lll1l1_ll_:
            l11l1l11111l_ll_ = re.match(l111lll_ll_ (u"ࡷ࠭ࠥࡴ࡞ࡶࡃࡂࡢࡳࡀࠧࡶ࠲ࡸࡶ࡬ࡪࡶ࡟ࠬࠧࠨ࡜ࠪࠩ䢥") % (l11l11llll1l_ll_[0], l11l11llll1l_ll_[0]), line)
            if l11l1l11111l_ll_:
                l1ll111111ll_ll_[l111lll_ll_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡹࠧ䢦")].append({l111lll_ll_ (u"ࠧࡧࡷࡱࡧࠬ䢧"): l111lll_ll_ (u"ࠨ࡮࡬ࡷࡹ࠭䢨"),
                                               l111lll_ll_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ䢩"): [l111lll_ll_ (u"ࠪࠩࡘࡏࡇࠦࠩ䢪")]})
            l11l1l111lll_ll_ = re.match(l111lll_ll_ (u"ࡶࠬࡸࡥࡵࡷࡵࡲࡡࡹࠫࠦࡵ࠱࡮ࡴ࡯࡮࡝ࠪࠥࠦࡡ࠯ࠧ䢫") % l11l11llll1l_ll_[0], line)
            if l11l1l111lll_ll_:
                l1ll111111ll_ll_[l111lll_ll_ (u"ࠬࡧࡣࡵ࡫ࡲࡲࡸ࠭䢬")].append({l111lll_ll_ (u"࠭ࡦࡶࡰࡦࠫ䢭"): l111lll_ll_ (u"ࠧ࡫ࡱ࡬ࡲࠬ䢮"),
                                               l111lll_ll_ (u"ࠨࡲࡤࡶࡦࡳࡳࠨ䢯"): [l111lll_ll_ (u"ࠩࠨࡗࡎࡍࠥࠨ䢰")]})
            l11l1l1111l1_ll_ = re.match(
                l111lll_ll_ (u"ࡵࠫ࠭ࡅࡐ࠽ࡱࡥ࡮ࡪࡩࡴࡠࡰࡤࡱࡪࡄ࡛ࠥࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡡ࠰࠯࡜࠯ࡁ࡟࡟ࡄࠨ࠿ࠩࡁࡓࡀ࡫ࡻ࡮ࡤࡶ࡬ࡳࡳࡥ࡮ࡢ࡯ࡨࡂࡠࠪࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺࡟࠮࠭ࠧࡅ࡜࡞ࡁ࡟ࠬ࠭ࡅࡐ࠽ࡲࡤࡶࡦࡳࡥࡵࡧࡵࡂࡠࡤࠩ࡞࠭ࠬࡠ࠮࠭䢱"),
                line)
            if l11l1l1111l1_ll_:
                l11l1l111l11_ll_ = l11l1l1111l1_ll_.group(l111lll_ll_ (u"ࠫࡴࡨࡪࡦࡥࡷࡣࡳࡧ࡭ࡦࠩ䢲"))
                l11llllll11_ll_ = l11l1l1111l1_ll_.group(l111lll_ll_ (u"ࠬ࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡟࡯ࡣࡰࡩࠬ䢳"))
                l1lll111l11l_ll_ = l11l1l1111l1_ll_.group(l111lll_ll_ (u"࠭ࡰࡢࡴࡤࡱࡪࡺࡥࡳࠩ䢴")).split(l111lll_ll_ (u"ࠧ࠭ࠩ䢵"))
                for i in range(len(l1lll111l11l_ll_)):
                    param = l1lll111l11l_ll_[i].strip()
                    if i == 0:
                        param = l111lll_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䢶")
                    else:
                        param = int(param)
                    l1lll111l11l_ll_[i] = param
                _11l1l111111_ll_ = self._11l11lll1ll_ll_(l11l1l111l11_ll_, l11llllll11_ll_, l11l11llllll_ll_)
                l11l1l111l1l_ll_ = re.match(l111lll_ll_ (u"ࡴࠪ࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰࠴ࡳ࡭࡫ࡦࡩࡡ࠮ࠨࡀࡒ࠿ࡥࡃࡢࡤࠬࠫ࠯࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰ࡢࠩࠨ䢷"), _11l1l111111_ll_[l111lll_ll_ (u"ࠪࡦࡴࡪࡹࠨ䢸")][0])
                if l11l1l111l1l_ll_:
                    a = int(l11l1l111l1l_ll_.group(l111lll_ll_ (u"ࠫࡦ࠭䢹")))
                    params = [l111lll_ll_ (u"ࠬࠫࡓࡊࡉࠨࠫ䢺"), a, l1lll111l11l_ll_[1]]
                    l1ll111111ll_ll_[l111lll_ll_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡹࠧ䢻")].append({l111lll_ll_ (u"ࠧࡧࡷࡱࡧࠬ䢼"): l111lll_ll_ (u"ࠨࡵ࡯࡭ࡨ࡫ࠧ䢽"),
                                                   l111lll_ll_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ䢾"): params})
                l11l11lllll1_ll_ = re.match(l111lll_ll_ (u"ࡵࠫࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱࠮ࡴࡲ࡯࡭ࡨ࡫࡜ࠩࠪࡂࡔࡁࡧ࠾࡝ࡦ࠮࠭࠱ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫ࡝ࠫࠪ䢿"), _11l1l111111_ll_[l111lll_ll_ (u"ࠫࡧࡵࡤࡺࠩ䣀")][0])
                if l11l11lllll1_ll_:
                    a = int(l11l11lllll1_ll_.group(l111lll_ll_ (u"ࠬࡧࠧ䣁")))
                    params = [l111lll_ll_ (u"࠭ࠥࡔࡋࡊࠩࠬ䣂"), a, l1lll111l11l_ll_[1]]
                    l1ll111111ll_ll_[l111lll_ll_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࡳࠨ䣃")].append({l111lll_ll_ (u"ࠨࡨࡸࡲࡨ࠭䣄"): l111lll_ll_ (u"ࠩࡶࡴࡱ࡯ࡣࡦࠩ䣅"),
                                                   l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ䣆"): params})
                l11l1l11l11l_ll_ = re.match(l111lll_ll_ (u"ࡶࠬࡼࡡࡳ࡞ࡶࡃࡠࡧ࠭ࡻࡃ࠰࡞ࡢ࠱࠽࡝ࡵࡂ࡟ࡦ࠳ࡺࡂ࠯࡝ࡡ࠰ࡢ࡛࠱࡞ࡠࠫ䣇"), _11l1l111111_ll_[l111lll_ll_ (u"ࠬࡨ࡯ࡥࡻࠪ䣈")][0])
                if l11l1l11l11l_ll_:
                    params = [l111lll_ll_ (u"࠭ࠥࡔࡋࡊࠩࠬ䣉"), l1lll111l11l_ll_[1]]
                    l1ll111111ll_ll_[l111lll_ll_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࡳࠨ䣊")].append({l111lll_ll_ (u"ࠨࡨࡸࡲࡨ࠭䣋"): l111lll_ll_ (u"ࠩࡶࡻࡦࡶࠧ䣌"),
                                                   l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ䣍"): params})
                l11l1l111ll1_ll_ = re.match(l111lll_ll_ (u"ࡶࠬࡡࡡ࠮ࡼࡄ࠱࡟ࡣ࠮ࡳࡧࡹࡩࡷࡹࡥ࡝ࠪ࡟࠭ࠬ䣎"), _11l1l111111_ll_[l111lll_ll_ (u"ࠬࡨ࡯ࡥࡻࠪ䣏")][0])
                if l11l1l111ll1_ll_:
                    params = [l111lll_ll_ (u"࠭ࠥࡔࡋࡊࠩࠬ䣐")]
                    l1ll111111ll_ll_[l111lll_ll_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࡳࠨ䣑")].append({l111lll_ll_ (u"ࠨࡨࡸࡲࡨ࠭䣒"): l111lll_ll_ (u"ࠩࡵࡩࡻ࡫ࡲࡴࡧࠪ䣓"),
                                                   l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ䣔"): params})
        return l1ll111111ll_ll_
    @staticmethod
    def _11l1l11l1l1_ll_(l11l11llllll_ll_):
        l11l11lll11l_ll_ = [
            l111lll_ll_ (u"ࡶࠬࡢࡢ࡜ࡥࡶࡡࡡࡹࠪࠧࠨ࡟ࡷ࠯ࡡࡡࡥࡨࡠࡠ࠳ࡹࡥࡵ࡞ࠫ࡟ࡣ࠲࡝ࠬ࡞ࡶ࠮࠱ࡢࡳࠫࡧࡱࡧࡴࡪࡥࡖࡔࡌࡇࡴࡳࡰࡰࡰࡨࡲࡹࡢࡳࠫ࡞ࠫࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࠫࠫ䣕"),
            l111lll_ll_ (u"ࡷ࠭࡜ࡣ࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡢ࠱࡜ࡴࠬࠩࠪࡡࡹࠪ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡡ࠰ࡢ࠮ࡴࡧࡷࡠ࠭ࡡ࡞࠭࡟࠮ࡠࡸ࠰ࠬ࡝ࡵ࠭ࡩࡳࡩ࡯ࡥࡧࡘࡖࡎࡉ࡯࡮ࡲࡲࡲࡪࡴࡴ࡝ࡵ࠭ࡠ࠭ࡢࡳࠫࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞࠭ࠬࡠ࠭࠭䣖"),
            l111lll_ll_ (u"ࡸࠧࠩࡁ࠽ࡠࡧࢂ࡛࡟ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࠨࡢ࠯ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࡻ࠳ࡿࠬࡠࡸ࠰࠽࡝ࡵ࠭ࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮࡜ࡴࠬࡤࡠࡸ࠰࡜ࠪ࡞ࡶ࠮ࢀࡢࡳࠫࡣ࡟ࡷ࠯ࡃ࡜ࡴࠬࡤࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭ࡢࡳࠫࠤࠥࡠࡸ࠰࡜ࠪࠩ䣗"),
            l111lll_ll_ (u"ࡲࠨࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞࠭ࠬࡠࡸ࠰࠽࡝ࡵ࠭ࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮࡜ࡴࠬࡤࡠࡸ࠰࡜ࠪ࡞ࡶ࠮ࢀࡢࡳࠫࡣ࡟ࡷ࠯ࡃ࡜ࡴࠬࡤࡠ࠳ࡹࡰ࡭࡫ࡷࡠ࠭ࡢࡳࠫࠤࠥࡠࡸ࠰࡜ࠪࠩ䣘"),
            l111lll_ll_ (u"ࡳࠩࠫ࡟ࠧࡢࠧ࡞ࠫࡶ࡭࡬ࡴࡡࡵࡷࡵࡩࡡ࠷࡜ࡴࠬ࠯ࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࠫࠫ䣙"),
            l111lll_ll_ (u"ࡴࠪࡠ࠳ࡹࡩࡨ࡞ࡿࡠࢁ࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࠨࡢ࠱ࠩ࡝ࠪࠪ䣚"),
            l111lll_ll_ (u"ࡵࠫࡾࡺ࡜࠯ࡣ࡮ࡥࡲࡧࡩࡻࡧࡧࡠ࠳ࡴࡥࡵ࠱࡟࠭ࡡࡹࠪ࡝ࡾ࡟ࢀࡡࡹࠪ࠯ࠬࡂࡠࡸ࠰࡛ࡤࡵࡠࡠࡸ࠰ࠦࠧ࡞ࡶ࠮ࡠࡧࡤࡧ࡟࡟࠲ࡸ࡫ࡴ࡝ࠪ࡞ࡢ࠱ࡣࠫ࡝ࡵ࠭࠰ࡡࡹࠪࠩࡁ࠽ࡩࡳࡩ࡯ࡥࡧࡘࡖࡎࡉ࡯࡮ࡲࡲࡲࡪࡴࡴ࡝ࡵ࠭ࡠ࠭࠯࠿࡝ࡵ࠭ࠫ䣛")
            l111lll_ll_ (u"ࡶࠬ࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࠨࡢ࠱ࠩ࡝ࠪࠪ䣜"),
            l111lll_ll_ (u"ࡷ࠭࡜ࡣ࡝ࡦࡷࡢࡢࡳࠫࠨࠩࡠࡸ࠰࡛ࡢࡦࡩࡡࡡ࠴ࡳࡦࡶ࡟ࠬࡠࡤࠬ࡞࠭࡟ࡷ࠯࠲࡜ࡴࠬࠫࡃࡕࡂ࡮ࡢ࡯ࡨࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࠥ࡟࠮࠭ࡡ࠮ࠧ䣝"),
            l111lll_ll_ (u"ࡸࠧ࡝ࡤ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡣࠫ࡝ࡵ࠭ࠪࠫࡢࡳࠫ࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡢ࠱࡜࠯ࡵࡨࡸࡡ࠮࡛࡟࠮ࡠ࠯ࡡࡹࠪ࠭࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡ࠰࠯࡜ࠩࠩ䣞"),
            l111lll_ll_ (u"ࡲࠨ࡞ࡥࡧࡡࡹࠪࠧࠨ࡟ࡷ࠯ࡧ࡜࠯ࡵࡨࡸࡡ࠮࡛࡟࠮ࡠ࠯ࡡࡹࠪ࠭࡞ࡶ࠮ࡡ࠮࡛࡟ࠫࡠ࠮ࡡ࠯࡜ࡴࠬ࡟ࠬࡡࡹࠪࠩࡁࡓࡀࡳࡧ࡭ࡦࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠬࠫ࡟ࠬࠬ䣟"),
            l111lll_ll_ (u"ࡳࠩ࡟ࡦࡨࡢࡳࠫࠨࠩࡠࡸ࠰࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࡠ࠯ࡡ࠴ࡳࡦࡶ࡟ࠬࡠࡤࠬ࡞࠭࡟ࡷ࠯࠲࡜ࡴࠬ࡟ࠬࡠࡤࠩ࡞ࠬ࡟࠭ࡡࡹࠪ࡝ࠪ࡟ࡷ࠯࠮࠿ࡑ࠾ࡱࡥࡲ࡫࠾࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࠨࡢ࠱ࠩ࡝ࠪࠪ䣠"),
            l111lll_ll_ (u"ࡴࠪࡠࡧࡩ࡜ࡴࠬࠩࠪࡡࡹࠪ࡜ࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡡ࠰ࡢ࠮ࡴࡧࡷࡠ࠭ࡡ࡞࠭࡟࠮ࡠࡸ࠰ࠬ࡝ࡵ࠭ࡠ࠭ࡡ࡞ࠪ࡟࠭ࡠ࠮ࡢࡳࠫ࡞ࠫࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࠫࠫ䣡")
        ]
        for pattern in l11l11lll11l_ll_:
            match = re.search(pattern, l11l11llllll_ll_)
            if match:
                return match.group(l111lll_ll_ (u"ࠪࡲࡦࡳࡥࠨ䣢"))
        return l111lll_ll_ (u"ࠫࠬ䣣")
    @staticmethod
    def _11l1l1111ll_ll_(l11llllll11_ll_, l11l11llllll_ll_):
        l11llllll11_ll_ = l11llllll11_ll_.replace(l111lll_ll_ (u"ࠬࠪࠧ䣤"), l111lll_ll_ (u"࠭࡜࡝ࠦࠪ䣥"))
        match = re.search(l111lll_ll_ (u"ࡲࠨ࡞ࡶࡃࠪࡹ࠽ࡧࡷࡱࡧࡹ࡯࡯࡯࡞ࠫࠬࡄࡖ࠼ࡱࡣࡵࡥࡲ࡫ࡴࡦࡴࡁ࡟ࡣ࠯࡝ࠬࠫ࡟࠭ࡡࡹ࠿ࡼ࡞ࡶࡃ࠭ࡅࡐ࠽ࡤࡲࡨࡾࡄ࡛࡟ࡿࡠ࠯࠮ࡢࡳࡀ࡞ࢀࠫ䣦") % l11llllll11_ll_, l11l11llllll_ll_)
        if match:
            return match.group(l111lll_ll_ (u"ࠨࡲࡤࡶࡦࡳࡥࡵࡧࡵࠫ䣧")), match.group(l111lll_ll_ (u"ࠩࡥࡳࡩࡿࠧ䣨"))
        return l111lll_ll_ (u"ࠪࠫ䣩"), l111lll_ll_ (u"ࠫࠬ䣪")
    @staticmethod
    def _11l1l11l111_ll_(l11l1l111l11_ll_, l11l11llllll_ll_):
        l11l1l111l11_ll_ = l11l1l111l11_ll_.replace(l111lll_ll_ (u"ࠬࠪࠧ䣫"), l111lll_ll_ (u"࠭࡜࡝ࠦࠪ䣬"))
        match = re.search(l111lll_ll_ (u"ࡲࠨࡸࡤࡶࠥࠫࡳ࠾ࡽࠫࡃࡕࡂ࡯ࡣ࡬ࡨࡧࡹࡥࡢࡰࡦࡼࡂ࠳࠰࠿ࡾࠫࢀ࠿ࠬ䣭") % l11l1l111l11_ll_, l11l11llllll_ll_, re.S)
        if match:
            return match.group(l111lll_ll_ (u"ࠨࡱࡥ࡮ࡪࡩࡴࡠࡤࡲࡨࡾ࠭䣮"))
        return l111lll_ll_ (u"ࠩࠪ䣯")
    def _11l11lll1ll_ll_(self, l11l1l111l11_ll_, l11llllll11_ll_, l11l11llllll_ll_):
        if l11l1l111l11_ll_ not in self._1l1ll1111ll_ll_:
            self._1l1ll1111ll_ll_[l11l1l111l11_ll_] = {}
        else:
            if l11llllll11_ll_ in self._1l1ll1111ll_ll_[l11l1l111l11_ll_]:
                return self._1l1ll1111ll_ll_[l11l1l111l11_ll_][l11llllll11_ll_]
        _11l11llll11_ll_ = self._11l1l11l111_ll_(l11l1l111l11_ll_, l11l11llllll_ll_)
        _11l11llll11_ll_ = _11l11llll11_ll_.split(l111lll_ll_ (u"ࠪࢁ࠱࠭䣰"))
        for _11l1l111111_ll_ in _11l11llll11_ll_:
            if not _11l1l111111_ll_.endswith(l111lll_ll_ (u"ࠫࢂ࠭䣱")):
                _11l1l111111_ll_ = l111lll_ll_ (u"ࠬ࠭䣲").join([_11l1l111111_ll_, l111lll_ll_ (u"࠭ࡽࠨ䣳")])
            _11l1l111111_ll_ = _11l1l111111_ll_.strip()
            match = re.match(l111lll_ll_ (u"ࡲࠨࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡣࡀ࡝ࠫࠫ࠽ࡪࡺࡴࡣࡵ࡫ࡲࡲࡡ࠮ࠨࡀࡒ࠿ࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࡄ࡛࡟ࠫࡠ࠮࠮ࡢࠩࡼࠪࡂࡔࡁࡨ࡯ࡥࡻࡁ࡟ࡣࢃ࡝ࠬࠫࢀࠫ䣴"), _11l1l111111_ll_)
            if match:
                name = match.group(l111lll_ll_ (u"ࠨࡰࡤࡱࡪ࠭䣵")).replace(l111lll_ll_ (u"ࠩࠥࠫ䣶"), l111lll_ll_ (u"ࠪࠫ䣷"))
                l1lll111l11l_ll_ = match.group(l111lll_ll_ (u"ࠫࡵࡧࡲࡢ࡯ࡨࡸࡪࡸࠧ䣸"))
                body = match.group(l111lll_ll_ (u"ࠬࡨ࡯ࡥࡻࠪ䣹")).split(l111lll_ll_ (u"࠭࠻ࠨ䣺"))
                self._1l1ll1111ll_ll_[l11l1l111l11_ll_][name] = {l111lll_ll_ (u"ࠧ࡯ࡣࡰࡩࠬ䣻"): name,
                                                         l111lll_ll_ (u"ࠨࡤࡲࡨࡾ࠭䣼"): body,
                                                         l111lll_ll_ (u"ࠩࡳࡥࡷࡧ࡭ࡴࠩ䣽"): l1lll111l11l_ll_}
        return self._1l1ll1111ll_ll_[l11l1l111l11_ll_][l11llllll11_ll_]