# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭྽")
headers = { l111lll_ll_ (u"࡛ࠬࡳࡦࡴ࠰ࡅ࡬࡫࡮ࡵࠩ྾") : l111lll_ll_ (u"࠭ࠧ྿") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠧࡠࡃࡕࡐࡤ࠭࿀")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ࠨ฻ิ์฻ࠦวๅ็ุหึ฿ษࠨ࿁"),l111lll_ll_ (u"ࠩส่่๊ࠧ࿂"),l111lll_ll_ (u"ࠪี๏อึส๋ࠢࠤ๊฻วา฻๊ࠫ࿃"),l111lll_ll_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭࿄"),l111lll_ll_ (u"ࠬอไฺษหࠫ࿅"),l111lll_ll_ (u"࠭ศาษ่ะ้ࠥๅษ์๋ฮึ࿆࠭"),l111lll_ll_ (u"ࠧๆ๊หห๏๊้ࠠࠢฯ์ฬ๊ࠧ࿇"),l111lll_ll_ (u"ࠨษ็ๆุ๋ࠠศๆสื้อๅ๋ࠩ࿈")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==200: results = l11l1ll_ll_(url)
	elif mode==201: results = l1l11l1_ll_(url)
	elif mode==202: results = l11_ll_(url)
	elif mode==203: results = l1l11ll_ll_(url)
	elif mode==204: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭࿉")+text)
	elif mode==205: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪ࿊")+text)
	elif mode==209: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠫࠬ࿋")):
	if l1111l_ll_==l111lll_ll_ (u"ࠬ࠭࿌"):
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭࿍"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧษฯฮࠤๆ๐ࠠศๆ่์็฿ࠧ࿎"),l111lll_ll_ (u"ࠨࠩ࿏"),209,l111lll_ll_ (u"ࠩࠪ࿐"),l111lll_ll_ (u"ࠪࠫ࿑"),l111lll_ll_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ࿒"))
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿓"),l1l1l1l_ll_+l111lll_ll_ (u"࠭แๅฬิࠤ๊ำฯะࠩ࿔"),l1ll1l1_ll_,205)
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿕"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨใ็ฮึࠦใศ็็ࠫ࿖"),l1ll1l1_ll_,204)
		l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ࿗"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭࿘"),l111lll_ll_ (u"ࠫࠬ࿙"),9999)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ࿚"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅๆ์ีอࠬ࿛"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧࡀࡁࡷࡶࡪࡴࡤࡪࡰࡪࠫ࿜"),201)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࿝"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩฦๅ้อๅࠡ็่๎ืฯࠧ࿞"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪࡃࡄࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧ࿟"),201)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿠"),l1l1l1l_ll_+l111lll_ll_ (u"๋ࠬำๅี็หฯࠦๅๆ์ีอࠬ࿡"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠿ࡀࡶࡵࡩࡳࡪࡩ࡯ࡩࡢࡷࡪࡸࡩࡦࡵࠪ࿢"),201)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ࿣"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬ࿤")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩสฺ่็อสࠢส่ึฬ๊ิ์ฬࠫ࿥"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪࡃࡄࡳࡡࡪࡰࡳࡥ࡬࡫ࠧ࿦"),201)
	#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࿧"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็ไหำࠪ࿨"),l111lll_ll_ (u"࠭ࠧ࿩"),114,l1ll1l1_ll_)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ࿪"),l1ll1l1_ll_,l111lll_ll_ (u"ࠨࠩ࿫"),headers,True,l111lll_ll_ (u"ࠩࠪ࿬"),l111lll_ll_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ࿭"))
	html = response.content#.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩ࿮"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷ࡯ࡥࡴ࠯ࡷࡥࡧࡹࠨ࠯ࠬࡂ࠭ࡒࡧࡩ࡯ࡔࡲࡻࠬ࿯"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡤࡢࡶࡤ࠱࡬࡫ࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡁ࡮࠳࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ࿰"),block,re.DOTALL)
		for filter,title in items:
			#link = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡩࡨࡸࡵࡵࡳࡵࡵࡂࡸࡾࡶࡥ࠾ࡱࡱࡩࠫࡪࡡࡵࡣࡀࠫ࿱")+filter
			link = l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡤ࡮ࡦࡾ࠯ࡩࡱࡰࡩ࠴ࡳ࡯ࡳࡧࡂࡪ࡮ࡲࡴࡦࡴࡀࠫ࿲")+filter
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ࿳"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ࿴")+l1l1l1l_ll_+title,link,201)
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ࿵"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ࿶"),l111lll_ll_ (u"࠭ࠧ࿷"),9999)
	#l11l1ll11_ll_(html)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱ࠱ࡲ࡫࡮ࡶࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭࿸"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪ࿹"),block,re.DOTALL)
	#l11ll11l1_ll_ = [l111lll_ll_ (u"่ࠩืู้ไศฬࠣࠫ࿺"),l111lll_ll_ (u"ࠪหๆ๊วๆࠢࠪ࿻"),l111lll_ll_ (u"ࠫอืวๆฮࠪ࿼"),l111lll_ll_ (u"ࠬ฿ัุ้ࠪ࿽"),l111lll_ll_ (u"࠭ใๅ์หหฯ࠭࿾"),l111lll_ll_ (u"ࠧศ฼ส๊๎࠭࿿")]
	for link,title in items:
		if l111lll_ll_ (u"ࠨࡪࡷࡸࡵ࠭က") not in link: link = l1ll1l1_ll_+link
		title = title.strip(l111lll_ll_ (u"ࠩࠣࠫခ"))
		if not any(value in title for value in l11lll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪဂ"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨဃ")+l1l1l1l_ll_+title,link,201)
	return html
def l1l11l1_ll_(url):
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋࠦࠤ࡫ࡵࡲࠡࡒࡒࡗ࡙ࠦࡦࡪ࡮ࡷࡩࡷࡀࠊࠊ࡫ࡩࠤࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩࠣ࡭ࡳࠦࡵࡳ࡮࠽ࠎࠎࠏࡵࡳ࡮࠵࠰࡫࡯࡬ࡵࡧࡵࡷ࠷ࠦ࠽ࠡࡷࡵࡰ࠳ࡹࡰ࡭࡫ࡷࠬࠬࡅࠧࠪࠌࠌࠍࡺࡸ࡬࠳ࠢࡀࠤࡺࡸ࡬࠳࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫ࠴࡭ࡥࡵࡲࡲࡷࡹࡹࠧ࠭ࠩ࠲ࡥ࡯ࡧࡸࡄࡧࡱࡸࡪࡸ࠿ࡠࡣࡦࡸ࡮ࡵ࡮࠾ࡃ࡭ࡥࡽࡌࡩ࡭ࡶࡨࡶ࡮ࡴࡧࡅࡣࡷࡥࠫࡥࡣࡰࡷࡱࡸࡂ࠻࠰ࠨࠫࠍࠍࠎࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࡸࡶࡱ࠸ࠬࡧ࡫࡯ࡸࡪࡸࡳ࠳ࠫࠍࠍࠎࡪࡡࡵࡣ࠵ࠤࡂࠦࡻࠨࡨࡲࡶࡲ࠭࠺ࡧ࡫࡯ࡸࡪࡸࡳ࠳࠮ࠪࡊ࡮ࡲࡴࡦࡴ࡚ࡳࡷࡪ࠽ࠨ࠼ࠪࠫࢂࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴ࠴ࠣࡁࠥ࡮ࡥࡢࡦࡨࡶࡸࠐࠉࠊࡪࡨࡥࡩ࡫ࡲࡴ࠴࡞ࠫࡈࡵ࡮ࡵࡧࡱࡸ࠲࡚ࡹࡱࡧࠪࡡࠥࡃࠠࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨࠌࠌࠍ࡭࡫ࡡࡥࡧࡵࡷ࠷ࡡ࡙ࠧ࠯ࡕࡩࡶࡻࡥࡴࡶࡨࡨ࠲࡝ࡩࡵࡪࠪࡡࠥࡃࠠࠨ࡚ࡐࡐࡍࡺࡴࡱࡔࡨࡵࡺ࡫ࡳࡵࠩࠍࠍࠎ࡮ࡥࡢࡦࡨࡶࡸ࠸࡛ࠨ࡚࠰ࡇࡘࡘࡆ࠮ࡖࡒࡏࡊࡔࠧ࡞ࠢࡀࠤࠬࡍ࡚࠵ࡑࡧ࠴ࡳࡰࡔࡄࡣࡊࡻࡨࡍࡱ࠵ࡋࡽࡋࡶࡎࡅࡳ࡛࠳ࡹ࡟ࡵࡡࡖ࡚࡝ࡇ࠻ࡎࡥ࡙ࡺࡻࠫࠏࠏࠉࡩࡧࡤࡨࡪࡸࡳ࠳࡝ࠪࡇࡴࡵ࡫ࡪࡧࠪࡡࠥࡃࠠࠨࡹࡤࡶࡧࡲࡩࡰࡰࡽࡸࡻࡥࡳࡦࡵࡶ࡭ࡴࡴ࠽ࡦࡻࡍࡴࡩ࡯ࡉ࠷ࡋࡰࡖ࠵ࡓࡘࡏࡌ࡜ࡰࡗࡒࡑ࡫ࡦࡤࡒࡉࡱࡸࡗࡰࡧࡋ࡟࠷ࡂ࠳࡛࡯ࡉ࠾ࡖࡓࡊࡵࡌࡲ࡟࡮ࡢࡉࡘ࡯ࡍ࡯ࡵࡩࡒࡖࡕࡖ࡛࡞ࡍ࠲ࡗ࡭ࡰࡌࡨࡆࡇࡴࡤ࡙ࡋࡱࡏࡆࡺࡈࡓ࡚࡜ࡑ࡚ࡗ࠷࠵ࡩ࠷ࡎࡘࡧࡋࡧࡼ࡫࡮ࡎࡻ࡙࡛ࡗࡌࡑ࡮࡮࠵࡙࡝ࡏ࠰ࡥ࡭ࡻࡰ࡟࠷ࡂ࡯ࡣ࠶ࡴ࡝࡙࠱ࡃ࡙ࡥࡘࡆ࠹ࡓ࡮ࡐ࡭ࡨࡋࡪ࠳ࡘࡅࡌࡷࡎࡳ࠱ࡩ࡛ࡼࡍ࠻ࡏࡪࡖࡺ࡝ࡘ࡬ࡿࡎ࡮ࡏࡼࡓࡌࡋࡹࡎ࡬ࡌ࠴ࡓࡊࡎ࡭࡜࡭࡬ࡱࡔ࠲ࡏ࡭࡝ࡘࡇࡳࡎ࡫ࡦࡰ࡝ࡿࡇ࠰ࡏ࡬ࡄࡻࡒ࡚ࡊ࡬ࡏࡽ࡞࡯ࡕࡄࡊࡼࡑࡘ࡞ࡿࡍࡻ࡭࠳ࡒࡉࡩ࠵ࡎࡖࡅ࡮ࡓ࡝ࡉࡺࡑࡗࡰ࡯ࡔࡪࡨ࡫ࡩࡕࡂࡃࠧࠋࠋࠌࡶࡪࡹࡰࡰࡰࡶࡩࠥࡃࠠࡐࡒࡈࡒ࡚ࡘࡌࡠࡔࡈࡕ࡚ࡋࡓࡕࡕࡢࡇࡆࡉࡈࡆࡆࠫࡖࡊࡍࡕࡍࡃࡕࡣࡈࡇࡃࡉࡇ࠯ࠫࡕࡕࡓࡕࠩ࠯ࡹࡷࡲ࠲࠭ࡦࡤࡸࡦ࠸ࠬࡩࡧࡤࡨࡪࡸࡳ࠳࠮ࡗࡶࡺ࡫ࠬࠨࠩ࠯ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡔࡊࡖࡏࡉࡘ࠳࠱ࡴࡶࠪ࠭ࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰ࡦࡳࡳࡺࡥ࡯ࡶࠦ࠲ࡪࡴࡣࡰࡦࡨࠬࠬࡻࡴࡧ࠺ࠪ࠭ࠏࠏࡥ࡭ࡵࡨ࠾ࠏࠏࠢࠣࠤင")
	if l111lll_ll_ (u"࠭࠿ࡀࠩစ") in url: url,type = url.split(l111lll_ll_ (u"ࠧࡀࡁࠪဆ"))
	else: type = l111lll_ll_ (u"ࠨࠩဇ")
	#l1ll1l_ll_(url,type)
	#if url==l1ll1l1_ll_: url = url+l111lll_ll_ (u"ࠩ࠲ࡥࡱࢀࠧဈ")
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠪࡘࡎ࡚ࡌࡆࡕࠪဉ"))
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨည"),url,l111lll_ll_ (u"ࠬ࠭ဋ"),headers,True,l111lll_ll_ (u"࠭ࠧဌ"),l111lll_ll_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠵ࡲࡩ࠭ဍ"))
	html = response.content#.encode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭ဎ"))
	#l1l1l1111_ll_(html)
	if l111lll_ll_ (u"ࠩࡪࡩࡹࡶ࡯ࡴࡶࡶࠫဏ") in url: l1lll_ll_ = [html]
	elif type==l111lll_ll_ (u"ࠪࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬတ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡒࡧࡳࡵࡧࡵࡗࡱ࡯ࡤࡦࡴࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࡜࡯ࠢ࠭ࡀ࠴ࡪࡩࡷࡀ࡟ࡲࠥ࠰࠼࠰ࡦ࡬ࡺࡃ࠭ထ"),html,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠬࡺࡲࡦࡰࡧ࡭ࡳ࡭࡟࡮ࡱࡹ࡭ࡪࡹࠧဒ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡓ࡭࡫ࡧࡩࡷࡥ࠱ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂ࠳ࡂ࠯ࡥ࡫ࡹࡂࠬဓ"),html,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠧࡵࡴࡨࡲࡩ࡯࡮ࡨࡡࡶࡩࡷ࡯ࡥࡴࠩန"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡕ࡯࡭ࡩ࡫ࡲࡠ࠴ࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄ࠮࠽࠱ࡧ࡭ࡻࡄࠧပ"),html,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠩ࠴࠵࠶ࡳࡡࡪࡰࡳࡥ࡬࡫ࠧဖ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡢ࡫ࡱࡩࡷࠦࡰࡢࡩࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡸࡦࡨࡳࠣࠩဗ"),html,re.DOTALL)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡵࡧࡧࡦ࠯ࡦࡳࡳࡺࡥ࡯ࡶࠫ࠲࠯ࡅࠩ࡮ࡣ࡬ࡲ࠲࡬࡯ࡰࡶࡨࡶࠬဘ"),html,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭မ"),str(l1lll_ll_))
	if not l1lll_ll_: return
	block = l1lll_ll_[0]
	#items = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡢࡰࡺ࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵ࡁࠬ࠳࠰࠿ࠪ࠾ࠪယ"),block,re.DOTALL)
	l11lllll1_ll_ = [l111lll_ll_ (u"ࠧๆึส๋ิฯࠧရ"),l111lll_ll_ (u"ࠨใํ่๊࠭လ"),l111lll_ll_ (u"ࠩส฾๋๐ษࠨဝ"),l111lll_ll_ (u"ࠪ็้๐ศࠨသ"),l111lll_ll_ (u"ࠫฬ฿ไศ่ࠪဟ"),l111lll_ll_ (u"ࠬํฯศใࠪဠ"),l111lll_ll_ (u"࠭ๅษษิหฮ࠭အ"),l111lll_ll_ (u"ฺࠧำูࠫဢ"),l111lll_ll_ (u"ࠨ็๊ีัอๆࠨဣ"),l111lll_ll_ (u"ࠩส่อ๎ๅࠨဤ")]
	#l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨဥ"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧဦ"),l111lll_ll_ (u"ࠬ࠭ဧ"),9999)
	items = re.findall(l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺ࠭ࡣࡱࡻࠦ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀࠬဨ"),block,re.DOTALL)
	if not items:
		items = re.findall(l111lll_ll_ (u"ࠧࡔ࡮࡬ࡨࡪࡸࡉࡵࡧࡰࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰࡥ࡬࡫࠺ࠡࡷࡵࡰࡡ࠮ࠨ࠯ࠬࡂ࠭ࡡ࠯࠮ࠫࡁ࠿࡬࠷ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ဩ"),block,re.DOTALL)
		links,l11ll111l_ll_,titles = zip(*items)
		items = zip(l11ll111l_ll_,links,titles)
	l1ll11ll_ll_ = []
	for img,link,title in items:
		#link = l1l1l11ll_ll_(link)
		#link = l1lll111_ll_(link)
		if l111lll_ll_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪဪ") in link: continue
		link = link.strip(l111lll_ll_ (u"ࠩ࠲ࠫါ"))
		title = unescapeHTML(title)
		title = title.strip(l111lll_ll_ (u"ࠪࠤࠬာ"))
		if l111lll_ll_ (u"ࠫ࠴࡬ࡩ࡭࡯࠲ࠫိ") in link or any(value in title for value in l11lllll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫီ"),l1l1l1l_ll_+title,link,202,img)
		elif l111lll_ll_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩု") in link and l111lll_ll_ (u"ࠧศๆะ่็ฯࠧူ") in title:
			episode = re.findall(l111lll_ll_ (u"ࠨࠪ࠱࠮ࡄ࠯ࠠศๆะ่็ฯࠠ࡝ࡦ࠮ࠫေ"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟ࠨဲ") + episode[0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪဳ"),l1l1l1l_ll_+title,link,203,img)
					l1ll11ll_ll_.append(title)
		elif l111lll_ll_ (u"ࠫ࠴ࡶࡡࡤ࡭࠲ࠫဴ") in link:
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬဵ"),l1l1l1l_ll_+title,link+l111lll_ll_ (u"࠭࠯ࡧ࡫࡯ࡱࡸ࠭ံ"),201,img)
		else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸ့ࠧ"),l1l1l1l_ll_+title,link,203,img)
	if type in [l111lll_ll_ (u"ࠨࠩး"),l111lll_ll_ (u"ࠩࡰࡥ࡮ࡴࡰࡢࡩࡨ္ࠫ")]:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡴࡦ࡭ࡩ࡯ࡣࡷ࡭ࡴࡴࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁ်ࠫ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫျ"),block,re.DOTALL)
			for link,title in items:
				link = unescapeHTML(link)
				title = unescapeHTML(title)
				title = title.replace(l111lll_ll_ (u"ࠬอไึใะอࠥ࠭ြ"),l111lll_ll_ (u"࠭ࠧွ"))
				if l111lll_ll_ (u"ࠧࡴࡧࡤࡶࡨ࡮࠿ࡴ࠿ࠪှ") in url:
					l11l1llll_ll_ = link.split(l111lll_ll_ (u"ࠨࡲࡤ࡫ࡪࡃࠧဿ"))[1]
					l11lll11l_ll_ = url.split(l111lll_ll_ (u"ࠩࡳࡥ࡬࡫࠽ࠨ၀"))[1]
					link = url.replace(l111lll_ll_ (u"ࠪࡴࡦ࡭ࡥ࠾ࠩ၁")+l11lll11l_ll_,l111lll_ll_ (u"ࠫࡵࡧࡧࡦ࠿ࠪ၂")+l11l1llll_ll_)
				if title!=l111lll_ll_ (u"ࠬ࠭၃"): l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭၄"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧึใะอࠥ࠭၅")+title,link,201)
	return
def l1l11ll_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࠩ၆"))
	l1l11111l_ll_,items,l11l1111_ll_ = -1,[],[]
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭၇"),url,l111lll_ll_ (u"ࠪࠫ၈"),headers,True,l111lll_ll_ (u"ࠫࠬ၉"),l111lll_ll_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭၊"))
	html = response.content#.encode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠻ࠫ။"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡵ࡫࠰ࡰ࡮ࡹࡴ࠮ࡰࡸࡱࡧ࡫ࡲࡦࡦࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ၌"),html,re.DOTALL)
	if l1lll_ll_:
		l11l1111_ll_ = []
		l1lll1l_ll_ = l111lll_ll_ (u"ࠨࠩ၍").join(l1lll_ll_)
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ၎"),l1lll1l_ll_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l111lll_ll_ (u"ࠪࡐ࡮ࡹࡴࡊࡶࡨࡱ࠳ࡒࡡࡣࡧ࡯ࠫ၏"))
	for link in items:
		link = link.strip(l111lll_ll_ (u"ࠫ࠴࠭ၐ"))
		title = l111lll_ll_ (u"ࠬࡥࡍࡐࡆࡢࠫၑ") + link.split(l111lll_ll_ (u"࠭࠯ࠨၒ"))[-1].replace(l111lll_ll_ (u"ࠧ࠮ࠩၓ"),l111lll_ll_ (u"ࠨࠢࠪၔ"))
		sequence = re.findall(l111lll_ll_ (u"ࠩส่า๊โส࠯ࠫࡠࡩ࠱ࠩࠨၕ"),link.split(l111lll_ll_ (u"ࠪ࠳ࠬၖ"))[-1],re.DOTALL)
		if sequence: sequence = sequence[0]
		else: sequence = l111lll_ll_ (u"ࠫ࠵࠭ၗ")
		l11l1111_ll_.append([link,title,sequence])
	items = sorted(l11l1111_ll_, reverse=False, key=lambda key: int(key[2]))
	l11llllll_ll_ = str(items).count(l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳ࠵ࠧၘ"))
	l1l11111l_ll_ = str(items).count(l111lll_ll_ (u"࠭࠯ࡦࡲ࡬ࡷࡴࡪࡥ࠰ࠩၙ"))
	if l11llllll_ll_>1 and l1l11111l_ll_>0 and l111lll_ll_ (u"ࠧ࠰ࡵࡨࡥࡸࡵ࡮࠰ࠩၚ") not in url:
		for link,title,sequence in items:
			if l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪၛ") in link:
				#link = l1lll111_ll_(link)
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩၜ"),l1l1l1l_ll_+title,link,203)
	else:
		for link,title,sequence in items:
			if l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬၝ") not in link:
				#if l111lll_ll_ (u"ࠫࠪ࠭ၞ") not in link: link = l1lll111_ll_(link)
				#else: link = l1lll111_ll_(l1111_ll_(link))
				#link = l1111_ll_(link)
				title = l1111_ll_(title)
				l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫၟ"),l1l1l1l_ll_+title,link,202)
	return
def l11_ll_(url):
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ၠ"),l111lll_ll_ (u"ࠧࡆࡏࡄࡈࠥ࠷࠱࠲ࠩၡ"))
	l1l111l_ll_ = []
	parts = url.split(l111lll_ll_ (u"ࠨ࠱ࠪၢ"))
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩࡓࡐࡆ࡟࠭࠲ࡵࡷࠫၣ"))
	#url = l1111_ll_(l1lll111_ll_(url))
	hostname = l1ll1l1_ll_
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧၤ"),url,l111lll_ll_ (u"ࠫࠬၥ"),headers,True,True,l111lll_ll_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠷ࡳࡵࠩၦ"))
	html = response.content#.encode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠻ࠫၧ"))
	id = re.findall(l111lll_ll_ (u"ࠧࡱࡱࡶࡸࡎࡪ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨၨ"),html,re.DOTALL)
	if not id: id = re.findall(l111lll_ll_ (u"ࠨࡲࡲࡷࡹࡥࡩࡥ࠿ࠫ࠲࠯ࡅࠩࠣࠩၩ"),html,re.DOTALL)
	if not id: id = re.findall(l111lll_ll_ (u"ࠩࡳࡳࡸࡺ࠭ࡪࡦࡀࠦ࠭࠴ࠪࡀࠫࠥࠫၪ"),html,re.DOTALL)
	if id: id = id[0]
	else: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭ၫ"),l111lll_ll_ (u"ࠫ๏ืฬ๊ࠢศีุอไ้ࠡำ๋ࠥอไๆึๆ่ฮࠦลๅ๋ࠣห้๋ศา็ฯࠤ๋ࠥๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠨၬ"))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬၭ"),l111lll_ll_ (u"࠭ࡅࡎࡃࡇࠤࡘ࡚ࡁࡓࡖࠣࡘࡎࡓࡉࡏࡉࠣ࠵࠶࠷ࠧၮ"))
	if l111lll_ll_ (u"ࠧ࠰ࡹࡤࡸࡨ࡮࠯ࠨၯ") in html:
		#parts = url.split(l111lll_ll_ (u"ࠨ࠱ࠪၰ"))
		l1ll111_ll_ = url.replace(parts[3],l111lll_ll_ (u"ࠩࡺࡥࡹࡩࡨࠨၱ"))
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧၲ"),l1ll111_ll_,l111lll_ll_ (u"ࠫࠬၳ"),headers,True,True,l111lll_ll_ (u"ࠬࡇࡒࡃࡎࡌࡓࡓࡠ࠭ࡑࡎࡄ࡝࠲࠸࡮ࡥࠩၴ"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"࠭ࡵࡵࡨ࠻ࠫၵ"))
		l1111ll1_ll_ = re.findall(l111lll_ll_ (u"ࠧࡥࡣࡷࡥ࠲࡫࡭ࡣࡧࡧࡨࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ၶ"),l1l111l1_ll_,re.DOTALL)
		l1llll111_ll_ = re.findall(l111lll_ll_ (u"ࠨࡦࡤࡸࡦ࠳ࡥ࡮ࡤࡨࡨࡩࡃࠢ࠯ࠬࡂࠬ࡭ࡺࡴࡱ࠰࠭ࡃ࠮࠮ࠢࡽࠨࡴࡹࡴࡺ࠻ࠪࠩၷ"),l1l111l1_ll_,re.DOTALL)
		l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠦࡲࡷࡲࡸࡀ࠮࠮ࠫࡁࠬࠪࡶࡻ࡯ࡵ࠽࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ၸ"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀ࡟ࡲ࠯࠴ࠪࡀࡵࡨࡶࡻ࡫ࡲࡠ࡫ࡰࡥ࡬࡫ࠢ࠿࡞ࡱࠬ࠳࠰࠿ࠪ࡞ࡱࠫၹ"),l1l111l1_ll_)
		l11l1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠫࡸࡸࡣ࠾ࠨࡴࡹࡴࡺ࠻ࠩ࠰࠭ࡃ࠮ࠬࡱࡶࡱࡷ࠿࠳࠰࠿ࡢ࡮ࡷࡁࠧ࠮࠮ࠫࡁࠬࠦࠬၺ"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		l11lll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹࡥࡳࡸࡨࡶࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧၻ"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
		items = l1111ll1_ll_+l1llll111_ll_+l1lll1lll_ll_+l1lll1l1l_ll_+l11l1ll1l_ll_+l11lll111_ll_
		#l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭ၼ"),l111lll_ll_ (u"ࠧࡆࡏࡄࡈ࡙ࠥࡔࡂࡔࡗࠤ࡙ࡏࡍࡊࡐࡊࠤ࠹࠺࠴ࠨၽ"))
		if not items:
			items = re.findall(l111lll_ll_ (u"ࠨ࠾ࡶࡴࡦࡴ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ၾ"),l1l111l1_ll_,re.DOTALL|re.IGNORECASE)
			items = [(b,a) for a,b in items]
		for server,title in items:
			if l111lll_ll_ (u"ࠩ࠱ࡴࡳ࡭ࠧၿ") in server: continue
			if l111lll_ll_ (u"ࠪ࠲࡯ࡶࡧࠨႀ") in server: continue
			if l111lll_ll_ (u"ࠫࠫࡷࡵࡰࡶ࠾ࠫႁ") in server: continue
			quality = re.findall(l111lll_ll_ (u"ࠬࡢࡤ࡝ࡦ࡟ࡨ࠰࠭ႂ"),title,re.DOTALL)
			if quality:
				quality = quality[0]
				if quality in title: title = title.replace(quality+l111lll_ll_ (u"࠭ࡰࠨႃ"),l111lll_ll_ (u"ࠧࠨႄ")).replace(quality,l111lll_ll_ (u"ࠨࠩႅ")).strip(l111lll_ll_ (u"ࠩࠣࠫႆ"))
				quality = l111lll_ll_ (u"ࠪࡣࡤࡥ࡟ࠨႇ")+quality
			else: quality = l111lll_ll_ (u"ࠫࠬႈ")
			#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬႉ"),l111lll_ll_ (u"࡛࠭ࠨႊ")+str(id)+l111lll_ll_ (u"ࠧ࡞ࠢࠣ࡟ࠬႋ")+str(hostname)+l111lll_ll_ (u"ࠨ࡟ࠣࠤࡠ࠭ႌ")+str(title)+l111lll_ll_ (u"ࠩࡠࠤࠥࡡႍࠧ")+str(quality)+l111lll_ll_ (u"ࠪࡡࠬႎ"))
			if server.isdigit():
				link = hostname+l111lll_ll_ (u"ࠫ࠴ࡅࡰࡰࡵࡷ࡭ࡩࡃࠧႏ")+id+l111lll_ll_ (u"ࠬࠬࡳࡦࡴࡹࡩࡷ࡯ࡤ࠾ࠩ႐")+server+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ႑")+title+l111lll_ll_ (u"ࠧࡠࡡࡺࡥࡹࡩࡨࠨ႒")+quality
			else:
				if l111lll_ll_ (u"ࠨࡪࡷࡸࡵ࠭႓") not in server: server = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ႔")+server
				quality = re.findall(l111lll_ll_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ႕"),title,re.DOTALL)
				if quality: quality = l111lll_ll_ (u"ࠫࡤࡥ࡟ࡠࠩ႖")+quality[0]
				else: quality = l111lll_ll_ (u"ࠬ࠭႗")
				link = server+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡹࡤࡸࡨ࡮ࠧ႘")+quality
			l1l111l_ll_.append(link)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ႙"),l111lll_ll_ (u"ࠨ࡝ࠪႚ")+quality+l111lll_ll_ (u"ࠩࡠࠤࠥࠦࠠ࡜ࠩႛ")+title+l111lll_ll_ (u"ࠪࡡࠬႜ"))
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩႝ"), l1l111l_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬࡽࡡࡵࡥ࡫ࠤ࠶࠭႞"),	str(len(items)))
	if l111lll_ll_ (u"࠭ࡄࡰࡹࡱࡰࡴࡧࡤࡏࡱࡺࠫ႟") in html:
		l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴ࠮ࡖࡼࡴࡪ࠭Ⴀ"):l111lll_ll_ (u"ࠨࡣࡳࡴࡱ࡯ࡣࡢࡶ࡬ࡳࡳ࠵ࡸ࠮ࡹࡺࡻ࠲࡬࡯ࡳ࡯࠰ࡹࡷࡲࡥ࡯ࡥࡲࡨࡪࡪ࠻ࠡࡥ࡫ࡥࡷࡹࡥࡵ࠿ࡘࡘࡋ࠳࠸ࠨႡ") }
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠩ࠲ࡨࡴࡽ࡮࡭ࡱࡤࡨࠬႢ")
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧႣ"),l1ll111_ll_,l111lll_ll_ (u"ࠫࠬႤ"),l1ll11l1l_ll_,True,l111lll_ll_ (u"ࠬ࠭Ⴅ"),l111lll_ll_ (u"࠭ࡁࡓࡄࡏࡍࡔࡔ࡚࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪႦ"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"ࠧࡶࡶࡩ࠼ࠬႧ"))
		#l1ll1l_ll_(l1ll111_ll_,l1l111l1_ll_)
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࠾ࡸࡰࠥࡩ࡬ࡢࡵࡶࡁࠧࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡪࡶࡨࡱࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩႨ"),l1l111l1_ll_,re.DOTALL)
		for block in l1lll_ll_:
			items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡵࡳࡥࡳࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿ࠫႩ"),block,re.DOTALL)
			for link,name,quality in items:
				link = link+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫႪ")+name+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨႫ")+l111lll_ll_ (u"ࠬࡥ࡟ࡠࡡࠪႬ")+quality
				l1l111l_ll_.append(link)
	elif l111lll_ll_ (u"࠭࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪႭ") in html:
		l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫႮ"):l111lll_ll_ (u"ࠨࠩႯ") , l111lll_ll_ (u"࡛ࠩ࠱ࡗ࡫ࡱࡶࡧࡶࡸࡪࡪ࠭ࡘ࡫ࡷ࡬ࠬႰ"):l111lll_ll_ (u"ࠪ࡜ࡒࡒࡈࡵࡶࡳࡖࡪࡷࡵࡦࡵࡷࠫႱ") }
		l1ll111_ll_ = hostname + l111lll_ll_ (u"ࠫ࠴ࡧࡪࡢࡺࡆࡩࡳࡺࡥࡳࡁࡢࡥࡨࡺࡩࡰࡰࡀ࡫ࡪࡺࡤࡰࡹࡱࡰࡴࡧࡤ࡭࡫ࡱ࡯ࡸࠬࡰࡰࡵࡷࡍࡩࡃࠧႲ")+id
		response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩႳ"),l1ll111_ll_,l111lll_ll_ (u"࠭ࠧႴ"),l1ll11l1l_ll_,True,True,l111lll_ll_ (u"ࠧࡂࡔࡅࡐࡎࡕࡎ࡛࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫႵ"))
		l1l111l1_ll_ = response.content#.encode(l111lll_ll_ (u"ࠨࡷࡷࡪ࠽࠭Ⴖ"))
		if l111lll_ll_ (u"ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧ࠱ࡧࡺ࡮ࡴࠩႷ") in l1l111l1_ll_:
			l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩႸ"),l1l111l1_ll_,re.DOTALL)
			for l11ll1_ll_ in l1lll1lll_ll_:
				if l111lll_ll_ (u"ࠫ࠴ࡶࡡࡨࡧ࠲ࠫႹ") not in l11ll1_ll_ and l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪႺ") in l11ll1_ll_:
					l11ll1_ll_ = l11ll1_ll_+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃ࡟ࡠࡦࡲࡻࡳࡲ࡯ࡢࡦࠪႻ")
					l1l111l_ll_.append(l11ll1_ll_)
				elif l111lll_ll_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧႼ") in l11ll1_ll_:
					quality = l111lll_ll_ (u"ࠨࠩႽ")
					response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭Ⴞ"),l11ll1_ll_,l111lll_ll_ (u"ࠪࠫႿ"),headers,True,True,l111lll_ll_ (u"ࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠳ࡐࡍࡃ࡜࠱࠺ࡺࡨࠨჀ"))
					l11ll11ll_ll_ = response.content#.encode(l111lll_ll_ (u"ࠬࡻࡴࡧ࠺ࠪჁ"))
					l1lll1l_ll_ = re.findall(l111lll_ll_ (u"࠭ࠨ࠽ࡵࡷࡶࡴࡴࡧ࠿࠰࠭ࡃ࠮࠳࠭࠮࠯࠰ࠫჂ"),l11ll11ll_ll_,re.DOTALL)
					for l1l111111_ll_ in l1lll1l_ll_:
						l11ll1l1l_ll_ = l111lll_ll_ (u"ࠧࠨჃ")
						l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠨ࠾ࡶࡸࡷࡵ࡮ࡨࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡶࡸࡷࡵ࡮ࡨࡀࠪჄ"),l1l111111_ll_,re.DOTALL)
						for l11lll1l1_ll_ in l1lll1l1l_ll_:
							item = re.findall(l111lll_ll_ (u"ࠩ࡟ࡨࡡࡪ࡜ࡥ࠭ࠪჅ"),l11lll1l1_ll_,re.DOTALL)
							if item:
								quality = l111lll_ll_ (u"ࠪࡣࡤࡥ࡟ࠨ჆")+item[0]
								break
						for l11lll1l1_ll_ in reversed(l1lll1l1l_ll_):
							item = re.findall(l111lll_ll_ (u"ࠫࡡࡽ࡜ࡸ࠭ࠪჇ"),l11lll1l1_ll_,re.DOTALL)
							if item:
								l11ll1l1l_ll_ = item[0]
								break
						l11l1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ჈"),l1l111111_ll_,re.DOTALL)
						for l11ll1lll_ll_ in l11l1ll1l_ll_:
							l11ll1lll_ll_ = l11ll1lll_ll_+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ჉")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ჊")+quality
							l1l111l_ll_.append(l11ll1lll_ll_)
			#l1ll1l_ll_(l111lll_ll_ (u"ࠨࡦࡲࡻࡳࡲ࡯ࡢࡦࠣ࠵ࠬ჋"),	str(len(l1l111l_ll_))	)
		elif l111lll_ll_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠧ჌") in l1l111l1_ll_:
			l1l111l1_ll_ = l1l111l1_ll_.replace(l111lll_ll_ (u"ࠪࡀ࡭࠼ࠠࠨჍ"),l111lll_ll_ (u"ࠫࡂࡃࡅࡏࡆࡀࡁࠥࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠨ჎"))+l111lll_ll_ (u"ࠬࡃ࠽ࡆࡐࡇࡁࡂ࠭჏")
			l1l111l1_ll_ = l1l111l1_ll_.replace(l111lll_ll_ (u"࠭࠼ࡩ࠵ࠣࠫა"),l111lll_ll_ (u"ࠧ࠾࠿ࡈࡒࡉࡃ࠽ࠡ࠿ࡀࡗ࡙ࡇࡒࡕ࠿ࡀࠫბ"))+l111lll_ll_ (u"ࠨ࠿ࡀࡉࡓࡊ࠽࠾ࠩგ")
			#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩდ"),l1l111l1_ll_)
			#with open(l111lll_ll_ (u"ࠪࡷ࠿ࡢ࡜ࡦ࡯ࡤࡨ࠳࡮ࡴ࡮࡮ࠪე"),l111lll_ll_ (u"ࠫࡼ࠭ვ")) as f: f.write(l1l111l1_ll_)
			l11l1lll1_ll_ = re.findall(l111lll_ll_ (u"ࠬࡃ࠽ࡔࡖࡄࡖ࡙ࡃ࠽ࠩ࠰࠭ࡃ࠮ࡃ࠽ࡆࡐࡇࡁࡂ࠭ზ"),l1l111l1_ll_,re.DOTALL)
			if l11l1lll1_ll_:
				for l1l111111_ll_ in l11l1lll1_ll_:
					if l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠬთ") not in l1l111111_ll_: continue
					#l1ll1l_ll_(l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࠢ࠴࠵࠶࠭ი"),	l1l111111_ll_	)
					l11lll1ll_ll_ = l111lll_ll_ (u"ࠨࠩკ")
					l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶࡰࡴࡽ࠭࡮ࡱࡷ࡭ࡴࡴࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨლ"),l1l111111_ll_,re.DOTALL)
					for l11lll1l1_ll_ in l1lll1l1l_ll_:
						item = re.findall(l111lll_ll_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫმ"),l11lll1l1_ll_,re.DOTALL)
						if item:
							l11lll1ll_ll_ = l111lll_ll_ (u"ࠫࡤࡥ࡟ࡠࠩნ")+item[0]
							break
					l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡷࡨࡃ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩࡪࡷࡸࡵ࠴ࠪࡀࠫࠥࠫო"),l1l111111_ll_,re.DOTALL)
					if l1lll1l1l_ll_:
						for l11ll1l1l_ll_,l11ll1ll1_ll_ in l1lll1l1l_ll_:
							l11ll1ll1_ll_ = l11ll1ll1_ll_+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧპ")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫჟ")+l11lll1ll_ll_
							l1l111l_ll_.append(l11ll1ll1_ll_)
					else:
						l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࡭ࡺࡴࡱ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡱࡥࡲ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨრ"),l1l111111_ll_,re.DOTALL)
						for l11ll1ll1_ll_,l11ll1l1l_ll_ in l1lll1l1l_ll_:
							l11ll1ll1_ll_ = l11ll1ll1_ll_.strip(l111lll_ll_ (u"ࠩࠣࠫს"))+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫტ")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࠨუ")+l11lll1ll_ll_
							l1l111l_ll_.append(l11ll1ll1_ll_)
			else:
				l1lll1l1l_ll_ = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࡞ࡺ࠯࠮ࡂࠧფ"),l1l111l1_ll_,re.DOTALL)
				for l11ll1ll1_ll_,l11ll1l1l_ll_ in l1lll1l1l_ll_:
					l11ll1ll1_ll_ = l11ll1ll1_ll_.strip(l111lll_ll_ (u"࠭ࠠࠨქ"))+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨღ")+l11ll1l1l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡨࡴࡽ࡮࡭ࡱࡤࡨࠬყ")
					l1l111l_ll_.append(l11ll1ll1_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩშ"),l111lll_ll_ (u"ࠪࡉࡒࡇࡄࠡ࠴࠵࠶ࠬჩ"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡧࡵࡴࡩ࠼ࠣࡻࡦࡺࡣࡩࠢࠩࠤࡩࡵࡷ࡯࡮ࡲࡥࡩ࠭ც"),	str(len(l1l111l_ll_))	)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪძ"), l1l111l_ll_)
	if len(l1l111l_ll_)==0: l1ll1l_ll_(l111lll_ll_ (u"࠭ัิษ็อ๋ࠥๆࠡษ็้อืๅอࠩწ"),l111lll_ll_ (u"ࠧศๆิหอ฽ࠠๅ์ึࠤๆ๐็ࠡใํำ๏๎ࠧჭ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧხ"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠩࠪჯ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠪࠫჰ"): return
	search = search.replace(l111lll_ll_ (u"ࠫࠥ࠭ჱ"),l111lll_ll_ (u"ࠬ࠱ࠧჲ"))
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪჳ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡣ࡯ࡾࠬჴ"),l111lll_ll_ (u"ࠨࠩჵ"),headers,True,l111lll_ll_ (u"ࠩࠪჶ"),l111lll_ll_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲࡙ࡅࡂࡔࡆࡌ࠲࠷ࡳࡵࠩჷ"))
	html = response.content#.encode(l111lll_ll_ (u"ࠫࡺࡺࡦ࠹ࠩჸ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩࡨࡦࡸࡵࡳࡳ࠳ࡳࡦ࡮ࡨࡧࡹ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪჹ"),html,re.DOTALL)
	if l1ll11_ll_ and l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡶࡢ࡮ࡸࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡀࠫ࠲࠯ࡅࠩ࠽ࠩჺ"),block,re.DOTALL)
		l11llll11_ll_,l11ll1l11_ll_ = [],[]
		for category,title in items:
			if title in [l111lll_ll_ (u"ࠧา์สฺฮ่ࠦࠡ็ุหึ฿็ࠨ჻")]: continue
			l11llll11_ll_.append(category)
			l11ll1l11_ll_.append(title)
		selection = l1l1111_ll_(l111lll_ll_ (u"ࠨษัฮึࠦวๅใ็ฮึࠦวๅ็้หุฮ࠺ࠨჼ"), l11ll1l11_ll_)
		if selection == -1 : return
		category = l11llll11_ll_[selection]
	else: category = l111lll_ll_ (u"ࠩࠪჽ")
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡸࡃࠧჾ")+search+l111lll_ll_ (u"ࠫࠫࡩࡡࡵࡧࡪࡳࡷࡿ࠽ࠨჿ")+category+l111lll_ll_ (u"ࠬࠬࡰࡢࡩࡨࡁ࠶࠭ᄀ")
	l1l11l1_ll_(url)
	return
def l1111l1_ll_(url,filter):
	filter = filter.replace(l111lll_ll_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᄁ"),l111lll_ll_ (u"ࠧࠨᄂ"))
	#l1ll1l_ll_(filter,url)
	# for l11ll1111_ll_ filter:		l1l1ll1l_ll_ = [l111lll_ll_ (u"ࠨࡅࡤࡸࡪ࡭࡯ࡳࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫᄃ"),l111lll_ll_ (u"ࠩ࡜ࡩࡦࡸࡃࡩࡧࡦ࡯ࡇࡵࡸࠨᄄ"),l111lll_ll_ (u"ࠪࡋࡪࡴࡲࡦࡅ࡫ࡩࡨࡱࡂࡰࡺࠪᄅ"),l111lll_ll_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᄆ")]
	l1l1ll1l_ll_ = [l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᄇ"),l111lll_ll_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᄈ"),l111lll_ll_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᄉ"),l111lll_ll_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩᄊ")]
	if l111lll_ll_ (u"ࠩࡂࠫᄋ") in url: url = url.split(l111lll_ll_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅࠧᄌ"))[0]
	type,filter = filter.split(l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨᄍ"),1)
	if filter==l111lll_ll_ (u"ࠬ࠭ᄎ"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"࠭ࠧᄏ"),l111lll_ll_ (u"ࠧࠨᄐ")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"ࠨࡡࡢࡣࠬᄑ"))
	if type==l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ᄒ"):
		if l1l1ll1l_ll_[0]+l111lll_ll_ (u"ࠪࡁࠬᄓ") not in l1l1l1ll_ll_: category = l1l1ll1l_ll_[0]
		for i in range(len(l1l1ll1l_ll_[0:-1])):
			if l1l1ll1l_ll_[i]+l111lll_ll_ (u"ࠫࡂ࠭ᄔ") in l1l1l1ll_ll_: category = l1l1ll1l_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠬࠬࠧᄕ")+category+l111lll_ll_ (u"࠭࠽࠱ࠩᄖ")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠧࠧࠩᄗ")+category+l111lll_ll_ (u"ࠨ࠿࠳ࠫᄘ")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"ࠩࠩࠫᄙ"))+l111lll_ll_ (u"ࠪࡣࡤࡥࠧᄚ")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠫࠫ࠭ᄛ"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᄜ"))
		l1ll111_ll_ = url+l111lll_ll_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᄝ")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"ࠧࡇࡋࡏࡘࡊࡘࡓࠨᄞ"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡺࡦࡲࡵࡦࡵࠪᄟ"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"ࠩࠪᄠ"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ᄡ"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠫࠬᄢ"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࠩᄣ")+l1l1l1l1_ll_
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᄤ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧฤฺ๊หึࠦโศศ่อࠥอไโ์า๎ํࠦวๅฬํࠤฯ๋ࠠศะอ๎ฬื็ศࠢࠪᄥ"),l1ll111_ll_,201)
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᄦ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩᄧ")+l1l1111l_ll_+l111lll_ll_ (u"ࠪࠤࠥࠦ࡝࡞ࠩᄨ"),l1ll111_ll_,201)
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩᄩ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᄪ"),l111lll_ll_ (u"࠭ࠧᄫ"),9999)
	html = l111ll1_ll_(l11l1l_ll_,url+l111lll_ll_ (u"ࠧ࠰ࡣ࡯ࡾࠬᄬ"),l111lll_ll_ (u"ࠨࠩᄭ"),headers,l111lll_ll_ (u"ࠩࠪᄮ"),l111lll_ll_ (u"ࠪࡅࡗࡈࡌࡊࡑࡑ࡞࠲ࡌࡉࡍࡖࡈࡖࡘࡥࡍࡆࡐࡘ࠱࠶ࡹࡴࠨᄯ"))
	#l11l1l1ll_ll_(url,html)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠩ࠰࠭ࡃ࠮ࡌࡩ࡭ࡶࡨࡶ࡜ࡵࡲࡥࠩᄰ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	# for l11ll1111_ll_ filter:		l11111l_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠫ࠲࠯ࡅࠩ࠽ࡪ࠵ࠫᄱ"),block,re.DOTALL)
	l11111l_ll_ = re.findall(l111lll_ll_ (u"࠭࠼࠰࡫ࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡪࡡࡵࡣ࠰ࡪࡴࡸࡔࡢࡺࡀࠦ࠭࠴ࠪࡀࠫࠥࠬ࠳࠰࠿ࠪ࠾࡫࠶ࠬᄲ"),block,re.DOTALL)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠧࠨᄳ"),str(l11111l_ll_))
	dict = {}
	for name,l1lllll1_ll_,block in l11111l_ll_:
		#name = name.replace(l111lll_ll_ (u"ࠨ࠯࠰ࠫᄴ"),l111lll_ll_ (u"ࠩࠪᄵ"))
		name = name.replace(l111lll_ll_ (u"ࠪหำะ๊ศำࠣࠫᄶ"),l111lll_ll_ (u"ࠫࠬᄷ"))
		name = name.replace(l111lll_ll_ (u"ูࠬๆสࠢส่ส์สศฮࠪᄸ"),l111lll_ll_ (u"࠭วๅี้อࠬᄹ"))
		items = re.findall(l111lll_ll_ (u"ࠧࡷࡣ࡯ࡹࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳ࡩ࡯ࡶ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨᄺ"),block,re.DOTALL)
		if l111lll_ll_ (u"ࠨ࠿ࠪᄻ") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠩࡆࡅ࡙ࡋࡇࡐࡔࡌࡉࡘ࠭ᄼ"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙࡟ࡠࡡࠪᄽ")+l1l1llll_ll_)
				return
			else:
				if l1lllll1_ll_==l1l1ll1l_ll_[-1]: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᄾ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไอ็ํ฽ࠥ࠭ᄿ"),l1ll111_ll_,201)
				else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅀ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆฯ้๏฿ࠠࠨᅁ"),l1ll111_ll_,205,l111lll_ll_ (u"ࠨࠩᅂ"),l111lll_ll_ (u"ࠩࠪᅃ"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖࠫᅄ"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠫࠫ࠭ᅅ")+l1lllll1_ll_+l111lll_ll_ (u"ࠬࡃ࠰ࠨᅆ")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"࠭ࠦࠨᅇ")+l1lllll1_ll_+l111lll_ll_ (u"ࠧ࠾࠲ࠪᅈ")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᅉ")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᅊ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้าๅ๋฻ࠣ࠾ࠬᅋ")+name,l1ll111_ll_,204,l111lll_ll_ (u"ࠫࠬᅌ"),l111lll_ll_ (u"ࠬ࠭ᅍ"),l1l1llll_ll_+l111lll_ll_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨᅎ"))
		dict[l1lllll1_ll_] = {}
		for value,option in items:
			option = option.replace(l111lll_ll_ (u"ࠧ࡝ࡰࠪᅏ"),l111lll_ll_ (u"ࠨࠩᅐ"))
			if option in l11lll1_ll_: continue
			#if option==l111lll_ll_ (u"ࠩส่่๊ࠧᅑ"): continue
			#option = l111lll_ll_ (u"ࠪ࡟ࠬᅒ")+option+l111lll_ll_ (u"ࠫࡢ࠭ᅓ")
			#if l111lll_ll_ (u"ࠬอไไๆࠪᅔ") in option: l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧᅕ"),l111lll_ll_ (u"ࠧ࡜ࠩᅖ")+str(option)+l111lll_ll_ (u"ࠨ࡟ࠪᅗ"))
			#if l111lll_ll_ (u"ࠩࡹࡥࡱࡻࡥࠨᅘ") not in value: value = option
			#else: value = re.findall(l111lll_ll_ (u"ࠪࠦ࠭࠴ࠪࡀࠫࠥࠫᅙ"),value,re.DOTALL)[0]
			dict[l1lllll1_ll_][value] = option
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠫࠫ࠭ᅚ")+l1lllll1_ll_+l111lll_ll_ (u"ࠬࡃࠧᅛ")+option
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"࠭ࠦࠨᅜ")+l1lllll1_ll_+l111lll_ll_ (u"ࠧ࠾ࠩᅝ")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᅞ")+l1ll1l11_ll_
			title = option+l111lll_ll_ (u"ࠩࠣ࠾ࠬᅟ")#+dict[l1lllll1_ll_][l111lll_ll_ (u"ࠪ࠴ࠬᅠ")]
			title = option+l111lll_ll_ (u"ࠫࠥࡀࠧᅡ")+name
			if type==l111lll_ll_ (u"ࠬࡌࡉࡍࡖࡈࡖࡘ࠭ᅢ"): l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᅣ"),l1l1l1l_ll_+title,url,204,l111lll_ll_ (u"ࠧࠨᅤ"),l111lll_ll_ (u"ࠨࠩᅥ"),l1llll1l_ll_+l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫᅦ"))
			elif type==l111lll_ll_ (u"ࠪࡇࡆ࡚ࡅࡈࡑࡕࡍࡊ࡙ࠧᅧ") and l1l1ll1l_ll_[-2]+l111lll_ll_ (u"ࠫࡂ࠭ᅨ") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡧ࡫࡯ࡸࡪࡸࡳࠨᅩ"))
				l11ll1_ll_ = url+l111lll_ll_ (u"࠭࠯ࡨࡧࡷࡴࡴࡹࡴࡴࡁࠪᅪ")+l1l11ll1_ll_
				l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᅫ"),l1l1l1l_ll_+title,l11ll1_ll_,201)
			else: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᅬ"),l1l1l1l_ll_+title,url,205,l111lll_ll_ (u"ࠩࠪᅭ"),l111lll_ll_ (u"ࠪࠫᅮ"),l1llll1l_ll_)
	return
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠫࡗࡋࡃࡐࡐࡖࡘࡗ࡛ࡃࡕࡡࡉࡍࡑ࡚ࡅࡓࠢ࠴࠵ࠬᅯ"))
	# mode==l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧᅰ")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"࠭࡭ࡰࡦ࡬ࡪ࡮࡫ࡤࡠࡨ࡬ࡰࡹ࡫ࡲࡴࠩᅱ")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"ࠧࡢ࡮࡯ࠫᅲ")					all filters (l1l11l11_ll_ empty filter)
	filters = filters.replace(l111lll_ll_ (u"ࠨ࠿ࠩࠫᅳ"),l111lll_ll_ (u"ࠩࡀ࠴ࠫ࠭ᅴ"))
	filters = filters.strip(l111lll_ll_ (u"ࠪࠪࠬᅵ"))
	l1l1ll11_ll_ = {}
	if l111lll_ll_ (u"ࠫࡂ࠭ᅶ") in filters:
		items = filters.split(l111lll_ll_ (u"ࠬࠬࠧᅷ"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"࠭࠽ࠨᅸ"))
			l1l1ll11_ll_[var] = value
	l1llll11_ll_ = l111lll_ll_ (u"ࠧࠨᅹ")
	# for l11ll1111_ll_ filter:		l1lll1l1_ll_ = [l111lll_ll_ (u"ࠨࡅࡤࡸࡪ࡭࡯ࡳࡻࡆ࡬ࡪࡩ࡫ࡃࡱࡻࠫᅺ"),l111lll_ll_ (u"ࠩ࡜ࡩࡦࡸࡃࡩࡧࡦ࡯ࡇࡵࡸࠨᅻ"),l111lll_ll_ (u"ࠪࡋࡪࡴࡲࡦࡅ࡫ࡩࡨࡱࡂࡰࡺࠪᅼ"),l111lll_ll_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࡈ࡮ࡥࡤ࡭ࡅࡳࡽ࠭ᅽ")]
	l1lll1l1_ll_ = [l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧᅾ"),l111lll_ll_ (u"࠭ࡲࡦ࡮ࡨࡥࡸ࡫࠭ࡺࡧࡤࡶࠬᅿ"),l111lll_ll_ (u"ࠧࡨࡧࡱࡶࡪ࠭ᆀ"),l111lll_ll_ (u"ࠨࡓࡸࡥࡱ࡯ࡴࡺࠩᆁ")]
	for key in l1lll1l1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"ࠩ࠳ࠫᆂ")
		if l111lll_ll_ (u"ࠪࠩࠬᆃ") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"ࠫࡲࡵࡤࡪࡨ࡬ࡩࡩࡥࡶࡢ࡮ࡸࡩࡸ࠭ᆄ") and value!=l111lll_ll_ (u"ࠬ࠶ࠧᆅ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"࠭ࠠࠬࠢࠪᆆ")+value
		elif mode==l111lll_ll_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪᆇ") and value!=l111lll_ll_ (u"ࠨ࠲ࠪᆈ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠩࠩࠫᆉ")+key+l111lll_ll_ (u"ࠪࡁࠬᆊ")+value
		elif mode==l111lll_ll_ (u"ࠫࡦࡲ࡬ࠨᆋ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠬࠬࠧᆌ")+key+l111lll_ll_ (u"࠭࠽ࠨᆍ")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠧࠡ࠭ࠣࠫᆎ"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠨࠨࠪᆏ"))
	l1llll11_ll_ = l1llll11_ll_.replace(l111lll_ll_ (u"ࠩࡀ࠴ࠬᆐ"),l111lll_ll_ (u"ࠪࡁࠬᆑ"))
	l1llll11_ll_ = l1llll11_ll_.replace(l111lll_ll_ (u"ࠫࡖࡻࡡ࡭࡫ࡷࡽࠬᆒ"),l111lll_ll_ (u"ࠬࡷࡵࡢ࡮࡬ࡸࡾ࠭ᆓ"))
	#l1ll1l_ll_(filters,l111lll_ll_ (u"࠭ࡒࡆࡅࡒࡒࡘ࡚ࡒࡖࡅࡗࡣࡋࡏࡌࡕࡇࡕࠤ࠷࠸ࠧᆔ"))
	return l1llll11_ll_
l111lll_ll_ (u"ࠢࠣࠤࠍࡪ࡮ࡲࡴࡦࡴࡶ࠾ࠎ࠷ࡳࡵࠢࡰࡩࡹ࡮࡯ࡥࠋࠌࠬࡺࡹࡥࡥࠢࡱࡳࡼࠦࡩ࡯ࠢࡺࡩࡧࡹࡩࡵࡧࠬࠎࡦࡪࡤࡪࡰࡪࠤ࡫࡯࡬ࡵࡧࡵࠤࡹࡵࠠࡴࡧࡤࡶࡨ࡮ࠊࡑࡑࡖࡘ࠿ࠏࡨࡵࡶࡳࡷ࠿࠵࠯ࡢࡴࡥࡰ࡮ࡵ࡮ࡻ࠰ࡤࡶࡹ࠵ࡡ࡫ࡣࡻࡇࡪࡴࡴࡦࡴࡂࡣࡦࡩࡴࡪࡱࡱࡁࡆࡰࡡࡹࡈ࡬ࡰࡹ࡫ࡲࡪࡰࡪࡈࡦࡺࡡࠧࡡࡦࡳࡺࡴࡴ࠾࠷࠳ࠎࠎࡪࡡࡵࡣ࠽ࠍࡠ࠭ࡃࡢࡶࡨ࡫ࡴࡸࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩ࠯ࠫ࡞࡫ࡡࡳࡅ࡫ࡩࡨࡱࡂࡰࡺࠪ࠰ࠬࡍࡥ࡯ࡴࡨࡇ࡭࡫ࡣ࡬ࡄࡲࡼࠬ࠲ࠧࡒࡷࡤࡰ࡮ࡺࡹࡄࡪࡨࡧࡰࡈ࡯ࡹࠩࡠࠎࠎ࡮ࡥࡢࡦࡨࡶࡸࡀࠉࡄࡱࡲ࡯࡮࡫࡛ࠠࠬࠢࡖࡊࡌ࠭ࡕࡑࡎࡉࡓࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠶ࡳࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠍࠎ࠮ࡵࡴࡧࡧࠤ࡮ࡴࠠࡵࡪ࡬ࡷࠥࡶࡲࡰࡩࡵࡥࡲ࠯ࠊࡈࡇࡗ࠾ࠎ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡡࡳࡤ࡯࡭ࡴࡴࡺ࠯ࡣࡵࡸ࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡲࡷࡤࡰ࡮ࡺࡹ࠾࡙ࡈࡆ࠲ࡊࡌࠧࡴࡨࡰࡪࡧࡳࡦ࠯ࡼࡩࡦࡸ࠽࠳࠲࠵࠴ࠏࠐࠊࠋࡨ࡬ࡰࡹ࡫ࡲࡴ࠼ࠌ࠷ࡷࡪࠠ࡮ࡧࡷ࡬ࡴࡪࠉࠊࠪࡲࡰࡩࠦ࡭ࡦࡶ࡫ࡳࡩࠦࡢࡶࡶࠣࡷࡹ࡯࡬࡭ࠢࡺࡳࡷࡱࡩ࡯ࡩࠬࠎࡌࡋࡔ࠻ࠋ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡥࡷࡨ࡬ࡪࡱࡱࡾ࠳ࡧࡲࡵ࠱ࡵࡩࡱ࡫ࡡࡴࡧ࠰ࡽࡪࡧࡲ࠰࠴࠳࠵࠾ࠐࡇࡆࡖ࠽ࠍ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡧࡲࡣ࡮࡬ࡳࡳࢀ࠮ࡢࡴࡷ࠳ࡶࡻࡡ࡭࡫ࡷࡽ࠴࠺ࡋࠦ࠴࠳ࡆࡱࡻࡒࡢࡻࠍࠦࠧࠨᆕ")