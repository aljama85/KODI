# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂࠩᤶ")
headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬᤷ") : l111lll_ll_ (u"ࠩࠪᤸ") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠪࡣࡍࡒࡁࡠ᤹ࠩ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,page,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==80: results = l11l1ll_ll_(url)
	elif mode==81: results = l11ll1l11l_ll_(url)
	elif mode==82: results = l11_ll_(url)
	elif mode==84: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ᤺"),l111lll_ll_ (u"᤻ࠬ࠭"),l111lll_ll_ (u"࠭࡮ࡦࡹ࡯ࡽࠬ᤼"),page)
	elif mode==85: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠧ࠰ࡥࡤࡸࡪ࡭࡯ࡳࡻ࠲ࠫ᤽"),l111lll_ll_ (u"ࠨࠩ᤾"),l111lll_ll_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧࠫ᤿"),page)
	elif mode==86: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵ࠧ᥀"),l111lll_ll_ (u"ࠫࠬ᥁"),l111lll_ll_ (u"ࠬࡼࡩࡦࡹࡶࠫ᥂"),page)
	elif mode==88: results = l11ll1l1l1_ll_()
	elif mode==89: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11ll1l1l1_ll_():
	message = l111lll_ll_ (u"࠭็ัษࠣห้๋่ใ฻ࠣฮ฿๐ัࠡสส่่อๅๅࠢ࠱࠲࠳่ࠦษฯสะฮࠦวๅ๋ࠣห฾อฯสࠢหี๊าษࠡ็้ࠤฬ๊ีโำࠣ࠲࠳࠴้ࠠษ็้อืๅอࠢะห้๐วࠡ็ื฾ํ๊้ࠠ์฼ห๋๐ࠠๆ่ࠣ์฾้ษࠡืะ๎ฮࠦ࠮࠯࠰ࠣ์้ํะศࠢึ์ๆ๊ࠦษไ์ࠤฬ๊ๅ้ไ฼ࠤ๊เไใࠢส่๎ࠦๅศࠢืหฦࠦวๅๆ๊ࠫ᥃")
	l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ᥄"),message)
	return
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠨࠩ᥅")):
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᥆"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪฬาัࠠโ์ࠣห้๋่ใ฻ࠪ᥇"),l111lll_ll_ (u"ࠫࠬ᥈"),89,l111lll_ll_ (u"ࠬ࠭᥉"),l111lll_ll_ (u"࠭ࠧ᥊"),l111lll_ll_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ᥋"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᥌"),l1111l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭᥍")+l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้๋ึศใࠣัิ๐หศࠩ᥎"),l111lll_ll_ (u"ࠫࠬ᥏"),84,l111lll_ll_ (u"ࠬ࠭ᥐ"),l111lll_ll_ (u"࠭࠰ࠨᥑ"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᥒ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬᥓ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩสๅ้อๅ๊่ࠡืู้ไศฬ้๊ࠣ๐าสࠩᥔ"),l111lll_ll_ (u"ࠪࠫᥕ"),85,l111lll_ll_ (u"ࠫࠬᥖ"),l111lll_ll_ (u"ࠬ࠶ࠧᥗ"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᥘ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫᥙ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨᥚ"),l111lll_ll_ (u"ࠩࠪᥛ"),86,l111lll_ll_ (u"ࠪࠫᥜ"),l111lll_ll_ (u"ࠫ࠵࠭ᥝ"))
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠬ࠭ᥞ"),headers,l111lll_ll_ (u"࠭ࠧᥟ"),l111lll_ll_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡐࡉࡓ࡛࠭࠲ࡵࡷࠫᥠ"))
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡦࡵࡳࡵࡪ࡯ࡸࡰࠫ࠲࠯ࡅࠩ࡯ࡣࡹࠫᥡ"),html,re.DOTALL)
	block = l1lll_ll_[1]
	items = re.findall(l111lll_ll_ (u"ࠩ࠿ࡥࠥ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᥢ"),block,re.DOTALL)
	#l1ll1l_ll_(block,str(items))
	l11lll1_ll_ = [l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩᥣ")]
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭ᥤ"))
		if not any(value in title for value in l11lll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᥥ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪᥦ")+l1l1l1l_ll_+title,link,81)
	return html
def l11ll1l11l_ll_(url,html=l111lll_ll_ (u"ࠧࠨᥧ"),type=l111lll_ll_ (u"ࠨࠩᥨ"),page=l111lll_ll_ (u"ࠩ࠳ࠫᥩ")):
	page = int(page)
	global headers
	if type==l111lll_ll_ (u"ࠪࠫᥪ"):
		if html==l111lll_ll_ (u"ࠫࠬᥫ"): html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠬ࠭ᥬ"),headers,l111lll_ll_ (u"࠭ࠧᥭ"),l111lll_ll_ (u"ࠧࡉࡃࡏࡅࡈࡏࡍࡂ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ᥮"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨ࡯ࡤ࡭ࡳ࠳ࡣࡰࡰࡷࡩࡳࡺࠨ࠯ࠬࡂ࠭ࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࠨ᥯"),html,re.DOTALL)
		if l1lll_ll_: block = l1lll_ll_[0]
		else: block = l111lll_ll_ (u"ࠩࠪᥰ")
	else:
		if page==0: l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠪ࠳ࡦࡰࡡࡹ࠱ࡪࡩࡹࡏࡴࡦ࡯ࠪᥱ")
		else: l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠫ࠴ࡧࡪࡢࡺ࠲ࡰࡴࡧࡤࡎࡱࡵࡩࠬᥲ")
		l1ll11l1l_ll_ = headers
		l1ll11l1l_ll_[l111lll_ll_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫᥳ")] = l111lll_ll_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬᥴ")
		payload = { l111lll_ll_ (u"ࠧࡂ࡬ࡤࡼࠬ᥵") : l111lll_ll_ (u"ࠨ࠳ࠪ᥶") , l111lll_ll_ (u"ࠩ࡬ࡸࡪࡳࠧ᥷") : type , l111lll_ll_ (u"ࠪࡳ࡫࡬ࡳࡦࡶࠪ᥸") : page*50 }
		data = l1lll11ll_ll_(payload)
		block = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,data,l1ll11l1l_ll_,l111lll_ll_ (u"ࠫࠬ᥹"),l111lll_ll_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡊࡖࡈࡑࡘ࠳࠲࡯ࡦࠪ᥺"))
	items = re.findall(l111lll_ll_ (u"࠭࠼ࡢࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡱࡵ࡭࡬࡯࡮ࡢ࡮ࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡣ࡭ࡣࡶࡷࡂࠨࡣࡰࡰࡷࡩࡳࡺࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨ᥻"),block,re.DOTALL)
	l1ll11ll_ll_,l11ll1111l_ll_,l11ll1l1ll_ll_,l11ll1ll11_ll_ = [],[],[],[]
	for link,img,title in items:
		l11ll11l11_ll_ = l111lll_ll_ (u"ࠧ࠺࠻࠼࠽࠾࠭᥼")
		if l111lll_ll_ (u"ࠨฯ็ๆฮ࠭᥽") in title and l111lll_ll_ (u"่ࠩ์ุ๋ࠧ᥾") not in title:
			episode = re.findall(l111lll_ll_ (u"ࠪั้่ษࠡࠪ࡟ࡨ࠰࠯ࠧ᥿"),title,re.DOTALL)
			if episode: l11ll11l11_ll_ = episode[0]
		if l111lll_ll_ (u"ࠫฬ๊อๅไฬࠫᦀ") in title and l111lll_ll_ (u"ࠬ࠵ࡣࡢࡶࡨ࡫ࡴࡸࡹ࠰ࠩᦁ") in url and l111lll_ll_ (u"࠭ศาษ่ะ࠲๎สๅใีอࠬᦂ") not in url:
			episode = re.findall(l111lll_ll_ (u"ࠧࠩ࠰࠭ࡃ࠮ࠦวๅฯ็ๆฮࠦ࡜ࡥ࠭ࠪᦃ"),title,re.DOTALL)
			if episode: title = episode[0]
			episode = re.findall(l111lll_ll_ (u"ࠨࠪ࠱࠮ࡄ࠯࠯ࡥࡱࡺࡲࡱࡵࡡࡥ࠯ࡹ࡭ࡪࡽ࠭ࡰࡰ࡯࡭ࡳ࡫࠯ࠩ࠰࠭ࡃ࠮࠳วๅฯ็ๆฮ࠴ࠪࡀ࠰࡫ࡸࡲࡲࠧᦄ"),link,re.DOTALL)
			if episode:
				link = episode[0][0]+l111lll_ll_ (u"ࠩ࠲ࡷࡪࡸࡩࡦࡵ࠲ࠫᦅ")+episode[0][1]+l111lll_ll_ (u"ࠪ࠲࡭ࡺ࡭࡭ࠩᦆ")
				link = link.replace(l111lll_ll_ (u"ฺ๊ࠫว่ัฬ࠱ࠬᦇ"),l111lll_ll_ (u"ࠬ࠭ᦈ"))
				link = link.replace(l111lll_ll_ (u"࠭ࡇࡢ࡯ࡨ࠱ࡴ࡬࠭ࡕࡪࡵࡳࡳ࡫ࡳ࠮ษ็้ํูๅ࠮ษ็ฯฬ๋ๆࠨᦉ"),l111lll_ll_ (u"ࠧࡈࡣࡰࡩ࠲ࡵࡦ࠮ࡖ࡫ࡶࡴࡴࡥࡴ࠯ส่๊๎ำๆ࠯࠻ࠫᦊ"))
				link = link.replace(l111lll_ll_ (u"ࠨ็ึุ่๊࠭ศๆ๊๎อฯ࠭ศๆฯึฦ࠳วๅอส่ะ࠭ᦋ"),l111lll_ll_ (u"ࠩส่์๐ศส࠯ส่๊๎ำๆ࠯࠶ࠫᦌ"))
				link = link.replace(l111lll_ll_ (u"ࠪ็้ฮิ࠮ษ็ะืว࠭ศๆฮห้ัࠧᦍ"),l111lll_ll_ (u"่๊ࠫศี࠯ส่ัุม࠮࠵ࠪᦎ"))
				#title = link.replace(l11ll11l1l_ll_[0][0],l111lll_ll_ (u"ࠬ࠭ᦏ"))
				title = l111lll_ll_ (u"࠭࡟ࡎࡑࡇࡣࠬᦐ")+title
		elif l111lll_ll_ (u"ࠧโ์็้ࠬᦑ") in title and l111lll_ll_ (u"ࠨ࠱ࡶࡩࡷ࡯ࡥࡴ࠱ࠪᦒ") in link and l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭ᦓ") in url:
			title = link
			title = title.replace(l111lll_ll_ (u"ࠪ࠱ࠬᦔ"),l111lll_ll_ (u"ࠫࠥ࠭ᦕ"))
			title = title.replace(l111lll_ll_ (u"ࠬ࠴ࡨࡵ࡯࡯ࠫᦖ"),l111lll_ll_ (u"࠭ࠧᦗ"))
			title = title.replace(l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩᦘ"),l111lll_ll_ (u"ࠨࠩᦙ"))
		title = title.strip(l111lll_ll_ (u"ࠩࠣ࠱ࠬᦚ"))
		title = title.strip(l111lll_ll_ (u"ࠪࠤࠬᦛ"))
		title = unescapeHTML(title)
		if title not in l1ll11ll_ll_:
			l1ll11ll_ll_.append(title)
			l11ll1111l_ll_.append(link)
			l11ll1l1ll_ll_.append(l11ll11l11_ll_)
			l11ll1ll11_ll_.append(img)
	z = zip(l1ll11ll_ll_,l11ll1111l_ll_,l11ll1l1ll_ll_,l11ll1ll11_ll_)
	#z = set(z)
	z = sorted(z, reverse=True, key=lambda key: int(key[2]))
	for title,link,l11ll11l11_ll_,img in z:
		if l111lll_ll_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠭ࡷ࡫ࡨࡻ࠲ࡵ࡮࡭࡫ࡱࡩ࠴࠭ᦜ") in link: l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫᦝ"),l1l1l1l_ll_+title,link,82,img)
		else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᦞ"),l1l1l1l_ll_+title,link,81,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨᦟ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨ࠾࡯࡭ࡃࡂࡡࠡࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾ࠪᦠ"),block,re.DOTALL)
		for link,title in items:
			title = title.replace(l111lll_ll_ (u"ࠩสฺ่็อสࠢࠪᦡ"),l111lll_ll_ (u"ࠪࠫᦢ"))
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᦣ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣࠫᦤ")+title,link,81)
	if type==l111lll_ll_ (u"࠭࡬ࡢࡵࡷࡖࡪࡩࡥ࡯ࡶࠪᦥ"): l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧᦦ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦวๅ็ี๎ิ࠭ᦧ"),l111lll_ll_ (u"ࠩࠪᦨ"),84,l111lll_ll_ (u"ࠪࠫᦩ"),str(page+1))
	elif type==l111lll_ll_ (u"ࠫࡵ࡯࡮ࠨᦪ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᦫ"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ีโฯฬࠤฬ๊ๅำ์าࠫ᦬"),l111lll_ll_ (u"ࠧࠨ᦭"),85,l111lll_ll_ (u"ࠨࠩ᦮"),str(page+1))
	elif type==l111lll_ll_ (u"ࠩࡹ࡭ࡪࡽࡳࠨ᦯"): l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᦰ"),l1l1l1l_ll_+l111lll_ll_ (u"ฺࠫ็อสࠢสุ่๊๊ะࠩᦱ"),l111lll_ll_ (u"ࠬ࠭ᦲ"),86,l111lll_ll_ (u"࠭ࠧᦳ"),str(page+1))
	return
def l11_ll_(url):
	l1l111l_ll_ = []
	global headers
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠧࠨᦴ"),headers,l111lll_ll_ (u"ࠨࠩᦵ"),l111lll_ll_ (u"ࠩࡋࡅࡑࡇࡃࡊࡏࡄ࠱ࡕࡒࡁ࡚࠯࠴ࡷࡹ࠭ᦶ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡨࡴࡽ࡮࡭ࡱࡤࡨ࠭࠴ࠪࡀࠫࡧ࡭ࡻ࠭ᦷ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪᦸ"),block,re.DOTALL)
	for link in items:
		if l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲࠪᦹ") not in link: link = l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾ࠬᦺ") + link
		l1l111l_ll_.append(link)
	l1ll111_ll_ = url.replace(l111lll_ll_ (u"ࠧ࠰ࡦࡲࡻࡳࡲ࡯ࡢࡦ࠰ࡺ࡮࡫ࡷ࠮ࡱࡱࡰ࡮ࡴࡥ࠰ࠩᦻ"),l111lll_ll_ (u"ࠨ࠱ࡲࡲࡱ࡯࡮ࡦ࠱ࠪᦼ"))
	html = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠩࠪᦽ"),headers,l111lll_ll_ (u"ࠪࠫᦾ"),l111lll_ll_ (u"ࠫࡍࡇࡌࡂࡅࡌࡑࡆ࠳ࡐࡍࡃ࡜࠱࠷ࡴࡤࠨᦿ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡧࡲࡵࡋࡧ࠲࠯ࡅࠨ࠯ࠬࡂ࠭ࡨࡵ࡬࠮ࡵࡰ࠱࠶࠸ࠧᧀ"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"࠭ࠠ࠾ࠢ࡟ࠫ࠭࠴ࠪࡀࠫ࡟ࠫࠬᧁ"),block,re.DOTALL)
	l11ll111ll_ll_ = items[0]
	l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࡣ࡭ࡥࡽ࠵ࡧࡦࡶ࡙࡭ࡩ࡫࡯ࡑ࡮ࡤࡽࡪࡸࠧᧂ")
	l1ll11l1l_ll_ = headers
	l1ll11l1l_ll_[l111lll_ll_ (u"ࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧᧃ")] = l111lll_ll_ (u"ࠩࡤࡴࡵࡲࡩࡤࡣࡷ࡭ࡴࡴ࠯ࡹ࠯ࡺࡻࡼ࠳ࡦࡰࡴࡰ࠱ࡺࡸ࡬ࡦࡰࡦࡳࡩ࡫ࡤࠨᧄ")
	items = re.findall(l111lll_ll_ (u"ࠪ࡫ࡪࡺࡖࡪࡦࡨࡳࡕࡲࡡࡺࡧࡵࡠ࠭ࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨᧅ"),block,re.DOTALL)
	threads = l11ll11lll_ll_(False)
	def l11ll1l111_ll_():
		html = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,data,l1ll11l1l_ll_,l111lll_ll_ (u"ࠫࠬᧆ"),l111lll_ll_ (u"ࠬࡎࡁࡍࡃࡆࡍࡒࡇ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩᧇ"))
		html = html.replace(l111lll_ll_ (u"࠭ࡓࡓࡅࡀࠫᧈ"),l111lll_ll_ (u"ࠧࡴࡴࡦࡁࠬᧉ"))
		link = re.findall(l111lll_ll_ (u"ࠣࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬࠨ᧊"),html,re.DOTALL)
		if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࠧ᧋") not in link[0]: link[0] = l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻ࠩ᧌") + link[0]
		return link[0]
	for server in items:
		payload = { l111lll_ll_ (u"ࠫࡆࡰࡡࡹࠩ᧍") : l111lll_ll_ (u"ࠬ࠷ࠧ᧎") , l111lll_ll_ (u"࠭ࡡࡳࡶࠪ᧏") : l11ll111ll_ll_ , l111lll_ll_ (u"ࠧࡴࡧࡵࡺࡪࡸࠧ᧐") : server }
		data = l1lll11ll_ll_(payload)
		threads.start_new_thread(server,l11ll1l111_ll_)
	threads.l11ll11ll1_ll_()
	l1l111l_ll_ = l1l111l_ll_ + threads.l11ll11111_ll_.values()
	import l1_ll_
	l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᧑"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠩࠪ᧒"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠪࠫ᧓"): return
	#search = search.replace(l111lll_ll_ (u"ࠫࠥ࠭᧔"),l111lll_ll_ (u"ࠬ࠱ࠧ᧕"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮࠮ࡩࡶࡰࡰࠬ᧖")
	headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ᧗") : l111lll_ll_ (u"ࠨࠩ᧘") , l111lll_ll_ (u"ࠩࡆࡳࡳࡺࡥ࡯ࡶ࠰ࡘࡾࡶࡥࠨ᧙") : l111lll_ll_ (u"ࠪࡥࡵࡶ࡬ࡪࡥࡤࡸ࡮ࡵ࡮࠰ࡺ࠰ࡻࡼࡽ࠭ࡧࡱࡵࡱ࠲ࡻࡲ࡭ࡧࡱࡧࡴࡪࡥࡥࠩ᧚") }
	payload = { l111lll_ll_ (u"ࠫࡳࡧ࡭ࡦࠩ᧛") : search , l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࠬ᧜") : l111lll_ll_ (u"࠭วๅสะฯࠬ᧝") }
	data = l1lll11ll_ll_(payload)
	html = l111ll1_ll_(l111l11_ll_,url,data,headers,l111lll_ll_ (u"ࠧࠨ᧞"),l111lll_ll_ (u"ࠨࡊࡄࡐࡆࡉࡉࡎࡃ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧ᧟"))
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	l11ll1l11l_ll_(l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴࠭᧠"),html)
	#if l111lll_ll_ (u"ࠪࡥࡷࡺ࡟࡭࡫ࡶࡸࠬ᧡") in html: l11ll1l11l_ll_(l111lll_ll_ (u"ࠫ࠴ࡩࡡࡵࡧࡪࡳࡷࡿ࠯ࠨ᧢"),html)
	#else: l1ll1l_ll_(l111lll_ll_ (u"ࠬࡴ࡯ࠡࡴࡨࡷࡺࡲࡴࡴࠩ᧣"),l111lll_ll_ (u"࠭ไศࠢอ์ัีࠠ็ฬสสัࠦไๅสะฯࠬ᧤"))
	return