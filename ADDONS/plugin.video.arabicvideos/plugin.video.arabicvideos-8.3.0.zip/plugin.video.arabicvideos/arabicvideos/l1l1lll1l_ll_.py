﻿# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_ = l111lll_ll_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆࠨො")
headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫෝ") : l111lll_ll_ (u"ࠨࠩෞ") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢࡑࡗࡌ࡟ࠨෟ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1l1llll1_ll_ = l11l11l_ll_[l1ll_ll_][1]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==40: results = l11l1ll_ll_(url)
	elif mode==41: results = l1ll11ll1_ll_()
	elif mode==42: results = l1l11ll_ll_(url)
	elif mode==43: results = l11_ll_(url)
	elif mode==44: results = CATEGORIES(url,text)
	elif mode==45: results = l1l11l1_ll_(url,text)
	elif mode==46: results = l1l1lll11_ll_()
	elif mode==47: results = l1l1l1l11_ll_(url)
	elif mode==49: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ෠")):
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ෡"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬอไษอࠣห้ำ๊ࠡๆๅ๊ฬฯࠠศๆ่฽ฬืแࠨ෢"),l111lll_ll_ (u"࠭ࠧ෣"),41)
	return
	l111lll_ll_ (u"ࠢࠣࠤࠍࠍࡦࡪࡤࡎࡧࡱࡹࡎࡺࡥ࡮ࠪࠪࡪࡴࡲࡤࡦࡴࠪ࠰ࡲ࡫࡮ࡶࡡࡱࡥࡲ࡫ࠫࠨสะฯࠥ็๊ࠡษ็้ํู่ࠨ࠮ࠪࠫ࠱࠺࠹࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ࠯ࠊࠊࡣࡧࡨࡒ࡫࡮ࡶࡋࡷࡩࡲ࠮ࠧࡧࡱ࡯ࡨࡪࡸࠧ࠭ࡹࡨࡦࡸ࡯ࡴࡦ࠭ࠪࡣࡤࡥࠧࠬ࡯ࡨࡲࡺࡥ࡮ࡢ࡯ࡨ࠯ࠬอไษำส้ัࠦวๅฯส่๏ฯࠧ࠭ࠩࠪ࠰࠹࠼ࠩࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡒࡔࡊࡔࡕࡓࡎࡢࡇࡆࡉࡈࡆࡆࠫࡐࡔࡔࡇࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡆࡒࡍࡂࡃࡕࡉࡋ࠳ࡍࡆࡐࡘ࠱࠶ࡹࡴࠨࠫࠍࠍ࡮ࡺࡥ࡮ࡵࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡀ࡭࠸࠾࠽ࡣࠣ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽࠱ࡤࡂࡁ࠵ࡨ࠳ࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡧࡱࡵࠤࡱ࡯࡮࡬࠮ࡱࡥࡲ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠱ࠧࡠࡡࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡰࡤࡱࡪ࠲࡬ࡪࡰ࡮࠰࠹࠻ࠬࠨࠩ࠯ࠫࠬ࠲ࠧ࠴ࠩࠬࠎࠎࡴࡡ࡮ࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࡶࡪࡩࡥ࡯ࡶ࠰ࡨࡪ࡬ࡡࡶ࡮ࡷ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠷ࡄࠧ࠭ࡪࡷࡱࡱ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍ࡮࡬ࠠ࡯ࡣࡰࡩ࠿ࠦࡡࡥࡦࡐࡩࡳࡻࡉࡵࡧࡰࠬࠬ࡬࡯࡭ࡦࡨࡶࠬ࠲ࡷࡦࡤࡶ࡭ࡹ࡫ࠫࠨࡡࡢࡣࠬ࠱࡭ࡦࡰࡸࡣࡳࡧ࡭ࡦ࠭ࡱࡥࡲ࡫࡛࠱࡟࠯ࡻࡪࡨࡳࡪࡶࡨ࠴ࡦ࠲࠴࠶࠮ࠪࠫ࠱࠭ࠧ࠭ࠩ࠵ࠫ࠮ࠐࠉ࡯ࡣࡰࡩࠥࡃࠠ࡜ࠩสีู๐แࠡษ็ฬึอๅอࠩࡠࠎࠎࠩ࡮ࡢ࡯ࡨࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࡨࡧࡴࡦࡩࡲࡶ࡮࡫ࡳࠣࡀ࠿ࡨ࡮ࡼࠠࡤ࡮ࡤࡷࡸࡃࠢࡸ࡫ࡧ࡫ࡪࡺ࠭ࡵࡱࡳࠦࡃࡂࡨ࠵ࡀࠫ࠲࠯ࡅࠩ࠽࠱࡫࠸ࡃ࠭ࠬࡩࡶࡰࡰ࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠌࠌ࡭࡫ࠦ࡮ࡢ࡯ࡨ࠾ࠥࡧࡤࡥࡏࡨࡲࡺࡏࡴࡦ࡯ࠫࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱ࡽࡥࡣࡵ࡬ࡸࡪ࠱ࠧࡠࡡࡢࠫ࠰ࡳࡥ࡯ࡷࡢࡲࡦࡳࡥࠬࡰࡤࡱࡪࡡ࠰࡞࠮ࡺࡩࡧࡹࡩࡵࡧ࠳ࡥ࠱࠺࠴࠭ࠩࠪ࠰ࠬ࠭ࠬࠨ࠲ࠪ࠭ࠏࠏࡲࡦࡶࡸࡶࡳࠦࡨࡵ࡯࡯ࠎࠎࠨࠢࠣ෤")
def l1l11l1_ll_(url,select):
	l11l11_ll_ = [l111lll_ll_ (u"ࠨฬฺฬ๏่วหࠢส่ฬา็ำหࠣห้ึใ๋หࠪ෥"),l111lll_ll_ (u"ࠩฯำํ๊ࠠศๆหีฬ๋ฬࠨ෦"),l111lll_ll_ (u"ࠪหํ่วหࠢหีฬ๋ฬ็ษࠪ෧")]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠫࠬ෨"),headers,l111lll_ll_ (u"ࠬ࠭෩"),l111lll_ll_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ෪"))
	if select==l111lll_ll_ (u"ࠧ࠳ࠩ෫"):
		l1l1ll111_ll_=re.findall(l111lll_ll_ (u"ࠨࡴࡨࡧࡪࡴࡴ࠮ࡦࡨࡪࡦࡻ࡬ࡵࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡣ࡭ࡧࡤࡶࠧ࠭෬"),html,re.DOTALL)
		if l1l1ll111_ll_:
			block = l1l1ll111_ll_[0]
			items=re.findall(l111lll_ll_ (u"ࠩࡶࡶࡨࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡴࡨࡰࡂࠨࡢࡰࡱ࡮ࡱࡦࡸ࡫ࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ෭"),block,re.DOTALL)
			for img,url,title in items:
				if not any(value in title for value in l11l11_ll_):
					title = unescapeHTML(title)
					l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ෮"),l1l1l1l_ll_+title,url,42,img)
	elif select==l111lll_ll_ (u"ࠫ࠸࠭෯"):
		l1l1l1lll_ll_=re.findall(l111lll_ll_ (u"ࠬࡧࡲࡤࡪ࡬ࡺࡪ࠳ࡢࡰࡺࠫ࠲࠯ࡅࠩࡴࡥࡵ࡭ࡵࡺࠧ෰"),html,re.DOTALL)
		if l1l1l1lll_ll_:
			block = l1l1l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"࠭ࡨ࠳࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࡁࠬ࠳࠰࠿ࠪ࠾࠱࠮ࡄࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ෱"),block,re.DOTALL)
			for url,title,img in items:
				if not any(value in title for value in l11l11_ll_):
					title = unescapeHTML(title)
					l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧෲ"),l1l1l1l_ll_+title,url,42,img)
	l1l1ll1l1_ll_=re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡲࡤ࡫࡮ࡴࡡࡵ࡫ࡲࡲࠧ࠮࠮ࠫࡁࠬࡀ࡭࠭ෳ"),html,re.DOTALL)
	if l1l1ll1l1_ll_:
		block = l1l1ll1l1_ll_[0]
		items=re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ෴"),block,re.DOTALL)
		for url,title in items:
			title = unescapeHTML(title)
			title = l111lll_ll_ (u"ูࠪๆำษࠡࠩ෵") + title
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ෶"),l1l1l1l_ll_+title,url,45,l111lll_ll_ (u"ࠬ࠭෷"),l111lll_ll_ (u"࠭ࠧ෸"),select)
	return
def l1l11ll_ll_(url):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠧࠨ෹"),headers,l111lll_ll_ (u"ࠨࠩ෺"),l111lll_ll_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠱ࡴࡶࠪ෻"))
	l1lll_ll_=re.findall(l111lll_ll_ (u"ࠪࡩࡳࡺࡲࡺ࠯ࡷ࡭ࡹࡲࡥࠣࡀ࠿ࡷࡵࡧ࡮ࠡ࡫ࡷࡩࡲࡶࡲࡰࡲࡀࠦࡳࡧ࡭ࡦࠤࡁࠬ࠳࠰࠿ࠪ࠾ࠪ෼"),html,re.DOTALL)
	if l1lll_ll_:
		name = l1lll_ll_[0]
		name = unescapeHTML(name)
		l1lll_ll_=re.findall(l111lll_ll_ (u"ࠫࡼࡶ࠭ࡱ࡮ࡤࡽࡱ࡯ࡳࡵ࠯ࡶࡧࡷ࡯ࡰࡵࠪ࠱࠮ࡄ࠯࠮ࡦࡰࡷࡶࡾ࠭෽"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items=re.findall(l111lll_ll_ (u"ࠬࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡪࡶ࡯ࡩࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡰࡩࡹࡧࠢ࠻ࠪ࠱࠮ࡄ࠯ࠬ࠯ࠬࡂ࡭ࡲࡧࡧࡦࠤ࠽ࡿࠧࡹࡲࡤࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡴࡩࡷࡰࡦࠧࡀࡻࠣࡵࡵࡧࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧ෾"),block,re.DOTALL)
			for link,title,meta,l1l1l1l1l_ll_,l1l1l1ll1_ll_ in items:
				l1l1l1l1l_ll_ = l1l1l1l1l_ll_.replace(l111lll_ll_ (u"࠭࡜࠰ࠩ෿"),l111lll_ll_ (u"ࠧ࠰ࠩ฀"))
				l1l1l1ll1_ll_ = l1l1l1ll1_ll_.replace(l111lll_ll_ (u"ࠨ࡞࠲ࠫก"),l111lll_ll_ (u"ࠩ࠲ࠫข"))
				link = link.replace(l111lll_ll_ (u"ࠪࡠ࠴࠭ฃ"),l111lll_ll_ (u"ࠫ࠴࠭ค"))
				title = l1l1l11ll_ll_(title)
				link = l1l1l11ll_ll_(link)
				title = title.split(l111lll_ll_ (u"ࠬࠦࠧฅ"))[-1]
				title = l111lll_ll_ (u"࠭࡟ࡎࡑࡇࡣࠬฆ") + name + l111lll_ll_ (u"ࠧࠡ࠯ࠣࠫง") + title
				duration = re.findall(l111lll_ll_ (u"ࠨ࡮ࡨࡲ࡬ࡺࡨࡠࡨࡲࡶࡲࡧࡴࡵࡧࡧࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭จ"),meta,re.DOTALL)
				if duration: duration = duration[0]
				else:  duration = l111lll_ll_ (u"ࠩࠪฉ")
				l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩช"),l1l1l1l_ll_+title,link,43,l1l1l1ll1_ll_,duration)
		else:
			items=re.findall(l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡲࡵࡳࡵࡃࠢ࡯ࡣࡰࡩࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠴ࠪࡀࡥࡲࡲࡹ࡫࡮ࡵࡗࡵࡰࠧࠦࡣࡰࡰࡷࡩࡳࡺ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡭ࡲࡧࡧࡦ࠰࠭ࡃࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪซ"),html,re.DOTALL)
			for title,link,img in items:
				img = img.replace(l111lll_ll_ (u"ࠬࡢ࠯ࠨฌ"),l111lll_ll_ (u"࠭࠯ࠨญ"))
				title = l1l1l11ll_ll_(title)
				link = l1l1l11ll_ll_(link)
				l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ฎ"),l1l1l1l_ll_+title,link,43,img)
			#l1l1ll1ll_ll_(url)
	else:
		l1lll_ll_=re.findall(l111lll_ll_ (u"ࠨ࡫ࡧࡁࠧࡪࡲࡰࡲࡧࡳࡼࡴ࠭࡮ࡧࡱࡹ࠲ࡹࡥࡳ࡫ࡨࡷࠧ࠮࠮ࠫࡁࠬࡀ࠴ࡻ࡬࠿ࠩฏ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			#l1ll1l_ll_(url, block)
			items=re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡶ࡬ࡸࡱ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨฐ"),block,re.DOTALL)
			for link,title in items:
				title = unescapeHTML(title)
				l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩฑ"),l1l1l1l_ll_+title,link,47)
	return
def l11_ll_(url):
	url = url.replace(l111lll_ll_ (u"ࠫࠥ࠭ฒ"),l111lll_ll_ (u"ࠬࠫ࠲࠱ࠩณ"))
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬด"))
	return
def l1l1l1l11_ll_(url):
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠧࠨต"),headers,l111lll_ll_ (u"ࠨࠩถ"),l111lll_ll_ (u"ࠩࡄࡐࡒࡇࡁࡓࡇࡉ࠱ࡕࡒࡁ࡚ࡡࡑࡉ࡜࡝ࡅࡃࡕࡌࡘࡊ࠳࠱ࡴࡶࠪท"))
	link = re.findall(l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡱࡴࡲࡴࡂࠨࡣࡰࡰࡷࡩࡳࡺࡕࡓࡎࠥࠤࡨࡵ࡮ࡵࡧࡱࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ธ"),html,re.DOTALL)
	l11_ll_(link[0])
	return
def CATEGORIES(url,category):
	#l1ll1l_ll_(type, url)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠫࠬน"),headers,l111lll_ll_ (u"ࠬ࠭บ"),l111lll_ll_ (u"࠭ࡁࡍࡏࡄࡅࡗࡋࡆ࠮ࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗ࠲࠷ࡳࡵࠩป"))
	l1lll_ll_=re.findall(l111lll_ll_ (u"ࠧࡤࡣࡷ࠵࠳ࡧ࡜ࠩ࠲࠯ࠬ࠳࠰࠿ࠪࡦࡲࡧࡺࡳࡥ࡯ࡶ࠱ࡻࡷ࡯ࡴࡦࠩผ"),html,re.DOTALL)
	block= l1lll_ll_[0]
	items=re.findall(l111lll_ll_ (u"ࠨࡥࡤࡸ࠶࠴ࡡ࡝ࠪࠫ࠲࠯ࡅࠩ࠭ࠪ࠱࠮ࡄ࠯ࠬ࡝ࠩࠫ࠲࠯ࡅࠩ࡝ࠩ࠯ࡠࠬࡢࠧ࠭࡞ࠪࠬ࠳࠰࠿ࠪ࡞ࠪࠫฝ"),block,re.DOTALL)
	l1l1ll11l_ll_=False
	l11l11_ll_ = [l111lll_ll_ (u"ࠩ࠰࠷࠾࠿ࠧพ"),l111lll_ll_ (u"ࠪ࠹࠻࠺࠳ࠨฟ"),l111lll_ll_ (u"ࠫ࠷࠹࠰࠷ࠩภ"),l111lll_ll_ (u"ࠬ࠻࠶࠶࠶ࠪม"),l111lll_ll_ (u"࠭࠱࠱࠹࠴࠺ࠬย"),l111lll_ll_ (u"ࠧ࠲࠲࠵࠻࠼࠭ร"),l111lll_ll_ (u"ࠨ࠹࠼࠸࠻࠭ฤ")]
	for cat,parent,title,link in items:
		if parent == category and cat not in l11l11_ll_:
			title = unescapeHTML(title)
			if l111lll_ll_ (u"๋ࠩๆฬะࠠษำส้ั࠭ล") in title: continue
			if l111lll_ll_ (u"ࠪࠬࠬฦ") in title:
				title = l111lll_ll_ (u"ࠫࡤࡓࡏࡅࡡࠪว") + title.replace(re.findall(l111lll_ll_ (u"ࠬࠦ࡜ࠩ࠰࠭ࡃࡡ࠯ࠧศ"),title)[0],l111lll_ll_ (u"࠭ࠧษ"))
			url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࠩส") + link
			if cat == l111lll_ll_ (u"ࠨ࠯࠴࠺࠺࠭ห"): title = l111lll_ll_ (u"ࠩࡢࡑࡔࡊ࡟ࠨฬ") + l111lll_ll_ (u"ࠪหู้๊ะุࠢฬฬำࠠีสิࠤ࠭࠼࠰ࠪࠩอ")
			if l111lll_ll_ (u"ࠫ࠲࠭ฮ") in cat: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬฯ"),l1l1l1l_ll_+title,url,44,l111lll_ll_ (u"࠭ࠧะ"),l111lll_ll_ (u"ࠧࠨั"),cat)
			else: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨา"),l1l1l1l_ll_+title,url,42)
			l1l1ll11l_ll_=True
	if not l1l1ll11l_ll_: l1l11l1_ll_(url,l111lll_ll_ (u"ࠩ࠶ࠫำ"))
	return
def l1l1lll11_ll_():
	#l1ll1l_ll_(type, url)
	html = l111ll1_ll_(l111l11_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠪࠫิ"),headers,l111lll_ll_ (u"ࠫࠬี"),l111lll_ll_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡑࡔࡒࡋࡗࡇࡍࡔ࠯࠴ࡷࡹ࠭ึ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭࡭ࡦࡩࡤ࠱ࡲ࡫࡮ࡶ࠯ࡥࡰࡴࡩ࡫ࠩ࠰࠭ࡃ࠮ࡳࡥࡨࡣ࠰ࡱࡪࡴࡵࠨื"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁุ࠭"),block,re.DOTALL)
	for link,title in items:
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨู"),l1l1l1l_ll_+title,link,44)
	return
def l1ll11ll1_ll_():
	html = l111ll1_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࡯࡭ࡻ࡫࠮ࡢ࡮ࡰࡥࡦࡸࡥࡧ࠰ࡷࡺฺࠬ"),l111lll_ll_ (u"ࠪࠫ฻"),headers,l111lll_ll_ (u"ࠫࠬ฼"),l111lll_ll_ (u"ࠬࡇࡌࡎࡃࡄࡖࡊࡌ࠭ࡍࡋ࡙ࡉ࠲࠷ࡳࡵࠩ฽"))
	items = re.findall(l111lll_ll_ (u"࠭ࡳࡰࡷࡵࡧࡪ࡛ࡒࡍࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ฾"),html,re.DOTALL)
	url = l1111_ll_(items[0])
	#l1ll1l_ll_(url,str(html))
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠧ࡭࡫ࡹࡩࠬ฿"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠨࠩเ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠩࠪแ"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠪࠤࠬโ"),l111lll_ll_ (u"ࠫࠪ࠸࠰ࠨใ"))
	url = l1l1llll1_ll_ + l111lll_ll_ (u"ࠬ࠵࠿ࡴ࠿ࠪไ") + l1llll1_ll_
	l1l11l1_ll_(url,l111lll_ll_ (u"࠭࠳ࠨๅ"))
	return