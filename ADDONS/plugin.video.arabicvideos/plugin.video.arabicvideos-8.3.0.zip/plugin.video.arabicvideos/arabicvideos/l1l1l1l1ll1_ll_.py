# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠭⢶")
l1ll1l1_ll_ = l11l11l_ll_[l111lll_ll_ (u"ࠧࡑ࡛ࡗࡌࡔࡔࠧ⢷")][0]
def l111l1l_ll_(mode,url):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==100: results = l11l1ll_ll_()
	elif mode==101: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠨ࠲ࠪ⢸"),True)
	elif mode==102: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠩ࠴ࠫ⢹"),True)
	elif mode==103: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠪ࠶ࠬ⢺"),True)
	elif mode==104: results = l11ll1l11l_ll_(l111lll_ll_ (u"ࠫ࠸࠭⢻"),True)
	elif mode==105: results = l11_ll_(url)
	else: results = False
	return results
def l11l1ll_ll_():
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⢼"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡋࡓࡘࠥࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⢽")+l111lll_ll_ (u"ࠧๅๆุ่ฯืใ๋่ࠣฬำีๅสࠢࡌࡔ࡙࡜ࠧ⢾"),l111lll_ll_ (u"ࠨࠩ⢿"),230)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣀"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡚ࡖ࠱ࠢࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⣁")+l111lll_ll_ (u"ࠫ็์่ศฬ้๋ࠣࠦๅ้ษๅ฽์อࠠศๆฦู้๐ษࠨ⣂"),l111lll_ll_ (u"ࠬ࠭⣃"),101)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣄"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟࡜࡙࡙ࠦࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ⣅")+l111lll_ll_ (u"ࠨไ้์ฬะฺࠠำห๎ฮࠦๅ็ࠢํ์ฯ๐่ษࠩ⣆"),l111lll_ll_ (u"ࠩࠪ⣇"),147)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ⣈"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࡙ࡖࡖࠣࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⣉")+l111lll_ll_ (u"่ࠬๆ้ษอࠤศาๆษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ⣊"),l111lll_ll_ (u"࠭ࠧ⣋"),148)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ⣌"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡍࡋࡒࠠࠡࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⣍")+l111lll_ll_ (u"ࠩๅ๊ฬฯࠠร์ࠣๅ๏๊ๅࠡ็้ࠤ๊๎โฺ้่ࠫ⣎"),l111lll_ll_ (u"ࠪࠫ⣏"),28)
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ⣐"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝ࡎࡔࡉࠤࠥࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⣑")+l111lll_ll_ (u"࠭โ็ษฬࠤฬ๊ๅฺษิๅ๋ࠥๆࠡ็๋ๆ฾ํๅࠨ⣒"),l111lll_ll_ (u"ࠧࠨ⣓"),41)
	#l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭⣔"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡐ࡝ࡔࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ⣕")+l111lll_ll_ (u"ࠪๆ๋อษࠡษ็็ํััࠡ็้ࠤ๊๎โฺ้่ࠫ⣖"),l111lll_ll_ (u"ࠫࠬ⣗"),135)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩࡷࡧࠪ⣘"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡒࡑࡘ࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⣙")+l111lll_ll_ (u"ࠧใ่สอࠥํไศ่๊๋่ࠢࠥใ฻ࠣฬฬ์๊หࠩ⣚"),l111lll_ll_ (u"ࠨࠩ⣛"),38)
	l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ⣜"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭⣝"),l111lll_ll_ (u"ࠫࠬ⣞"),9999)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ⣟"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࡖ࡙࠵࡛ࠥࠦ࠰ࡅࡒࡐࡔࡘ࡝ࠨ⣠")+l111lll_ll_ (u"ࠧใ่๋หฯࠦสๅใี๎ํ์๊สࠢ฼ห๊ฯࠧ⣡"),l111lll_ll_ (u"ࠨࠩ⣢"),102)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ⣣"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࡚ࡖ࠳ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ⣤")+l111lll_ll_ (u"ࠫ็์่ศฬࠣฮ้็า๋๊้๎ฮࠦฮศืฬࠫ⣥"),l111lll_ll_ (u"ࠬ࠭⣦"),103)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭⣧"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡗ࡚࠸ࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ⣨")+l111lll_ll_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆ๋ห่้ࠣ็อึࠩ⣩"),l111lll_ll_ (u"ࠩࠪ⣪"),104)
	return
def l11ll1l11l_ll_(l11l1llll1_ll_,show=True):
	l1l1l1l_ll_=l111lll_ll_ (u"ࠪࡣ࡙࡜ࠧ⣫")+l11l1llll1_ll_+l111lll_ll_ (u"ࠫࡤ࠭⣬")
	client = l11l1lll1ll_ll_(32)
	payload = { l111lll_ll_ (u"ࠬ࡯ࡤࠨ⣭") : l111lll_ll_ (u"࠭ࠧ⣮") , l111lll_ll_ (u"ࠧࡶࡵࡨࡶࠬ⣯") : client , l111lll_ll_ (u"ࠨࡨࡸࡲࡨࡺࡩࡰࡰࠪ⣰") : l111lll_ll_ (u"ࠩ࡯࡭ࡸࡺࠧ⣱") , l111lll_ll_ (u"ࠪࡱࡪࡴࡵࠨ⣲") : l11l1llll1_ll_ }
	#data = l1lll11ll_ll_(payload)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ⣳"),str(payload))
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ⣴"),str(data))
	#response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫ⣵"), l1ll1l1_ll_, payload, l111lll_ll_ (u"ࠧࠨ⣶"), True,l111lll_ll_ (u"ࠨࠩ⣷"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡌࡘࡊࡓࡓ࠮࠳ࡶࡸࠬ⣸"))
	#html = response.content
	response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨ⣹"),l1ll1l1_ll_,payload,l111lll_ll_ (u"ࠫࠬ⣺"),l111lll_ll_ (u"ࠬ࠭⣻"),l111lll_ll_ (u"࠭ࠧ⣼"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡊࡖࡈࡑࡘ࠳࠱ࡴࡶࠪ⣽"))
	html = response.content
	#html = html.replace(l111lll_ll_ (u"ࠨ࡞ࡵࠫ⣾"),l111lll_ll_ (u"ࠩࠪ⣿"))
	#l1ll1l_ll_(html,html)
	#file = open(l111lll_ll_ (u"ࠪࡷ࠿࠵ࡥ࡮ࡣࡧ࠲࡭ࡺ࡭࡭ࠩ⤀"), l111lll_ll_ (u"ࠫࡼ࠭⤁"))
	#file.write(html)
	#file.close()
	items = re.findall(l111lll_ll_ (u"ࠬ࠮࡛࡟࠽࡟ࡶࡡࡴ࡝ࠬࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠮࠮ࠫࡁࠬ࠿ࡀ࠭⤂"),html,re.DOTALL)
	if l111lll_ll_ (u"࠭ࡎࡰࡶࠣࡅࡱࡲ࡯ࡸࡧࡧࠫ⤃") in html:
		if show: l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⤄"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ⤅"),l111lll_ll_ (u"ࠩࠪ⤆"),9999)
		#if show: l1ll1l_ll_(l111lll_ll_ (u"ࠪࠫ⤇"),l111lll_ll_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ⤈"))
		#l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ⤉"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ไๅลึๅ๊ࠥวࠡฬ๋ะิࠦโ็๊สฮࠥะไโิ๋๊๏ฯࠠๅๅࠪ⤊"),l111lll_ll_ (u"ࠧࠨ⤋"),9999)
		#l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭⤌"),l1l1l1l_ll_+l111lll_ll_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไศไิฬฬว้ࠠษ็หฺีโศรࠣๅ็฽ࠧ⤍"),l111lll_ll_ (u"ࠪࠫ⤎"),9999)
		#l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ⤏"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨ⤐"),l111lll_ll_ (u"࠭ࠧ⤑"),9999)
		#l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ⤒"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡗࡱࡪࡴࡸࡴࡶࡰࡤࡸࡪࡲࡹ࠭ࠢࡱࡳ࡚ࠥࡖࠡࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠣࡪࡴࡸࠠࡺࡱࡸࠫ⤓"),l111lll_ll_ (u"ࠩࠪ⤔"),9999)
		#l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ⤕"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫࡎࡺࠠࡪࡵࠣࡪࡴࡸࠠࡳࡧ࡯ࡥࡹ࡯ࡶࡦࡵࠣࠪࠥ࡬ࡲࡪࡧࡱࡨࡸࠦ࡯࡯࡮ࡼࠫ⤖"),l111lll_ll_ (u"ࠬ࠭⤗"),9999)
	else:
		for i in range(len(items)):
			name = items[i][3]
			start = name[0:2]
			start = start.replace(l111lll_ll_ (u"࠭ࡡ࡭ࠩ⤘"),l111lll_ll_ (u"ࠧࡂ࡮ࠪ⤙"))
			start = start.replace(l111lll_ll_ (u"ࠨࡇ࡯ࠫ⤚"),l111lll_ll_ (u"ࠩࡄࡰࠬ⤛"))
			start = start.replace(l111lll_ll_ (u"ࠪࡅࡑ࠭⤜"),l111lll_ll_ (u"ࠫࡆࡲࠧ⤝"))
			start = start.replace(l111lll_ll_ (u"ࠬࡋࡌࠨ⤞"),l111lll_ll_ (u"࠭ࡁ࡭ࠩ⤟"))
			name = start+name[2:]
			start = name[0:3]
			start = start.replace(l111lll_ll_ (u"ࠧࡂ࡮࠰ࠫ⤠"),l111lll_ll_ (u"ࠨࡃ࡯ࠫ⤡"))
			start = start.replace(l111lll_ll_ (u"ࠩࡄࡰࠥ࠭⤢"),l111lll_ll_ (u"ࠪࡅࡱ࠭⤣"))
			name = start+name[3:]
			items[i] = items[i][0],items[i][1],items[i][2],name,items[i][4]
		items = set(items)
		items = sorted(items, reverse=False, key=lambda key: key[0].lower())
		items = sorted(items, reverse=False, key=lambda key: key[3].lower())
		for source,server,l111ll1ll_ll_,name,img in items:
			if l111lll_ll_ (u"ࠫࠨ࠭⤤") in source: continue
			#if source in [l111lll_ll_ (u"ࠬࡔࡔࠨ⤥"),l111lll_ll_ (u"࡙࠭ࡖࠩ⤦"),l111lll_ll_ (u"ࠧࡘࡕ࠳ࠫ⤧"),l111lll_ll_ (u"ࠨࡔࡏ࠵ࠬ⤨"),l111lll_ll_ (u"ࠩࡕࡐ࠷࠭⤩")]: continue
			if source!=l111lll_ll_ (u"࡙ࠪࡗࡒࠧ⤪"): name = name+l111lll_ll_ (u"ࠫࠥࠦࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ⤫")+source+l111lll_ll_ (u"ࠬࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ⤬")
			url = source+l111lll_ll_ (u"࠭࠻࠼ࠩ⤭")+server+l111lll_ll_ (u"ࠧ࠼࠽ࠪ⤮")+l111ll1ll_ll_+l111lll_ll_ (u"ࠨ࠽࠾ࠫ⤯")+l11l1llll1_ll_
			l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡻ࡫ࠧ⤰"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪࠫ⤱")+name,url,105,img)
	return
def l11_ll_(id):
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠫࡸࡺࡡࡳࡶࠪ⤲"))
	#l1ll11l_ll_(l111lll_ll_ (u"ࠬาวา์ࠣฮูเ๊ๅࠢส่็์วสࠩ⤳"),l111lll_ll_ (u"࠭ࠧ⤴"))
	source,server,l111ll1ll_ll_,l11l1llll1_ll_ = id.split(l111lll_ll_ (u"ࠧ࠼࠽ࠪ⤵"))
	url = l111lll_ll_ (u"ࠨࠩ⤶")
	#l1ll1l_ll_(source,l111ll1ll_ll_)
	#try:
	if source==l111lll_ll_ (u"ࠩࡘࡖࡑ࠭⤷"): url = l111ll1ll_ll_
	elif source==l111lll_ll_ (u"ࠪࡋࡆ࠭⤸"):
		#l1ll1l_ll_(url,html)
		#xbmc.log(html, level=xbmc.LOGNOTICE)
		payload = { l111lll_ll_ (u"ࠫ࡮ࡪࠧ⤹") : l111lll_ll_ (u"ࠬࡥ࡟ࡊࡆ࠵ࡣࡤ࠭⤺") , l111lll_ll_ (u"࠭ࡵࡴࡧࡵࠫ⤻") : l11l1lll1ll_ll_(32) , l111lll_ll_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ⤼") : l111lll_ll_ (u"ࠨࡲ࡯ࡥࡾࡍࡁ࠲ࠩ⤽") , l111lll_ll_ (u"ࠩࡰࡩࡳࡻࠧ⤾") : l11l1llll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨ⤿"),l1ll1l1_ll_,payload,l111lll_ll_ (u"ࠫࠬ⥀"),False,l111lll_ll_ (u"ࠬ࠭⥁"),l111lll_ll_ (u"࠭ࡌࡊࡘࡈࡘ࡛࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ⥂"))
		if l111lll_ll_ (u"ࠧࡏࡱࡷࠤࡆࡲ࡬ࡰࡹࡨࡨࠬ⥃") in response.content:
			l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ⥄"),l111lll_ll_ (u"๊ࠩิ์ࠦวๅะา้ฮࠦๅฯืุอ๊ࠥไๆสิ้ัࠦแใูࠪ⥅"))
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠪࡷࡹࡵࡰࠨ⥆"))
			return
		#l111ll111ll_ll_,l11ll1ll11l_ll_ = l111l1lllll_ll_()
		url = response.headers[l111lll_ll_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭⥇")]#+l111lll_ll_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ⥈")+l11ll1ll11l_ll_
		#l1ll1l_ll_(url,l111lll_ll_ (u"࠭ࠧ⥉"))
		response = l111111_ll_(l1l1l11ll1l_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ⥊"),url,l111lll_ll_ (u"ࠨࠩ⥋"),l111lll_ll_ (u"ࠩࠪ⥌"),False,l111lll_ll_ (u"ࠪࠫ⥍"),l111lll_ll_ (u"ࠫࡑࡏࡖࡆࡖ࡙࠱ࡕࡒࡁ࡚࠯࠵ࡲࡩ࠭⥎"))
		cookies = response.cookies.get_dict()
		session = cookies[l111lll_ll_ (u"ࠬࡇࡓࡑ࠰ࡑࡉ࡙ࡥࡓࡦࡵࡶ࡭ࡴࡴࡉࡥࠩ⥏")]
		#html = response.content
		#session = re.findall(l111lll_ll_ (u"࠭ࡓࡦࡵࡶ࡭ࡴࡴࡉࡅࠢࡀࠤࠧ࠮࠮ࠫࡁࠬࠦࠬ⥐"),html,re.DOTALL)
		#session = session[0]
		payload = { l111lll_ll_ (u"ࠧࡪࡦࠪ⥑") : l111lll_ll_ (u"ࠨࡡࡢࡍࡉ࠸࡟ࡠࠩ⥒") , l111lll_ll_ (u"ࠩࡸࡷࡪࡸࠧ⥓") : l11l1lll1ll_ll_(32) , l111lll_ll_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ⥔") : l111lll_ll_ (u"ࠫࡵࡲࡡࡺࡉࡄ࠶ࠬ⥕") , l111lll_ll_ (u"ࠬࡳࡥ࡯ࡷࠪ⥖") : l11l1llll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫ⥗"),l1ll1l1_ll_,payload,l111lll_ll_ (u"ࠧࠨ⥘"),False,l111lll_ll_ (u"ࠨࠩ⥙"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠴ࡴࡧࠫ⥚"))
		if l111lll_ll_ (u"ࠪࡒࡴࡺࠠࡂ࡮࡯ࡳࡼ࡫ࡤࠨ⥛") in response.content:
			l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧ⥜"),l111lll_ll_ (u"ࠬํะ่ࠢส่ำีๅส่ࠢาฺ฻ษࠡๆ็้อืๅอࠢไๆ฼࠭⥝"))
			#l1ll1ll11_ll_(l111lll_ll_ (u"࠭ࡳࡵࡱࡳࠫ⥞"))
			return
		url = response.headers[l111lll_ll_ (u"ࠧࡍࡱࡦࡥࡹ࡯࡯࡯ࠩ⥟")].replace(l111lll_ll_ (u"ࠨࡡࡢࡍࡉ࠸࡟ࡠࠩ⥠"),l111ll1ll_ll_)
		headers = { l111lll_ll_ (u"ࠩࡆࡳࡴࡱࡩࡦࠩ⥡") : l111lll_ll_ (u"ࠪࡅࡘࡖ࠮ࡏࡇࡗࡣࡘ࡫ࡳࡴ࡫ࡲࡲࡎࡪ࠽ࠨ⥢")+session }
		response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠫࡌࡋࡔࠨ⥣"),url,l111lll_ll_ (u"ࠬ࠭⥤"),headers,False,l111lll_ll_ (u"࠭ࠧ⥥"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠺ࡴࡩࠩ⥦"))
		html = response.content
		url = re.findall(l111lll_ll_ (u"ࠨࡴࡨࡷࡵࠨ࠺ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࡰ࠷ࡺ࠾ࠩࠩ࠰࠭ࡃ࠮ࠨࠧ⥧"),html,re.DOTALL)
		link = url[0][0]
		params = url[0][1]
		#url = link+params
		l1111lll11l_ll_ = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠶࠼࠳࠭⥨")+server+l111lll_ll_ (u"ࠪ࠻࠼࠽࠯ࠨ⥩")+l111ll1ll_ll_+l111lll_ll_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭⥪")+params
		l1111lll1l1_ll_ = l1111lll11l_ll_.replace(l111lll_ll_ (u"ࠬ࠹࠶࠻࠹ࠪ⥫"),l111lll_ll_ (u"࠭࠴࠱࠼࠺ࠫ⥬")).replace(l111lll_ll_ (u"ࠧࡠࡊࡇ࠲ࡲ࠹ࡵ࠹ࠩ⥭"),l111lll_ll_ (u"ࠨ࠰ࡰ࠷ࡺ࠾ࠧ⥮"))
		l1111llll11_ll_ = l1111lll11l_ll_.replace(l111lll_ll_ (u"ࠩ࠶࠺࠿࠽ࠧ⥯"),l111lll_ll_ (u"ࠪ࠸࠷ࡀ࠷ࠨ⥰")).replace(l111lll_ll_ (u"ࠫࡤࡎࡄ࠯࡯࠶ࡹ࠽࠭⥱"),l111lll_ll_ (u"ࠬ࠴࡭࠴ࡷ࠻ࠫ⥲"))
		l1111ll_ll_ = [l111lll_ll_ (u"࠭ࡈࡅࠩ⥳"),l111lll_ll_ (u"ࠧࡔࡆ࠴ࠫ⥴"),l111lll_ll_ (u"ࠨࡕࡇ࠶ࠬ⥵")]
		l1l111l_ll_ = [l1111lll11l_ll_,l1111lll1l1_ll_,l1111llll11_ll_]
		selection = 0
		#selection = l1l1111_ll_(l111lll_ll_ (u"ࠩสาฯืࠠศๆ่่ๆࠦวๅ็้หุฮ࠺ࠨ⥶"), l1111ll_ll_)
		if selection == -1:
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠪࡷࡹࡵࡰࠨ⥷"))
			return
		else: url = l1l111l_ll_[selection]
		#l1ll1l_ll_(items[0],url)
		l111lll_ll_ (u"ࠦࠧࠨࠊࠊࠋ࡫ࡩࡦࡪࡥࡳࡵࠣࡁࠥࢁࠠࠨࡅࡲࡲࡹ࡫࡮ࡵ࠯ࡗࡽࡵ࡫ࠧࠡ࠼ࠣࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪࠤࢂࠐࠉࠊࡲࡤࡽࡱࡵࡡࡥࠢࡀࠤࢀࠦࠧࡪࡦࠪࠤ࠿ࠦࡩࡥ࠴ࠣ࠰ࠥ࠭ࡵࡴࡧࡵࠫࠥࡀࠠࡥࡷࡰࡱࡾࡉ࡬ࡪࡧࡱࡸࡎࡊࠨ࠴࠴ࠬࠤ࠱ࠦࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩࠣ࠾ࠥ࠭ࡰ࡭ࡣࡼࡋࡆ࠭ࠠ࠭ࠢࠪࡱࡪࡴࡵࠨࠢ࠽ࠤࡲ࡫࡮ࡶࠢࢀࠎࠎࠏࡲࡦࡵࡳࡳࡳࡹࡥࠡ࠿ࠣࡓࡕࡋࡎࡖࡔࡏࡣࡗࡋࡑࡖࡇࡖࡘࡘࡥࡃࡂࡅࡋࡉࡉ࠮ࡓࡉࡑࡕࡘࡤࡉࡁࡄࡊࡈ࠰ࠬࡖࡏࡔࡖࠪ࠰ࠥࡽࡥࡣࡵ࡬ࡸࡪ࠶ࡡ࠭ࠢࡳࡥࡾࡲ࡯ࡢࡦ࠯ࠤ࡭࡫ࡡࡥࡧࡵࡷ࠱ࠦࡆࡢ࡮ࡶࡩ࠱࠭ࠧ࠭ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠲ࡵࡷࠫ࠮ࠐࠉࠊࡷࡵࡰࠥࡃࠠࡳࡧࡶࡴࡴࡴࡳࡦ࠰࡫ࡩࡦࡪࡥࡳࡵ࡞ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭࡝ࠋࠋࠌ࡬ࡹࡳ࡬ࠡ࠿ࠣࡶࡪࡹࡰࡰࡰࡶࡩ࠳ࡩ࡯࡯ࡶࡨࡲࡹࠐࠉࠊࡪࡷࡱࡱࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࡜࠯ࠪ࠱࠮ࡄ࠯࡜࠯ࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠏࠏࠉࡩࡶࡰࡰࠥࡃࠠࡣࡣࡶࡩ࠻࠺࠮ࡣ࠸࠷ࡨࡪࡩ࡯ࡥࡧࠫ࡬ࡹࡳ࡬࡜࠲ࡠ࠭ࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࠢ࡭࡫ࡱ࠲࠯ࡅ࠳ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࠊࡷࡵࡰࠥࡃࠠࡪࡶࡨࡱࡸࡡ࠰࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡ࠵ࠧ࠭ࠩ࠲ࠫ࠮ࠐࠉࠊࠤࠥࠦ⥸")
	elif source==l111lll_ll_ (u"ࠬࡔࡔࠨ⥹"):
		headers = { l111lll_ll_ (u"࠭ࡃࡰࡰࡷࡩࡳࡺ࠭ࡕࡻࡳࡩࠬ⥺") : l111lll_ll_ (u"ࠧࡢࡲࡳࡰ࡮ࡩࡡࡵ࡫ࡲࡲ࠴ࡾ࠭ࡸࡹࡺ࠱࡫ࡵࡲ࡮࠯ࡸࡶࡱ࡫࡮ࡤࡱࡧࡩࡩ࠭⥻") }
		payload = { l111lll_ll_ (u"ࠨ࡫ࡧࠫ⥼") : l111ll1ll_ll_ , l111lll_ll_ (u"ࠩࡸࡷࡪࡸࠧ⥽") : l11l1lll1ll_ll_(32) , l111lll_ll_ (u"ࠪࡪࡺࡴࡣࡵ࡫ࡲࡲࠬ⥾") : l111lll_ll_ (u"ࠫࡵࡲࡡࡺࡐࡗࠫ⥿") , l111lll_ll_ (u"ࠬࡳࡥ࡯ࡷࠪ⦀") : l11l1llll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"࠭ࡐࡐࡕࡗࠫ⦁"), l1ll1l1_ll_, payload, headers, False,l111lll_ll_ (u"ࠧࠨ⦂"),l111lll_ll_ (u"ࠨࡎࡌ࡚ࡊ࡚ࡖ࠮ࡒࡏࡅ࡞࠳࠵ࡵࡪࠪ⦃"))
		if l111lll_ll_ (u"ࠩࡑࡳࡹࠦࡁ࡭࡮ࡲࡻࡪࡪࠧ⦄") in response.content:
			l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭⦅"),l111lll_ll_ (u"ࠫ์ึ็ࠡษ็าิ๋ษࠡ็ัฺูฯࠠๅๆ่ฬึ๋ฬࠡใๅ฻ࠬ⦆"))
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠬࡹࡴࡰࡲࠪ⦇"))
			return
		url = response.headers[l111lll_ll_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ⦈")]
		url = url.replace(l111lll_ll_ (u"ࠧࠦ࠴࠳ࠫ⦉"),l111lll_ll_ (u"ࠨࠢࠪ⦊"))
		url = url.replace(l111lll_ll_ (u"ࠩࠨ࠷ࡉ࠭⦋"),l111lll_ll_ (u"ࠪࡁࠬ⦌"))
		if l111lll_ll_ (u"ࠫࡑ࡫ࡡࡳࡰࠪ⦍") in l111ll1ll_ll_:
			url = url.replace(l111lll_ll_ (u"ࠬࡔࡔࡏࡐ࡬ࡰࡪ࠭⦎"),l111lll_ll_ (u"࠭ࠧ⦏"))
			url = url.replace(l111lll_ll_ (u"ࠧ࡭ࡧࡤࡶࡳ࡯࡮ࡨ࠳ࠪ⦐"),l111lll_ll_ (u"ࠨࡎࡨࡥࡷࡴࡩ࡯ࡩࠪ⦑"))
	elif source==l111lll_ll_ (u"ࠩࡓࡐࠬ⦒"):
		headers = { l111lll_ll_ (u"ࠪࡇࡴࡴࡴࡦࡰࡷ࠱࡙ࡿࡰࡦࠩ⦓") : l111lll_ll_ (u"ࠫࡦࡶࡰ࡭࡫ࡦࡥࡹ࡯࡯࡯࠱ࡻ࠱ࡼࡽࡷ࠮ࡨࡲࡶࡲ࠳ࡵࡳ࡮ࡨࡲࡨࡵࡤࡦࡦࠪ⦔") }
		payload = { l111lll_ll_ (u"ࠬ࡯ࡤࠨ⦕") : l111ll1ll_ll_ , l111lll_ll_ (u"࠭ࡵࡴࡧࡵࠫ⦖") : l11l1lll1ll_ll_(32) , l111lll_ll_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࠩ⦗") : l111lll_ll_ (u"ࠨࡲ࡯ࡥࡾࡖࡌࠨ⦘") , l111lll_ll_ (u"ࠩࡰࡩࡳࡻࠧ⦙") : l11l1llll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨ⦚"), l1ll1l1_ll_, payload, headers, True,l111lll_ll_ (u"ࠫࠬ⦛"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠺ࡹ࡮ࠧ⦜"))
		if l111lll_ll_ (u"࠭ࡎࡰࡶࠣࡅࡱࡲ࡯ࡸࡧࡧࠫ⦝") in response.content:
			l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ⦞"),l111lll_ll_ (u"ࠨ้ำ๋ࠥอไฯั่อ๋ࠥฮึืฬࠤ้๊ๅษำ่ะࠥ็โุࠩ⦟"))
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠩࡶࡸࡴࡶࠧ⦠"))
			return
		response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨ⦡"), response.headers[l111lll_ll_ (u"ࠫࡑࡵࡣࡢࡶ࡬ࡳࡳ࠭⦢")], l111lll_ll_ (u"ࠬ࠭⦣"), {l111lll_ll_ (u"࠭ࡒࡦࡨࡨࡶࡪࡸࠧ⦤"):response.headers[l111lll_ll_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ⦥")]}, True,l111lll_ll_ (u"ࠨࠩ⦦"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋࡔࡗ࠯ࡓࡐࡆ࡟࠭࠸ࡶ࡫ࠫ⦧"))
		html = response.content
		items = re.findall(l111lll_ll_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ⦨"),html,re.DOTALL)
		url = items[0]
	elif source in [l111lll_ll_ (u"࡙ࠫࡇࠧ⦩"),l111lll_ll_ (u"ࠬࡌࡍࠨ⦪"),l111lll_ll_ (u"࡙࠭ࡖࠩ⦫"),l111lll_ll_ (u"ࠧࡘࡕ࠴ࠫ⦬"),l111lll_ll_ (u"ࠨ࡙ࡖ࠶ࠬ⦭"),l111lll_ll_ (u"ࠩࡕࡐ࠶࠭⦮"),l111lll_ll_ (u"ࠪࡖࡑ࠸ࠧ⦯")]:
		if source==l111lll_ll_ (u"࡙ࠫࡇࠧ⦰"): l111ll1ll_ll_ = id
		headers = { l111lll_ll_ (u"ࠬࡉ࡯࡯ࡶࡨࡲࡹ࠳ࡔࡺࡲࡨࠫ⦱") : l111lll_ll_ (u"࠭ࡡࡱࡲ࡯࡭ࡨࡧࡴࡪࡱࡱ࠳ࡽ࠳ࡷࡸࡹ࠰ࡪࡴࡸ࡭࠮ࡷࡵࡰࡪࡴࡣࡰࡦࡨࡨࠬ⦲") }
		payload = { l111lll_ll_ (u"ࠧࡪࡦࠪ⦳") : l111ll1ll_ll_ , l111lll_ll_ (u"ࠨࡷࡶࡩࡷ࠭⦴") : l11l1lll1ll_ll_(32) , l111lll_ll_ (u"ࠩࡩࡹࡳࡩࡴࡪࡱࡱࠫ⦵") : l111lll_ll_ (u"ࠪࡴࡱࡧࡹࠨ⦶")+source , l111lll_ll_ (u"ࠫࡲ࡫࡮ࡶࠩ⦷") : l11l1llll1_ll_ }
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡖࡏࡔࡖࠪ⦸"), l1ll1l1_ll_, payload, headers, False,l111lll_ll_ (u"࠭ࠧ⦹"),l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉ࡙࡜࠭ࡑࡎࡄ࡝࠲࠾ࡴࡩࠩ⦺"))
		if l111lll_ll_ (u"ࠨࡐࡲࡸࠥࡇ࡬࡭ࡱࡺࡩࡩ࠭⦻") in response.content:
			l1ll1l_ll_(l111lll_ll_ (u"ࠩิืฬ๊ษࠡ็้ࠤฬ๊ๅษำ่ะࠬ⦼"),l111lll_ll_ (u"๋ࠪีํࠠศๆัำ๊ฯࠠๆะุูฮࠦไๅ็หี๊าࠠโไฺࠫ⦽"))
			#l1ll1ll11_ll_(l111lll_ll_ (u"ࠫࡸࡺ࡯ࡱࠩ⦾"))
			return
		url = response.headers[l111lll_ll_ (u"ࠬࡒ࡯ࡤࡣࡷ࡭ࡴࡴࠧ⦿")]
		if source==l111lll_ll_ (u"࠭ࡆࡎࠩ⧀"):
			#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࠨ⧁"))
			response = l111111_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ⧂"), url, l111lll_ll_ (u"ࠩࠪ⧃"), l111lll_ll_ (u"ࠪࠫ⧄"), False,l111lll_ll_ (u"ࠫࠬ⧅"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡗ࡚࠲ࡖࡌࡂ࡛࠰࠽ࡹ࡮ࠧ⧆"))
			url = response.headers[l111lll_ll_ (u"࠭ࡌࡰࡥࡤࡸ࡮ࡵ࡮ࠨ⧇")]
			url = url.replace(l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸ࠭⧈"),l111lll_ll_ (u"ࠨࡪࡷࡸࡵ࠭⧉"))
	#l1ll1ll11_ll_(l111lll_ll_ (u"ࠩࡶࡸࡴࡶࠧ⧊"))
	result = l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠪࡰ࡮ࡼࡥࠨ⧋"))
	#except:
	#	l1ll1l_ll_(l111lll_ll_ (u"ࠫ์ึ็ࠡษ็ๆ๋อษࠡใํ๋ฬࠦๅีๅ็อ๋ࠥๆࠡษ็้ํู่ࠡษ็หฺ๊๊ࠨ⧌"),l1111lll1ll_ll_)
	return