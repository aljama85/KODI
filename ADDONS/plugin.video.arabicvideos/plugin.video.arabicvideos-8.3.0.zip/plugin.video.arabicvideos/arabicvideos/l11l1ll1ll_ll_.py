# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_ = l111lll_ll_ (u"࠭ࡉࡇࡋࡏࡑࠬᩰ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠧࡠࡋࡉࡐࡤ࠭ᩱ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1l1llll1_ll_ = l11l11l_ll_[l1ll_ll_][1]
l11l1l1111_ll_ = l11l11l_ll_[l1ll_ll_][2]
l11l1l11ll_ll_ = l11l11l_ll_[l1ll_ll_][3]
#l11l1ll111_ll_  = l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠻࠶࠲࠶࠿࠰࠯࠴࠷࠲࠶࠸࠲ࠨᩲ")
l11l1ll111_ll_  = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡤࡶ࠳࡯ࡦࡪ࡮ࡰࡸࡻ࠴ࡣࡰ࡯ࠪᩳ")
def l111l1l_ll_(mode,url,page,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==20: results = l11l1l1l11_ll_()
	elif mode==21: results = l11l1ll_ll_(url)
	elif mode==22: results = l1l11l1_ll_(url,page)
	elif mode==23: results = l1l11ll_ll_(url,page)
	elif mode==24: results = l11_ll_(url)
	elif mode==25: results = l11l11l111_ll_(url)
	elif mode==27: results = l1ll11ll1_ll_(url)
	elif mode==28: results = l11l1l1ll1_ll_()
	elif mode==29: results = l1lll1_ll_(url,text)
	else: results = False
	return results
def l11l1l1l11_ll_():
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᩴ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫ฾ืศ๋ࠩ᩵"),l1ll1l1_ll_,21,l111lll_ll_ (u"ࠬ࠭᩶"),l111lll_ll_ (u"࠭࠱࠱࠳ࠪ᩷"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ᩸"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ᩹"),l1l1llll1_ll_,21,l111lll_ll_ (u"ࠩࠪ᩺"),l111lll_ll_ (u"ࠪ࠵࠵࠷ࠧ᩻"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᩼"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็วาี์ࠫ᩽"),l11l1l1111_ll_,21,l111lll_ll_ (u"࠭ࠧ᩾"),l111lll_ll_ (u"ࠧ࠲࠲࠴᩿ࠫ"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᪀"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩไหึู้ࠡ࠴ࠪ᪁"),l11l1l11ll_ll_,21,l111lll_ll_ (u"ࠪࠫ᪂"),l111lll_ll_ (u"ࠫ࠶࠶࠱ࠨ᪃"))
	return
def l11l1l1ll1_ll_():
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩࡷࡧࠪ᪄"),l1l1l1l_ll_+l111lll_ll_ (u"ู࠭าสํࠫ᪅"),l1ll1l1_ll_,27)
	l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡹࡩࠬ᪆"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡇࡱ࡫ࡱ࡯ࡳࡩࠩ᪇"),l1l1llll1_ll_,27)
	l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡻ࡫ࠧ᪈"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪๅฬืำ๊ࠩ᪉"),l11l1l1111_ll_,27)
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ᪊"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็วาี์ࠤ࠷࠭᪋"),l11l1l11ll_ll_,27)
	return
def l11l1ll_ll_(l11l1l1lll_ll_):
	l1111l_ll_ = l11l1l1lll_ll_
	if l11l1l1lll_ll_==l111lll_ll_ (u"࠭ࡉࡇࡋࡏࡑࡤࡇࡒࡂࡄࡌࡇࠬ᪌"): l11l1l1lll_ll_ = l1ll1l1_ll_
	elif l11l1l1lll_ll_==l111lll_ll_ (u"ࠧࡊࡈࡌࡐࡒࡥࡅࡏࡉࡏࡍࡘࡎࠧ᪍"): l11l1l1lll_ll_ = l1l1llll1_ll_
	else: l1111l_ll_ = l111lll_ll_ (u"ࠨࠩ᪎")
	lang = l11l1ll11l_ll_(l11l1l1lll_ll_)
	if lang==l111lll_ll_ (u"ࠩࡤࡶࠬ᪏") or l1111l_ll_!=l111lll_ll_ (u"ࠪࠫ᪐"):
		l11l11l1l1_ll_ = l111lll_ll_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫ᪑")
		l11l11l11l_ll_ = l111lll_ll_ (u"ࠬอไๆี็ื้อสࠡษ็ัฬ๊๊สࠩ᪒")
		l11l11ll11_ll_ = l111lll_ll_ (u"࠭วๅ็ึุ่๊วห่ࠢีฯฮษࠡฯึฬࠥอไศฯาฯࠬ᪓")
		l11l11l1ll_ll_ = l111lll_ll_ (u"ࠧศๆ่ืู้ไศฬ้ࠣึะศสࠢะือࠦวๅษหะิ๐ษࠨ᪔")
		l11l11lll1_ll_ = l111lll_ll_ (u"ࠨษ็ฬะࠦวๅฯํࠤ้่ๆศหࠣห๏ࠦแ๋ๆ่ࠫ᪕")
		l11l11ll1l_ll_ = l111lll_ll_ (u"ࠩฦๅ้อๅࠨ᪖")
	elif lang==l111lll_ll_ (u"ࠪࡩࡳ࠭᪗"):
		l11l11l1l1_ll_ = l111lll_ll_ (u"ࠫࡘ࡫ࡡࡳࡥ࡫ࠤ࡮ࡴࠠࡴ࡫ࡷࡩࠬ᪘")
		l11l11l11l_ll_ = l111lll_ll_ (u"ࠬࡉࡵࡳࡴࡨࡲࡹࠦࡓࡦࡴ࡬ࡩࡸ࠭᪙")
		l11l11ll11_ll_ = l111lll_ll_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦࡳࡰࡴࡷࡩࡩࠦࡢࡺࠢࡏࡥࡹ࡫ࡳࡵࠩ᪚")
		l11l11l1ll_ll_ = l111lll_ll_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠠࡴࡱࡵࡸࡪࡪࠠࡣࡻࠣࡅࡱࡶࡨࡢࡤࡨࡸࠬ᪛")
		l11l11lll1_ll_ = l111lll_ll_ (u"ࠨࡎ࡬ࡺࡪࠦࡢࡳࡱࡤࡨࡨࡧࡳࡵࠢࡲࡪࠥ࡯ࡆࡪ࡮ࡰࠤࡨ࡮ࡡ࡯ࡰࡨࡰࠬ᪜")
		l11l11ll1l_ll_ = l111lll_ll_ (u"ࠩࡐࡳࡻ࡯ࡥࡴࠩ᪝")
	elif lang in [l111lll_ll_ (u"ࠪࡪࡦ࠭᪞"),l111lll_ll_ (u"ࠫ࡫ࡧ࠲ࠨ᪟")]:
		l11l11l1l1_ll_ = l111lll_ll_ (u"ࠬาำหฮ๋ࠤิืࠠิษ໏ฮࠬ᪠")
		l11l11l11l_ll_ = l111lll_ll_ (u"࠭ำา์ส่ࠥํวࠡฮสี໑࠭᪡")
		l11l11ll11_ll_ = l111lll_ll_ (u"ࠧิำํห้ࠦ็ศ่ࠢีฯฮࠠิษีํࠥฮัศีสืࠬ᪢")
		l11l11l1ll_ll_ = l111lll_ll_ (u"ࠨีิ๎ฬ๊่ࠠษ้ࠣึะศࠡฯิ์ๆࠦวๅใหหࠬ᪣")
		l11l11lll1_ll_ = l111lll_ll_ (u"ࠩກาูࠦา็ั๊ࠤฬุࠠศ์ࠣๅ๏๊ๅࠡๅส๊ฬ๊ࠧ᪤")
		l11l11ll1l_ll_ = l111lll_ll_ (u"ࠪๅ๏๊ๅࠨ᪥")
	l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ᪦"),l1l1l1l_ll_+l11l11lll1_ll_,l11l1l1lll_ll_,27)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᪧ"),l1l1l1l_ll_+l11l11l1l1_ll_,l11l1l1lll_ll_,29,l111lll_ll_ (u"࠭ࠧ᪨"),l111lll_ll_ (u"ࠧࠨ᪩"),l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ᪪"))
	html = l111ll1_ll_(l11l1l_ll_,l11l1l1lll_ll_+l111lll_ll_ (u"ࠩ࠲࡬ࡴࡳࡥࠨ᪫"),l111lll_ll_ (u"ࠪࠫ᪬"),l111lll_ll_ (u"ࠫࠬ᪭"),l111lll_ll_ (u"ࠬ࠭᪮"),l111lll_ll_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡅࡏࡗ࠰࠵ࡸࡺࠧ᪯"))
	#html = l111ll1_ll_(l11l1l_ll_,l11l1l1lll_ll_+l111lll_ll_ (u"ࠧ࠰ࡪࡲࡱࡪ࠵ࡩ࡯ࡦࡨࡼࠬ᪰"),l111lll_ll_ (u"ࠨࠩ᪱"),l111lll_ll_ (u"ࠩࠪ᪲"),l111lll_ll_ (u"ࠪࠫ᪳"),l111lll_ll_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡑࡊࡔࡕ࠮࠳ࡶࡸࠬ᪴"))
	l1lll_ll_=re.findall(l111lll_ll_ (u"ࠬࡨࡵࡵࡶࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠰ࡅࡲࡲࡹࡧࡣࡵ᪵ࠩ"),html,re.DOTALL)
	l11l1llll1_ll_ = [l111lll_ll_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ᪶࠭"),l111lll_ll_ (u"ࠧࡑࡴࡲ࡫ࡷࡧ࡭ࠨ᪷"),l111lll_ll_ (u"ࠨࡏࡸࡷ࡮ࡩ᪸ࠧ")]#,l111lll_ll_ (u"ࠩࡉ࡭ࡱࡳ᪹ࠧ")]
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽᪺ࠩ"),block,re.DOTALL)
	#l1ll1l_ll_(str(len(items)),str(items))
	for link,title in items:
		if any(value in link for value in l11l1llll1_ll_):
			#l1ll1l_ll_(link,str(title))
			url = l11l1l1lll_ll_+link
			if l111lll_ll_ (u"ࠫࡘ࡫ࡲࡪࡧࡶࠫ᪻") in link:
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ᪼"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡ᪽ࠪ")+l1l1l1l_ll_+l11l11l11l_ll_,url,22,l111lll_ll_ (u"ࠧࠨ᪾"),l111lll_ll_ (u"ࠨ࠳࠳࠴ᪿࠬ"))
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳᫀࠩ"),l1111l_ll_+l111lll_ll_ (u"ࠪࡣࡤࡥࠧ᫁")+l1l1l1l_ll_+l11l11ll11_ll_,url,22,l111lll_ll_ (u"ࠫࠬ᫂"),l111lll_ll_ (u"ࠬ࠷࠰࠲᫃ࠩ"))
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ᫄࠭"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ᫅")+l1l1l1l_ll_+l11l11l1ll_ll_,url,22,l111lll_ll_ (u"ࠨࠩ᫆"),l111lll_ll_ (u"ࠩ࠵࠴࠶࠭᫇"))
			elif l111lll_ll_ (u"ࠪࡑࡺࡹࡩࡤࠩ᫈") in link:
				if l1111l_ll_!=l111lll_ll_ (u"ࠫࠬ᫉"): title = l111lll_ll_ (u"๋่ࠬิ์ๅํ᫊ࠬ")
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫋"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫᫌ")+l1l1l1l_ll_+title,url,25,l111lll_ll_ (u"ࠨࠩᫍ"),l111lll_ll_ (u"ࠩ࠴࠴࠶࠭ᫎ"))
			elif l111lll_ll_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ᫏"):
				if l1111l_ll_!=l111lll_ll_ (u"ࠫࠬ᫐"): title = l111lll_ll_ (u"ࠬฮัศ็ฯࠫ᫑")
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫒"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ᫓")+l1l1l1l_ll_+title,url,22,l111lll_ll_ (u"ࠨࠩ᫔"),l111lll_ll_ (u"ࠩ࠴࠴࠶࠭᫕"))
			elif l111lll_ll_ (u"ࠪࡊ࡮ࡲ࡭ࠨ᫖"):
				if l1111l_ll_!=l111lll_ll_ (u"ࠫࠬ᫗"): title = l111lll_ll_ (u"ࠬ็๊ๅ็ࠪ᫘")
				l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫙"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ᫚")+l1l1l1l_ll_+l11l11ll1l_ll_,url,22,l111lll_ll_ (u"ࠨࠩ᫛"),l111lll_ll_ (u"ࠩ࠴࠴࠵࠭᫜"))
	return html
def l11l11l111_ll_(url):
	l11l1l1lll_ll_ = l11l11llll_ll_(url)
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠪࠫ᫝"),l111lll_ll_ (u"ࠫࠬ᫞"),l111lll_ll_ (u"ࠬ࠭᫟"),l111lll_ll_ (u"࠭ࡉࡇࡋࡏࡑ࠲ࡓࡕࡔࡋࡆࡣࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᫠"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡎࡷࡶ࡭ࡨ࠳ࡴࡰࡱ࡯ࡷ࠲࡮ࡥࡢࡦࡨࡶ࠭࠴ࠪࡀࠫࡐࡹࡸ࡯ࡣ࠮ࡤࡲࡨࡾ࠭᫡"),html,re.DOTALL)
	block = l1lll_ll_[0]
	title = re.findall(l111lll_ll_ (u"ࠨ࠾ࡳࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡵࡄࠧ᫢"),block,re.DOTALL)[0]
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ᫣"),l1l1l1l_ll_+title,url,22,l111lll_ll_ (u"ࠪࠫ᫤"),l111lll_ll_ (u"ࠫ࠶࠶࠱ࠨ᫥"))
	items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ᫦"),block,re.DOTALL)
	for link,title in items:
		link = l11l1l1lll_ll_ + link
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭᫧"),l1l1l1l_ll_+title,link,23,l111lll_ll_ (u"ࠧࠨ᫨"),l111lll_ll_ (u"ࠨ࠳࠳࠵ࠬ᫩"))
	return
def l1l11l1_ll_(url,page):
	l11l1l1lll_ll_ = l11l11llll_ll_(url)
	lang = l11l1ll11l_ll_(url)
	type = url.split(l111lll_ll_ (u"ࠩ࠲ࠫ᫪"))[-1]
	order = str(int(page)/100)
	page = str(int(page)%100)
	#l1ll1l_ll_(url, type)
	if type==l111lll_ll_ (u"ࠪࡗࡪࡸࡩࡦࡵࠪ᫫") and page==l111lll_ll_ (u"ࠫ࠵࠭᫬"):
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠬ࠭᫭"),l111lll_ll_ (u"࠭ࠧ᫮"),l111lll_ll_ (u"ࠧࠨ᫯"),l111lll_ll_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫ᫰"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶࡩࡷ࡯ࡡ࡭࠯ࡥࡳࡩࡿࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡷࡵࡷࠨ᫱"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠪ࠱࠮ࡄ࠯࠾࠯ࠬࡂ࡬࠸ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭᫲"),block,re.DOTALL)
		for link,img,title in items:
			title = l1l1l11ll_ll_(title)
			title = unescapeHTML(title)
			link = l11l1l1lll_ll_ + link
			img = l11l1l1lll_ll_ + l1lll111_ll_(img)
			l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ᫳"),l1l1l1l_ll_+title,link,23,img,order+l111lll_ll_ (u"ࠬ࠶࠱ࠨ᫴"))
	l11l111lll_ll_=0
	if type==l111lll_ll_ (u"࠭ࡓࡦࡴ࡬ࡩࡸ࠭᫵"): category=l111lll_ll_ (u"ࠧ࠴ࠩ᫶")
	if type==l111lll_ll_ (u"ࠨࡈ࡬ࡰࡲ࠭᫷"): category=l111lll_ll_ (u"ࠩ࠸ࠫ᫸")
	if type==l111lll_ll_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫ᫹"): category=l111lll_ll_ (u"ࠫ࠼࠭᫺")
	if type in [l111lll_ll_ (u"࡙ࠬࡥࡳ࡫ࡨࡷࠬ᫻"),l111lll_ll_ (u"࠭ࡐࡳࡱࡪࡶࡦࡳࠧ᫼"),l111lll_ll_ (u"ࠧࡇ࡫࡯ࡱࠬ᫽")] and page!=l111lll_ll_ (u"ࠨ࠲ࠪ᫾"):
		l1ll111_ll_ = l11l1l1lll_ll_+l111lll_ll_ (u"ࠩ࠲ࡌࡴࡳࡥ࠰ࡒࡤ࡫ࡪ࡯࡮ࡨࡋࡷࡩࡲࡅࡣࡢࡶࡨ࡫ࡴࡸࡹ࠾ࠩ᫿")+category+l111lll_ll_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪᬀ")+page+l111lll_ll_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬ࡯ࡳࡦࡨࡶࡧࡿ࠽ࠨᬁ")+order
		html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭ᬂ"),l111lll_ll_ (u"࠭ࠧᬃ"),l111lll_ll_ (u"ࠧࠨᬄ"),l111lll_ll_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡕࡋࡗࡐࡊ࡙࠭࠳ࡰࡧࠫᬅ"))
		#l1ll1l_ll_(l1ll111_ll_, html)
		items = re.findall(l111lll_ll_ (u"ࠩࠥࡍࡩࠨ࠺ࠩ࠰࠭ࡃ࠮࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠩ࠰࠭ࡃ࠮࠲࠮ࠬࡁࠥࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ᬆ"),html,re.DOTALL)
		for id,title,img in items:
			title = l1l1l11ll_ll_(title)
			title = title.replace(l111lll_ll_ (u"ࠪࡠࡡ࠭ᬇ"),l111lll_ll_ (u"ࠫࠬᬈ"))
			title = title.replace(l111lll_ll_ (u"ࠬࠨࠧᬉ"),l111lll_ll_ (u"࠭ࠧᬊ"))
			l11l111lll_ll_ += 1
			link = l11l1l1lll_ll_ + l111lll_ll_ (u"ࠧ࠰ࠩᬋ") + type + l111lll_ll_ (u"ࠨ࠱ࡆࡳࡳࡺࡥ࡯ࡶ࠲ࠫᬌ") + id
			img = l11l1l1lll_ll_ + l1lll111_ll_(img)
			if type==l111lll_ll_ (u"ࠩࡉ࡭ࡱࡳࠧᬍ"): l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩᬎ"),l1l1l1l_ll_+title,link,24,img,order+l111lll_ll_ (u"ࠫ࠵࠷ࠧᬏ"))
			else: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᬐ"),l1l1l1l_ll_+title,link,23,img,order+l111lll_ll_ (u"࠭࠰࠲ࠩᬑ"))
	if type==l111lll_ll_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭ᬒ"):
		html = l111ll1_ll_(l111l11_ll_,l11l1l1lll_ll_+l111lll_ll_ (u"ࠨ࠱ࡐࡹࡸ࡯ࡣ࠰ࡋࡱࡨࡪࡾ࠿ࡱࡣࡪࡩࡂ࠭ᬓ")+page,l111lll_ll_ (u"ࠩࠪᬔ"),l111lll_ll_ (u"ࠪࠫᬕ"),l111lll_ll_ (u"ࠫࠬᬖ"),l111lll_ll_ (u"ࠬࡏࡆࡊࡎࡐ࠱࡙ࡏࡔࡍࡇࡖ࠱࠸ࡸࡤࠨᬗ"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰ࠰ࡨࡪࡳ࡯ࠩ࠰࠭ࡃ࠮ࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯࠯ࡧࡩࡲࡵࠧᬘ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾࡫࠷ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠳࠿ࠩᬙ"),block,re.DOTALL)
		for link,img,title in items:
			l11l111lll_ll_ += 1
			img = l11l1l1lll_ll_ + img
			link = l11l1l1lll_ll_ + link
			l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᬚ"),l1l1l1l_ll_+title,link,23,img,l111lll_ll_ (u"ࠩ࠴࠴࠶࠭ᬛ"))
	if l11l111lll_ll_>20:
		title=l111lll_ll_ (u"ูࠪๆำษࠡࠩᬜ")
		if lang==l111lll_ll_ (u"ࠫࡪࡴࠧᬝ"): title = l111lll_ll_ (u"ࠬࡖࡡࡨࡧࠣࠫᬞ")
		if lang==l111lll_ll_ (u"࠭ࡦࡢࠩᬟ"): title = l111lll_ll_ (u"ࠧึใะ๋ࠥ࠭ᬠ")
		if lang==l111lll_ll_ (u"ࠨࡨࡤ࠶ࠬᬡ"): title = l111lll_ll_ (u"ุࠩๅาํࠠࠨᬢ")
		for l11l1l11l1_ll_ in range(1,11) :
			if not page==str(l11l1l11l1_ll_):
				counter = l111lll_ll_ (u"ࠪ࠴ࠬᬣ")+str(l11l1l11l1_ll_)
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᬤ"),l1l1l1l_ll_+title+str(l11l1l11l1_ll_),url,22,l111lll_ll_ (u"ࠬ࠭ᬥ"),order+counter[-2:])
	return
def l1l11ll_ll_(url,page):
	l11l1l1lll_ll_ = l11l11llll_ll_(url)
	lang = l11l1ll11l_ll_(url)
	parts = url.split(l111lll_ll_ (u"࠭࠯ࠨᬦ"))
	id,type = parts[-1],parts[3]
	order = str(int(page)/100)
	page = str(int(page)%100)
	l11l111lll_ll_=0
	#l1ll1l_ll_(url, type)
	if type==l111lll_ll_ (u"ࠧࡔࡧࡵ࡭ࡪࡹࠧᬧ"):
		html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠨࠩᬨ"),l111lll_ll_ (u"ࠩࠪᬩ"),l111lll_ll_ (u"ࠪࠫᬪ"),l111lll_ll_ (u"ࠫࡎࡌࡉࡍࡏ࠰ࡉࡕࡏࡓࡐࡆࡈࡗ࠲࠷ࡳࡵࠩᬫ"))
		items = re.findall(l111lll_ll_ (u"ࠬࡉ࡯࡮࡯ࡨࡲࡹࡥࡰࡢࡰࡨࡰࡤࡏࡴࡦ࡯࠱࠮ࡄࡶ࠾ࠩ࠰࠭ࡃ࠮ࡂࡩ࠯࠭ࡂࡺࡦࡸࠠࡪࡰࡷࡩࡷࡥࠠ࠾ࠢࠫ࠲࠯ࡅࠩ࠼࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩ࡝ࠩ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡹࡷࡲ࠽ࠣࠪ࠱࠮ࡄ࠯࡜ࠨࠩᬬ"),html,re.DOTALL)
		title = l111lll_ll_ (u"࠭ࠠ࠮ࠢส่า๊โสࠢࠪᬭ")
		if lang==l111lll_ll_ (u"ࠧࡦࡰࠪᬮ"): title = l111lll_ll_ (u"ࠨࠢ࠰ࠤࡊࡶࡩࡴࡱࡧࡩࠥ࠭ᬯ")
		if lang==l111lll_ll_ (u"ࠩࡩࡥࠬᬰ"): title = l111lll_ll_ (u"ࠪࠤ࠲ࠦโิ็อࠤࠬᬱ")
		if lang==l111lll_ll_ (u"ࠫ࡫ࡧ࠲ࠨᬲ"): title = l111lll_ll_ (u"ࠬࠦ࠭ࠡไึ้ฯࠦࠧᬳ")
		if lang==l111lll_ll_ (u"࠭ࡦࡢ᬴ࠩ"): l11l1l1l1l_ll_ = l111lll_ll_ (u"ࠧࠨᬵ")
		else: l11l1l1l1l_ll_ = lang
		l11l1ll1l1_ll_ = re.findall(l111lll_ll_ (u"ࠨࡦࡤࡸࡦ࠳ࡶࡪࡦࡨࡳࡂࠨࠨ࠯ࠬࡂ࠭࠭ࡢࠧ࠯ࠬࡂࡠࠬࡥࠩࠩ࠰࠭ࡃ࠮ࠨ࠾ࠨᬶ"),html,re.DOTALL)
		for name,count,img,link in items:
			for episode in range(int(count),0,-1):
				l1l1l1l1l_ll_ = img + l11l1l1l1l_ll_ + id + l111lll_ll_ (u"ࠩ࠲ࠫᬷ") + str(episode) + l111lll_ll_ (u"ࠪ࠲ࡵࡴࡧࠨᬸ")
				#l11l1l111l_ll_ = link + l11l1l1l1l_ll_ + id + l111lll_ll_ (u"ࠫ࠴࠭ᬹ") + str(episode) + l111lll_ll_ (u"ࠬ࠴࡭ࡱ࠶ࠪᬺ")
				l11l1l111l_ll_ = l11l1ll1l1_ll_[0][0]+lang+id+l111lll_ll_ (u"࠭࠯࠭ࠩᬻ")+str(episode)+l111lll_ll_ (u"ࠧ࠭ࠩᬼ")+str(episode)+l111lll_ll_ (u"ࠨࡡࠪᬽ")+l11l1ll1l1_ll_[0][2]
				l11l11l11l_ll_ = name + title + str(episode)
				l11l11l11l_ll_ = unescapeHTML(l11l11l11l_ll_)
				l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᬾ"),l1l1l1l_ll_+l11l11l11l_ll_,l11l1l111l_ll_,24,l1l1l1l1l_ll_)
	if type==l111lll_ll_ (u"ࠪࡔࡷࡵࡧࡳࡣࡰࠫᬿ"):
		l1ll111_ll_ = l11l1l1lll_ll_+l111lll_ll_ (u"ࠫ࠴ࡎ࡯࡮ࡧ࠲ࡔࡦ࡭ࡥࡪࡰࡪࡅࡹࡺࡡࡤࡪࡰࡩࡳࡺࡉࡵࡧࡰࡃ࡮ࡪ࠽ࠨᭀ")+str(id)+l111lll_ll_ (u"ࠬࠬࡰࡢࡩࡨࡁࠬᭁ")+page+l111lll_ll_ (u"࠭ࠦࡴ࡫ࡽࡩࡂ࠹࠰ࠧࡱࡵࡨࡪࡸࡢࡺ࠿࠴ࠫᭂ")
		html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠧࠨᭃ"),l111lll_ll_ (u"ࠨ᭄ࠩ"),l111lll_ll_ (u"ࠩࠪᭅ"),l111lll_ll_ (u"ࠪࡍࡋࡏࡌࡎ࠯ࡈࡔࡎ࡙ࡏࡅࡇࡖ࠱࠷ࡴࡤࠨᭆ"))
		items = re.findall(l111lll_ll_ (u"ࠫࡊࡶࡩࡴࡱࡧࡩࠧࡀࠨ࠯ࠬࡂ࠭࠱࠴ࠪࡀࡋࡰࡥ࡬࡫ࡁࡥࡦࡵࡩࡸࡹ࡟ࡔࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡖࡪࡦࡨࡳࡆࡪࡤࡳࡧࡶࡷࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁࡇ࡭ࡸࡩࡲࡪࡲࡷ࡭ࡴࡴࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠧᭇ"),html,re.DOTALL)
		title = l111lll_ll_ (u"ࠬࠦ࠭ࠡษ็ั้่ษࠡࠩᭈ")
		if lang==l111lll_ll_ (u"࠭ࡥ࡯ࠩᭉ"): title = l111lll_ll_ (u"ࠧࠡ࠯ࠣࡉࡵ࡯ࡳࡰࡦࡨࠤࠬᭊ")
		if lang==l111lll_ll_ (u"ࠨࡨࡤࠫᭋ"): title = l111lll_ll_ (u"ࠩࠣ࠱่ࠥำๆฬࠣࠫᭌ")
		if lang==l111lll_ll_ (u"ࠪࡪࡦ࠸ࠧ᭍"): title = l111lll_ll_ (u"ࠫࠥ࠳ࠠใี่ฮࠥ࠭᭎")
		for episode,img,link,desc,name in items:
			l11l111lll_ll_ += 1
			l1l1l1l1l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(img)
			l11l1l111l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(link)
			name = l1l1l11ll_ll_(name)
			l11l11l11l_ll_ = name + title + str(episode)
			l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ᭏"),l1l1l1l_ll_+l11l11l11l_ll_,l11l1l111l_ll_,24,l1l1l1l1l_ll_)
	if type==l111lll_ll_ (u"࠭ࡍࡶࡵ࡬ࡧࠬ᭐"):
		if l111lll_ll_ (u"ࠧࡄࡱࡱࡸࡪࡴࡴࠨ᭑") in url and l111lll_ll_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪ᭒") not in url:
			l1ll111_ll_ = l11l1l1lll_ll_+l111lll_ll_ (u"ࠩ࠲ࡑࡺࡹࡩࡤ࠱ࡊࡩࡹ࡚ࡲࡢࡥ࡮ࡷࡇࡿ࠿ࡪࡦࡀࠫ᭓")+str(id)+l111lll_ll_ (u"ࠪࠪࡵࡧࡧࡦ࠿ࠪ᭔")+page+l111lll_ll_ (u"ࠫࠫࡹࡩࡻࡧࡀ࠷࠵ࠬࡴࡺࡲࡨࡁ࠵࠭᭕")
			html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠬ࠭᭖"),l111lll_ll_ (u"࠭ࠧ᭗"),l111lll_ll_ (u"ࠧࠨ᭘"),l111lll_ll_ (u"ࠨࡋࡉࡍࡑࡓ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠶ࡶࡩ࠭᭙"))
			items = re.findall(l111lll_ll_ (u"ࠩࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡗࡱ࡬ࡧࡪࡇࡤࡥࡴࡨࡷࡸࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡇࡦࡶࡴࡪࡱࡱࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠲ࠢࡕ࡫ࡷࡰࡪࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ᭚"),html,re.DOTALL)
			for img,link,name,title in items:
				l11l111lll_ll_ += 1
				l1l1l1l1l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(img)
				l11l1l111l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(link)
				l11l11l11l_ll_ = name + l111lll_ll_ (u"ࠪࠤ࠲ࠦࠧ᭛") + title
				l11l11l11l_ll_ = l11l11l11l_ll_.strip(l111lll_ll_ (u"ࠫࠥ࠭᭜"))
				l11l11l11l_ll_ = l1l1l11ll_ll_(l11l11l11l_ll_)
				l111_ll_(l111lll_ll_ (u"ࠬࡼࡩࡥࡧࡲࠫ᭝"),l1l1l1l_ll_+l11l11l11l_ll_,l11l1l111l_ll_,24,l1l1l1l1l_ll_)
		elif l111lll_ll_ (u"࠭ࡃ࡭࡫ࡳࡷࠬ᭞") in url:
			l1ll111_ll_ = l11l1l1lll_ll_+l111lll_ll_ (u"ࠧ࠰ࡏࡸࡷ࡮ࡩ࠯ࡈࡧࡷࡘࡷࡧࡣ࡬ࡵࡅࡽࡄ࡯ࡤ࠾࠲ࠩࡴࡦ࡭ࡥ࠾ࠩ᭟")+page+l111lll_ll_ (u"ࠨࠨࡶ࡭ࡿ࡫࠽࠴࠲ࠩࡸࡾࡶࡥ࠾࠳࠸ࠫ᭠")
			html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠩࠪ᭡"),l111lll_ll_ (u"ࠪࠫ᭢"),l111lll_ll_ (u"ࠫࠬ᭣"),l111lll_ll_ (u"ࠬࡏࡆࡊࡎࡐ࠱ࡊࡖࡉࡔࡑࡇࡉࡘ࠳࠴ࡵࡪࠪ᭤"))
			items = re.findall(l111lll_ll_ (u"࠭ࡉ࡮ࡣࡪࡩࡆࡪࡤࡳࡧࡶࡷࡤ࡙ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࡙࡭ࡩ࡫࡯ࡂࡦࡧࡶࡪࡹࡳࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ᭥"),html,re.DOTALL)
			for img,title,link in items:
				l11l111lll_ll_ += 1
				l1l1l1l1l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(img)
				l11l1l111l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(link)
				l11l11l11l_ll_ = title.strip(l111lll_ll_ (u"ࠧࠡࠩ᭦"))
				l11l11l11l_ll_ = l1l1l11ll_ll_(l11l11l11l_ll_)
				l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ᭧"),l1l1l1l_ll_+l11l11l11l_ll_,l11l1l111l_ll_,24,l1l1l1l1l_ll_)
		elif l111lll_ll_ (u"ࠩࡦࡥࡹ࡫ࡧࡰࡴࡼࠫ᭨") in url:
			if l111lll_ll_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠼ࠧ᭩") in url:
				html = l111ll1_ll_(l111l11_ll_,l11l1l1lll_ll_+l111lll_ll_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭᭪")+page+l111lll_ll_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠼ࠧ᭫"),l111lll_ll_ (u"᭬࠭ࠧ"),l111lll_ll_ (u"ࠧࠨ᭭"),l111lll_ll_ (u"ࠨࠩ᭮"),l111lll_ll_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠹ࡹ࡮ࠧ᭯"))
			elif l111lll_ll_ (u"ࠪࡧࡦࡺࡥࡨࡱࡵࡽࡂ࠺ࠧ᭰") in url:
				html = l111ll1_ll_(l111l11_ll_,l11l1l1lll_ll_+l111lll_ll_ (u"ࠫ࠴ࡓࡵࡴ࡫ࡦ࠳ࡌ࡫ࡴࡕࡴࡤࡧࡰࡹࡂࡺࡁ࡬ࡨࡂ࠶ࠦࡱࡣࡪࡩࡂ࠭᭱")+page+l111lll_ll_ (u"ࠬࠬࡳࡪࡼࡨࡁ࠸࠶ࠦࡵࡻࡳࡩࡂ࠺ࠧ᭲"),l111lll_ll_ (u"࠭ࠧ᭳"),l111lll_ll_ (u"ࠧࠨ᭴"),l111lll_ll_ (u"ࠨࠩ᭵"),l111lll_ll_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠺ࡹ࡮ࠧ᭶"))
			items = re.findall(l111lll_ll_ (u"ࠪࡍࡲࡧࡧࡦࡃࡧࡨࡷ࡫ࡳࡴࡡࡖࠦ࠿ࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡘࡲ࡭ࡨ࡫ࡁࡥࡦࡵࡩࡸࡹࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡈࡧࡰࡵ࡫ࡲࡲࠧࡀࠢࠩ࠰࠭ࡃ࠮ࠨࠬࠣࡖ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣࠩ᭷"),html,re.DOTALL)
			for img,link,name,title in items:
				l11l111lll_ll_ += 1
				l1l1l1l1l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(img)
				l11l1l111l_ll_ = l11l1ll111_ll_ + l1lll111_ll_(link)
				l11l11l11l_ll_ = name + l111lll_ll_ (u"ࠫࠥ࠳ࠠࠨ᭸") + title
				l11l11l11l_ll_ = l11l11l11l_ll_.strip(l111lll_ll_ (u"ࠬࠦࠧ᭹"))
				l11l11l11l_ll_ = l1l1l11ll_ll_(l11l11l11l_ll_)
				l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ᭺"),l1l1l1l_ll_+l11l11l11l_ll_,l11l1l111l_ll_,24,l1l1l1l1l_ll_)
	if type==l111lll_ll_ (u"ࠧࡎࡷࡶ࡭ࡨ࠭᭻") or type==l111lll_ll_ (u"ࠨࡒࡵࡳ࡬ࡸࡡ࡮ࠩ᭼"):
		if l11l111lll_ll_>25:
			title=l111lll_ll_ (u"ุࠩๅาฯࠠࠨ᭽")
			if lang==l111lll_ll_ (u"ࠪࡩࡳ࠭᭾"): title = l111lll_ll_ (u"ࠫࠥࡖࡡࡨࡧࠣࠫ᭿")
			if lang==l111lll_ll_ (u"ࠬ࡬ࡡࠨᮀ"): title = l111lll_ll_ (u"࠭ࠠึใะ๋ࠥ࠭ᮁ")
			if lang==l111lll_ll_ (u"ࠧࡧࡣ࠵ࠫᮂ"): title = l111lll_ll_ (u"ࠨุࠢๅาํࠠࠨᮃ")
			for l11l1l11l1_ll_ in range(1,11):
				if not page==str(l11l1l11l1_ll_):
					counter = l111lll_ll_ (u"ࠩ࠳ࠫᮄ")+str(l11l1l11l1_ll_)
					l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪᮅ"),l1l1l1l_ll_+title+str(l11l1l11l1_ll_),url,23,l111lll_ll_ (u"ࠫࠬᮆ"),order+counter[-2:])
	return
def l11_ll_(url):
	#logging.warning(l111lll_ll_ (u"ࠬ࡫࡭ࡢࡦ࠵࠾ࠥࠦࠧᮇ")+ url)
	l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬᮈ"))
	return
def l11l11llll_ll_(url):
	if l1ll1l1_ll_ in url: site = l1ll1l1_ll_
	elif l1l1llll1_ll_ in url: site = l1l1llll1_ll_
	elif l11l1l1111_ll_ in url: site = l11l1l1111_ll_
	elif l11l1l11ll_ll_ in url: site = l11l1l11ll_ll_
	return site
def l11l1ll11l_ll_(url):
	lang = l111lll_ll_ (u"ࠧࠨᮉ")
	if   l1ll1l1_ll_ in url: lang = l111lll_ll_ (u"ࠨࡣࡵࠫᮊ")
	elif l1l1llll1_ll_ in url: lang = l111lll_ll_ (u"ࠩࡨࡲࠬᮋ")
	elif l11l1l1111_ll_ in url: lang = l111lll_ll_ (u"ࠪࡪࡦ࠭ᮌ")
	elif l11l1l11ll_ll_ in url: lang = l111lll_ll_ (u"ࠫ࡫ࡧ࠲ࠨᮍ")
	return lang
def l1ll11ll1_ll_(url):
	lang = l11l1ll11l_ll_(url)
	l1ll111_ll_ = url + l111lll_ll_ (u"ࠬ࠵ࡈࡰ࡯ࡨ࠳ࡑ࡯ࡶࡦࠩᮎ")
	html = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"࠭ࠧᮏ"),l111lll_ll_ (u"ࠧࠨᮐ"),l111lll_ll_ (u"ࠨࠩᮑ"),l111lll_ll_ (u"ࠩࡌࡊࡎࡒࡍ࠮ࡎࡌ࡚ࡊ࠳࠱ࡴࡶࠪᮒ"))
	items = re.findall(l111lll_ll_ (u"ࠪࡷࡴࡻࡲࡤࡧࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨᮓ"),html,re.DOTALL)
	l11ll1_ll_ = items[0]
	l111lll1_ll_(l11ll1_ll_,l1ll_ll_,l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩᮔ"))
	return
def l1lll1_ll_(url,search=l111lll_ll_ (u"ࠬ࠭ᮕ")):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"࠭ࠧᮖ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠧࠨᮗ"): return
	if url==l111lll_ll_ (u"ࠨࠩᮘ") and l1ll11_ll_:
		l11l1lllll_ll_ = [ l1ll1l1_ll_ , l1l1llll1_ll_ , l11l1l1111_ll_ , l11l1l11ll_ll_ ]
		l11l1lll11_ll_ = [ l111lll_ll_ (u"ࠩ฼ีอ๐ࠧᮙ") , l111lll_ll_ (u"ࠪࡉࡳ࡭࡬ࡪࡵ࡫ࠫᮚ") , l111lll_ll_ (u"ࠫๆอัิ๋ࠪᮛ") , l111lll_ll_ (u"ࠬ็วาี์ࠤ࠷࠭ᮜ") ]
		selection = l1l1111_ll_(l111lll_ll_ (u"࠭วฯฬิࠤฬ๊ไ฻หࠣห้๋ๆศีหอ࠿࠭ᮝ"), l11l1lll11_ll_)
		if selection == -1 : return l111lll_ll_ (u"ࠧࠨᮞ")
		url = l11l1lllll_ll_[selection]
	else: url = l1ll1l1_ll_
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"ࠨࠢࠪᮟ"),l111lll_ll_ (u"ࠩ࠮ࠫᮠ"))
	lang = l11l1ll11l_ll_(url)
	l1ll111_ll_ = url + l111lll_ll_ (u"ࠥ࠳ࡍࡵ࡭ࡦ࠱ࡖࡩࡦࡸࡣࡩࡁࡶࡩࡦࡸࡣࡩࡵࡷࡶ࡮ࡴࡧ࠾ࠤᮡ") + l1llll1_ll_
	#l1ll1l_ll_(lang,l1ll111_ll_)
	html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠫࠬᮢ"),l111lll_ll_ (u"ࠬ࠭ᮣ"),l111lll_ll_ (u"࠭ࠧᮤ"),l111lll_ll_ (u"ࠧࡊࡈࡌࡐࡒ࠳ࡓࡆࡃࡕࡇࡍ࠳࠱ࡴࡶࠪᮥ"))
	items = re.findall(l111lll_ll_ (u"ࠨࠤࡌࡱࡦ࡭ࡥࡂࡦࡧࡶࡪࡹࡳࡠࡕࠥ࠾ࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࠣࡅࡤࡸࡪ࡭࡯ࡳࡻࡌࡨࠧࡀࠨ࠯ࠬࡂ࠭࠱ࠨࡉࡥࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠥࡘ࡮ࡺ࡬ࡦࠤ࠽ࠬ࠳࠰࠿ࠪ࠮ࠪᮦ"),html,re.DOTALL)
	if items:
		for img,category,id,title in items:
			if category==l111lll_ll_ (u"ࠩ࠶ࠫᮧ") or category==l111lll_ll_ (u"ࠪ࠻ࠬᮨ"):
				title = title.replace(l111lll_ll_ (u"ࠫࡡࡢࠧᮩ"),l111lll_ll_ (u"᮪ࠬ࠭"))
				title = title.replace(l111lll_ll_ (u"࠭ࠢࠨ᮫"),l111lll_ll_ (u"ࠧࠨᮬ"))
				if category==l111lll_ll_ (u"ࠨ࠵ࠪᮭ"):
					type = l111lll_ll_ (u"ࠩࡖࡩࡷ࡯ࡥࡴࠩᮮ")
					if lang==l111lll_ll_ (u"ࠪࡥࡷ࠭ᮯ"): name = l111lll_ll_ (u"ู๊ࠫไิๆࠣ࠾ࠥ࠭᮰")
					elif lang==l111lll_ll_ (u"ࠬ࡫࡮ࠨ᮱"): name = l111lll_ll_ (u"࠭ࡓࡦࡴ࡬ࡩࡸࠦ࠺ࠡࠩ᮲")
					elif lang==l111lll_ll_ (u"ࠧࡧࡣࠪ᮳"): name = l111lll_ll_ (u"ࠨีิ๎ฬ๊่ࠠษࠣ࠾ࠥ࠭᮴")
					elif lang==l111lll_ll_ (u"ࠩࡩࡥ࠷࠭᮵"): name = l111lll_ll_ (u"ࠪืึ๐วๅ๊ࠢหࠥࡀࠠࠨ᮶")
				if category==l111lll_ll_ (u"ࠫ࠼࠭᮷"):
					type = l111lll_ll_ (u"ࠬࡖࡲࡰࡩࡵࡥࡲ࠭᮸")
					if lang==l111lll_ll_ (u"࠭ࡡࡳࠩ᮹"): name = l111lll_ll_ (u"ࠧษำ้ห๊าࠠ࠻ࠢࠪᮺ")
					elif lang==l111lll_ll_ (u"ࠨࡧࡱࠫᮻ"): name = l111lll_ll_ (u"ࠩࡓࡶࡴ࡭ࡲࡢ࡯ࠣ࠾ࠥ࠭ᮼ")
					elif lang==l111lll_ll_ (u"ࠪࡪࡦ࠭ᮽ"): name = l111lll_ll_ (u"ࠫอืๆศ็๊ࠤ์อࠠ࠻ࠢࠪᮾ")
					elif lang==l111lll_ll_ (u"ࠬ࡬ࡡ࠳ࠩᮿ"): name = l111lll_ll_ (u"࠭ศา่ส้์ࠦ็ศࠢ࠽ࠤࠬᯀ")
				title = name + title
				link = url + l111lll_ll_ (u"ࠧ࠰ࠩᯁ") + type + l111lll_ll_ (u"ࠨ࠱ࡆࡳࡳࡺࡥ࡯ࡶ࠲ࠫᯂ") + id
				img = url + l1lll111_ll_(img)
				l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᯃ"),l1l1l1l_ll_+title,link,23,img,l111lll_ll_ (u"ࠪ࠵࠵࠷ࠧᯄ"))
	#else: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็หี๊าࠧᯅ"),,لا توجد نتائج للبحث')
	return