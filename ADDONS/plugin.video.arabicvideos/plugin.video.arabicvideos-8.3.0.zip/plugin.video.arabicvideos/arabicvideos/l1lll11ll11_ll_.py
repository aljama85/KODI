# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠧࡔࡇࡕࡍࡊ࡙࠴ࡘࡃࡗࡇࡍ࠭㨔")
headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ㨕") : l111lll_ll_ (u"ࠩࠪ㨖") }
l1l1l1l_ll_=l111lll_ll_ (u"ࠪࡣࡘࡌࡗࡠࠩ㨗")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==210: results = l11l1ll_ll_(url)
	elif mode==211: results = l1l11l1_ll_(url)
	elif mode==212: results = l11_ll_(url)
	elif mode==213: results = l1l11ll_ll_(url)
	elif mode==214: results = l1l11l111l1l_ll_(url)
	elif mode==215: results = l1l11l111ll1_ll_(url)
	elif mode==218: results = l11ll1l1l1_ll_()
	elif mode==219: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11ll1l1l1_ll_():
	message = l111lll_ll_ (u"ࠫ์ึวࠡษ็้ํู่ࠡฬ฽๎ึࠦศศๆๆห๊๊ࠠ࠯࠰࠱ࠤํฮอศฮฬࠤฬ๊้ࠡษ฼หิฯࠠษำ่ะฮࠦๅ็ࠢสฺ่็ัࠡ࠰࠱࠲ࠥ๎วๅ็หี๊าࠠฮษ็๎ฬࠦๅี฼๋่ࠥ๎ฺ๊ษ้๎๋ࠥๆ๊ࠡ฼็ฮࠦีฮ์ฬࠤ࠳࠴࠮๊ࠡ็๋ีอࠠิ๊ไࠤ๏ฮโ๊ࠢส่๊๎โฺ่ࠢ฾้่ࠠศๆ์ࠤ๊อࠠีษฤࠤฬ๊ไ่ࠩ㨘")
	l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ㨙"),l111lll_ll_ (u"࠭วๅ็๋ๆ฾ࠦส฻์ิࠤออไไษ่่ࠬ㨚"),message)
	return
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠧࠨ㨛")):
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㨜"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ㨝"),l111lll_ll_ (u"ࠪࠫ㨞"),219,l111lll_ll_ (u"ࠫࠬ㨟"),l111lll_ll_ (u"ࠬ࠭㨠"),l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㨡"))
	#l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ㨢"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨใ็ฮึ࠭㨣"),l111lll_ll_ (u"ࠩࠪ㨤"),114,l1ll1l1_ll_)
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡖࡩ࡯ࡁࡷࡽࡵ࡫࠽ࡰࡰࡨࠪࡩࡧࡴࡢ࠿ࡳ࡭ࡳࠬ࡬ࡪ࡯࡬ࡸࡂ࠸࠵ࠨ㨥")
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㨦"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ㨧")+l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅ็่๎ืฯࠧ㨨"),url,211)
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"ࠧࠨ㨩"),headers,l111lll_ll_ (u"ࠨࠩ㨪"),l111lll_ll_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡏࡈࡒ࡚࠳࠱ࡴࡶࠪ㨫"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡊ࡮ࡲࡴࡦࡴࡶࡆࡺࡺࡴࡰࡰࡶࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㨬"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫࡩࡧࡴࡢ࠯ࡪࡩࡹࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿࠳࡮ࡄࠨ࠯ࠬࡂ࠭ࡁ࠭㨭"),block,re.DOTALL)
	for link,title in items:#[1:-1]:
		url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡶࡼࡴࡪࡃ࡯࡯ࡧࠩࡨࡦࡺࡡ࠾ࠩ㨮")+link
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㨯"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ㨰")+l1l1l1l_ll_+title,url,211)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡰࡤࡺ࡮࡭ࡡࡵ࡫ࡲࡲ࠲ࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩ࠽࠱ࡧ࡭ࡻࡄࠧ㨱"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࡫ࡸࡹࡶ࠮ࠫࡁࠬࠦࡃ࠮࠮ࠫࡁࠬࡀࠬ㨲"),block,re.DOTALL)
	l11lll1_ll_ = [l111lll_ll_ (u"ุ้๊ࠪำๅษอࠤฬ์ๅ๋ࠩ㨳"),l111lll_ll_ (u"ࠫฬ๊ัว์ึ๎ฮ࠭㨴")]
	#l11ll11l1_ll_ = [l111lll_ll_ (u"๋ࠬำๅี็หฯࠦࠧ㨵"),l111lll_ll_ (u"࠭วโๆส้ࠥ࠭㨶"),l111lll_ll_ (u"ࠧษำส้ั࠭㨷"),l111lll_ll_ (u"ࠨ฻ิ์฻࠭㨸"),l111lll_ll_ (u"ࠩๆ่๏ฮวหࠩ㨹"),l111lll_ll_ (u"ࠪห฿อๆ๊ࠩ㨺")]
	for link,title in items:
		title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭㨻"))
		if not any(value in title for value in l11lll1_ll_):
		#	if any(value in title for value in l11ll11l1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㨼"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ㨽")+l1l1l1l_ll_+title,link,211)
	return html
def l1l11l1_ll_(url):
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠧࠨ㨾"),headers,l111lll_ll_ (u"ࠨࠩ㨿"),l111lll_ll_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡖࡌࡘࡑࡋࡓ࠮࠳ࡶࡸࠬ㩀"))
	#l1ll1l_ll_(url,html)
	if l111lll_ll_ (u"ࠪ࡫ࡪࡺࡰࡰࡵࡷࡷࠬ㩁") in url or l111lll_ll_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࡄࡹ࠽ࠨ㩂") in url: block = html
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡓࡥࡥ࡫ࡤࡋࡷ࡯ࡤࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫ㩃"),html,re.DOTALL)
		if l1lll_ll_: block = l1lll_ll_[0]
		else: return
	items = re.findall(l111lll_ll_ (u"࠭ࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿࠽ࡪ࠶ࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㩄"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	l11lllll1_ll_ = [l111lll_ll_ (u"ࠧๆึส๋ิฯࠧ㩅"),l111lll_ll_ (u"ࠨใํ่๊࠭㩆"),l111lll_ll_ (u"ࠩส฾๋๐ษࠨ㩇"),l111lll_ll_ (u"ࠪ็้๐ศࠨ㩈"),l111lll_ll_ (u"ࠫฬ฿ไศ่ࠪ㩉"),l111lll_ll_ (u"ࠬํฯศใࠪ㩊"),l111lll_ll_ (u"࠭ๅษษิหฮ࠭㩋"),l111lll_ll_ (u"ฺࠧำูࠫ㩌"),l111lll_ll_ (u"ࠨ็๊ีัอๆࠨ㩍"),l111lll_ll_ (u"ࠩส่อ๎ๅࠨ㩎")]
	for img,link,title in items:
		if l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡲࡪࡧࡶ࠳ࠬ㩏") in link: continue
		link = l1111_ll_(link).strip(l111lll_ll_ (u"ࠫ࠴࠭㩐"))
		title = unescapeHTML(title)
		title = title.strip(l111lll_ll_ (u"ࠬࠦࠧ㩑"))
		if l111lll_ll_ (u"࠭࠯ࡧ࡫࡯ࡱ࠴࠭㩒") in link or any(value in title for value in l11lllll1_ll_):
			l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㩓"),l1l1l1l_ll_+title,link,212,img)
		elif l111lll_ll_ (u"ࠨ࠱ࡨࡴ࡮ࡹ࡯ࡥࡧ࠲ࠫ㩔") in link and l111lll_ll_ (u"ࠩส่า๊โสࠩ㩕") in title:
			episode = re.findall(l111lll_ll_ (u"ࠪࠬ࠳࠰࠿ࠪࠢส่า๊โสࠢ࡟ࡨ࠰࠭㩖"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠫࡤࡓࡏࡅࡡࠪ㩗") + episode[0]
				if title not in l1ll11ll_ll_:
					l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩘"),l1l1l1l_ll_+title,link,213,img)
					l1ll11ll_ll_.append(title)
		else: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㩙"),l1l1l1l_ll_+title,link,213,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡱࡣࡪ࡭ࡳࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ㩚"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨ࠾ࡤࠤ࡭ࡸࡥࡧ࠿࡞ࠦࡡ࠭࡝ࠩࡪࡷࡸࡵ࠴ࠪࡀࠫ࡞ࠦࡡ࠭࡝࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ㩛"),block,re.DOTALL)
		for link,title in items:
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			title = title.replace(l111lll_ll_ (u"ࠩสฺ่็อสࠢࠪ㩜"),l111lll_ll_ (u"ࠪࠫ㩝"))
			if title!=l111lll_ll_ (u"ࠫࠬ㩞"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩟"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ีโฯฬࠤࠬ㩠")+title,link,211)
	return
def l1l11ll_ll_(url):
	l1l11111l_ll_,items,l11l1111_ll_ = -1,[],[]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠧࠨ㩡"),headers,l111lll_ll_ (u"ࠨࠩ㩢"),l111lll_ll_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧ㩣"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡸ࡮࠳࡬ࡪࡵࡷ࠱ࡳࡻ࡭ࡣࡧࡵࡩࡩ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ㩤"),html,re.DOTALL)
	if l1lll_ll_:
		l1lll1l_ll_ = l111lll_ll_ (u"ࠫࠬ㩥").join(l1lll_ll_)
		items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ㩦"),l1lll1l_ll_,re.DOTALL)
	items.append(url)
	items = set(items)
	#name = xbmc.getInfoLabel(l111lll_ll_ (u"࠭ࡌࡪࡵࡷࡍࡹ࡫࡭࠯ࡎࡤࡦࡪࡲࠧ㩧"))
	for link in items:
		link = link.strip(l111lll_ll_ (u"ࠧ࠰ࠩ㩨"))
		title = l111lll_ll_ (u"ࠨࡡࡐࡓࡉࡥࠧ㩩") + link.split(l111lll_ll_ (u"ࠩ࠲ࠫ㩪"))[-1].replace(l111lll_ll_ (u"ࠪ࠱ࠬ㩫"),l111lll_ll_ (u"ࠫࠥ࠭㩬"))
		sequence = re.findall(l111lll_ll_ (u"ࠬอไฮๆๅอ࠲࠮࡜ࡥ࠭ࠬࠫ㩭"),link.split(l111lll_ll_ (u"࠭࠯ࠨ㩮"))[-1],re.DOTALL)
		if sequence: sequence = sequence[0]
		else: sequence = l111lll_ll_ (u"ࠧ࠱ࠩ㩯")
		l11l1111_ll_.append([link,title,sequence])
	items = sorted(l11l1111_ll_, reverse=False, key=lambda key: int(key[2]))
	l11llllll_ll_ = str(items).count(l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡹ࡯࡯࠱ࠪ㩰"))
	l1l11111l_ll_ = str(items).count(l111lll_ll_ (u"ࠩ࠲ࡩࡵ࡯ࡳࡰࡦࡨ࠳ࠬ㩱"))
	if l11llllll_ll_>1 and l1l11111l_ll_>0 and l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡴࡱࡱ࠳ࠬ㩲") not in url:
		for link,title,sequence in items:
			if l111lll_ll_ (u"ࠫ࠴ࡹࡥࡢࡵࡲࡲ࠴࠭㩳") in link: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㩴"),l1l1l1l_ll_+title,link,213)
	else:
		for link,title,sequence in items:
			if l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡷࡴࡴ࠯ࠨ㩵") not in link: l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭㩶"),l1l1l1l_ll_+title,link,212)
	return
def l11_ll_(url):
	l1l111l_ll_ = []
	parts = url.split(l111lll_ll_ (u"ࠨ࠱ࠪ㩷"))
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠩࠪ㩸"),headers,l111lll_ll_ (u"ࠪࠫ㩹"),l111lll_ll_ (u"ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬ㩺"))
	# watch links
	if l111lll_ll_ (u"ࠬ࠵ࡷࡢࡶࡦ࡬࠴࠭㩻") in html:
		l1ll111_ll_ = url.replace(parts[3],l111lll_ll_ (u"࠭ࡷࡢࡶࡦ࡬ࠬ㩼"))
		l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠧࠨ㩽"),headers,l111lll_ll_ (u"ࠨࠩ㩾"),l111lll_ll_ (u"ࠩࡖࡉࡗࡏࡅࡔ࠶࡚ࡅ࡙ࡉࡈ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ㩿"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡸࡶࡦࡴࡶ࠱ࡱ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㪀"),l1l111l1_ll_,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠫࡩࡧࡴࡢ࠯ࡨࡱࡧ࡫ࡤࡥ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡹࡥࡳࡸࡨࡶࡤ࡯࡭ࡢࡩࡨࠦࡃࡢ࡮ࠩ࠰࠭ࡃ࠮ࡢ࡮ࠨ㪁"),block,re.DOTALL)
			if items:
				id = re.findall(l111lll_ll_ (u"ࠬࡶ࡯ࡴࡶࡢ࡭ࡩࡃࠨ࠯ࠬࡂ࠭ࠧ࠭㪂"),l1l111l1_ll_,re.DOTALL)
				if id:
					l111ll1ll_ll_ = id[0]
					for link,title in items:
						link = l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡀࡲࡲࡷࡹ࡯ࡤ࠾ࠩ㪃")+l111ll1ll_ll_+l111lll_ll_ (u"ࠧࠧࡵࡨࡶࡻ࡫ࡲࡪࡦࡀࠫ㪄")+link+l111lll_ll_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩ㪅")+title+l111lll_ll_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪ㪆")
						l1l111l_ll_.append(link)
			else:
				# l1ll1l1l_ll_://l1l11l111lll_ll_.tv/watch/مشاهدة-برنامج-نفسنة-تقديم-انتصار-وهيدى-وشيماء-حلقة-1
				items = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡧࡰࡦࡪࡪࡤ࠾ࠤ࠱࠮ࡄ࠮ࡨࡵࡶࡳ࠲࠯ࡅࠩࠩࠤࡿࠪࡶࡻ࡯ࡵ࠽ࠬࠫ㪇"),block,re.DOTALL)
				for link,dummy in items:
					l1l111l_ll_.append(link)
	# download links
	if l111lll_ll_ (u"ࠫ࠴ࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࠯ࠨ㪈") in html:
		l1ll111_ll_ = url.replace(parts[3],l111lll_ll_ (u"ࠬࡪ࡯ࡸࡰ࡯ࡳࡦࡪࠧ㪉"))
		l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"࠭ࠧ㪊"),headers,l111lll_ll_ (u"ࠧࠨ㪋"),l111lll_ll_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎ࠭ࡑࡎࡄ࡝࠲࠹ࡲࡥࠩ㪌"))
		id = re.findall(l111lll_ll_ (u"ࠩࡳࡳࡸࡺࡉࡥ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ㪍"),l1l111l1_ll_,re.DOTALL)
		if id:
			l111ll1ll_ll_ = id[0]
			l1ll11l1l_ll_ = { l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㪎"):l111lll_ll_ (u"ࠫࠬ㪏") , l111lll_ll_ (u"ࠬ࡞࠭ࡓࡧࡴࡹࡪࡹࡴࡦࡦ࠰࡛࡮ࡺࡨࠨ㪐"):l111lll_ll_ (u"࠭ࡘࡎࡎࡋࡸࡹࡶࡒࡦࡳࡸࡩࡸࡺࠧ㪑") }
			l1ll111_ll_ = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࡣ࡭ࡥࡽࡉࡥ࡯ࡶࡨࡶࡄࡥࡡࡤࡶ࡬ࡳࡳࡃࡧࡦࡶࡧࡳࡼࡴ࡬ࡰࡣࡧࡰ࡮ࡴ࡫ࡴࠨࡳࡳࡸࡺࡉࡥ࠿ࠪ㪒")+l111ll1ll_ll_
			l1l111l1_ll_ = l111ll1_ll_(l11l1l_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩ㪓"),l1ll11l1l_ll_,l111lll_ll_ (u"ࠩࠪ㪔"),l111lll_ll_ (u"ࠪࡗࡊࡘࡉࡆࡕ࠷࡛ࡆ࡚ࡃࡉ࠯ࡓࡐࡆ࡟࠭࠵ࡶ࡫ࠫ㪕"))
			l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡁ࡮࠳࠯ࠬࡂࠬࡡࡪࠫࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡦ࡬ࡺࡃ࠭㪖"),l1l111l1_ll_,re.DOTALL)
			if l1lll_ll_:
				for resolution,block in l1lll_ll_:
					items = re.findall(l111lll_ll_ (u"ࠬࡂࡴࡥࡀࠫ࠲࠯ࡅࠩ࠽࠰࠭ࡃ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ㪗"),block,re.DOTALL)
					for name,link in items:
						l1l111l_ll_.append(link+l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㪘")+name+l111lll_ll_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㪙")+l111lll_ll_ (u"ࠨࡡࡢࡣࡤ࠭㪚")+resolution)
			else:
				l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࠿࡬࠻࠮࠮ࠫࡁࠬࡀ࠴ࡺࡡࡣ࡮ࡨࡂࠬ㪛"),l1l111l1_ll_,re.DOTALL)
				if not l1lll_ll_: l1lll_ll_ = [l1l111l1_ll_]
				for block in l1lll_ll_:
					l111lll_ll_ (u"ࠥࠦࠧࠐࠉࠊࠋࠌࠍࡳࡧ࡭ࡦࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡩࡷࡼࡥࡳࡵࡗ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫ࠱ࡨ࡬ࡰࡥ࡮࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࠍࠎࠏࡩࡧࠢࡱࡥࡲ࡫࠺ࠋࠋࠌࠍࠎࠏࠉ࡯ࡣࡰࡩࠥࡃࠠ࡯ࡣࡰࡩࡠ࠳࠱࡞࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫฬ๊ฯใหࠣࠫ࠱࠭ࠧࠪ࠰ࡵࡩࡵࡲࡡࡤࡧࠫࠫࡡࡴࠧ࠭ࠩࠪ࠭ࠏࠏࠉࠊࠋࠌࠍ࡮࡬ࠠ࡯ࡣࡰࡩࠦࡃࠧࠨ࠼ࠣࡲࡦࡳࡥࠡ࠿ࠣࡲࡦࡳࡥࠡ࠭ࠣࠫࠥๆࠠࠨࠌࠌࠍࠎࠏࠉࡦ࡮ࡶࡩ࠿ࠦ࡮ࡢ࡯ࡨࠤࡂࠦࠧࠨࠌࠌࠍࠎࠏࠉࠣࠤࠥ㪜")
					name = l111lll_ll_ (u"ࠫࠬ㪝")
					items = re.findall(l111lll_ll_ (u"ࠬ࡮ࡲࡦࡨࡀࠦ࠭࡮ࡴࡵࡲ࠱࠮ࡄ࠯ࠢࠨ㪞"),block,re.DOTALL)
					for link in items:
						server = l111lll_ll_ (u"࠭ࠦࠧࠩ㪟") + link.split(l111lll_ll_ (u"ࠧ࠰ࠩ㪠"))[2].lower() + l111lll_ll_ (u"ࠨࠨࠩࠫ㪡")
						server = server.replace(l111lll_ll_ (u"ࠩ࠱ࡧࡴࡳࠦࠧࠩ㪢"),l111lll_ll_ (u"ࠪࠫ㪣")).replace(l111lll_ll_ (u"ࠫ࠳ࡩ࡯ࠧࠨࠪ㪤"),l111lll_ll_ (u"ࠬ࠭㪥"))
						server = server.replace(l111lll_ll_ (u"࠭࠮࡯ࡧࡷࠪࠫ࠭㪦"),l111lll_ll_ (u"ࠧࠨ㪧")).replace(l111lll_ll_ (u"ࠨ࠰ࡲࡶ࡬ࠬࠦࠨ㪨"),l111lll_ll_ (u"ࠩࠪ㪩"))
						server = server.replace(l111lll_ll_ (u"ࠪ࠲ࡱ࡯ࡶࡦࠨࠩࠫ㪪"),l111lll_ll_ (u"ࠫࠬ㪫")).replace(l111lll_ll_ (u"ࠬ࠴࡯࡯࡮࡬ࡲࡪࠬࠦࠨ㪬"),l111lll_ll_ (u"࠭ࠧ㪭"))
						server = server.replace(l111lll_ll_ (u"ࠧࠧࠨ࡫ࡨ࠳࠭㪮"),l111lll_ll_ (u"ࠨࠩ㪯")).replace(l111lll_ll_ (u"ࠩࠩࠪࡼࡽࡷ࠯ࠩ㪰"),l111lll_ll_ (u"ࠪࠫ㪱"))
						server = server.replace(l111lll_ll_ (u"ࠫࠫࠬࠧ㪲"),l111lll_ll_ (u"ࠬ࠭㪳"))
						link = link + l111lll_ll_ (u"࠭࠿࡯ࡣࡰࡩࡩࡃࠧ㪴") + name + server + l111lll_ll_ (u"ࠧࡠࡡࡧࡳࡼࡴ࡬ࡰࡣࡧࠫ㪵")
						l1l111l_ll_.append(link)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"ࠨำึห้ฯࠠๆ่ࠣห้๋ศา็ฯࠫ㪶"),l111lll_ll_ (u"ࠩส่ึอศุࠢ็๎ุࠦแ๋้ࠣๅ๏ี๊้ࠩ㪷"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ㪸"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠫࠬ㪹"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠬ࠭㪺"): return
	search = search.replace(l111lll_ll_ (u"࠭ࠠࠨ㪻"),l111lll_ll_ (u"ࠧࠬࠩ㪼"))
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ㪽")+search
	l1l11l1_ll_(url)
	return
	l111lll_ll_ (u"ࠤࠥࠦࠏࠏࡨࡵ࡯࡯ࠤࡂࠦࡏࡑࡇࡑ࡙ࡗࡒ࡟ࡄࡃࡆࡌࡊࡊࠨࡓࡇࡊ࡙ࡑࡇࡒࡠࡅࡄࡇࡍࡋࠬࡸࡧࡥࡷ࡮ࡺࡥ࠱ࡣ࠯ࠫࠬ࠲ࡨࡦࡣࡧࡩࡷࡹࠬࠨࠩ࠯ࠫࡘࡋࡒࡊࡇࡖ࠸࡜ࡇࡔࡄࡊ࠰ࡗࡊࡇࡒࡄࡊ࠰࠵ࡸࡺࠧࠪࠌࠌ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࡣࡧࡺࡦࡴࡣࡦࡦ࠰ࡷࡪࡧࡲࡤࡪࠣࡷࡪࡩ࡯࡯ࡦࡤࡶࡾ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠐࠉࡪࡨࠣ࡬ࡹࡳ࡬ࡠࡤ࡯ࡳࡨࡱࡳ࠻ࠌࠌࠍࡧࡲ࡯ࡤ࡭ࠣࡁࠥ࡮ࡴ࡮࡮ࡢࡦࡱࡵࡣ࡬ࡵ࡞࠴ࡢࠐࠉࠊ࡫ࡷࡩࡲࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡥࡣࡷࡥ࠲ࡩࡡࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡩࡨࡦࡥ࡮ࡱࡦࡸ࡫࠮ࡤࡲࡰࡩࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂ࠯ࡴࡲࡤࡲࡃ࠭ࠬࡣ࡮ࡲࡧࡰ࠲ࡲࡦ࠰ࡇࡓ࡙ࡇࡌࡍࠫࠍࠍࠎࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࠰࡫࡯࡬ࡵࡧࡵࡐࡎ࡙ࡔࠡ࠿ࠣ࡟ࡢ࠲࡛࡞ࠌࠌࠍ࡫ࡵࡲࠡࡥࡤࡸࡪ࡭࡯ࡳࡻ࠯ࡸ࡮ࡺ࡬ࡦࠢ࡬ࡲࠥ࡯ࡴࡦ࡯ࡶ࠾ࠏࠏࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡤࡣࡷࡩ࡬ࡵࡲࡺࠫࠍࠍࠎࠏࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫࡸ࡮ࡺ࡬ࡦࠫࠍࠍࠎࡹࡥ࡭ࡧࡦࡸ࡮ࡵ࡮ࠡ࠿ࠣࡈࡎࡇࡌࡐࡉࡢࡗࡊࡒࡅࡄࡖࠫࠫฬิสาࠢส่ๆ๊สาࠢส่๊์วิส࠽ࠫ࠱ࠦࡦࡪ࡮ࡷࡩࡷࡒࡉࡔࡖࠬࠎࠎࠏࡩࡧࠢࡶࡩࡱ࡫ࡣࡵ࡫ࡲࡲࠥࡃ࠽ࠡ࠯࠴ࠤ࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࡥࡤࡸࡪ࡭࡯ࡳࡻࠣࡁࠥࡩࡡࡵࡧࡪࡳࡷࡿࡌࡊࡕࡗ࡟ࡸ࡫࡬ࡦࡥࡷ࡭ࡴࡴ࡝ࠋࠋࠌࡹࡷࡲࠠ࠾ࠢࡺࡩࡧࡹࡩࡵࡧ࠳ࡥࠥ࠱ࠠࠨ࠱ࡶࡩࡦࡸࡣࡩࡁࡶࡁࠬ࠱ࡳࡦࡣࡵࡧ࡭࠱ࠧࠧࡥࡤࡸࡪ࡭࡯ࡳࡻࡀࠫ࠰ࡩࡡࡵࡧࡪࡳࡷࡿࠊࠊࠋࡗࡍ࡙ࡒࡅࡔࠪࡸࡶࡱ࠯ࠊࠊࡴࡨࡸࡺࡸ࡮ࠋࠋࠥࠦࠧ㪾")