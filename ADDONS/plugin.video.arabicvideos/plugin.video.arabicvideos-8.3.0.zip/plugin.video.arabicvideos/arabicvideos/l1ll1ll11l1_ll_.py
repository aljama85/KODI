# -*- coding: utf-8 -*-
from __future__ import unicode_literals
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
#
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠪࡖࡆࡔࡄࡐࡏࡖࠫㇸ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠫࡤࡒࡓࡕࡡࠪㇹ")
l1ll1ll1ll11_ll_ = 5
def l111l1l_ll_(mode,url,text=l111lll_ll_ (u"ࠬ࠭ㇺ")):
	if   mode==160: results = l11l1ll_ll_()
	elif mode==161: results = l1ll1llll111_ll_(text)
	elif mode==162: results = l1ll1ll1111l_ll_(text,162)
	elif mode==163: results = l1ll1ll1111l_ll_(text,163)
	elif mode==164: results = l1ll1lll111l_ll_(text)
	elif mode==165: results = l1ll1ll1l1ll_ll_(text)
	elif mode==166: results = l1ll1lll1111_ll_(url,text)
	elif mode==167: results = l1ll1l1lll1l_ll_(url,text)
	else: results = False
	return results
def l11l1ll_ll_():
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ㇻ"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤ࠶࠴ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪㇼ")+l111lll_ll_ (u"ࠨไ้์ฬะࠠหๆไึ๏๎ๆࠡ฻ื์ฬฬ๊สࠩㇽ"),l111lll_ll_ (u"ࠩࠪㇾ"),161,l111lll_ll_ (u"ࠪࠫㇿ"),l111lll_ll_ (u"ࠫࠬ㈀"),l111lll_ll_ (u"ࠬࡥࡌࡊࡘࡈࡘ࡛ࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㈁"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈂"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤ࠷࠴ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈃")+l111lll_ll_ (u"ࠨไึ้ࠥ฿ิ้ษษ๎ࠬ㈄"),l111lll_ll_ (u"ࠩࠪ㈅"),162,l111lll_ll_ (u"ࠪࠫ㈆"),l111lll_ll_ (u"ࠫࠬ㈇"),l111lll_ll_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㈈"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈉"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤ࠸࠴ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈊")+l111lll_ll_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠫ㈋"),l111lll_ll_ (u"ࠩࠪ㈌"),163,l111lll_ll_ (u"ࠪࠫ㈍"),l111lll_ll_ (u"ࠫࠬ㈎"),l111lll_ll_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈏"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈐"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤ࠹࠴ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈑")+l111lll_ll_ (u"ࠨใํำ๏๎็ศฬࠣฬาัฺࠠึ๋หห๐ࠧ㈒"),l111lll_ll_ (u"ࠩࠪ㈓"),164,l111lll_ll_ (u"ࠪࠫ㈔"),l111lll_ll_ (u"ࠫࠬ㈕"),l111lll_ll_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈖"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㈗"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࠤ࠺࠴ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈘")+l111lll_ll_ (u"ࠨใํำ๏๎็ศฬࠣ฽ู๎วว์ฬࠤ๊์ࠠใี่ࠫ㈙"),l111lll_ll_ (u"ࠩࠪ㈚"),165,l111lll_ll_ (u"ࠪࠫ㈛"),l111lll_ll_ (u"ࠫࠬ㈜"),l111lll_ll_ (u"ࠬࡥࡓࡊࡖࡈࡗࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈝"))
	l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡰ࡮ࠫ㈞"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㈟"),l111lll_ll_ (u"ࠨࠩ㈠"),9999)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈡"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠ࠷࠰ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈢")+l111lll_ll_ (u"ࠫ็์่ศฬࠣࡍࡕ࡚ࡖࠡ฻ื์ฬฬ๊สࠩ㈣"),l111lll_ll_ (u"ࠬ࠭㈤"),163,l111lll_ll_ (u"࠭ࠧ㈥"),l111lll_ll_ (u"ࠧࠨ㈦"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡃࡑࡈࡔࡓ࡟ࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㈧"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈨"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠ࠸࠰ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈩")+l111lll_ll_ (u"ࠫ็ูๅࠡไ้์ฬะࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ㈪"),l111lll_ll_ (u"ࠬ࠭㈫"),162,l111lll_ll_ (u"࠭ࠧ㈬"),l111lll_ll_ (u"ࠧࠨ㈭"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡎࡌ࡚ࡊࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈮"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈯"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠ࠹࠰ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈰")+l111lll_ll_ (u"ࠫ็ูๅࠡใํำ๏๎ࠠࡊࡒࡗ࡚ࠥ฿ิ้ษษ๎ࠬ㈱"),l111lll_ll_ (u"ࠬ࠭㈲"),162,l111lll_ll_ (u"࠭ࠧ㈳"),l111lll_ll_ (u"ࠧࠨ㈴"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㈵"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈶"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࠠ࠺࠰ࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㈷")+l111lll_ll_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอࠬ㈸"),l111lll_ll_ (u"ࠬ࠭㈹"),163,l111lll_ll_ (u"࠭ࠧ㈺"),l111lll_ll_ (u"ࠧࠨ㈻"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡘࡒࡈࡤࡥࡒࡂࡐࡇࡓࡒࡥ࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ㈼"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㈽"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷࠰࠯ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㈾")+l111lll_ll_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤอำหࠡ฻ื์ฬฬ๊ࠨ㈿"),l111lll_ll_ (u"ࠬ࠭㉀"),164,l111lll_ll_ (u"࠭ࠧ㉁"),l111lll_ll_ (u"ࠧࠨ㉂"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㉃"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉄"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢ࠷࠱࠯ࠢࠣ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㉅")+l111lll_ll_ (u"ࠫๆ๐ฯ๋๊๊หฯࠦࡉࡑࡖ࡙ࠤ฾ฺ่ศศํอ๋ࠥๆࠡไึ้ࠬ㉆"),l111lll_ll_ (u"ࠬ࠭㉇"),165,l111lll_ll_ (u"࠭ࠧ㉈"),l111lll_ll_ (u"ࠧࠨ㉉"),l111lll_ll_ (u"ࠨࡡࡌࡔ࡙࡜࡟ࡠࡔࡄࡒࡉࡕࡍࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㉊"))
	return
def l1ll1llll111_ll_(options):
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㉋"),l111lll_ll_ (u"ࠪษ฾อฯสฺ่ࠢอࠦโ็๊สฮࠥ฿ิ้ษษ๎ฮ࠭㉌"),l111lll_ll_ (u"ࠫࠬ㉍"),161,l111lll_ll_ (u"ࠬ࠭㉎"),l111lll_ll_ (u"࠭ࠧ㉏"),l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡒࡉࡗࡇࡗ࡚ࡤࡥࡒࡂࡐࡇࡓࡒࡥࠧ㉐"))
	l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭㉑"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㉒"),l111lll_ll_ (u"ࠪࠫ㉓"),9999)
	l1lll111ll1_ll_ = l11l11lll_ll_[:]
	l11l11lll_ll_[:] = []
	#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㉔"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࡛ࠡࡘࡘࠥࠦࠠ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ㉕")+l111lll_ll_ (u"࠭โ็๊สฮࠥ฿ัษ์ฬࠤ๊์๋๊ࠠอ๎ํฮࠧ㉖"),l111lll_ll_ (u"ࠧࠨ㉗"),147)
	#l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ㉘"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠥ࡟ࡕࡕࠢࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㉙")+l111lll_ll_ (u"ࠪๆ๋๎วหࠢฦะ๋ฮ๊ส่๊ࠢࠥ๐่ห์๋ฬࠬ㉚"),l111lll_ll_ (u"ࠫࠬ㉛"),148)
	#l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㉜"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠢࡌࡊࡑࠦࠠࠡࠢ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ㉝")+l111lll_ll_ (u"ࠧใ่สอࠥศ๊ࠡใํ่๊ࠦๅ็่ࠢ์็฿็ๆࠩ㉞"),l111lll_ll_ (u"ࠨࠩ㉟"),28)
	#l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡻ࡫ࠧ㉠"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࠦࡍࡓࡈࠣࠤࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㉡")+l111lll_ll_ (u"ࠫ็์วสࠢส่๊฿วาใ้๋ࠣࠦๅ้ไ฼๋๊࠭㉢"),l111lll_ll_ (u"ࠬ࠭㉣"),41)
	#l111_ll_(l111lll_ll_ (u"࠭࡬ࡪࡸࡨࠫ㉤"),l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠣࡏ࡜࡚ࠠࠡ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠪ㉥")+l111lll_ll_ (u"ࠨไ้หฮࠦวๅๅ๋ฯึࠦๅ็่ࠢ์็฿็ๆࠩ㉦"),l111lll_ll_ (u"ࠩࠪ㉧"),135)
	import l1l1l1l1ll1_ll_
	l1l1l1l1ll1_ll_.l11ll1l11l_ll_(l111lll_ll_ (u"ࠪ࠴ࠬ㉨"),False)
	l1l1l1l1ll1_ll_.l11ll1l11l_ll_(l111lll_ll_ (u"ࠫ࠶࠭㉩"),False)
	l1l1l1l1ll1_ll_.l11ll1l11l_ll_(l111lll_ll_ (u"ࠬ࠸ࠧ㉪"),False)
	#l1l1l1l1ll1_ll_.l11ll1l11l_ll_(l111lll_ll_ (u"࠭࠳ࠨ㉫"),False)
	if l111lll_ll_ (u"ࠧࡠࡔࡄࡒࡉࡕࡍࡠࠩ㉬") in options:
		l11l11lll_ll_[:] = l1ll1ll11l1l_ll_(l11l11lll_ll_)
		if len(l11l11lll_ll_)>l1ll1ll1ll11_ll_: l11l11lll_ll_[:] = random.sample(l11l11lll_ll_,l1ll1ll1ll11_ll_)
	l11l11lll_ll_[:] = l1lll111ll1_ll_+l11l11lll_ll_
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㉭"),l111lll_ll_ (u"ࠩࡈࡑࡆࡊࠠࠡࠢࡕࡅࡓࡊࡏࡎࡡࡏࡍ࡛ࡋࡔࡗࠩ㉮")+str(l1l11ll111l_ll_))
	return
def l1ll1lll111l_ll_(options):
	options = options.replace(l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㉯"),l111lll_ll_ (u"ࠫࠬ㉰")).replace(l111lll_ll_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㉱"),l111lll_ll_ (u"࠭ࠧ㉲"))
	headers = { l111lll_ll_ (u"ࠧࡖࡵࡨࡶ࠲ࡇࡧࡦࡰࡷࠫ㉳") : l111lll_ll_ (u"ࠨࠩ㉴") }
	url = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡻࡼࡽ࠮ࡣࡧࡶࡸࡷࡧ࡮ࡥࡱࡰࡷ࠳ࡩ࡯࡮࠱ࡵࡥࡳࡪ࡯࡮࠯ࡤࡶࡦࡨࡩࡤ࠯ࡺࡳࡷࡪࡳࠨ㉵")
	payload = { l111lll_ll_ (u"ࠪࡵࡺࡧ࡮ࡵ࡫ࡷࡽࠬ㉶") : l111lll_ll_ (u"ࠫ࠺࠶ࠧ㉷") }
	data = l1lll11ll_ll_(payload)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭㉸"),str(data))
	response = l111111_ll_(l1l1l11ll1l_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ㉹"),url,data,headers,l111lll_ll_ (u"ࠧࠨ㉺"),l111lll_ll_ (u"ࠨࠩ㉻"),l111lll_ll_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡗࡊࡇࡒࡄࡊࡢࡖࡆࡔࡄࡐࡏࡢ࡚ࡎࡊࡅࡐࡕ࠰࠵ࡸࡺࠧ㉼"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡧࡴࡴࡴࡦࡰࡷࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡦࡰࡪࡧࡲࡧ࡫ࡻࠦࠬ㉽"),html,re.DOTALL)
	block = l1lll_ll_[0]
	items = re.findall(l111lll_ll_ (u"ࠫࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿࠰࠭ࡃࡁࡹࡰࡢࡰࡁࠬ࠳࠰࠿ࠪ࠾࠲ࡷࡵࡧ࡮࠿ࠩ㉾"),block,re.DOTALL)
	l1ll1l1l1lll_ll_,l1ll1l1lll11_ll_ = zip(*items)
	l1ll1lll11l1_ll_ = []
	l1ll1lll1lll_ll_ = [l111lll_ll_ (u"ࠬࠦࠧ㉿"),l111lll_ll_ (u"࠭ࠢࠨ㊀"),l111lll_ll_ (u"ࠧࡡࠩ㊁"),l111lll_ll_ (u"ࠨ࠮ࠪ㊂"),l111lll_ll_ (u"ࠩ࠱ࠫ㊃"),l111lll_ll_ (u"ࠪ࠾ࠬ㊄"),l111lll_ll_ (u"ࠫࡀ࠭㊅"),l111lll_ll_ (u"ࠧ࠭ࠢ㊆"),l111lll_ll_ (u"࠭࠭ࠨ㊇")]
	l1ll1ll1l1l1_ll_ = l1ll1l1lll11_ll_+l1ll1l1l1lll_ll_
	for word in l1ll1ll1l1l1_ll_:
		if word in l1ll1l1lll11_ll_: l1ll1ll1l11l_ll_ = 2
		if word in l1ll1l1l1lll_ll_: l1ll1ll1l11l_ll_ = 4
		l1ll1lll11ll_ll_ = [i in word for i in l1ll1lll1lll_ll_]
		if any(l1ll1lll11ll_ll_):
			index = l1ll1lll11ll_ll_.index(True)
			l1ll1l1llll1_ll_ = l1ll1lll1lll_ll_[index]
			l1ll1ll1lll1_ll_ = l111lll_ll_ (u"ࠧࠨ㊈")
			if word.count(l1ll1l1llll1_ll_)>1: l1ll1ll1llll_ll_,l1ll1ll1ll1l_ll_,l1ll1ll1lll1_ll_ = word.split(l1ll1l1llll1_ll_,2)
			else: l1ll1ll1llll_ll_,l1ll1ll1ll1l_ll_ = word.split(l1ll1l1llll1_ll_,1)
			if len(l1ll1ll1llll_ll_)>l1ll1ll1l11l_ll_: l1ll1lll11l1_ll_.append(l1ll1ll1llll_ll_.lower())
			if len(l1ll1ll1ll1l_ll_)>l1ll1ll1l11l_ll_: l1ll1lll11l1_ll_.append(l1ll1ll1ll1l_ll_.lower())
			if len(l1ll1ll1lll1_ll_)>l1ll1ll1l11l_ll_: l1ll1lll11l1_ll_.append(l1ll1ll1lll1_ll_.lower())
		elif len(word)>l1ll1ll1l11l_ll_: l1ll1lll11l1_ll_.append(word.lower())
	for i in range(9): random.shuffle(l1ll1lll11l1_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㊉"),str(l1ll1lll11l1_ll_))
	#selection = l1l1111_ll_(str(len(l1ll1lll11l1_ll_)),l1ll1lll11l1_ll_)
	l111lll_ll_ (u"ࠤࠥࠦࠏࠏ࡬ࡪࡵࡷࠤࡂ࡛ࠦࠨๅ็้ฬะฺࠠึ๋หห๐ษࠡ฻ิฬ๏ฯࠧ࠭ࠩๆ่๊อสࠡ฻ื์ฬฬ๊สࠢศ๊่๊๊ำ์ฬࠫࡢࠐࠉࠤࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠳ࠫࠍࠍࡱ࡯ࡳࡵ࠳ࠣࡁࠥࡡ࡝ࠋࠋࡦࡳࡺࡴࡴࡴࠢࡀࠤࡱ࡫࡮ࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࡵ࠭࠹࠮ࡀࠠࡳࡣࡱࡨࡴࡳ࠮ࡴࡪࡸࡪ࡫ࡲࡥࠩ࡮࡬ࡷࡹ࠸ࠩࠋࠋࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡰࡪࡴࡧࡵࡪࠬ࠾ࠥࡲࡩࡴࡶ࠴࠲ࡦࡶࡰࡦࡰࡧ้ࠬࠬไๆหࠣ฽ู๎วว์ฬࠤึ่ๅࠡࠩ࠮ࡷࡹࡸࠨࡪࠫࠬࠎࠎࡽࡨࡪ࡮ࡨࠤ࡙ࡸࡵࡦ࠼ࠍࠍࠎࠩࡳࡦ࡮ࡨࡧࡹ࡯࡯࡯ࠢࡀࠤࡉࡏࡁࡍࡑࡊࡣࡘࡋࡌࡆࡅࡗࠬࠬอฮหำࠣหฺ้๊ส࠼ࠪ࠰ࠥࡲࡩࡴࡶࠬࠎࠎࠏࠣࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࠊࠥࡨࡰ࡮࡬ࠠࡴࡧ࡯ࡩࡨࡺࡩࡰࡰࡀࡁ࠵ࡀࠠ࡭࡫ࡶࡸ࠷ࠦ࠽ࠡࡣࡵࡦࡑࡏࡓࡕࠌࠌࠍࠨ࡫࡬ࡴࡧ࠽ࠤࡱ࡯ࡳࡵ࠴ࠣࡁࠥ࡫࡮ࡨࡎࡌࡗ࡙ࠐࠉࠊࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࡂࠦࡄࡊࡃࡏࡓࡌࡥࡓࡆࡎࡈࡇ࡙࠮ࠧศะอี้ࠥไๆห่้ࠣฮอฬࠢ฼๊์อ࠺ࠨ࠮ࠣࡰ࡮ࡹࡴ࠲ࠫࠍࠍࠎ࡯ࡦࠡࡵࡨࡰࡪࡩࡴࡪࡱࡱࠤࠦࡃࠠ࠮࠳࠽ࠤࡧࡸࡥࡢ࡭ࠍࠍࠎ࡫࡬ࡪࡨࠣࡷࡪࡲࡥࡤࡶ࡬ࡳࡳࠦ࠽࠾ࠢ࠰࠵࠿ࠦࡲࡦࡶࡸࡶࡳࠐࠉࡴࡧࡤࡶࡨ࡮ࠠ࠾ࠢ࡯࡭ࡸࡺ࠲࡜ࡵࡨࡰࡪࡩࡴࡪࡱࡱࡡࠏࠏࠢࠣࠤ㊊")
	if l111lll_ll_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ㊋") in options:
		l1ll1ll11l11_ll_ = [19,29,39,49,59,69,79,99,119,139,149,209,229,249,259,309]
	elif l111lll_ll_ (u"ࠫࡤࡏࡐࡕࡘࡢࠫ㊌") in options:
		l1ll1ll11l11_ll_ = [239]
		import l1111lllll_ll_
		if not l1111lllll_ll_.l11111111l_ll_(True): return
	count,l1ll1l1ll111_ll_ = 0,0
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㊍"),l111lll_ll_ (u"࠭วๅสะฯࠥ฿ๆࠡ࠼ࠣ࡟ࠥࠦ࡝ࠨ㊎"),l111lll_ll_ (u"ࠧࠨ㊏"),164,l111lll_ll_ (u"ࠨࠩ㊐"),l111lll_ll_ (u"ࠩࠪ㊑"),l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㊒")+options)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㊓"),l111lll_ll_ (u"ࠬหูศัฬࠤฬ๊ศฮอࠣห้฿ิ้ษษ๎ࠬ㊔"),l111lll_ll_ (u"࠭ࠧ㊕"),164,l111lll_ll_ (u"ࠧࠨ㊖"),l111lll_ll_ (u"ࠨࠩ㊗"),l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㊘")+options)
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㊙"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㊚"),l111lll_ll_ (u"ࠬ࠭㊛"),9999)
	l1ll1l1l1ll1_ll_ = l11l11lll_ll_[:]
	l11l11lll_ll_[:] = []
	for i in range(0,20):
		text = random.sample(l1ll1lll11l1_ll_,1)[0]
		#text = text+l111lll_ll_ (u"࠭࡟ࡠࡡࠪ㊜")
		mode = random.sample(l1ll1ll11l11_ll_,1)[0]
		l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㊝"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤ࡛࡯ࡤࡦࡱࠣࡗࡪࡧࡲࡤࡪࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠫ㊞")+str(mode)+l111lll_ll_ (u"ࠩࠣࠤࡹ࡫ࡸࡵ࠼ࠪ㊟")+text)
		results = l1lll1111ll_ll_(l111lll_ll_ (u"ࠪࠫ㊠"),l111lll_ll_ (u"ࠫࠬ㊡"),l111lll_ll_ (u"ࠬ࠭㊢"),mode,l111lll_ll_ (u"࠭ࠧ㊣"),l111lll_ll_ (u"ࠧࠨ㊤"),text+l111lll_ll_ (u"ࠨࡡࡑࡓࡉࡏࡁࡍࡑࡊࡗࡤ࠭㊥"),l111lll_ll_ (u"ࠩࠪ㊦"))
		if len(l11l11lll_ll_)>0: break
	#text = text.replace(l111lll_ll_ (u"ࠪࡣࠬ㊧"),l111lll_ll_ (u"ࠫࠬ㊨"))
	l1ll1l1l1ll1_ll_[0][1] = l111lll_ll_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㊩")+text[:-2]+l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ฬาัฺ่ࠠࠣ࠾ࠥࡡࠠࠨ㊪")
	l11l11lll_ll_[:] = l1ll1ll11l1l_ll_(l11l11lll_ll_)
	if len(l11l11lll_ll_)>l1ll1ll1ll11_ll_: l11l11lll_ll_[:] = random.sample(l11l11lll_ll_,l1ll1ll1ll11_ll_)
	l11l11lll_ll_[:] = l1ll1l1l1ll1_ll_+l11l11lll_ll_
	#l111111ll1l_ll_(search,False)
	#l1ll1l_ll_(str(len(l11l11lll_ll_)),l111lll_ll_ (u"ࠧࡎࡇࡑ࡙ࡘ࠭㊫"))
	return
def l1ll1lll1l1l_ll_():
	l1ll1ll111ll_ll_ = 5
	global l1l11ll111l_ll_
	results = l1llll11l1l_ll_(l111lll_ll_ (u"ࠨࡏࡌࡗࡈ࠭㊬"),l111lll_ll_ (u"ࠩࡖࡍ࡙ࡋࡓࡠࡕࡈࡇ࡙ࡏࡏࡏࡕࠪ㊭"))
	if results: l1l11ll111l_ll_ = results ; return
	l1ll1l1ll1ll_ll_ = l11l11lll_ll_[:]
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㊮"),l111lll_ll_ (u"ࠫࡘ࡚ࡁࡓࡖࠣࡘࡎࡓࡉࡏࡉࠪ㊯"))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠬ࠭㊰"),l111lll_ll_ (u"࠭ࡳࡵࡣࡵࡸࠬ㊱"))
	l1ll1ll1l111_ll_ = 0
	l1ll1ll11ll1_ll_ = l111lll_ll_ (u"ࠧࠨ㊲")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l1l1l1_ll_ ; html = l11l1l1l1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠨࡄࡒࡏࡗࡇࠧ㊳"))
			if l111lll_ll_ (u"ࠩࡢࡣࡊࡸࡲࡰࡴࡢࡣࠬ㊴") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠪࠤࡇࡕࡋࡓࡃࠪ㊵")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l11l1ll1_ll_ ; html = l1l11l1ll1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝ࠧ㊶"))
			if l111lll_ll_ (u"ࠬࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࠨ㊷") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"࠭ࠠࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙ࠪ㊸")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l11l111l1_ll_ ; html = l1l11l111l1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠧࡎ࡛ࡆࡍࡒࡇࠧ㊹"))
			if l111lll_ll_ (u"ࠨࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࠫ㊺") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠩࠣࡑ࡞ࡉࡉࡎࡃࠪ㊻")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l1lll1_ll_ ; html = l1l1lll1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎࡅࡄࡑࠬ㊼"))
			if l111lll_ll_ (u"ࠫࡤࡥࡅࡳࡴࡲࡶࡤࡥࠧ㊽") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠬࠦࡁࡌࡑࡄࡑࡈࡇࡍࠨ㊾")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l_ll_ ; html = l1l_ll_.l11l1ll_ll_(l111lll_ll_ (u"࠭ࡁࡌࡑࡄࡑࠬ㊿"))
			if l111lll_ll_ (u"ࠧࡠࡡࡈࡶࡷࡵࡲࡠࡡࠪ㋀") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠨࠢࡄࡏࡔࡇࡍࠨ㋁")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l1lll_ll_ ; html = l1l1lll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠩࡄࡏ࡜ࡇࡍࠨ㋂"))
			if l111lll_ll_ (u"ࠪࡣࡤࡋࡲࡳࡱࡵࡣࡤ࠭㋃") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠫࠥࡇࡋࡘࡃࡐࠫ㋄")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l1ll1l1l_ll_ ; html = l11l1ll1l1l_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠬࡖࡁࡏࡇࡗࠫ㋅"))
			if l111lll_ll_ (u"࠭࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࠩ㋆") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠧࠡࡒࡄࡒࡊ࡚ࠧ㋇")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l111l_ll_ ; html = l11l111l_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠨࡃࡏࡅࡗࡇࡂࠨ㋈"))
			if l111lll_ll_ (u"ࠩࡢࡣࡊࡸࡲࡰࡴࡢࡣࠬ㋉") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠪࠤࡆࡒࡁࡓࡃࡅࠫ㋊")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l1ll1ll_ll_ ; html = l11l1ll1ll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠫࡎࡌࡉࡍࡏࡢࡅࡗࡇࡂࡊࡅࠪ㋋"))
			if l111lll_ll_ (u"ࠬࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࠨ㋌") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"࠭ࠠࡊࡈࡌࡐࡒࡥࡁࡓࡃࡅࡍࡈ࠭㋍")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l1ll1ll_ll_ ; html = l11l1ll1ll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠧࡊࡈࡌࡐࡒࡥࡅࡏࡉࡏࡍࡘࡎࠧ㋎"))
			if l111lll_ll_ (u"ࠨࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࠫ㋏") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠩࠣࡍࡋࡏࡌࡎࡡࡈࡒࡌࡒࡉࡔࡊࠪ㋐")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1ll1lll1_ll_ ; html = l1ll1lll1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠪࡅࡑࡌࡁࡕࡋࡐࡍࠬ㋑"))
			if l111lll_ll_ (u"ࠫࡤࡥࡅࡳࡴࡲࡶࡤࡥࠧ㋒") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠬࠦࡁࡍࡈࡄࡘࡎࡓࡉࠨ㋓")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1l111l11_ll_ ; html = l1l111l11_ll_.l11l1ll_ll_(l111lll_ll_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄࠨ㋔"))
			if l111lll_ll_ (u"ࠧࡠࡡࡈࡶࡷࡵࡲࡠࡡࠪ㋕") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠨࠢࡄࡖࡆࡈࡓࡆࡇࡇࠫ㋖")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1ll1lll111_ll_ ; html = l1ll1lll111_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠩࡖࡌࡔࡕࡆࡎࡃ࡛ࠫ㋗"))
			if l111lll_ll_ (u"ࠪࡣࡤࡋࡲࡳࡱࡵࡣࡤ࠭㋘") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"࡙ࠫࠥࡈࡐࡑࡉࡑࡆ࡞ࠧ㋙")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1ll11111_ll_ ; html = l1ll11111_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠬࡇࡌࡌࡃ࡚ࡘࡍࡇࡒࠨ㋚"))
			if l111lll_ll_ (u"࠭࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࠩ㋛") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠧࠡࡃࡏࡏࡆ࡝ࡔࡉࡃࡕࠫ㋜")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l111ll_ll_ ; html = l11l111ll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠨࡅࡌࡑࡆࡔࡏࡘࠩ㋝"))
			if l111lll_ll_ (u"ࠩࡢࡣࡊࡸࡲࡰࡴࡢࡣࠬ㋞") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠪࠤࡈࡏࡍࡂࡐࡒ࡛ࠬ㋟")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11ll11llll_ll_ ; html = l11ll11llll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠫࡘࡎࡉࡂࡘࡒࡍࡈࡋࠧ㋠"))
			if l111lll_ll_ (u"ࠬࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࠨ㋡") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"࠭ࠠࡔࡊࡌࡅ࡛ࡕࡉࡄࡇࠪ㋢")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1lll1ll111_ll_ ; html = l1lll1ll111_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠧࡌࡃࡕࡆࡆࡒࡁࡕࡘࠪ㋣"))
			if l111lll_ll_ (u"ࠨࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࠫ㋤") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠩࠣࡏࡆࡘࡂࡂࡎࡄࡘ࡛࠭㋥")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l11l1ll11l1_ll_ ; html = l11l1ll11l1_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠪࡑࡔ࡜ࡓ࠵ࡗࠪ㋦"))
			if l111lll_ll_ (u"ࠫࡤࡥࡅࡳࡴࡲࡶࡤࡥࠧ㋧") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠬࠦࡍࡐࡘࡖ࠸࡚࠭㋨")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1ll1l1ll11_ll_ ; html = l1ll1l1ll11_ll_.l11l1ll_ll_(l111lll_ll_ (u"࠭ࡓࡉࡃࡋࡍࡉ࠺ࡕࠨ㋩"))
			if l111lll_ll_ (u"ࠧࡠࡡࡈࡶࡷࡵࡲࡠࡡࠪ㋪") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠨࠢࡖࡌࡆࡎࡉࡅ࠶ࡘࠫ㋫")
	if l1ll1ll1l111_ll_<=l1ll1ll111ll_ll_:
		try:
			import l1ll111lll_ll_ ; html = l1ll111lll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠩࡈࡋ࡞ࡈࡅࡔࡖࠪ㋬"))
			if l111lll_ll_ (u"ࠪࡣࡤࡋࡲࡳࡱࡵࡣࡤ࠭㋭") in html: l1ll1ll1l111_ll_ += 1
		except:
			l1ll1ll1l111_ll_ += 1
			l1ll1ll11ll1_ll_ += l111lll_ll_ (u"ࠫࠥࡋࡇ࡚ࡄࡈࡗ࡙࠭㋮")
	l111lll_ll_ (u"ࠧࠨࠢࠋࠋ࡬ࡪࠥ࡬ࡡࡪ࡮ࡨࡨࡁࡃࡦࡢ࡫࡯ࡩࡩࡥ࡭ࡢࡺ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡪ࡯ࡳࡳࡷࡺࠠࡉࡇࡏࡅࡑࠦ࠻ࠡࡪࡷࡱࡱࠦ࠽ࠡࡊࡈࡐࡆࡒ࠮ࡎࡇࡑ࡙࠭࠭ࡈࡆࡎࡄࡐࠬ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡠࡡࡈࡶࡷࡵࡲࡠࡡࠪࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠦࡦࡢ࡫࡯ࡩࡩࠦࠫ࠾ࠢ࠴ࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠊࠊࠋࠌࡪࡦ࡯࡬ࡦࡦࠣ࠯ࡂࠦ࠱ࠋࠋࠌࠍ࡫ࡧࡩ࡭ࡧࡧࡣࡱ࡯ࡳࡵࠢ࠮ࡁࠥ࠭ࠠࡉࡇࡏࡅࡑ࠭ࠊࠊ࡫ࡩࠤ࡫ࡧࡩ࡭ࡧࡧࡀࡂ࡬ࡡࡪ࡮ࡨࡨࡤࡳࡡࡹ࠼ࠍࠍࠎࡺࡲࡺ࠼ࠍࠍࠎࠏࡩ࡮ࡲࡲࡶࡹࠦࡁࡓࡄࡏࡍࡔࡔ࡚ࠡ࠽ࠣ࡬ࡹࡳ࡬ࠡ࠿ࠣࡅࡗࡈࡌࡊࡑࡑ࡞࠳ࡓࡅࡏࡗࠫࠫࡆࡘࡂࡍࡋࡒࡒ࡟࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡀࠠࡧࡣ࡬ࡰࡪࡪࠠࠬ࠿ࠣ࠵ࠏࠏࠉࡦࡺࡦࡩࡵࡺ࠺ࠋࠋࠌࠍ࡫ࡧࡩ࡭ࡧࡧࠤ࠰ࡃࠠ࠲ࠌࠌࠍࠎ࡬ࡡࡪ࡮ࡨࡨࡤࡲࡩࡴࡶࠣ࠯ࡂࠦࠧࠡࡃࡕࡆࡑࡏࡏࡏ࡜ࠪࠎࠎ࡯ࡦࠡࡨࡤ࡭ࡱ࡫ࡤ࠽࠿ࡩࡥ࡮ࡲࡥࡥࡡࡰࡥࡽࡀࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡉࡌ࡟ࡂࡆࡕࡗ࡚ࡎࡖࠠ࠼ࠢ࡫ࡸࡲࡲࠠ࠾ࠢࡈࡋ࡞ࡈࡅࡔࡖ࡙ࡍࡕ࠴ࡍࡆࡐࡘࠬࠬࡋࡇ࡚ࡄࡈࡗ࡙࡜ࡉࡑࠩࠬࠎࠎࠏࠉࡪࡨࠣࠫࡤࡥࡅࡳࡴࡲࡶࡤࡥࠧࠡ࡫ࡱࠤ࡭ࡺ࡭࡭࠼ࠣࡪࡦ࡯࡬ࡦࡦࠣ࠯ࡂࠦ࠱ࠋࠋࠌࡩࡽࡩࡥࡱࡶ࠽ࠎࠎࠏࠉࡧࡣ࡬ࡰࡪࡪࠠࠬ࠿ࠣ࠵ࠏࠏࠉࠊࡨࡤ࡭ࡱ࡫ࡤࡠ࡮࡬ࡷࡹࠦࠫ࠾ࠢࠪࠤࡊࡍ࡙ࡃࡇࡖࡘ࡛ࡏࡐࠨࠌࠌ࡭࡫ࠦࡦࡢ࡫࡯ࡩࡩࡂ࠽ࡧࡣ࡬ࡰࡪࡪ࡟࡮ࡣࡻ࠾ࠏࠏࠉࡵࡴࡼ࠾ࠏࠏࠉࠊ࡫ࡰࡴࡴࡸࡴࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓࠦ࠻ࠡࡪࡷࡱࡱࠦ࠽ࠡࡆࡄࡍࡑ࡟ࡍࡐࡖࡌࡓࡓ࠴ࡍࡆࡐࡘࠬࠬࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࠨࠢ࡬ࡲࠥ࡮ࡴ࡮࡮࠽ࠤ࡫ࡧࡩ࡭ࡧࡧࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠏࠏࠉࠊࡨࡤ࡭ࡱ࡫ࡤࠡ࠭ࡀࠤ࠶ࠐࠉࠊࠋࡩࡥ࡮ࡲࡥࡥࡡ࡯࡭ࡸࡺࠠࠬ࠿ࠣࠫࠥࡊࡁࡊࡎ࡜ࡑࡔ࡚ࡉࡐࡐࠪࠎࠎ࡯ࡦࠡࡨࡤ࡭ࡱ࡫ࡤ࠽࠿ࡩࡥ࡮ࡲࡥࡥࡡࡰࡥࡽࡀࠊࠊࠋࡷࡶࡾࡀࠊࠊࠋࠌ࡭ࡲࡶ࡯ࡳࡶࠣࡅࡑࡓࡁࡂࡔࡈࡊࠥࡁࠠࡩࡶࡰࡰࠥࡃࠠࡂࡎࡐࡅࡆࡘࡅࡇ࠰ࡐࡉࡓ࡛ࠨࠨࡃࡏࡑࡆࡇࡒࡆࡈࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤࠬࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࠨࠢ࡬ࡲࠥ࡮ࡴ࡮࡮࠽ࠤ࡫ࡧࡩ࡭ࡧࡧࠤ࠰ࡃࠠ࠲ࠌࠌࠍࡪࡾࡣࡦࡲࡷ࠾ࠏࠏࠉࠊࡨࡤ࡭ࡱ࡫ࡤࠡ࠭ࡀࠤ࠶ࠐࠉࠊࠋࡩࡥ࡮ࡲࡥࡥࡡ࡯࡭ࡸࡺࠠࠬ࠿ࠣࠫࠥࡇࡌࡎࡃࡄࡖࡊࡌࠧࠋࠋ࡬ࡪࠥ࡬ࡡࡪ࡮ࡨࡨࡁࡃࡦࡢ࡫࡯ࡩࡩࡥ࡭ࡢࡺ࠽ࠎࠎࠏࡴࡳࡻ࠽ࠎࠎࠏࠉࡪ࡯ࡳࡳࡷࡺ࡚ࠠࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘࠦ࠻ࠡࡪࡷࡱࡱࠦ࠽࡛ࠡࡗࡆࡤࡉࡈࡂࡐࡑࡉࡑ࡙࠮ࡎࡇࡑ࡙࡙࠭࠭ࡕࡄࡢࡇࡍࡇࡎࡏࡇࡏࡗࠬ࠯ࠊࠊࠋࠌ࡭࡫ࠦࠧࡠࡡࡈࡶࡷࡵࡲࡠࡡࠪࠤ࡮ࡴࠠࡩࡶࡰࡰ࠿ࠦࡦࡢ࡫࡯ࡩࡩࠦࠫ࠾ࠢ࠴ࠎࠎࠏࡥࡹࡥࡨࡴࡹࡀࠊࠊࠋࠌࡪࡦ࡯࡬ࡦࡦࠣ࠯ࡂࠦ࠱ࠋࠋࠌࠍ࡫ࡧࡩ࡭ࡧࡧࡣࡱ࡯ࡳࡵࠢ࠮ࡁ࡚ࠥ࠭ࠠࡖࡅࡣࡈࡎࡁࡏࡐࡈࡐࡘ࠭ࠊࠊࠤࠥࠦ㋯")
	#import l11ll111l1_ll_		;	l11ll111l1_ll_.l11l1ll_ll_(l111lll_ll_ (u"࠭ࡈࡂࡎࡄࡇࡎࡓࡁࠨ㋰"))
	#import l11ll1ll1ll_ll_		;	l11ll1ll1ll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠧࡎࡑ࡙ࡍ࡟ࡒࡁࡏࡆࠪ㋱"))
	#import l1lll11ll11_ll_	;	l1lll11ll11_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠨࡕࡈࡖࡎࡋࡓ࠵࡙ࡄࡘࡈࡎࠧ㋲"))
	#import l1l1lll11ll_ll_			;	l1l1lll11ll_ll_.l11l1ll_ll_(l111lll_ll_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࠪ㋳"))
	l11l11lll_ll_[:] = l1ll1l1ll1ll_ll_
	if l1ll1ll1l111_ll_>l1ll1ll111ll_ll_: l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㋴"),l111lll_ll_ (u"้ࠫี๊ไุ่่๊ࠢษࠡใํࠤࠬ㋵")+str(l1ll1ll1l111_ll_)+l111lll_ll_ (u"ࠬࠦๅ้ษๅ฽๋ࠥๆࠡ็๋ห็฿ࠠศๆหี๋อๅอࠢ࠱࠲࠳่ࠦิสห๋ฬࠦโะࠢํ็ํ์ฺࠠั่ࠤํา่ะࠢศ๊ฯืๆ๋ฬࠣๅ๏ࠦฬ่ษี็ࠥ๎็๋࠼ࠪ㋶")+l1ll1ll11ll1_ll_)
	else: l1111l1lll_ll_(l111lll_ll_ (u"࠭ࡍࡊࡕࡆࠫ㋷"),l111lll_ll_ (u"ࠧࡔࡋࡗࡉࡘࡥࡓࡆࡅࡗࡍࡔࡔࡓࠨ㋸"),l1l11ll111l_ll_,l11l111l11_ll_)
	return
def l1ll1ll11111_ll_(options):
	message = l111lll_ll_ (u"ࠨๆ็วุ็ࠠๅัํ็๋ࠥิไๆฬࠤๆ๐่ࠠาสࠤฬ๊ๅ้ไ฼ࠤ࠳่ࠦาีส่ฮࠦวๅะฺว้ࠥว็ࠢไ๎์อࠠหใสู๏๊ࠠศๆุ่่๊ษࠡ࠰ࠣวีอࠠศๆุ่่๊ษࠡๆํืฯࠦออสࠣๅัืศࠡวิืฬ๊่ࠠา๊ࠤฬ๊ๅีๅ็อࠥหไ๊ࠢส่๊ฮัๆฮ้๋ࠣࠦโศศ่อࠥิฯๆษอࠤฬ๊ศา่ส้ั࠭㋹")
	import l1111lllll_ll_
	if l1111lllll_ll_.l11111111l_ll_(True):
		#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ㋺"),options)
		if l111lll_ll_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㋻") in options and l111lll_ll_ (u"ࠫࡤࡒࡉࡗࡇࡢࠫ㋼") not in options:
			try: l1111lllll_ll_.l1lllll1l11_ll_(l111lll_ll_ (u"ࠬ࡜ࡏࡅࡡࡒࡖࡎࡍࡉࡏࡃࡏࡣࡌࡘࡏࡖࡒࡈࡈࠬ㋽"),l111lll_ll_ (u"࠭ࠧ㋾"),options+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㋿"))
			except: l1ll1l_ll_(l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦࡉࡑࡖ࡙ࠤ้๊แ๋ัํ์์อสࠨ㌀"),message)
		if str(l1l11ll111l_ll_).count(l111lll_ll_ (u"ࠩ࠼࠽࠾࠿ࠧ㌁"))>=4:
			if l111lll_ll_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㌂") in options and l111lll_ll_ (u"ࠫࡤ࡜ࡏࡅࡡࠪ㌃") not in options:
				try: l1111lllll_ll_.l1lllll1l11_ll_(l111lll_ll_ (u"ࠬࡒࡉࡗࡇࡢࡓࡗࡏࡇࡊࡐࡄࡐࡤࡍࡒࡐࡗࡓࡉࡉ࠭㌄"),l111lll_ll_ (u"࠭ࠧ㌅"),options+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㌆"))
				except: l1ll1l_ll_(l111lll_ll_ (u"ࠨ็๋ๆ฾ࠦࡉࡑࡖ࡙ࠤ้๊โ็๊สฮࠬ㌇"),message)
	#else: l1l111l1l11_ll_(l111lll_ll_ (u"ࠩࡕࡅࡓࡊࡏࡎࡕ࠰ࡍࡒࡖࡏࡓࡖࡢࡍࡕ࡚ࡖ࠮࠳ࡶࡸࠬ㌈"))
	return
def l1ll1ll1l1ll_ll_(options):
	l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㌉"),l111lll_ll_ (u"ࠫ฾๋ไ๋หࠣะ๊฿ࠠใษษ้ฮࠦวๅลๅืฬ๋ࠠใัࠣฮาะวอࠢ฼ำฮࠦฯใษษๆࠥ࠴่ࠠๆࠣฮึ๐ฯࠡล้ࠤฯาไษࠢๅหห๋ษࠡษ็ว็ูวๆࠢส่ว์ࠠภࠩ㌊"),l111lll_ll_ (u"ࠬ࠭㌋"),l111lll_ll_ (u"࠭ࠧ㌌"),l111lll_ll_ (u"ࠧไๆสࠫ㌍"),l111lll_ll_ (u"ࠨ่฼้ࠬ㌎"))
	if not l111111l1_ll_: return
	#l1ll1l_ll_(l111lll_ll_ (u"ࠩࠪ㌏"),options)
	l1ll1lll1ll1_ll_ = options.replace(l111lll_ll_ (u"ࠪࡣࡈࡘࡅࡂࡖࡈࡒࡊ࡝࡟ࠨ㌐"),l111lll_ll_ (u"ࠫࠬ㌑")).replace(l111lll_ll_ (u"ࠬࡥࡆࡐࡔࡊࡉ࡙ࡘࡅࡔࡗࡏࡘࡘࡥࠧ㌒"),l111lll_ll_ (u"࠭ࠧ㌓")).replace(l111lll_ll_ (u"ࠧࡠࡔࡈࡑࡊࡓࡂࡆࡔࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㌔"),l111lll_ll_ (u"ࠨࠩ㌕"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㌖"),l111lll_ll_ (u"ࠪฮาี๊ฬ๊ࠢิ์ࠦวๅไสส๊ฯࠧ㌗"),l111lll_ll_ (u"ࠫࠬ㌘"),165,l111lll_ll_ (u"ࠬ࠭㌙"),l111lll_ll_ (u"࠭ࠧ㌚"),l111lll_ll_ (u"ࠧࡠࡅࡕࡉࡆ࡚ࡅࡏࡇ࡚ࡣࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭㌛")+l1ll1lll1ll1_ll_)
	l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭㌜"),l111lll_ll_ (u"ࠩ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀ࡟࠴ࡉࡏࡍࡑࡕࡡࠬ㌝"),l111lll_ll_ (u"ࠪࠫ㌞"),9999)
	if l111lll_ll_ (u"ࠫࡤ࡙ࡉࡕࡇࡖࡣࠬ㌟") in options:
		if l111lll_ll_ (u"ࠬࡥࡃࡓࡇࡄࡘࡊࡔࡅࡘࡡࠪ㌠") in options: l11111l1ll_ll_(l111lll_ll_ (u"࠭ࡍࡊࡕࡆࠫ㌡"),l111lll_ll_ (u"ࠧࡔࡋࡗࡉࡘࡥࡓࡆࡅࡗࡍࡔࡔࡓࠨ㌢"))
		l1ll1lll1l1l_ll_()
		#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩ㌣"),str(len(l11l11lll_ll_)))
		for l11l1111l11_ll_ in sorted(l1l11ll111l_ll_.keys()):
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ㌤"),l1l1l1l_ll_+l11l1111l11_ll_,l11l1111l11_ll_,166,l111lll_ll_ (u"ࠪࠫ㌥"),l111lll_ll_ (u"ࠫࠬ㌦"),l1ll1lll1ll1_ll_)
	elif l111lll_ll_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㌧") in options:
		if l111lll_ll_ (u"࠭࡟ࡄࡔࡈࡅ࡙ࡋࡎࡆ࡙ࡢࠫ㌨") in options:
			import l1111lllll_ll_
			l1111lllll_ll_.l1lllllll11_ll_()
		l1ll1ll11111_ll_(l1ll1lll1ll1_ll_)
	return
def l1ll1lll1111_ll_(l11l1111l11_ll_,options):
	options = options.replace(l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㌩"),l111lll_ll_ (u"ࠨࠩ㌪")).replace(l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㌫"),l111lll_ll_ (u"ࠪࠫ㌬"))
	#l1ll1l_ll_(l11l1111l11_ll_,options)
	l1ll1lll1l1l_ll_()
	if l1l11ll111l_ll_=={}: return
	if l111lll_ll_ (u"ࠫࡤࡘࡁࡏࡆࡒࡑࡤ࠭㌭") in options:
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㌮"),l111lll_ll_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㌯")+l11l1111l11_ll_+l111lll_ll_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭㌰"),l11l1111l11_ll_,166,l111lll_ll_ (u"ࠨࠩ㌱"),l111lll_ll_ (u"ࠩࠪ㌲"),l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㌳")+options)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㌴"),l111lll_ll_ (u"ࠬหูศัฬࠤฬ๊ืๅสࠣห้฿ิ้ษษ๎๋ࠥๆ่ࠡไืࠥอไใี่ࠫ㌵"),l11l1111l11_ll_,166,l111lll_ll_ (u"࠭ࠧ㌶"),l111lll_ll_ (u"ࠧࠨ㌷"),l111lll_ll_ (u"ࠨࡡࡉࡓࡗࡍࡅࡕࡔࡈࡗ࡚ࡒࡔࡔࡡࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭㌸")+options)
		l111_ll_(l111lll_ll_ (u"ࠩ࡯࡭ࡳࡱࠧ㌹"),l111lll_ll_ (u"ࠪ࡟ࡈࡕࡌࡐࡔࠣࡊࡋࡉ࠸࠺࠲࠳࠼ࡢࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡠ࠵ࡃࡐࡎࡒࡖࡢ࠭㌺"),l111lll_ll_ (u"ࠫࠬ㌻"),9999)
	for l1111l_ll_ in sorted(l1l11ll111l_ll_[l11l1111l11_ll_].keys()):
		type,name,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_ = l1l11ll111l_ll_[l11l1111l11_ll_][l1111l_ll_]
		if l111lll_ll_ (u"ࠬࡥࡒࡂࡐࡇࡓࡒࡥࠧ㌼") in options or len(l1l11ll111l_ll_[l11l1111l11_ll_])==1:
			l1lll1111ll_ll_(type,l111lll_ll_ (u"࠭ࠧ㌽"),url,l1l111lll11_ll_,l111lll_ll_ (u"ࠧࠨ㌾"),page,text,l111lll_ll_ (u"ࠨࠩ㌿"))
			l11l11lll_ll_[:] = l1ll1ll11l1l_ll_(l11l11lll_ll_)
			l1ll1l1ll1l1_ll_,l1l1l111l1_ll_ = l11l11lll_ll_[:3],l11l11lll_ll_[3:]
			for i in range(9): random.shuffle(l1l1l111l1_ll_)
			if l111lll_ll_ (u"ࠩࡢࡖࡆࡔࡄࡐࡏࡢࠫ㍀") in options: l11l11lll_ll_[:] = l1ll1l1ll1l1_ll_+l1l1l111l1_ll_[:l1ll1ll1ll11_ll_]
			else: l11l11lll_ll_[:] = l1ll1l1ll1l1_ll_+l1l1l111l1_ll_
		elif l111lll_ll_ (u"ࠪࡣࡘࡏࡔࡆࡕࡢࠫ㍁") in options: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㍂"),l1111l_ll_,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ㍃"),str(l1l11ll111l_ll_[l11l1111l11_ll_]))
	#l1ll1l_ll_(str(l1l11ll111l_ll_[l11l1111l11_ll_].keys()),str(l1l11ll111l_ll_[l11l1111l11_ll_]))
	return
def l1ll1ll1111l_ll_(options,mode):
	options = options.replace(l111lll_ll_ (u"࠭࡟ࡇࡑࡕࡋࡊ࡚ࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㍄"),l111lll_ll_ (u"ࠧࠨ㍅")).replace(l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬ㍆"),l111lll_ll_ (u"ࠩࠪ㍇"))
	#l1ll1l_ll_(options,str(mode))
	name,l1ll1l1ll11l_ll_ = l111lll_ll_ (u"ࠪࠫ㍈"),[]
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㍉"),l111lll_ll_ (u"ࠬࡡࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㍊")+name+l111lll_ll_ (u"࡛࠭࠰ࡅࡒࡐࡔࡘ࡝ࠡษ็ๆุ๋ࠠ࠻ࠢ࡞ࠤࠬ㍋"),l111lll_ll_ (u"ࠧࠨ㍌"),mode,l111lll_ll_ (u"ࠨࠩ㍍"),l111lll_ll_ (u"ࠩࠪ㍎"),l111lll_ll_ (u"ࠪࡣࡋࡕࡒࡈࡇࡗࡖࡊ࡙ࡕࡍࡖࡖࡣࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㍏")+options)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ㍐"),l111lll_ll_ (u"ࠬหูศัฬࠤ฼๊ศࠡไึ้ࠥ฿ิ้ษษ๎ࠬ㍑"),l111lll_ll_ (u"࠭ࠧ㍒"),mode,l111lll_ll_ (u"ࠧࠨ㍓"),l111lll_ll_ (u"ࠨࠩ㍔"),l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㍕")+options)
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㍖"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㍗"),l111lll_ll_ (u"ࠬ࠭㍘"),9999)
	l1ll1l1ll1l1_ll_ = l11l11lll_ll_[:]
	l11l11lll_ll_[:] = []
	if l111lll_ll_ (u"࠭࡟ࡔࡋࡗࡉࡘࡥࠧ㍙") in options:
		l1ll1lll1l1l_ll_()
		if l1l11ll111l_ll_=={}: return
		l1ll1lll1l11_ll_ = l1l11ll111l_ll_.keys()
		l11l1111l11_ll_ = random.sample(l1ll1lll1l11_ll_,1)[0]
		l1ll1lll11l1_ll_ = l1l11ll111l_ll_[l11l1111l11_ll_].keys()
		l1111l_ll_ = random.sample(l1ll1lll11l1_ll_,1)[0]
		type,name,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_ = l1l11ll111l_ll_[l11l1111l11_ll_][l1111l_ll_]
		l1111l1l_ll_(l111lll_ll_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ㍚"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠨࠢࠣࠤࡗࡧ࡮ࡥࡱࡰࠤࡈࡧࡴࡦࡩࡲࡶࡾࠦࠠࠡࡹࡨࡦࡸ࡯ࡴࡦ࠼ࠣࠫ㍛")+l1111l_ll_+l111lll_ll_ (u"ࠩࠣࠤࠥࡴࡡ࡮ࡧ࠽ࠤࠬ㍜")+name+l111lll_ll_ (u"ࠪࠤࠥࠦࡵࡳ࡮࠽ࠤࠬ㍝")+url+l111lll_ll_ (u"ࠫࠥࠦࠠ࡮ࡱࡧࡩ࠿ࠦࠧ㍞")+str(l1l111lll11_ll_))
	elif l111lll_ll_ (u"ࠬࡥࡉࡑࡖ࡙ࡣࠬ㍟") in options:
		l1ll1ll11111_ll_(options)
		type,name,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_ = random.sample(l11l11lll_ll_,1)[0]
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭㍠"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡖࡦࡴࡤࡰ࡯ࠣࡇࡦࡺࡥࡨࡱࡵࡽࠥࠦࠠ࡯ࡣࡰࡩ࠿ࠦࠧ㍡")+name+l111lll_ll_ (u"ࠨࠢࠣࠤࡺࡸ࡬࠻ࠢࠪ㍢")+url+l111lll_ll_ (u"ࠩࠣࠤࠥࡳ࡯ࡥࡧ࠽ࠤࠬ㍣")+str(l1l111lll11_ll_))
	l1ll1l1lllll_ll_ = name
	l1ll1ll11lll_ll_ = []
	for i in range(0,10):
		if i>0: l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ㍤"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡓࡣࡱࡨࡴࡳࠠࡄࡣࡷࡩ࡬ࡵࡲࡺࠢࠣࠤࡳࡧ࡭ࡦ࠼ࠣࠫ㍥")+name+l111lll_ll_ (u"ࠬࠦࠠࠡࡷࡵࡰ࠿ࠦࠧ㍦")+url+l111lll_ll_ (u"࠭ࠠࠡࠢࡰࡳࡩ࡫࠺ࠡࠩ㍧")+str(l1l111lll11_ll_))
		l11l11lll_ll_[:] = []
		#l1ll1l_ll_(name,l111lll_ll_ (u"ࠧࠨ㍨"))
		if l1l111lll11_ll_==234 and l111lll_ll_ (u"ࠨࡡࡢࡍࡕ࡚ࡖࡔࡧࡵ࡭ࡪࡹ࡟ࡠࠩ㍩") in text: l1l111lll11_ll_ = 233
		if l1l111lll11_ll_==144: l1l111lll11_ll_ = 291
		html = l1lll1111ll_ll_(type,name,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_)
		#if l111lll_ll_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥࠧ㍪") in html: l1ll1ll1111l_ll_(options,mode)
		if l111lll_ll_ (u"ࠪࡣࡎࡖࡔࡗࡡࠪ㍫") in options and l1l111lll11_ll_==167: del l11l11lll_ll_[:3]
		l1ll1l1ll11l_ll_[:] = l1ll1ll11l1l_ll_(l11l11lll_ll_)
		if l1ll1ll11lll_ll_ and l1ll111l1ll_ll_(l111lll_ll_ (u"ࡹࠬำไใหࠪ㍬")) in str(l1ll1l1ll11l_ll_) or l1ll111l1ll_ll_(l111lll_ll_ (u"ࡺ࠭อๅไ๊ࠫ㍭")) in str(l1ll1l1ll11l_ll_):
			name = l1ll1l1lllll_ll_
			l1ll1l1ll11l_ll_[:] = l1ll1ll11lll_ll_
			break
		l1ll1l1lllll_ll_ = name
		l1ll1ll11lll_ll_ = l1ll1l1ll11l_ll_[:]
		if str(l1ll1l1ll11l_ll_).count(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳࠬ㍮"))>0: break
		if str(l1ll1l1ll11l_ll_).count(l111lll_ll_ (u"ࠧ࡭࡫ࡹࡩࠬ㍯"))>0: break
		if l1l111lll11_ll_==233: break	# l1111ll1l11_ll_ series names l11l1l1ll11_ll_ of episodes name
		if l1l111lll11_ll_==291: break	# youtube channels names l11l1l1ll11_ll_ of youtube channels contents
		if l1ll1l1ll11l_ll_: type,name,url,l1l111lll11_ll_,image,page,text,l1l1111111_ll_ = random.sample(l1ll1l1ll11l_ll_,1)[0]
	if name==l111lll_ll_ (u"ࠨࠩ㍰"): name = l111lll_ll_ (u"ࠩ࠱࠲࠳࠴ࠧ㍱")
	elif name.count(l111lll_ll_ (u"ࠪࡣࠬ㍲"))>1: name = name.split(l111lll_ll_ (u"ࠫࡤ࠭㍳"),2)[2]
	name = name.replace(l111lll_ll_ (u"࡛ࠬࡎࡌࡐࡒ࡛ࡓࡀࠠࠨ㍴"),l111lll_ll_ (u"࠭ࠧ㍵"))#.replace(l111lll_ll_ (u"ࠧ࠭ࡏࡒ࡚ࡎࡋࡓ࠻ࠢࠪ㍶"),l111lll_ll_ (u"ࠨࠩ㍷")).replace(l111lll_ll_ (u"ࠩ࠯ࡗࡊࡘࡉࡆࡕ࠽ࠤࠬ㍸"),l111lll_ll_ (u"ࠪࠫ㍹")).replace(l111lll_ll_ (u"ࠫ࠱ࡒࡉࡗࡇ࠽ࠤࠬ㍺"),l111lll_ll_ (u"ࠬ࠭㍻"))
	l1ll1l1ll1l1_ll_[0][1] = l111lll_ll_ (u"࡛࠭ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࠫ㍼")+name+l111lll_ll_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢส่็ูๅࠡ࠼ࠣ࡟ࠥ࠭㍽")
	for i in range(9): random.shuffle(l1ll1l1ll11l_ll_)
	if l111lll_ll_ (u"ࠨࡡࡕࡅࡓࡊࡏࡎࡡࠪ㍾") in options: l11l11lll_ll_[:] = l1ll1l1ll1l1_ll_+l1ll1l1ll11l_ll_[:l1ll1ll1ll11_ll_]
	else: l11l11lll_ll_[:] = l1ll1l1ll1l1_ll_+l1ll1l1ll11l_ll_
	return
def l1ll1l1lll1l_ll_(l1111ll1l1_ll_,l111ll1111_ll_):
	l111ll1111_ll_ = l111ll1111_ll_.replace(l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࠫ㍿"),l111lll_ll_ (u"ࠪࠫ㎀")).replace(l111lll_ll_ (u"ࠫࡤࡘࡅࡎࡇࡐࡆࡊࡘࡒࡆࡕࡘࡐ࡙࡙࡟ࠨ㎁"),l111lll_ll_ (u"ࠬ࠭㎂"))
	#l1ll1l_ll_(l1111ll1l1_ll_,l111ll1111_ll_)
	l1ll1ll111l1_ll_ = l111ll1111_ll_
	if l111lll_ll_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㎃") in l111ll1111_ll_:
		l1ll1ll111l1_ll_ = l111ll1111_ll_.split(l111lll_ll_ (u"ࠧࡠࡡࡌࡔ࡙࡜ࡓࡦࡴ࡬ࡩࡸࡥ࡟ࠨ㎄"))[0]
		type = l111lll_ll_ (u"ࠨ࠮ࡖࡉࡗࡏࡅࡔ࠼ࠣࠫ㎅")
	elif l111lll_ll_ (u"࡙ࠩࡓࡉ࠭㎆") in l1111ll1l1_ll_: type = l111lll_ll_ (u"ࠪ࠰࡛ࡏࡄࡆࡑࡖ࠾ࠥ࠭㎇")
	elif l111lll_ll_ (u"ࠫࡑࡏࡖࡆࠩ㎈") in l1111ll1l1_ll_: type = l111lll_ll_ (u"ࠬ࠲ࡌࡊࡘࡈ࠾ࠥ࠭㎉")
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭㎊"),l111lll_ll_ (u"ࠧ࡜ࠢ࡞ࡇࡔࡒࡏࡓࠢࡉࡊࡈ࠾࠹࠱࠲࠻ࡡࠬ㎋")+type+l1ll1ll111l1_ll_+l111lll_ll_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣห้่ำๆࠢ࠽ࠤࡠࠦࠧ㎌"),l1111ll1l1_ll_,167,l111lll_ll_ (u"ࠩࠪ㎍"),l111lll_ll_ (u"ࠪࠫ㎎"),l111lll_ll_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ㎏")+l111ll1111_ll_)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ㎐"),l111lll_ll_ (u"࠭ลฺษาอࠥอไุๆหࠤฬู๊ี๊สส๏ࠦๅ็้ࠢๅุࠦวๅไึ้ࠬ㎑"),l1111ll1l1_ll_,167,l111lll_ll_ (u"ࠧࠨ㎒"),l111lll_ll_ (u"ࠨࠩ㎓"),l111lll_ll_ (u"ࠩࡢࡊࡔࡘࡇࡆࡖࡕࡉࡘ࡛ࡌࡕࡕࡢࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ㎔")+l111ll1111_ll_)
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ㎕"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ㎖"),l111lll_ll_ (u"ࠬ࠭㎗"),9999)
	import l1111lllll_ll_
	if l111lll_ll_ (u"࠭࡟ࡠࡋࡓࡘ࡛࡙ࡥࡳ࡫ࡨࡷࡤࡥࠧ㎘") in l111ll1111_ll_: l1111lllll_ll_.l1lllll1l11_ll_(l1111ll1l1_ll_,l111ll1111_ll_,l111lll_ll_ (u"ࠧࠨ㎙"))
	else: l1111lllll_ll_.l11ll1l11l_ll_(l1111ll1l1_ll_,l111ll1111_ll_)
	l11l11lll_ll_[:] = l1ll1ll11l1l_ll_(l11l11lll_ll_)
	if len(l11l11lll_ll_)>(l1ll1ll1ll11_ll_+3): l11l11lll_ll_[:] = l11l11lll_ll_[:3]+random.sample(l11l11lll_ll_[3:],l1ll1ll1ll11_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ㎚"),str(l1l11ll111l_ll_[l11l1111l11_ll_]))
	#l1ll1l_ll_(str(l1l11ll111l_ll_[l11l1111l11_ll_].keys()),str(l1l11ll111l_ll_[l11l1111l11_ll_]))
	return
def l1ll1ll11l1l_ll_(l11l11lll_ll_):
	l1ll1l1ll11l_ll_ = []
	for type,name,url,mode,image,page,text,l1l1111111_ll_ in l11l11lll_ll_:
		if l111lll_ll_ (u"ุࠩๅาฯࠧ㎛") in name or l111lll_ll_ (u"ูࠪๆำ็ࠨ㎜") in name or l111lll_ll_ (u"ࠫࡵࡧࡧࡦࠩ㎝") in name.lower(): continue
		l1ll1l1ll11l_ll_.append([type,name,url,mode,image,page,text,l1l1111111_ll_])
	return l1ll1l1ll11l_ll_