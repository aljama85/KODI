# coding: UTF-8
from __future__ import unicode_literals
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
def l1l1111111ll_ll_():
	#l1ll11l_ll_(l111lll_ll_ (u"ࠨฮสี๏ࠦแฮืࠪ㸓"),l111lll_ll_ (u"ࠩฯ้๏฿ࠠศๆ่์ฬู่ࠨ㸔"))
	l11ll11llll1_ll_ = l11l11l_ll_.keys()
	headers = { l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ㸕") : l111lll_ll_ (u"ࠫࠬ㸖") }
	def l11ll1ll11ll_ll_(type,proxy_url=l111lll_ll_ (u"ࠬ࠭㸗")):
		def l11ll1l11ll1_ll_(site,type,proxy_url):
			if type==l111lll_ll_ (u"࠭ࡰࡳࡱࡻࡽࠬ㸘"): url = l11l11l_ll_[site][0]+l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡕࡸ࡯ࡹࡻࡘࡶࡱࡃࠧ㸙")+proxy_url
			else: url = l11l11l_ll_[site][0]
			if type==l111lll_ll_ (u"ࠨࡦ࡬ࡶࡪࡩࡴࠨ㸚"): html = l111ll1_ll_(l1l11lll_ll_,url,l111lll_ll_ (u"ࠩࠪ㸛"),headers,l111lll_ll_ (u"ࠪࠫ㸜"),l111lll_ll_ (u"ࠫࡘࡋࡒࡗࡋࡆࡉࡘ࠳ࡔࡆࡕࡗࡣࡆࡒࡌࡠ࡙ࡈࡆࡘࡏࡔࡆࡕ࠰࠵ࡸࡺࠧ㸝"))
			elif type==l111lll_ll_ (u"ࠬࡶࡲࡰࡺࡼࠫ㸞"): html = l111ll1ll1l_ll_(url,l111lll_ll_ (u"࠭ࠧ㸟"),headers,l111lll_ll_ (u"ࠧࠨ㸠"),l111lll_ll_ (u"ࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡘࡊ࡙ࡔࡠࡃࡏࡐࡤ࡝ࡅࡃࡕࡌࡘࡊ࡙࠭࠳ࡰࡧࠫ㸡"))
			#if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࡳࠨ㸢") in url: html = l111lll_ll_ (u"ࠪࡣࡤࡥࡅࡳࡴࡲࡶࡤࡥ࡟ࠨ㸣")
			#else: html = l111lll_ll_ (u"ࠫࠬ㸤")
			return html
		threads = l11ll11lll_ll_(True)
		for site in l11ll11llll1_ll_:
			threads.start_new_thread(type+l111lll_ll_ (u"ࠬࡥࠧ㸥")+site,l11ll1l11ll1_ll_,site,type,proxy_url)
		threads.l11ll11ll1_ll_()
		return threads.l11ll11111_ll_
	l11ll1l11l1l_ll_ = l11ll1ll11ll_ll_(l111lll_ll_ (u"࠭ࡤࡪࡴࡨࡧࡹ࠭㸦"))
	type,l11ll1ll111l_ll_,l111ll111ll_ll_,l11ll1l111ll_ll_ = l111lll_ll_ (u"ࠧࡥ࡫ࡵࡩࡨࡺࠧ㸧"),l111lll_ll_ (u"ࠨࠩ㸨"),l111lll_ll_ (u"ࠩࠪ㸩"),l111lll_ll_ (u"ࠪࠫ㸪")
	for site in sorted(l11ll11llll1_ll_):
		result = l11ll1l11l1l_ll_[type+l111lll_ll_ (u"ࠫࡤ࠭㸫")+site]
		if l111lll_ll_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ㸬") not in result: l11ll1ll111l_ll_ += site.lower()+l111lll_ll_ (u"࠭ࠠࠡࠩ㸭")
		else: l11ll1ll111l_ll_ += l111lll_ll_ (u"ࠧ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ࠪ㸮")+site.lower()+l111lll_ll_ (u"ࠨ࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࠤࠬ㸯")
	if l111lll_ll_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥࠧ㸰") in str(l11ll1l11l1l_ll_):
		l111ll1l11l_ll_,l111llll1ll_ll_ = l111l11l1l1_ll_()
		l11ll1l1l111_ll_,l11ll1l11l11_ll_ = [],[]
		i = 0
		for id in l111ll1l11l_ll_:
			l11ll1l1l111_ll_.append(l11llll1_ll_[id][0]+l111lll_ll_ (u"ࠪࠤࠥࠦࠧ㸱")+str(int(1000*l111llll1ll_ll_[i]))+l111lll_ll_ (u"ࠫࡲࡹࠧ㸲"))
			l11ll1l11l11_ll_.append(l11llll1_ll_[id][1])
			i += 1
		selection = l1l1111_ll_(str(len(l11ll1l1l111_ll_))+l111lll_ll_ (u"ࠬࠦวฯฬิࠤอื่ไีํࠤ࠭อไฤีิ฽ࠥ็่ใࠫࠪ㸳"), l11ll1l1l111_ll_)
		if selection == -1: return
		else:
			l111ll111ll_ll_ = l11ll1l1l111_ll_[selection].split(l111lll_ll_ (u"࠭ࠠࠡࠢࠪ㸴"))[0]
			l11ll1ll11l_ll_ = l11ll1l11l11_ll_[selection]
		type,l11ll1l11111_ll_ = l111lll_ll_ (u"ࠧࡱࡴࡲࡼࡾ࠭㸵"),l111lll_ll_ (u"ࠨࠩ㸶")
		l11ll1l111ll_ll_ = l11ll1ll11ll_ll_(l111lll_ll_ (u"ࠩࡳࡶࡴࡾࡹࠨ㸷"),l11ll1ll11l_ll_)
		for site in sorted(l11ll11llll1_ll_):
			result = l11ll1l111ll_ll_[type+l111lll_ll_ (u"ࠪࡣࠬ㸸")+site]
			if l111lll_ll_ (u"ࠫࡤࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࡠࠩ㸹") not in result: l11ll1l11111_ll_ += site.lower()+l111lll_ll_ (u"ࠬࠦࠠࠨ㸺")
			else: l11ll1l11111_ll_ += l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞ࠩ㸻")+site.lower()+l111lll_ll_ (u"ࠧ࡜࠱ࡆࡓࡑࡕࡒ࡞ࠢࠣࠫ㸼")
	else: l11ll1l11111_ll_ = l111lll_ll_ (u"ࠨฮ่๎฾ࠦวๅ็๋ห็฿ࠠห฻่่ࠥ฿ๆะๅࠣ์ฬ๊ศา่ส้ัࠦไศࠢํัฯอฬࠡสิ์ู่๊ࠨ㸽")
	message  = l111lll_ll_ (u"ࠩࡀࡁࠥอไๆ๊สๆ฾ࠦวๅสํฺฬวࠠห฻่่ࠥ๎วๅฯ่ีฬวࠠๅษࠣฮ฾๋ไࠡ࠿ࡀࠫ㸾")
	message += l111lll_ll_ (u"ࠪࡠࡳࡢ࡮ࠨ㸿")+l111lll_ll_ (u"ࠫࡂࡃࠠ࡜ࡅࡒࡐࡔࡘࠠࡇࡈࡆ࠼࠾࠶࠰࠹࡟ไัฺࠦศศีอาิอๅࠡึห็ฮࠦวๅว้ฮึ์๊หࠢส่ำอีสࠢห็ࡠ࠵ࡃࡐࡎࡒࡖࡢࠦ࠽࠾ࠩ㹀")
	message += l111lll_ll_ (u"ࠬࡢ࡮ࠨ㹁")+l11ll1ll111l_ll_.strip(l111lll_ll_ (u"࠭ࠠࠨ㹂"))
	if l111ll111ll_ll_!=l111lll_ll_ (u"ࠧࠨ㹃"): message += l111lll_ll_ (u"ࠨ࡞ࡱࡠࡳ࠭㹄")+l111lll_ll_ (u"ࠩࡀࡁࠥࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝โฯุࠤออำหะาห๊ࠦศา๊ๆื๏ࠦๅ้ฮ๋ำࠥ็๊ࠡࠩ㹅")+l111ll111ll_ll_+l111lll_ll_ (u"ࠪ࡟࠴ࡉࡏࡍࡑࡕࡡࠥࡃ࠽ࠨ㹆")
	else: message += l111lll_ll_ (u"ࠫࡡࡴ࡜࡯ࠩ㹇")+l111lll_ll_ (u"ࠬࡃ࠽ࠡ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠๅา฻ࠠษษึฮำีวๆࠢหีํ้ำ๋ࠢหฬ้ี้ࠠว้ฮึ์๊ห่ࠢาฯ๊แส࡝࠲ࡇࡔࡒࡏࡓ࡟ࠣࡁࡂ࠭㹈")
	message += l111lll_ll_ (u"࠭࡜࡯ࠩ㹉")+l11ll1l11111_ll_.strip(l111lll_ll_ (u"ࠧࠡࠩ㹊"))
	l11l1l1ll_ll_(l111lll_ll_ (u"ࠨใะูࠥาๅ๋฻้ࠣํอโฺࠢส่อืๆศ็ฯࠫ㹋"),message)
	l11ll1ll1111_ll_,proxy = l111lll_ll_ (u"ࠩࠪ㹌"),l111lll_ll_ (u"ࠪࠫ㹍")
	if l111lll_ll_ (u"ࠫࡤࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࡠࠩ㹎") in str(l11ll1l11l1l_ll_): l11ll1ll1111_ll_ = l111lll_ll_ (u"ࠬࡶࡲࡰࡤ࡯ࡩࡲ࠭㹏")
	if l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ㹐") in str(l11ll1l111ll_ll_): proxy = l111lll_ll_ (u"ࠧࡱࡴࡲࡦࡱ࡫࡭ࠨ㹑")
	if l11ll1ll1111_ll_==l111lll_ll_ (u"ࠨࡲࡵࡳࡧࡲࡥ࡮ࠩ㹒") and proxy!=l111lll_ll_ (u"ࠩࡳࡶࡴࡨ࡬ࡦ࡯ࠪ㹓"):
		l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㹔"),l111lll_ll_ (u"ࠫฬ๊ๅีๅ็อࠥอไห์ࠣ฽๋ีใࠡใํࠤอ฿ึࠡษ็้ํอโฺࠢๅำࠥอฮหใอࠤออำหะาห๊ࠦศา๊ๆื๏่่ࠦาสࠤ๊฿ๆศ้ࠣห๋ࠦวๅ็ื็้ฯࠠๆ่ࠣ฻ึ็ใ๊ࠡ็๎ุะࠠๆ่ࠣห้ฮั็ษ่ะ࠳ࠦอศ๊็ࠤา๊ࠠๆึๆ่ฯ้ࠠฦ็สࠤออำหะาห๊ࠦࡄࡏࡕࠣวํࠦࡐࡳࡱࡻࡽࠥษ่ࠡࡘࡓࡒࠬ㹕"))
	elif l11ll1ll1111_ll_==l111lll_ll_ (u"ࠬࡶࡲࡰࡤ࡯ࡩࡲ࠭㹖") and proxy==l111lll_ll_ (u"࠭ࡰࡳࡱࡥࡰࡪࡳࠧ㹗"):
		l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㹘"),l111lll_ll_ (u"ࠨ็ื็้ะใฺ๊ࠡีฯࠦๅฺࠢหีํ้ำ๋๋ࠢฬิ๎ๆࠡสิ์ู่๊๊ࠡึฬอํวࠡว่ห๋ࠥๆࠡษ็้ํู่ࠡษ็วฺ๊๊ࠡล๋ࠤฬ๊ศา่ส้ัࠦร้ࠢส่อื่ไีํࠤฬ๊ะ๋ࠢส๊ฯࠦวฯฬิฮ์࠴ࠠอำหࠤส฿วะหࠣห้็อึࠢหหำะ๊ศำࠣฬึ๎ใิ์้ࠣำะไโ๋ࠢหึูไࠡีฯ่ࠥอไฤะฺหฦ่ࠦศๆสืฯิฯศ็่้๋ࠣศา็ฯࠤ๋࠭ๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠪࠩ㹙"))
	elif l11ll1ll1111_ll_!=l111lll_ll_ (u"ࠩࡳࡶࡴࡨ࡬ࡦ࡯ࠪ㹚"):
		l1ll1l_ll_(l111lll_ll_ (u"ࠪีุอไส่๊ࠢࠥอไๆสิ้ั࠭㹛"),l111lll_ll_ (u"ࠫัฺ๋๊ࠢส่๊๎วใ฻ࠣฮ฾๋ไࠡ฻้ำ่ࠦศะ๊้ࠤฺ๊ใๅหࠣ์์ึวࠡ็฼๊ฬํࠠฦ่ࠣะ์อาไࠢ็หࠥ๐อหษฯࠤศ๐ࠠห฻า๎้อส࠯ࠢไษีอࠠไษ้ฮ๊ࠥฯ๋ๅู้้ࠣไสࠢไ๎ࠥอไษำ้ห๊าࠠโไ่ࠤอหัิษ็ࠤุาไࠡษ็วำ฽วย๋ࠢห้อำหะาห๊ࠦลๅ๋ࠣห้๋ศา็ฯࠤ๋࠭ๆࠡไสส๊ฯࠠฯั่หฯࠦวๅสิ๊ฬ๋ฬࠪࠩ㹜"))
	return
def l11ll1l1lll1_ll_(l11ll1l11lll_ll_,l1l111l1llll_ll_):
	l11lll11ll11_ll_,l1l111ll1l1l_ll_ = l111lll_ll_ (u"ࠬ࠭㹝"),l111lll_ll_ (u"࠭ࠧ㹞")
	html = l111ll1_ll_(l1l11lll_ll_,l1l111l1llll_ll_,l111lll_ll_ (u"ࠧࠨ㹟"),l111lll_ll_ (u"ࠨࠩ㹠"),l111lll_ll_ (u"ࠩࠪ㹡"),l111lll_ll_ (u"ࠪࡗࡊࡘࡖࡊࡅࡈࡗ࠲ࡒࡁࡕࡇࡖࡘࡤࡋࡍࡂࡆࡢ࡚ࡊࡘࡓࡊࡑࡑࡗ࠲࠷ࡳࡵࠩ㹢"))
	l11ll11lll1l_ll_ = re.findall(l111lll_ll_ (u"ࠫࡳࡧ࡭ࡦ࠿ࠥࠫ㹣")+l11ll1l11lll_ll_+l111lll_ll_ (u"ࠬࠨࠠࡷࡧࡵࡷ࡮ࡵ࡮࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩ㹤"),html,re.DOTALL)
	if l11ll11lll1l_ll_: l11lll11ll11_ll_ = l11ll11lll1l_ll_[0]
	l11ll1ll11l1_ll_ = re.findall(l111lll_ll_ (u"࠭ࠢࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡡࡳࡣࡥ࡭ࡨࡼࡩࡥࡧࡲࡷࠧࠦ࡮ࡢ࡯ࡨࡁࠧࡋࡍࡂࡆࠣࡅࡷࡧࡢࡪࡥ࡚ࠣ࡮ࡪࡥࡰࡵࠥࠤࡻ࡫ࡲࡴ࡫ࡲࡲࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭㹥"),html,re.DOTALL)
	if l11ll1ll11l1_ll_: l1l111ll1l1l_ll_ = l11ll1ll11l1_ll_[0]
	l111lll_ll_ (u"ࠧࠨࠩࠐࠎࠎࡻࡲ࡭ࠢࡀࠤࠬ࡮ࡴࡵࡲ࠽࠳࠴࡫࡭ࡢࡦࡰࡥ࡭ࡪࡩ࠯ࡲࡼࡸ࡭ࡵ࡮ࡢࡰࡼࡻ࡭࡫ࡲࡦ࠰ࡦࡳࡲ࠵ࡋࡐࡆࡌ࠳ࡦࡪࡤࡰࡰࡶ࠲ࡽࡳ࡬ࠨࠏࠍࠍ࡭ࡺ࡭࡭ࠢࡀࠤࡔࡖࡅࡏࡗࡕࡐࡤࡉࡁࡄࡊࡈࡈ࠭ࡔࡏࡠࡅࡄࡇࡍࡋࠬࡶࡴ࡯࠰ࠬ࠭ࠬࠨࠩ࠯ࠫࠬ࠲ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡏࡅ࡙ࡋࡓࡕࡡࡈࡑࡆࡊ࡟ࡗࡇࡕࡗࡎࡕࡎࡔ࠯࠵ࡲࡩ࠭ࠩࠎࠌࠌࡖࡊࡖࡏࡠࡘࡈࡖ࠸ࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭࡮ࡢ࡯ࡨࡁࠧࡋࡍࡂࡆࠣࡖࡪࡶ࡯ࡴ࡫ࡷࡳࡷࡿࠢࠡࡸࡨࡶࡸ࡯࡯࡯࠿ࠥࠬ࠳࠰࠿ࠪࠤࠪ࠰࡭ࡺ࡭࡭࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠓࠊࠊ࡫ࡩࠤࡗࡋࡐࡐࡡ࡙ࡉࡗ࠹࠺ࠡࡔࡈࡔࡔࡥࡖࡆࡔ࠶ࠤࡂࠦࡒࡆࡒࡒࡣ࡛ࡋࡒ࠴࡝࠳ࡡࠒࠐࠉࡂࡆࡇࡓࡓࡥࡖࡆࡔ࠶ࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫࠧࡶ࡬ࡶࡩ࡬ࡲ࠳ࡼࡩࡥࡧࡲ࠲ࡦࡸࡡࡣ࡫ࡦࡺ࡮ࡪࡥࡰࡵࠥࠤࡳࡧ࡭ࡦ࠿ࠥࡉࡒࡇࡄࠡࡃࡵࡥࡧ࡯ࡣࠡࡘ࡬ࡨࡪࡵࡳࠣࠢࡹࡩࡷࡹࡩࡰࡰࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ࠱࡮ࡴ࡮࡮࠯ࡶࡪ࠴ࡄࡐࡖࡄࡐࡑ࠯ࠍࠋࠋ࡬ࡪࠥࡇࡄࡅࡑࡑࡣ࡛ࡋࡒ࠴࠼ࠣࡅࡉࡊࡏࡏࡡ࡙ࡉࡗ࠹ࠠ࠾ࠢࡄࡈࡉࡕࡎࡠࡘࡈࡖ࠸ࡡ࠰࡞ࠏࠍࠍ࡮࡬ࠠࡓࡇࡓࡓࡤ࡜ࡅࡓ࠴ࡁࡖࡊࡖࡏࡠࡘࡈࡖ࠸ࡀࠠ࡭ࡣࡷࡩࡸࡺ࡟ࡓࡇࡓࡓࡤ࡜ࡅࡓࠢࡀࠤࡗࡋࡐࡐࡡ࡙ࡉࡗ࠸ࠍࠋࠋࡨࡰࡸ࡫࠺ࠡ࡮ࡤࡸࡪࡹࡴࡠࡔࡈࡔࡔࡥࡖࡆࡔࠣࡁࠥࡘࡅࡑࡑࡢ࡚ࡊࡘ࠳ࠎࠌࠌ࡭࡫ࠦࡁࡅࡆࡒࡒࡤ࡜ࡅࡓ࠴ࡁࡅࡉࡊࡏࡏࡡ࡙ࡉࡗ࠹࠺ࠡ࡮ࡤࡸࡪࡹࡴࡠࡃࡇࡈࡔࡔ࡟ࡗࡇࡕࠤࡂࠦࡁࡅࡆࡒࡒࡤ࡜ࡅࡓ࠴ࠐࠎࠎ࡫࡬ࡴࡧ࠽ࠤࡱࡧࡴࡦࡵࡷࡣࡆࡊࡄࡐࡐࡢ࡚ࡊࡘࠠ࠾ࠢࡄࡈࡉࡕࡎࡠࡘࡈࡖ࠸ࠓࠊࠊ࡫ࡩࠤࡰࡵࡤࡪࡡࡹࡩࡷࡹࡩࡰࡰࡁ࠵࠽࠴࠹࠺࠻࠽ࠑࠏࠏࠉࡶࡴ࡯ࠤࡂࠦࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡴࡤࡻ࠳࡭ࡩࡵࡪࡸࡦࡺࡹࡥࡳࡥࡲࡲࡹ࡫࡮ࡵ࠰ࡦࡳࡲ࠵ࡥ࡮ࡣࡧࡱࡦ࡮ࡤࡪ࠱ࡎࡓࡉࡏ࠯࡮ࡣࡶࡸࡪࡸ࠯ࡂࡆࡇࡓࡓ࡙࠱࠺࠱ࡤࡨࡩࡵ࡮ࡴ࠳࠼࠲ࡽࡳ࡬ࠨࠏࠍࠍࠎ࡮ࡴ࡮࡮ࠣࡁࠥࡕࡐࡆࡐࡘࡖࡑࡥࡃࡂࡅࡋࡉࡉ࠮ࡎࡐࡡࡆࡅࡈࡎࡅ࠭ࡷࡵࡰ࠱࠭ࠧ࠭ࠩࠪ࠰ࠬ࠭ࠬࠨࡕࡈࡖ࡛ࡏࡃࡆࡕ࠰ࡐࡆ࡚ࡅࡔࡖࡢࡉࡒࡇࡄࡠࡘࡈࡖࡘࡏࡏࡏࡕ࠰࠷ࡷࡪࠧࠪࠏࠍࠍࠎࡲࡡࡵࡧࡶࡸࡤࡇࡄࡅࡑࡑࡣ࡛ࡋࡒࠡ࠿ࠣࡶࡪ࠴ࡦࡪࡰࡧࡥࡱࡲࠨࠨࠤࡳࡰࡺ࡭ࡩ࡯࠰ࡹ࡭ࡩ࡫࡯࠯ࡣࡵࡥࡧ࡯ࡣࡷ࡫ࡧࡩࡴࡹࠢࠡࡰࡤࡱࡪࡃࠢࡆࡏࡄࡈࠥࡇࡲࡢࡤ࡬ࡧࠥ࡜ࡩࡥࡧࡲࡷࠧࠦࡶࡦࡴࡶ࡭ࡴࡴ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠨ࠮࡫ࡸࡲࡲࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬ࡟࠵ࡣࠍࠋࠋࠪࠫࠬ㹦")
	return l11lll11ll11_ll_,l1l111ll1l1l_ll_
def l11lllll11ll_ll_():
	urls = [ l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡻࡦࡺࡣࡩࡁࡹࡁࡇࡧࡗࡠ࡬ࡨࡲࡴࢀࡋࡤࠩ㹧") ]
	#
	success = 0
	xbmc.log(l111lll_ll_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࠣࡗ࡙ࡇࡒࡕࡋࡑࡋࠥࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ㹨"),level=xbmc.LOGNOTICE)
	import youtube_dl
	#import resolveurl
	#import urlresolver
	ydl = youtube_dl.YoutubeDL({l111lll_ll_ (u"ࠪࡳࡺࡺࡴ࡮ࡲ࡯ࠫ㹩"): l111lll_ll_ (u"ࠫࠪ࠮ࡩࡥࠫࡶࠩ࠭࡫ࡸࡵࠫࡶࠫ㹪")})
	for url in urls:
		t1 = time.time()
		try:
			with ydl:
				result = ydl.extract_info(url,download=False) # l11ll1l1l1ll_ll_ just l11ll1l1l1l1_ll_ to extract the info
			#result = urlresolver.l1ll111l1l1l_ll_(url).l1ll11l111ll_ll_()
			#result = resolveurl.l1ll111l1l1l_ll_(url).l1ll11l111ll_ll_()
			if not result: raise
			success += 1
			message = l111lll_ll_ (u"ࠬࠦࠠࠡࠢࠣࠤࡘࡻࡣࡤࡧࡨࡨࡪࡪ࡟ࡪࡰࡳࡹࡹࡀࠠࠡࠩ㹫")+url+l111lll_ll_ (u"࠭ࠠࠡࠢࠪ㹬")+str(result)
			xbmc.log(l111lll_ll_ (u"ࠧࠡࠢࠣࠤࠥࠦࡓࡶࡥࡦࡩࡪࡪࡥࡥࡡࡲࡹࡹࡶࡵࡵ࠼ࠣࠤࠬ㹭")+str(result[l111lll_ll_ (u"ࠨࡨࡲࡶࡲࡧࡴࡴࠩ㹮")][0][l111lll_ll_ (u"ࠩࡸࡶࡱ࠭㹯")]),level=xbmc.LOGNOTICE)
			xbmc.log(l111lll_ll_ (u"ࠪࠤࠥࠦࠠࠡࠢࡖࡹࡨࡩࡥࡦࡦࡨࡨࡤࡵࡵࡵࡲࡸࡸ࠿ࠦࠠࠨ㹰")+str(result[l111lll_ll_ (u"ࠫ࡫ࡵࡲ࡮ࡣࡷࡷࠬ㹱")][0][l111lll_ll_ (u"ࠬ࡬࡯ࡳ࡯ࡤࡸࠬ㹲")]),level=xbmc.LOGNOTICE)
		except:
			message = l111lll_ll_ (u"࠭ࠠࠡࠢࠣࠤࠥࡌࡡࡪ࡮ࡨࡨ࠿ࠦࠠࠨ㹳")+url
		l1lll1l1l1_ll_ = time.time()
		t0 = str(l1lll1l1l1_ll_-t1)[0:4]
		xbmc.log(t0+message,level=xbmc.LOGNOTICE)
	l1ll1l_ll_(l111lll_ll_ (u"ࠧาีส่ฮࠦๅ็ࠢส่๊ฮัๆฮࠪ㹴"),l111lll_ll_ (u"ࠨࡆࡲࡲࡪ࠭㹵"),l111lll_ll_ (u"ࠩࡖࡹࡨࡩࡥࡦࡦࡨࡨ࠿ࠦࠠࠨ㹶")+str(success))
	xbmc.log(l111lll_ll_ (u"ࠪࡁࡂࡃ࠽࠾࠿ࡀࠤࡋࡏࡎࡊࡕࡋࡉࡉࠦ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ㹷"),level=xbmc.LOGNOTICE)
	return
	if l111lll_ll_ (u"ࠫࡪࡴࡴࡳ࡫ࡨࡷࠬ㹸") in result:
		# l11ll1l111l1_ll_ be a playlist or a list of videos
		video = result[l111lll_ll_ (u"ࠬ࡫࡮ࡵࡴ࡬ࡩࡸ࠭㹹")][0]
	else:
		# l11ll11lllll_ll_ a video
		video = result
	video_url = video[l111lll_ll_ (u"࠭ࡵࡳ࡮ࠪ㹺")]
	l1ll1l_ll_(video_url,video)
	return
	#l111lll1_ll_(url)
	#return
	#url = l111lll_ll_ (u"ࠧࠨ㹻")
	import resolveurl
	try:
		#l11ll1l1llll_ll_ = urlresolver.l1ll111l1l1l_ll_(url).l1l1ll11llll_ll_()
		link = resolveurl.l1ll111l1l1l_ll_(url).l1ll11l111ll_ll_()
		l1ll1l_ll_(str(link),url)
	except: l1ll1l_ll_(l111lll_ll_ (u"ࠨࡔࡨࡷࡴࡲࡶࡦࡴ࠽ࠤ࡫ࡧࡩ࡭ࡧࡧࠫ㹼"),url)
	return
	import l1_ll_
	titles,urls = l1_ll_.l1l1lll1l1ll_ll_(url)
	selection = l1l1111_ll_(l111lll_ll_ (u"ࠩࡗࡍ࡙ࡒࡅࡔࠢ࠽ࠫ㹽"), titles)
	selection = l1l1111_ll_(l111lll_ll_ (u"࡙ࠪࡗࡒࡓࠡ࠼ࠪ㹾"), urls)
	#url = l111lll_ll_ (u"ࠫࠬ㹿")
	#l111lll1_ll_(url)
	#settings.setSetting(l111lll_ll_ (u"ࠬࡺࡥࡴࡶ࠴ࠫ㺀"),l111lll_ll_ (u"࠭ࡨࡦ࡮࡯ࡳࠥࡺࡥࡴࡶ࠴ࠫ㺁"))
	#var = settings.getSetting(l111lll_ll_ (u"ࠧࡵࡧࡶࡸ࠷࠭㺂"))
	#xbmc.log(l111lll_ll_ (u"ࠨࡇࡐࡅࡉ࠷࠱ࠡࠩ㺃") + str(var) + l111lll_ll_ (u"ࠩࠣ࠵࠶ࡋࡍࡂࡆࠪ㺄"),level=xbmc.LOGNOTICE)
	#import subprocess
	#var = subprocess.check_output(l111lll_ll_ (u"ࠪࡻࡲ࡯ࡣࠡࡥࡶࡴࡷࡵࡤࡶࡥࡷࠤ࡬࡫ࡴࠡࡗࡘࡍࡉ࠭㺅"))
	#xbmc.log(l111lll_ll_ (u"ࠫࡊࡓࡁࡅ࠳࠴ࠤࠬ㺆") + str(var) + l111lll_ll_ (u"ࠬࠦ࠱࠲ࡇࡐࡅࡉ࠭㺇"),level=xbmc.LOGNOTICE)
	#import os
	#var = os.popen(l111lll_ll_ (u"ࠨࡷ࡮࡫ࡦࠤࡩ࡯ࡳ࡬ࡦࡵ࡭ࡻ࡫ࠠࡨࡧࡷࠤࡸ࡫ࡲࡪࡣ࡯ࡲࡺࡳࡢࡦࡴࠥ㺈")).read()
	#xbmc.log(l111lll_ll_ (u"ࠧࡆࡏࡄࡈ࠶࠷ࠠࠨ㺉") + str(var) + l111lll_ll_ (u"ࠨࠢ࠴࠵ࡊࡓࡁࡅࠩ㺊"),level=xbmc.LOGNOTICE)
	#var = l11l1lll1ll_ll_(32)
	#l1ll1l_ll_(var,l111lll_ll_ (u"ࠩࠪ㺋"))
	#xbmc.log(l111lll_ll_ (u"ࠪࡉࡒࡇࡄ࠲࠳ࠪ㺌") + html + l111lll_ll_ (u"ࠫ࠶࠷ࡅࡎࡃࡇࠫ㺍"),level=xbmc.LOGNOTICE)
	url = l111lll_ll_ (u"ࠬ࠭㺎")
	l11ll1l1ll11_ll_ = [
		l111lll_ll_ (u"࠭ࠧ㺏")
		]
	#l1l111ll11l_ll_ = xbmcgui.ListItem(path=url, thumbnailImage=l111lll_ll_ (u"ࠧࠨ㺐"))
	#l1l111ll11l_ll_.setInfo(type=l111lll_ll_ (u"ࠣࡘ࡬ࡨࡪࡵࠢ㺑"), infoLabels={l111lll_ll_ (u"ࠤࡗ࡭ࡹࡲࡥࠣ㺒"):l111lll_ll_ (u"ࠪࠫ㺓")})
	# l11ll11lll11_ll_ the item to the l11ll1l1l11l_ll_ player.
	#xbmcplugin.setResolvedUrl(l1l1l11l1ll_ll_, True, listitem=l1l111ll11l_ll_)
	# l11ll1l1ll1l_ll_ play the item.
	#xbmc.Player().play(url, l1l111ll11l_ll_)
	#import l1_ll_
	#url = l1_ll_.l11_ll_(l11ll1l1ll11_ll_,l1ll_ll_,l111lll_ll_ (u"ࠫࡱ࡯ࡶࡦࠩ㺔"))
	#l111lll1_ll_(url,l1ll_ll_,l111lll_ll_ (u"ࠬࡿࡥࡴࠩ㺕"))
	return