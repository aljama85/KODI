# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࠩ䆽")
l1l1l1l_ll_=l111lll_ll_ (u"ࠩࡢ࡝࡚࡚࡟ࠨ䆾")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
#headers = l111lll_ll_ (u"ࠪࠫ䆿")
#headers = {l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䇀"):l111lll_ll_ (u"ࠬ࠭䇁")}
def l111l1l_ll_(mode,url,text,type,page):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if	 mode==140: results = l11l1ll_ll_()
	#elif mode==141: results = l11l1llll11l_ll_(url)
	#elif mode==142: results = l11l1lllll1l_ll_(url,text)
	elif mode==143: results = l11_ll_(url,type)
	elif mode==144: results = l11ll1l11l_ll_(url,page,text)
	elif mode==145: results = l11ll1111lll_ll_(url)
	elif mode==146: results = l11l1lllll11_ll_(url)
	elif mode==147: results = l11l1lll11l1_ll_()
	elif mode==148: results = l11l1lll1l11_ll_()
	elif mode==149: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_():
	#url = l111lll_ll_ (u"࠭ࡨࡵࡶࡳࡷ࠿࠵࠯ࡸࡹࡺ࠲ࡾࡵࡵࡵࡷࡥࡩ࠳ࡩ࡯࡮࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡃࡱ࡯ࡳࡵ࠿ࡓࡐࡉ࠹ࡘࡤ࡚ࡎࡆ࡚ࡹࡺ࡭ࡄࡷࡑࡘࡽࡆࡧ࡜࡝࡚࡙ࡒࡐࡌࡼࡽࡴࡷࡾࡏࡔࠩ䇂")
	#l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇃"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡖࡈࡗ࡙࡙ࠦࡐࡗࡗ࡙ࡇࡋࠧ䇄"),url,144)
	#l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇅"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪࡳࡱࡪࡥࡳࠢࡳࡰࡦࡿ࡬ࡪࡵࡷࠤࡳࡵࡴࠡ࡮࡬ࡷࡹ࡯࡮ࡨࠢࡱࡩࡼ࡫ࡲࠡࡲ࡯ࡽࡦࡲࡩࡴࡶࠪ䇆"),l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡼࡳࡺࡺࡵࡣࡧ࠱ࡧࡴࡳ࠯ࡸࡣࡷࡧ࡭ࡅࡶ࠾࡚ࡉࡴࡶ࡫࡙ࡻ࡚࡝ࡪࡰࠬ࡬ࡪࡵࡷࡁࡗࡊࡑࡎ࠸࠶ࡺࡍࡰࡐ࠱ࡪࡨࡘࡸ࠭䇇"),144)
	#l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇈"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅ้ไ฼ࠤๆอั฻ࠩ䇉"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࡘࡇࡹࡕࡶࡰࡰ࡭࠸ࡌࡿ࡯ࡱࡏࡗࡑࡇࡧ࠲࠴ࡳࡘࡧࡼ࠭䇊"),144)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇋"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ䇌"),l111lll_ll_ (u"ࠪࠫ䇍"),149,l111lll_ll_ (u"ࠫࠬ䇎"),l111lll_ll_ (u"ࠬ࠭䇏"),l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ䇐"))
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇑"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ูๆำษࠡษ็ีห๐ำ๋หࠪ䇒"),l1ll1l1_ll_,144)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇓"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้๋อห๊์ࠤฬ๊ัศศฯࠫ䇔"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴࡬ࡥࡦࡦ࠲ࡸࡷ࡫࡮ࡥ࡫ࡱ࡫ࠬ䇕"),146)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇖"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ๅ้ษๅ฽ࠥอฮหษิ๋ฬ๊้ࠦฬํ์อ࠭䇗"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡨࡨࡩࡩ࠵ࡧࡶ࡫ࡧࡩࡤࡨࡵࡪ࡮ࡧࡩࡷ࠭䇘"),144)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇙"),l111lll_ll_ (u"ࠩࡢ࡝࡙ࡉ࡟ࠨ䇚")+l111lll_ll_ (u"้ࠪํอโฺࠢสาฯอั่ษࠣห้๋ศา็ฯࠫ䇛"),l111lll_ll_ (u"ࠫࠬ䇜"),290)
	l111_ll_(l111lll_ll_ (u"ࠬࡲࡩ࡯࡭ࠪ䇝"),l111lll_ll_ (u"࡛࠭ࡄࡑࡏࡓࡗࠦࡆࡇࡅ࠻࠽࠵࠶࠸࡞࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࡜࠱ࡆࡓࡑࡕࡒ࡞ࠩ䇞"),l111lll_ll_ (u"ࠧࠨ䇟"),9999)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇠"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࡀࠠใ่๋หฯูࠦาสํอࠬ䇡"),l111lll_ll_ (u"ࠪࠫ䇢"),147)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇣"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬฮอฬ࠼ࠣๆ๋๎วหࠢฦะ๋ฮ๊สࠩ䇤"),l111lll_ll_ (u"࠭ࠧ䇥"),148)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇦"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨสะฯ࠿ࠦวโๆส้ࠥ฿ัษ์ฬࠫ䇧"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀๅ๏๊ๅࠨ䇨"),144)
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇩"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫอำห࠻ࠢสๅ้อๅࠡษฯ๊อ๐ษࠨ䇪"),l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡲࡦࡵࡸࡰࡹࡹ࠿ࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾࡃ࡭ࡰࡸ࡬ࡩࠬ䇫"),144)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭䇬"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧษฯฮ࠾๋ࠥำาฯํหฯูࠦาสํอࠬ䇭"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿่ืึำ๊สࠩ䇮"),144)
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䇯"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪฬาั࠺ࠡ็ึุ่๊วหࠢ฼ีอ๐ษࠨ䇰"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡸࡥࡴࡷ࡯ࡸࡸࡅࡳࡦࡣࡵࡧ࡭ࡥࡱࡶࡧࡵࡽࡂ๋ำๅี็ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ䇱"),144)
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䇲"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอ࠽ࠤู๊ไิๆสฮࠥอฬ็สํอࠬ䇳"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࡵࡨࡶ࡮࡫ࡳࠧࡵࡳࡁࡊ࡭ࡉࡒࡃࡺࡁࡂ࠭䇴"),144)
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䇵"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࡀࠠๆี็ื้อสࠡๅสีฯ๎ๆࠨ䇶"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡷ࡫ࡳࡶ࡮ࡷࡷࡄࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࡁ่อัห๊้ࠪࡸࡶ࠽ࡆࡩࡌࡕࡆࡽ࠽࠾ࠩ䇷"),144)
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䇸"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬฮอฬ࠼ࠣา฼ฮษࠡษ็้ึาู๋หࠪ䇹"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡳࡧࡶࡹࡱࡺࡳࡀࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿ࠽ใ่สอ࠰้ัษๆสล࠰อไโุสส๏ฯࠫฯูหอ࠰อไอ็฼อࠫࡹࡰ࠾ࡅࡄࡍࡘࡇࡨࡂࡄࠪ䇺"),144)
	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䇻"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็฽ึอโࠡะฺฬฮࠦวๅ็ิะ฾๐ษࠨ䇼"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡄࡲࡩࡴࡶࡀࡔࡑ࠺ࡪࡖࡳ࠹ࡴࡳࡍ࠳࠷ࡓ࡭ࡹ࡝ࡊࡨࡏࡰࡌࡰࡷ࡯ࡵࡻࡴࡲࡘࡋࡺ࡭ࡧࡴࠪ䇽"),144)
	#l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ䇾"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ฿ฯศัสฮࠥอึศใฬࠤ๏๎ส๋๊หࠫ䇿"),l111lll_ll_ (u"ࠬ࠭䈀"),144)
	#l111111l1_ll_ = l1llll1111_ll_(l111lll_ll_ (u"࠭็ๅࠢอี๏ีࠠศๆสืฯ๋ัศำࠣรࠬ䈁"),l111lll_ll_ (u"่ࠧาสࠤฬ๊วฯฬํหึࠦำ้ใࠣ๎ำืฬไ่๊ࠢࠥอไษำ้ห๊าࠧ䈂"),l111lll_ll_ (u"ࠨๆฦ๊์ࠦำ้ใࠣ๎็๎ๅࠡสอุ฿๐ไࠡสิ๊ฬ๋ฬࠡ์๋ฮ๏๎ศࠨ䈃"))
	#if l111111l1_ll_:
	#	url = l111lll_ll_ (u"ࠩࡳࡰࡺ࡭ࡩ࡯࠼࠲࠳ࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠫ䈄")
	#	xbmc.executebuiltin(l111lll_ll_ (u"ࠪࡈ࡮ࡧ࡬ࡰࡩ࠱ࡇࡱࡵࡳࡦࠪࡥࡹࡸࡿࡤࡪࡣ࡯ࡳ࡬࠯ࠧ䈅"))
	#	xbmc.executebuiltin(l111lll_ll_ (u"ࠫࡗ࡫ࡰ࡭ࡣࡦࡩ࡜࡯࡮ࡥࡱࡺࠬࡻ࡯ࡤࡦࡱࡶ࠰ࠬ䈆")+url+l111lll_ll_ (u"ࠬ࠯ࠧ䈇"))
	#	#xbmc.executebuiltin(l111lll_ll_ (u"࠭ࡒࡶࡰࡄࡨࡩࡵ࡮ࠩࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥࠪࠩ䈈"))
	return
l111lll_ll_ (u"ࠢࠣࠤࠍࡨࡪ࡬ࠠࡎࡃࡌࡒࡕࡇࡇࡆࠪࡸࡶࡱ࠯࠺ࠋࠋ࡫ࡸࡲࡲࠬࡤࡥࠣࡁࠥࡍࡅࡕࡡࡓࡅࡌࡋ࡟ࡅࡃࡗࡅ࠭ࡻࡲ࡭ࠫࠍࠍ࡮࡬ࠠࠨࡔࡨࡪࡦࡧࡴࠡࡃ࡯࠱ࡌࡧ࡭࡮ࡣ࡯ࠫࠥ࡯࡮ࠡࡪࡷࡱࡱࡀࠠࡅࡋࡄࡐࡔࡍ࡟ࡐࡍࠫࡹࡷࡲࠬࠨࡻࡨࡷࠬ࠯ࠊࠊࡦࡧࠤࡂࠦࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡪࡨࡥࡩ࡫ࡲࠨ࡟࡞ࠫ࡫࡫ࡥࡥࡈ࡬ࡰࡹ࡫ࡲࡄࡪ࡬ࡴࡇࡧࡲࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞ࠌࠌࡪࡴࡸࠠࡪࠢ࡬ࡲࠥࡸ࡮ࡢࡩࡨࠬࡱ࡫࡮ࠩࡦࡧ࠭࠮ࡀࠊࠊࠋ࡬ࡸࡪࡳࠠ࠾ࠢࡧࡨࡠ࡯࡝ࠋࠋࠌࡍࡓ࡙ࡅࡓࡖࡢࡍ࡙ࡋࡍࡠࡖࡒࡣࡒࡋࡎࡖࠪ࡬ࡸࡪࡳࠩࠋࠋࡌࡘࡊࡓࡓࠩࡷࡵࡰ࠮ࠐࠉࡳࡧࡷࡹࡷࡴࠊࠣࠤࠥ䈉")
def l11l1lll11l1_ll_():
	l11ll1l11l_ll_(l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡵࡩࡸࡻ࡬ࡵࡵࡂࡷࡪࡧࡲࡤࡪࡢࡵࡺ࡫ࡲࡺ࠿ๅ๊ฬฯࠫษอࠩࡷࡵࡃࡅࡨࡌࡄࡅࡖࡃ࠽ࠨ䈊"))
	return
def l11l1lll1l11_ll_():
	l11ll1l11l_ll_(l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡶࡪࡹࡵ࡭ࡶࡶࡃࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࡀࡸࡻࠬࡳࡱ࠿ࡈ࡫ࡏࡇࡁࡒ࠿ࡀࠫ䈋"))
	return
def l11_ll_(url,type):
	#url = url+l111lll_ll_ (u"ࠪࠪࠬ䈌")
	#items = re.findall(l111lll_ll_ (u"ࠫࡻࡃࠨ࠯ࠬࡂ࠭ࠫ࠭䈍"),url,re.DOTALL)
	#id = items[0]
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠬ࠭䈎"))
	#link = l111lll_ll_ (u"࠭ࡰ࡭ࡷࡪ࡭ࡳࡀ࠯࠰ࡲ࡯ࡹ࡬࡯࡮࠯ࡸ࡬ࡨࡪࡵ࠮ࡺࡱࡸࡸࡺࡨࡥ࠰ࡲ࡯ࡥࡾ࠵࠿ࡷ࡫ࡧࡩࡴࡥࡩࡥ࠿ࠪ䈏")+id
	#l111lll1_ll_(link,l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭䈐"))
	l1l111l_ll_ = [url]
	import l1_ll_
	result = l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,type)
	if l111lll_ll_ (u"ࠨࡔࡈࡘ࡚ࡘࡎࡠࡖࡒࡣ࡞ࡕࡕࡕࡗࡅࡉࠬ䈑") in result:
		link = l1ll1l1_ll_+result.split(l111lll_ll_ (u"ࠩ࠽࠾ࠬ䈒"))[1]
		#l1ll1l_ll_(link,result)
		new_path = sys.argv[0]+l111lll_ll_ (u"ࠪࡃࡹࡿࡰࡦ࠿ࡩࡳࡱࡪࡥࡳࠨࡰࡳࡩ࡫࠽࠲࠶࠷ࠪࡺࡸ࡬࠾ࠩ䈓")+link
		xbmc.executebuiltin(l111lll_ll_ (u"ࠦࡈࡵ࡮ࡵࡣ࡬ࡲࡪࡸ࠮ࡖࡲࡧࡥࡹ࡫ࠨࠣ䈔")+new_path+l111lll_ll_ (u"ࠧ࠯ࠢ䈕"))
		#threads = l11ll11lll_ll_(False,False)
		#threads.start_new_thread(l111lll_ll_ (u"࠭࠱ࠨ䈖"),xbmc.executebuiltin,l111lll_ll_ (u"ࠢࡄࡱࡱࡸࡦ࡯࡮ࡦࡴ࠱࡙ࡵࡪࡡࡵࡧࠫࠦ䈗")+new_path+l111lll_ll_ (u"ࠣࠫࠥ䈘"))
		#l1ll1l_ll_(link,str(len(l11ll1ll1l1_ll_)))
		#l1111l1l_ll_(l111lll_ll_ (u"ࠩࡑࡓ࡙ࡏࡃࡆࠩ䈙"),l111lll_ll_ (u"ࠪࡉࡒࡇࡄࠡࡇࡐࡅࡉࠦ࠹࠺࠻࠼࠾ࠥ࠭䈚")+new_path)
	return
def l11l1lllll11_ll_(url):
	html,cc = l11l1ll1lll1_ll_(url)
	dd = cc[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䈛")][l111lll_ll_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䈜")][l111lll_ll_ (u"࠭ࡴࡢࡤࡶࠫ䈝")]
	for i in range(len(dd)):
		item = dd[i]
		l11l1ll1ll11_ll_(item)
	ee = dd[0][l111lll_ll_ (u"ࠧࡵࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬ䈞")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩ䈟")][l111lll_ll_ (u"ࠩࡶࡩࡨࡺࡩࡰࡰࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䈠")][l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬ䈡")]
	s = 0
	for i in range(len(ee)):
		item = ee[i][l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䈢")][l111lll_ll_ (u"ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ䈣")][0]
		if item[l111lll_ll_ (u"࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䈤")][l111lll_ll_ (u"ࠧࡤࡱࡱࡸࡪࡴࡴࠨ䈥")].keys()[0]==l111lll_ll_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䈦"): continue
		succeeded,title,link,img,count,duration,live,l11l1ll1llll_ll_ = l11ll111l1ll_ll_(item)
		if title==l111lll_ll_ (u"ࠩࠪ䈧"):
			s += 1
			title = l111lll_ll_ (u"ࠪๅ๏ี๊้้สฮࠥืววฮฬࠤࠬ䈨")+str(s)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䈩"),l1l1l1l_ll_+title,url,144,l111lll_ll_ (u"ࠬ࠭䈪"),str(i))
	key = re.findall(l111lll_ll_ (u"࠭ࠢࡪࡰࡱࡩࡷࡺࡵࡣࡧࡄࡴ࡮ࡑࡥࡺࠤ࠽ࠦ࠭࠴ࠪࡀࠫࠥࠫ䈫"),html,re.DOTALL)
	l1ll111_ll_ = l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳ࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡣࡰ࡯࠲ࡽࡴࡻࡴࡶࡤࡨ࡭࠴ࡼ࠱࠰ࡩࡸ࡭ࡩ࡫࠿࡬ࡧࡼࡁࠬ䈬")+key[0]
	html,cc = l11l1ll1lll1_ll_(l1ll111_ll_)
	for j in range(3,4):
		dd = cc[l111lll_ll_ (u"ࠨ࡫ࡷࡩࡲࡹࠧ䈭")][j][l111lll_ll_ (u"ࠩࡪࡹ࡮ࡪࡥࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩ䈮")][l111lll_ll_ (u"ࠪ࡭ࡹ࡫࡭ࡴࠩ䈯")]
		for i in range(len(dd)):
			item = dd[i]
			if l111lll_ll_ (u"ࠫ࡞ࡵࡵࡕࡷࡥࡩࠥࡖࡲࡦ࡯࡬ࡹࡲ࠭䈰") in str(item): continue
			l11l1ll1ll11_ll_(item)
	return
def l11ll1l11l_ll_(url,index=l111lll_ll_ (u"ࠬ࠭䈱"),l11ll111l1l1_ll_=l111lll_ll_ (u"࠭ࠧ䈲")):
	#l1ll1l_ll_(url,index)
	global settings
	html,cc = l11l1ll1lll1_ll_(url,l11ll111l1l1_ll_)
	l111ll111_ll_,ff = l111lll_ll_ (u"ࠧࠨ䈳"),l111lll_ll_ (u"ࠨࠩ䈴")
	#if l111lll_ll_ (u"ࠩࡲࡻࡳ࡫ࡲࠨ䈵") in html.lower(): l1ll1l_ll_(l111lll_ll_ (u"ࠪࡳࡼࡴࡥࡳࠢࡨࡼ࡮ࡹࡴࠨ䈶"),l111lll_ll_ (u"ࠫ࡮ࡴࠠࡩࡶࡰࡰࠬ䈷"))
	owner = re.findall(l111lll_ll_ (u"ࠬࠨ࡯ࡸࡰࡨࡶࡓࡧ࡭ࡦࠤ࠱࠮ࡄࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䈸"),html,re.DOTALL)
	if not owner: owner = re.findall(l111lll_ll_ (u"࠭ࠢࡷ࡫ࡧࡩࡴࡕࡷ࡯ࡧࡵࠦ࠳࠰࠿ࠣࡶࡨࡼࡹࠨ࠺ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࠦࡺࡸ࡬ࠣ࠼ࠥࠬ࠳࠰࠿ࠪࠤࠪ䈹"),html,re.DOTALL)
	if not owner: owner = re.findall(l111lll_ll_ (u"ࠧࠣࡥ࡫ࡥࡳࡴࡥ࡭ࡏࡨࡸࡦࡪࡡࡵࡣࡕࡩࡳࡪࡥࡳࡧࡵࠦ࠿ࡢࡻࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࠧࡵࡷ࡯ࡧࡵ࡙ࡷࡲࡳࠣ࠼࡟࡟ࠧ࠮࠮ࠫࡁࠬࠦࠬ䈺"),html,re.DOTALL)
	if owner:
		l111ll111_ll_ = l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡓ࡜ࡔࡅࡓ࠼ࠣࠤࠬ䈻")+owner[0][0]+l111lll_ll_ (u"ࠩ࡞࠳ࡈࡕࡌࡐࡔࡠࠫ䈼")
		link = owner[0][1]
		if l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰࠨ䈽") not in link: link = l1ll1l1_ll_+link
		#if l111lll_ll_ (u"ࠫ࠴ࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠨ䈾") in url and l111lll_ll_ (u"ࠬ࠵ࡣࡩࡣࡱࡲࡪࡲ࠯ࠨ䈿") not in url and l111lll_ll_ (u"࠭࠯ࡤ࠱ࠪ䉀") not in url and l111lll_ll_ (u"ࠧ࠰ࡷࡶࡩࡷ࠵ࠧ䉁") not in url:
		if l111lll_ll_ (u"ࠨ࡮࡬ࡷࡹࡃࠧ䉂") in url: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䉃"),l1l1l1l_ll_+l111ll111_ll_,link,144)
	#if cc==l111lll_ll_ (u"ࠪࠫ䉄"): l11l1ll11l1l_ll_(url,html) ; return
	l11l1ll111ll_ll_ = [l111lll_ll_ (u"ࠫ࠴ࡹࡥࡢࡴࡦ࡬ࠬ䉅"),l111lll_ll_ (u"ࠬ࠵ࡶࡪࡦࡨࡳࡸ࠭䉆"),l111lll_ll_ (u"࠭࠯ࡤࡪࡤࡲࡳ࡫࡬ࡴࠩ䉇"),l111lll_ll_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡶࠫ䉈"),l111lll_ll_ (u"ࠨ࠱ࡩࡩࡦࡺࡵࡳࡧࡧࠫ䉉"),l111lll_ll_ (u"ࠩࡶࡷࡂ࠭䉊"),l111lll_ll_ (u"ࠪࡧࡹࡵ࡫ࡦࡰࡀࠫ䉋"),l111lll_ll_ (u"ࠫࡰ࡫ࡹ࠾ࠩ䉌"),l111lll_ll_ (u"ࠬࡨࡰ࠾ࠩ䉍"),l111lll_ll_ (u"࠭ࡳࡩࡧ࡯ࡪࡤ࡯ࡤ࠾ࠩ䉎")]
	l11l1ll11111_ll_ = not any(value in url for value in l11l1ll111ll_ll_)
	if l11l1ll11111_ll_:
		if l111lll_ll_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤหัะࠨࠧ䉏") in html: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉐"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋๊ࠢิฬࠦวๅ็๋ๆ฾࠭䉑"),url,145,l111lll_ll_ (u"ࠪࠫ䉒"),l111lll_ll_ (u"ࠫࠬ䉓"),l111lll_ll_ (u"ࠬࡥࡒࡆࡏࡈࡑࡇࡋࡒࡓࡇࡖ࡙ࡑ࡚ࡓࡠࠩ䉔"))
		if l111lll_ll_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣไ๋หห๋ࠠศๆอุ฿๐ไࠣࠩ䉕") in html: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䉖"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࠢ࠰ࠤ็๎วว็ࠪ䉗")+l111ll111_ll_,url+l111lll_ll_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭䉘"),144)
		if l111lll_ll_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ䉙") in html: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉚"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬࠦ࠭ࠡใํำ๏๎็ศฬࠪ䉛")+l111ll111_ll_,url+l111lll_ll_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䉜"),144)
		if l111lll_ll_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤส่็์่ศฬࠥࠫ䉝") in html: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉞"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࠣ࠱่ࠥๆ้ษอࠫ䉟")+l111ll111_ll_,url+l111lll_ll_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䉠"),144)
		if l111lll_ll_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡓࡦࡣࡵࡧ࡭ࠨࠧ䉡") in html: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉢"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦ็ัษࠣห้๋่ใ฻ࠪ䉣"),url,145,l111lll_ll_ (u"ࠧࠨ䉤"),l111lll_ll_ (u"ࠨࠩ䉥"),l111lll_ll_ (u"ࠩࡢࡖࡊࡓࡅࡎࡄࡈࡖࡗࡋࡓࡖࡎࡗࡗࡤ࠭䉦"))
		if l111lll_ll_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧࡖ࡬ࡢࡻ࡯࡭ࡸࡺࡳࠣࠩ䉧") in html: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䉨"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬࠦ࠭ࠡไ๋หห๋ࠧ䉩")+l111ll111_ll_,url+l111lll_ll_ (u"࠭࠯ࡱ࡮ࡤࡽࡱ࡯ࡳࡵࡵࠪ䉪"),144)
		if l111lll_ll_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤ࡙࡭ࡩ࡫࡯ࡴࠤࠪ䉫") in html: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䉬"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࠣ࠱ࠥ็๊ะ์๋๋ฬะࠧ䉭")+l111ll111_ll_,url+l111lll_ll_ (u"ࠪ࠳ࡻ࡯ࡤࡦࡱࡶࠫ䉮"),144)
		if l111lll_ll_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨࡃࡩࡣࡱࡲࡪࡲࡳࠣࠩ䉯") in html: l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䉰"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ࠠ࠮ࠢๅ๊ํอสࠨ䉱")+l111ll111_ll_,url+l111lll_ll_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭ࡵࠪ䉲"),144)
	if l111lll_ll_ (u"ࠨࡵࡨࡥࡷࡩࡨࡠࡳࡸࡩࡷࡿࠧ䉳") in url:
		dd = cc[l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䉴")][l111lll_ll_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䉵")][l111lll_ll_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭䉶")][l111lll_ll_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䉷")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ䉸")]
		l11l1lll1l1l_ll_ = 0
		for i in range(len(dd)):
			if l111lll_ll_ (u"ࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䉹") in dd[i].keys():
				l11ll1111l11_ll_ = dd[i][l111lll_ll_ (u"ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䉺")]
				length = len(str(l11ll1111l11_ll_))
				if length>l11l1lll1l1l_ll_:
					l11l1lll1l1l_ll_ = length
					ff = l11ll1111l11_ll_
		if l11l1lll1l1l_ll_==0: return
	elif l111lll_ll_ (u"ࠩࠩࡰ࡮ࡹࡴ࠾ࠩ䉻") in url or l111lll_ll_ (u"ࠪ࠳ࡸ࡫ࡡࡳࡥ࡫ࡃࡰ࡫ࡹ࠾ࠩ䉼") in url or l111lll_ll_ (u"ࠫ࠴ࡨࡲࡰࡹࡶࡩࡄࡱࡥࡺ࠿ࠪ䉽") in url or l111lll_ll_ (u"ࠬࡩࡴࡰ࡭ࡨࡲࡂ࠭䉾") in url or l111lll_ll_ (u"࠭࠯ࡴࡧࡤࡶࡨ࡮ࠧ䉿") in url or url==l1ll1l1_ll_:
		trial = []
		trial.append(l111lll_ll_ (u"ࠢࡤࡥ࡞ࠫࡴࡴࡒࡦࡵࡳࡳࡳࡹࡥࡓࡧࡦࡩ࡮ࡼࡥࡥࡅࡲࡱࡲࡧ࡮ࡥࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠࠦ䊀"))
		trial.append(l111lll_ll_ (u"ࠣࡥࡦ࡟ࠬࡵ࡮ࡓࡧࡶࡴࡴࡴࡳࡦࡔࡨࡧࡪ࡯ࡶࡦࡦࡄࡧࡹ࡯࡯࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡤࡴࡵ࡫࡮ࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡷࡆࡩࡴࡪࡱࡱࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡏࡴࡦ࡯ࡶࠫࡢࠨ䊁"))
		trial.append(l111lll_ll_ (u"ࠤࡦࡧࡠ࠷࡝࡜ࠩࡵࡩࡸࡶ࡯࡯ࡵࡨࠫࡢࡡࠧࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳࡉ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝ࠪࡷࡪࡩࡴࡪࡱࡱࡐ࡮ࡹࡴࡄࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭࡝ࠣ䊂"))
		trial.append(l111lll_ll_ (u"ࠥࡧࡨࡡ࠱࡞࡝ࠪࡶࡪࡹࡰࡰࡰࡶࡩࠬࡣ࡛ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡃࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞ࠫ࡬ࡸࡩࡥࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䊃"))
		trial.append(l111lll_ll_ (u"ࠦࡨࡩ࡛࠲࡟࡞ࠫࡷ࡫ࡳࡱࡱࡱࡷࡪ࠭࡝࡜ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡄࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟ࠬࡶ࡬ࡢࡻ࡯࡭ࡸࡺࡖࡪࡦࡨࡳࡑ࡯ࡳࡵࡅࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࠧ࡞ࠤ䊄"))
		trial.append(l111lll_ll_ (u"ࠧࡩࡣ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࠧࡵࡹࡲࡇࡴࡲࡵ࡮ࡰࡅࡶࡴࡽࡳࡦࡔࡨࡷࡺࡲࡴࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡢࡤࡶࠫࡢࡡ࠭࠲࡟࡞ࠫࡪࡾࡰࡢࡰࡧࡥࡧࡲࡥࡕࡣࡥࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࠩࡠ࡟ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࠨ䊅"))
		trial.append(l111lll_ll_ (u"ࠨࡣࡤ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࠨࡶࡺࡳࡈࡵ࡬ࡶ࡯ࡱࡆࡷࡵࡷࡴࡧࡕࡩࡸࡻ࡬ࡵࡵࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡵࡣࡥࡷࠬࡣ࡛࠱࡟࡞ࠫࡹࡧࡢࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡵ࡭ࡨ࡮ࡇࡳ࡫ࡧࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣࠢ䊆"))
		trial.append(l111lll_ll_ (u"ࠢࡤࡥ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜ࠩࡷࡻࡴࡉ࡯࡭ࡷࡰࡲ࡜ࡧࡴࡤࡪࡑࡩࡽࡺࡒࡦࡵࡸࡰࡹࡹࠧ࡞࡝ࠪࡴࡱࡧࡹ࡭࡫ࡶࡸࠬࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶࠪࡡࠧ䊇"))
		l11l1llll1ll_ll_,ff = l11l1llll111_ll_(cc,cc,trial)
		#l1ll1l_ll_(l111lll_ll_ (u"ࠨ࠲࠳࠴࠵ࠦࡩ࡯ࡦࡨࡼࡂࠦࠧ䊈")+index,l111lll_ll_ (u"ࠩࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࠬ䊉")+l11l1llll1ll_ll_)
	if ff==l111lll_ll_ (u"ࠪࠫ䊊"):
		try:
			dd = cc[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭䊋")][l111lll_ll_ (u"ࠬࡺࡷࡰࡅࡲࡰࡺࡳ࡮ࡃࡴࡲࡻࡸ࡫ࡒࡦࡵࡸࡰࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䊌")][l111lll_ll_ (u"࠭ࡴࡢࡤࡶࠫ䊍")]
			l1111l1111_ll_ = l111lll_ll_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ䊎") in url or l111lll_ll_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䊏") in url or l111lll_ll_ (u"ࠩ࠲ࡧ࡭ࡧ࡮࡯ࡧ࡯ࡷࠬ䊐") in url
			l11l1ll11lll_ll_ = l111lll_ll_ (u"ࠪࠦࡹ࡯ࡴ࡭ࡧࠥ࠾ࠧอไโ์า๎ํํวหࠤࠪ䊑") in html or l111lll_ll_ (u"ࠫࠧࡺࡩࡵ࡮ࡨࠦ࠿ࠨโ้ษษ้ࠥอไหึ฽๎้ࠨࠧ䊒") in html or l111lll_ll_ (u"ࠬࠨࡴࡪࡶ࡯ࡩࠧࡀࠢศๆๅ๊ํอสࠣࠩ䊓") in html
			l11l1ll11ll1_ll_ = l111lll_ll_ (u"࠭ࠢࡵ࡫ࡷࡰࡪࠨ࠺ࠣࡘ࡬ࡨࡪࡵࡳࠣࠩ䊔") in html or l111lll_ll_ (u"ࠧࠣࡶ࡬ࡸࡱ࡫ࠢ࠻ࠤࡓࡰࡦࡿ࡬ࡪࡵࡷࡷࠧ࠭䊕") in html or l111lll_ll_ (u"ࠨࠤࡷ࡭ࡹࡲࡥࠣ࠼ࠥࡇ࡭ࡧ࡮࡯ࡧ࡯ࡷࠧ࠭䊖") in html
			if l1111l1111_ll_ and (l11l1ll11lll_ll_ or l11l1ll11ll1_ll_):
				for i in range(len(dd)):
					if l111lll_ll_ (u"ࠩࡷࡥࡧࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䊗") not in dd[i].keys(): continue
					ee = dd[i][l111lll_ll_ (u"ࠪࡸࡦࡨࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䊘")]
					try: l11ll1111ll1_ll_ = ee[l111lll_ll_ (u"ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬ䊙")][l111lll_ll_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䊚")][l111lll_ll_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ䊛")][l111lll_ll_ (u"ࠧࡤࡪࡤࡲࡳ࡫࡬ࡔࡷࡥࡑࡪࡴࡵࡓࡧࡱࡨࡪࡸࡥࡳࠩ䊜")][l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡫࡮ࡵࡖࡼࡴࡪ࡙ࡵࡣࡏࡨࡲࡺࡏࡴࡦ࡯ࡶࠫ䊝")][0]
					except: l11ll1111ll1_ll_ = ee
					try: link = l11ll1111ll1_ll_[l111lll_ll_ (u"ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫ䊞")][l111lll_ll_ (u"ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬ䊟")][l111lll_ll_ (u"ࠫࡼ࡫ࡢࡄࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ䊠")][l111lll_ll_ (u"ࠬࡻࡲ࡭ࠩ䊡")]
					except: continue
					if   l111lll_ll_ (u"࠭࠯ࡷ࡫ࡧࡩࡴࡹࠧ䊢")		in link	and l111lll_ll_ (u"ࠧ࠰ࡸ࡬ࡨࡪࡵࡳࠨ䊣")		in url: ee = dd[i] ; break
					elif l111lll_ll_ (u"ࠨ࠱ࡳࡰࡦࡿ࡬ࡪࡵࡷࡷࠬ䊤")	in link	and l111lll_ll_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭䊥")	in url: ee = dd[i] ; break
					elif l111lll_ll_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䊦")	in link	and l111lll_ll_ (u"ࠫ࠴ࡩࡨࡢࡰࡱࡩࡱࡹࠧ䊧")		in url: ee = dd[i] ; break
					else: ee = dd[0]
			else: ee = dd[0]
			ff = ee[l111lll_ll_ (u"ࠬࡺࡡࡣࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䊨")][l111lll_ll_ (u"࠭ࡣࡰࡰࡷࡩࡳࡺࠧ䊩")][l111lll_ll_ (u"ࠧࡴࡧࡦࡸ࡮ࡵ࡮ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䊪")]
		except: pass
	if ff==l111lll_ll_ (u"ࠨࠩ䊫"): return
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠩ࡬ࡲࡩ࡫ࡸ࠾ࠩ䊬")+index)
	trial = []
	trial.append(l111lll_ll_ (u"ࠥࡪ࡫ࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࡮ࡴࡴࠩ࡫ࡱࡨࡪࡾࠩ࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䊭"))
	trial.append(l111lll_ll_ (u"ࠦ࡫࡬࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࡯࡮ࡵࠪ࡬ࡲࡩ࡫ࡸࠪ࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡩࡱࡵ࡭ࡿࡵ࡮ࡵࡣ࡯ࡑࡴࡼࡩࡦࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡭ࡹ࡫࡭ࡴࠩࡠࠦ䊮"))
	trial.append(l111lll_ll_ (u"ࠧ࡬ࡦ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡࡩ࡯ࡶࠫ࡭ࡳࡪࡥࡹࠫࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡩࡵࡧࡰࡷࠬࡣࠢ䊯"))
	trial.append(l111lll_ll_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛ࡪࡰࡷࠬ࡮ࡴࡤࡦࡺࠬࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡶ࡬ࡪࡲࡦࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䊰"))
	trial.append(l111lll_ll_ (u"ࠢࡧࡨ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࡫ࡱࡸ࠭࡯࡮ࡥࡧࡻ࠭ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪࡷ࡭࡫࡬ࡧࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ䊱"))
	trial.append(l111lll_ll_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࡬ࡲࡹ࠮ࡩ࡯ࡦࡨࡼ࠮ࡣ࡛ࠨ࡫ࡷࡩࡲ࡙ࡥࡤࡶ࡬ࡳࡳࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡭ࡵࡲࡪࡼࡲࡲࡹࡧ࡬ࡄࡣࡵࡨࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡢࡴࡧࡷࠬࡣࠢ䊲"))
	trial.append(l111lll_ll_ (u"ࠤࡩࡪࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࡭ࡳࡺࠨࡪࡰࡧࡩࡽ࠯࡝࡜ࠩࡵ࡭ࡨ࡮ࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࠬࡣࠢ䊳"))
	if l111lll_ll_ (u"ࠪࡺ࡮࡫ࡷ࠾ࠩ䊴") not in url: trial.append(l111lll_ll_ (u"ࠦ࡫࡬࡛ࠨࡵࡸࡦࡒ࡫࡮ࡶࠩࡠ࡟ࠬࡩࡨࡢࡰࡱࡩࡱ࡙ࡵࡣࡏࡨࡲࡺࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡘࡾࡶࡥࡔࡷࡥࡑࡪࡴࡵࡊࡶࡨࡱࡸ࠭࡝ࠣ䊵"))
	trial.append(l111lll_ll_ (u"ࠧ࡬ࡦ࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࡡ࠰࡞࡝ࠪ࡭ࡹ࡫࡭ࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡳࡩࡧ࡯ࡪࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪࡡࡠ࠭ࡥࡹࡲࡤࡲࡩ࡫ࡤࡔࡪࡨࡰ࡫ࡉ࡯࡯ࡶࡨࡲࡹࡹࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䊶"))
	trial.append(l111lll_ll_ (u"ࠨࡦࡧ࡝ࠪࡧࡴࡴࡴࡦࡰࡷࡷࠬࡣ࡛࠱࡟࡞ࠫ࡮ࡺࡥ࡮ࡕࡨࡧࡹ࡯࡯࡯ࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟࡞࠴ࡢࡡࠧࡴࡪࡨࡰ࡫ࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࡡࠧࡨࡴ࡬ࡨࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡬ࡸࡪࡳࡳࠨ࡟ࠥ䊷"))
	trial.append(l111lll_ll_ (u"ࠢࡧࡨ࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠ࡟ࠬ࡯ࡴࡦ࡯ࡖࡩࡨࡺࡩࡰࡰࡕࡩࡳࡪࡥࡳࡧࡵࠫࡢࡡࠧࡤࡱࡱࡸࡪࡴࡴࡴࠩࡠ࡟࠵ࡣ࡛ࠨࡲ࡯ࡥࡾࡲࡩࡴࡶ࡙࡭ࡩ࡫࡯ࡍ࡫ࡶࡸࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫࡢࠨ䊸"))
	trial.append(l111lll_ll_ (u"ࠣࡨࡩ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹࡹࠧ࡞࡝࠳ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩࡪࡶ࡮ࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡮ࡺࡥ࡮ࡵࠪࡡࠧ䊹"))
	trial.append(l111lll_ll_ (u"ࠤࡩࡪࡠ࠭ࡣࡰࡰࡷࡩࡳࡺࡳࠨ࡟ࠥ䊺"))
	trial.append(l111lll_ll_ (u"ࠥࡪ࡫ࠨ䊻"))
	l11l1ll11ll_ll_ = l1ll111l1ll_ll_(l111lll_ll_ (u"ࡹ้ࠬไࠡไ๋หห๋ࠠศๆอุ฿๐ไࠨ䊼"))
	l11l1ll1l11_ll_ = l1ll111l1ll_ll_(l111lll_ll_ (u"ࡺ࠭ใๅࠢส่ๆ๐ฯ๋๊๊หฯ࠭䊽"))
	l11l1ll111l1_ll_ = l1ll111l1ll_ll_(l111lll_ll_ (u"ࡻࠧไๆࠣห้่ๆ้ษอࠫ䊾"))
	l1ll1lll1l11_ll_ = [l11l1ll11ll_ll_,l11l1ll1l11_ll_,l11l1ll111l1_ll_,l111lll_ll_ (u"ࠧࡂ࡮࡯ࠤࡵࡲࡡࡺ࡮࡬ࡷࡹࡹࠧ䊿"),l111lll_ll_ (u"ࠨࡃ࡯ࡰࠥࡼࡩࡥࡧࡲࡷࠬ䋀"),l111lll_ll_ (u"ࠩࡄࡰࡱࠦࡣࡩࡣࡱࡲࡪࡲࡳࠨ䋁")]
	l11l1ll11l11_ll_,l11ll1111ll1_ll_ = l11l1llll111_ll_(ff,index,trial)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠪ࠵࠶࠷࠱ࠡ࡫ࡱࡨࡪࡾ࠽ࠡࠩ䋂")+index+l111lll_ll_ (u"ࠫࠥࠦࠠࡧࡱࡸࡲࡩࠦࡩ࡯ࠢࠪ䋃")+l11l1ll11l11_ll_,str(len(l11ll1111ll1_ll_)))
	#l11l1l1ll_ll_(l111lll_ll_ (u"ࠬ࠭䋄"),str(l11ll1111ll1_ll_))
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧ䋅"),str(len(l11ll1111ll1_ll_)))
	if l111lll_ll_ (u"ࠧ࡭࡫ࡶࡸࠬ䋆") in str(type(l11ll1111ll1_ll_)) and any(value in str(l11ll1111ll1_ll_[0]) for value in l1ll1lll1l11_ll_): del l11ll1111ll1_ll_[0]
	for index2 in range(len(l11ll1111ll1_ll_)):
		trial = []
		trial.append(l111lll_ll_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࡠ࠭ࡩࡵࡧࡰࡗࡪࡩࡴࡪࡱࡱࡖࡪࡴࡤࡦࡴࡨࡶࠬࡣ࡛ࠨࡥࡲࡲࡹ࡫࡮ࡵࡵࠪࡡࡠ࠶࡝࡜ࠩ࡫ࡳࡷ࡯ࡺࡰࡰࡷࡥࡱࡉࡡࡳࡦࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡭࡫ࡡࡥࡧࡵࠫࡢࠨ䋇"))
		trial.append(l111lll_ll_ (u"ࠤࡪ࡫ࡠ࡯࡮ࡥࡧࡻ࠶ࡢࡡࠧࡪࡶࡨࡱࡘ࡫ࡣࡵ࡫ࡲࡲࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭࡝࡜ࠩ࡫ࡩࡦࡪࡥࡳࠩࡠࠦ䋈"))
		trial.append(l111lll_ll_ (u"ࠥ࡫࡬ࡡࡩ࡯ࡦࡨࡼ࠷ࡣ࡛ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡈࡧࡲࡥࡎ࡬ࡷࡹࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪ࡬ࡪࡧࡤࡦࡴࠪࡡࠧ䋉"))
		trial.append(l111lll_ll_ (u"ࠦ࡬࡭࡛ࡪࡰࡧࡩࡽ࠸࡝࡜ࠩ࡬ࡸࡪࡳࡓࡦࡥࡷ࡭ࡴࡴࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡨࡵ࡮ࡵࡧࡱࡸࡸ࠭࡝࡜࠲ࡠࠦ䋊"))		#4
		trial.append(l111lll_ll_ (u"ࠧ࡭ࡧ࡜࡫ࡱࡨࡪࡾ࠲࡞࡝ࠪࡶ࡮ࡩࡨࡔࡧࡦࡸ࡮ࡵ࡮ࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡩ࡯࡯ࡶࡨࡲࡹ࠭࡝ࠣ䋋"))		#7
		trial.append(l111lll_ll_ (u"ࠨࡧࡨ࡝࡬ࡲࡩ࡫ࡸ࠳࡟࡞ࠫࡷ࡯ࡣࡩࡋࡷࡩࡲࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ࡞࡝ࠪࡧࡴࡴࡴࡦࡰࡷࠫࡢࠨ䋌"))		#6
		trial.append(l111lll_ll_ (u"ࠢࡨࡩ࡞࡭ࡳࡪࡥࡹ࠴ࡠ࡟ࠬ࡭ࡡ࡮ࡧࡆࡥࡷࡪࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫ࡬ࡧ࡭ࡦࠩࡠࠦ䋍"))		#5
		trial.append(l111lll_ll_ (u"ࠣࡩࡪ࡟࡮ࡴࡤࡦࡺ࠵ࡡࠧ䋎"))
		l11l1llll1ll_ll_,item = l11l1llll111_ll_(l11ll1111ll1_ll_,index2,trial)
		#l1ll1l_ll_(l111lll_ll_ (u"ࠩ࠵࠶࠷࠸ࠠࡪࡰࡧࡩࡽࡃࠠࠨ䋏")+index,l111lll_ll_ (u"ࠪࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥ࠭䋐")+l11l1llll1ll_ll_)
		#if l11l1llll1ll_ll_ not in [l111lll_ll_ (u"ࠫ࠷࠭䋑"),l111lll_ll_ (u"ࠬ࠺ࠧ䋒"),l111lll_ll_ (u"࠭࠵ࠨ䋓")]: l11l1ll1ll11_ll_(item)		# 2,4,7
		#else: l11l1ll1ll11_ll_(item,url,str(index2),l11ll111l1l1_ll_)
		l11l1ll1ll11_ll_(item,url,str(index2),l11ll111l1l1_ll_)
		if l11l1llll1ll_ll_==l111lll_ll_ (u"ࠧ࠵ࠩ䋔"):
			try:
				hh = item[l111lll_ll_ (u"ࠨࡵ࡫ࡩࡱ࡬ࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䋕")][l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࠪ䋖")][l111lll_ll_ (u"ࠪ࡬ࡴࡸࡩࡻࡱࡱࡸࡦࡲࡍࡰࡸ࡬ࡩࡑ࡯ࡳࡵࡔࡨࡲࡩ࡫ࡲࡦࡴࠪ䋗")][l111lll_ll_ (u"ࠫ࡮ࡺࡥ࡮ࡵࠪ䋘")]
				for l11l1ll1l1l1_ll_ in range(len(hh)):
					l11l1llllll1_ll_ = hh[l11l1ll1l1l1_ll_]
					l11l1ll1ll11_ll_(l11l1llllll1_ll_)
			except: pass
	l11l1ll1l111_ll_ = False
	if l111lll_ll_ (u"ࠬࡼࡩࡦࡹࡀࠫ䋙") not in url and l11l1ll11l11_ll_==l111lll_ll_ (u"࠭࠸ࠨ䋚"): l11l1ll1l111_ll_ = True
	if l111lll_ll_ (u"ࠧࠧ࡮࡬ࡷࡹࡃࠧ䋛") not in url and l111lll_ll_ (u"ࠨࠤࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࡴࠤࠪ䋜") in html and not l11l1ll1l111_ll_ and l111lll_ll_ (u"ࠩࡶ࡬ࡪࡲࡦࡠ࡫ࡧࠫ䋝") not in url:	# and (index!=l111lll_ll_ (u"ࠪࠫ䋞") or l111lll_ll_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ䋟") in url or l111lll_ll_ (u"ࠬࡲࡩࡴࡶࡀࠫ䋠") in url or l111lll_ll_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅࡱࡶࡧࡵࡽࡂ࠭䋡") in url or l111lll_ll_ (u"ࠧࡷ࡫ࡨࡻࡂ࠭䋢") in url):
		continuation = settings.getSetting(l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䋣"))
		l11ll1111l1l_ll_ = settings.getSetting(l111lll_ll_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱࡚ࡎ࡙ࡉࡕࡑࡕࡣࡎࡔࡆࡐ࠳ࡢࡐࡎ࡜ࡅࠨ䋤"))
		l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨࡣࡦࡰࡡࡹࡁࡦࡸࡴࡱࡥ࡯࠿ࠪ䋥")+continuation
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ䋦"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ฻แฮหࠣหำื้ࠨ䋧"),l1ll111_ll_,144,l111lll_ll_ (u"࠭ࠧ䋨"),l111lll_ll_ (u"ࠧࠨ䋩"),l11ll1111l1l_ll_)
	elif l111lll_ll_ (u"ࠨࠤࡷࡳࡰ࡫࡮ࠣࠩ䋪") in html and l111lll_ll_ (u"ࠩࡥࡴࡂ࠭䋫") not in url:
		key = settings.getSetting(l111lll_ll_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡰ࡫ࡹࠨ䋬"))
		l11l1lll1lll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠪ䋭"))
		if l111lll_ll_ (u"ࠬࡹࡥࡢࡴࡦ࡬ࡤࡷࡵࡦࡴࡼࠫ䋮") in url or l111lll_ll_ (u"࠭ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ䋯") in url: l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡻࡲࡹࡹࡻࡢࡦ࡫࠲ࡺ࠶࠵ࡳࡦࡣࡵࡧ࡭ࡅ࡫ࡦࡻࡀࠫ䋰")+key
		else: l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱ࡼࡳࡺࡺࡵࡣࡧ࡬࠳ࡻ࠷࠯ࡣࡴࡲࡻࡸ࡫࠿࡬ࡧࡼࡁࠬ䋱")+key
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䋲"),l1l1l1l_ll_+l111lll_ll_ (u"ูࠪๆำษࠡษัี๎࠭䋳"),l1ll111_ll_,144,l111lll_ll_ (u"ࠫࠬ䋴"),l111lll_ll_ (u"ࠬ࠭䋵"),l11l1lll1lll_ll_)
	#l1ll1l_ll_(l111lll_ll_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋ࠮ࡊࡖࡈࡑࡘ࠮ࠩࠡࡵ࡬ࡾࡪ࠭䋶"),str(len(l11l11lll_ll_)))
	return
def l11l1llll111_ll_(l1lllllll1l1_ll_,l11111111l1_ll_,l11ll111111l_ll_):
	#l11l1l1ll_ll_(l111lll_ll_ (u"ࠧ࡮ࡷ࡯ࡸ࡮ࠦࡴࡳࡻࠪ䋷"),str(counter))
	cc,cc = l1lllllll1l1_ll_,l11111111l1_ll_
	l11ll1111ll1_ll_,index2 = l1lllllll1l1_ll_,l11111111l1_ll_
	ff,index = l1lllllll1l1_ll_,l11111111l1_ll_
	item,render = l1lllllll1l1_ll_,l11111111l1_ll_
	count = len(l11ll111111l_ll_)
	for counter in range(count):
		try:
			out = eval(l11ll111111l_ll_[counter])
			return str(counter+1),out
		except: pass
	return l111lll_ll_ (u"ࠨࠩ䋸"),l111lll_ll_ (u"ࠩࠪ䋹")
def l11ll111l1ll_ll_(item):
	try: l11l1lll1111_ll_ = item.keys()[0]
	except: return False,l111lll_ll_ (u"ࠪࠫ䋺"),l111lll_ll_ (u"ࠫࠬ䋻"),l111lll_ll_ (u"ࠬ࠭䋼"),l111lll_ll_ (u"࠭ࠧ䋽"),l111lll_ll_ (u"ࠧࠨ䋾"),l111lll_ll_ (u"ࠨࠩ䋿"),l111lll_ll_ (u"ࠩࠪ䌀")
	succeeded,title,link,img,count,duration,live,l11l1ll1llll_ll_ = False,l111lll_ll_ (u"ࠪࠫ䌁"),l111lll_ll_ (u"ࠫࠬ䌂"),l111lll_ll_ (u"ࠬ࠭䌃"),l111lll_ll_ (u"࠭ࠧ䌄"),l111lll_ll_ (u"ࠧࠨ䌅"),l111lll_ll_ (u"ࠨࠩ䌆"),l111lll_ll_ (u"ࠩࠪ䌇")
	render = item[l11l1lll1111_ll_]
	#l1111l1l_ll_(l111lll_ll_ (u"ࠪࡒࡔ࡚ࡉࡄࡇࠪ䌈"),str(item))
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡧࡧࡤࡨࡧࡶࠫ䌉"),l111lll_ll_ (u"ࠬ࡫ࡸࡪࡵࡷࠫ䌊"))
	trial = []
	trial.append(l111lll_ll_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡶࡰࡳࡰࡦࡿࡡࡣ࡮ࡨࡘࡪࡾࡴࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ䌋"))
	trial.append(l111lll_ll_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡨࡲࡶࡲࡧࡴࡵࡧࡧࡘ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䌌"))
	trial.append(l111lll_ll_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡷ࡭ࡹࡲࡥࠨ࡟࡞ࠫࡸ࡯࡭ࡱ࡮ࡨࡘࡪࡾࡴࠨ࡟ࠥ䌍"))
	trial.append(l111lll_ll_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡸ࡮ࡺ࡬ࡦࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ䌎"))
	trial.append(l111lll_ll_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䌏"))
	trial.append(l111lll_ll_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡲࡶࡰࡶࠫࡢࡡ࠰࡞࡝ࠪࡸࡪࡾࡴࠨ࡟ࠥ䌐"))
	trial.append(l111lll_ll_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡪࡶ࡯ࡩࠬࡣࠢ䌑"))
	trial.append(l111lll_ll_ (u"ࠨࡩࡵࡧࡰ࡟ࠬࡺࡩࡵ࡮ࡨࠫࡢࠨ䌒"))
	l11l1llll1ll_ll_,title = l11l1llll111_ll_(item,render,trial)
	trial = []
	trial.append(l111lll_ll_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡬ࡸࡱ࡫ࠧ࡞࡝ࠪࡶࡺࡴࡳࠨ࡟࡞࠴ࡢࡡࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࡉࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ䌓"))
	trial.append(l111lll_ll_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡱࡥࡻ࡯ࡧࡢࡶ࡬ࡳࡳࡋ࡮ࡥࡲࡲ࡭ࡳࡺࠧ࡞࡝ࠪࡧࡴࡳ࡭ࡢࡰࡧࡑࡪࡺࡡࡥࡣࡷࡥࠬࡣ࡛ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ䌔"))
	trial.append(l111lll_ll_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡩࡳࡪࡰࡰ࡫ࡱࡸࠬࡣ࡛ࠨࡥࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡷࡦࡤࡆࡳࡲࡳࡡ࡯ࡦࡐࡩࡹࡧࡤࡢࡶࡤࠫࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ䌕"))
	trial.append(l111lll_ll_ (u"ࠥ࡭ࡹ࡫࡭࡜ࠩࡨࡲࡩࡶ࡯ࡪࡰࡷࠫࡢࡡࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩࡠ࡟ࠬࡽࡥࡣࡅࡲࡱࡲࡧ࡮ࡥࡏࡨࡸࡦࡪࡡࡵࡣࠪࡡࡠ࠭ࡵࡳ࡮ࠪࡡࠧ䌖")) # required for channels l11l1ll1l111_ll_
	l11l1llll1ll_ll_,link = l11l1llll111_ll_(item,render,trial)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠫࡷ࡫࡮ࡥࡧࡵࠤࡱ࡯࡮࡬࠼ࠣࠤࠬ䌗")+link,l111lll_ll_ (u"ࠬ࡬࡯ࡶࡰࡧࠤ࡮ࡴࠠࠨ䌘")+l11l1llll1ll_ll_)
	trial = []
	trial.append(l111lll_ll_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࠪࡡࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡵࠪࡡࡠ࠶࡝࡜ࠩࡸࡶࡱ࠭࡝ࠣ䌙"))
	trial.append(l111lll_ll_ (u"ࠢࡳࡧࡱࡨࡪࡸ࡛ࠨࡶ࡫ࡹࡲࡨ࡮ࡢ࡫࡯ࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡳࠨ࡟࡞࠴ࡢࡡࠧࡶࡴ࡯ࠫࡢࠨ䌚"))
	l11l1llll1ll_ll_,img = l11l1llll111_ll_(item,render,trial)
	trial = []
	trial.append(l111lll_ll_ (u"ࠣࡴࡨࡲࡩ࡫ࡲ࡜ࠩࡹ࡭ࡩ࡫࡯ࡄࡱࡸࡲࡹ࠭࡝ࠣ䌛"))
	trial.append(l111lll_ll_ (u"ࠤࡵࡩࡳࡪࡥࡳ࡝ࠪࡺ࡮ࡪࡥࡰࡅࡲࡹࡳࡺࡔࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ䌜"))
	trial.append(l111lll_ll_ (u"ࠥࡶࡪࡴࡤࡦࡴ࡞ࠫࡹ࡮ࡵ࡮ࡤࡱࡥ࡮ࡲࡏࡷࡧࡵࡰࡦࡿࡳࠨ࡟࡞࠴ࡢࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡅࡳࡹࡺ࡯࡮ࡒࡤࡲࡪࡲࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠ࡟ࠬࡸࡵ࡯ࡵࠪࡡࡠ࠶࡝࡜ࠩࡷࡩࡽࡺࠧ࡞ࠤ䌝"))
	l11l1llll1ll_ll_,count = l11l1llll111_ll_(item,render,trial)
	trial = []
	trial.append(l111lll_ll_ (u"ࠦࡷ࡫࡮ࡥࡧࡵ࡟ࠬࡲࡥ࡯ࡩࡷ࡬࡙࡫ࡸࡵࠩࡠ࡟ࠬࡹࡩ࡮ࡲ࡯ࡩ࡙࡫ࡸࡵࠩࡠࠦ䌞"))
	trial.append(l111lll_ll_ (u"ࠧࡸࡥ࡯ࡦࡨࡶࡠ࠭ࡴࡩࡷࡰࡦࡳࡧࡩ࡭ࡑࡹࡩࡷࡲࡡࡺࡵࠪࡡࡠ࠶࡝࡜ࠩࡷ࡬ࡺࡳࡢ࡯ࡣ࡬ࡰࡔࡼࡥࡳ࡮ࡤࡽ࡙࡯࡭ࡦࡕࡷࡥࡹࡻࡳࡓࡧࡱࡨࡪࡸࡥࡳࠩࡠ࡟ࠬࡺࡥࡹࡶࠪࡡࡠ࠭ࡳࡪ࡯ࡳࡰࡪ࡚ࡥࡹࡶࠪࡡࠧ䌟"))
	trial.append(l111lll_ll_ (u"ࠨࡲࡦࡰࡧࡩࡷࡡࠧࡵࡪࡸࡱࡧࡴࡡࡪ࡮ࡒࡺࡪࡸ࡬ࡢࡻࡶࠫࡢࡡ࠰࡞࡝ࠪࡸ࡭ࡻ࡭ࡣࡰࡤ࡭ࡱࡕࡶࡦࡴ࡯ࡥࡾ࡚ࡩ࡮ࡧࡖࡸࡦࡺࡵࡴࡔࡨࡲࡩ࡫ࡲࡦࡴࠪࡡࡠ࠭ࡴࡦࡺࡷࠫࡢࡡࠧࡳࡷࡱࡷࠬࡣ࡛࠱࡟࡞ࠫࡹ࡫ࡸࡵࠩࡠࠦ䌠"))
	l11l1llll1ll_ll_,duration = l11l1llll111_ll_(item,render,trial)
	if l111lll_ll_ (u"ࠧࡍࡋ࡙ࡉࠬ䌡") in duration: duration,live = l111lll_ll_ (u"ࠨࠩ䌢"),l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ䌣")
	if l111lll_ll_ (u"้ࠪออิาࠩ䌤") in duration: duration,live = l111lll_ll_ (u"ࠫࠬ䌥"),l111lll_ll_ (u"ࠬࡒࡉࡗࡇ࠽ࠤࠥ࠭䌦")
	if l111lll_ll_ (u"࠭ࡢࡢࡦࡪࡩࡸ࠭䌧") in render.keys():
		l11ll11111l1_ll_ = str(render[l111lll_ll_ (u"ࠧࡣࡣࡧ࡫ࡪࡹࠧ䌨")])
		if l111lll_ll_ (u"ࠨࡈࡵࡩࡪࠦࡷࡪࡶ࡫ࠤࡆࡪࡳࠨ䌩") in l11ll11111l1_ll_: l11l1ll1llll_ll_ = l111lll_ll_ (u"ࠩࠧ࠾ࠬ䌪")
		if l111lll_ll_ (u"ࠪࡐࡎ࡜ࡅࠡࡐࡒ࡛ࠬ䌫") in l11ll11111l1_ll_: live = l111lll_ll_ (u"ࠫࡑࡏࡖࡆ࠼ࠣࠤࠬ䌬")
		if l111lll_ll_ (u"ࠬࡈࡵࡺࠩ䌭") in l11ll11111l1_ll_ or l111lll_ll_ (u"࠭ࡒࡦࡰࡷࠫ䌮") in l11ll11111l1_ll_: l11l1ll1llll_ll_ = l111lll_ll_ (u"ࠧࠥࠦ࠽ࠫ䌯")
		if l1ll111l1ll_ll_(l111lll_ll_ (u"ࡶ่ࠩฬฬฺัࠨ䌰")) in l11ll11111l1_ll_: live = l111lll_ll_ (u"ࠩࡏࡍ࡛ࡋ࠺ࠡࠢࠪ䌱")
		if l1ll111l1ll_ll_(l111lll_ll_ (u"ࡸูࠫืวยࠩ䌲")) in l11ll11111l1_ll_: l11l1ll1llll_ll_ = l111lll_ll_ (u"ࠫࠩࠪ࠺ࠨ䌳")
		if l1ll111l1ll_ll_(l111lll_ll_ (u"ࡺ࠭วิฬษะฬืࠧ䌴")) in l11ll11111l1_ll_: l11l1ll1llll_ll_ = l111lll_ll_ (u"࠭ࠤࠥ࠼ࠪ䌵")
		if l1ll111l1ll_ll_(l111lll_ll_ (u"ࡵࠨว฼่ฬ์วหࠩ䌶")) in l11ll11111l1_ll_: l11l1ll1llll_ll_ = l111lll_ll_ (u"ࠨࠦ࠽ࠫ䌷")
	if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶࠧ䌸") not in img and img!=l111lll_ll_ (u"ࠪࠫ䌹"): img = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽ࠫ䌺")+img
	link = l1l1l11ll_ll_(link)
	if link!=l111lll_ll_ (u"ࠬ࠭䌻") and l111lll_ll_ (u"࠭ࡨࡵࡶࡳࠫ䌼") not in link: link = l1ll1l1_ll_+link
	title = l1l1l11ll_ll_(title)
	if l11l1ll1llll_ll_!=l111lll_ll_ (u"ࠧࠨ䌽"): title = l11l1ll1llll_ll_+l111lll_ll_ (u"ࠨࠢࠣࠫ䌾")+title
	#title = unescapeHTML(title)
	duration = duration.replace(l111lll_ll_ (u"ࠩ࠯ࠫ䌿"),l111lll_ll_ (u"ࠪࠫ䍀"))
	count = count.replace(l111lll_ll_ (u"ࠫ࠱࠭䍁"),l111lll_ll_ (u"ࠬ࠭䍂"))
	count = re.findall(l111lll_ll_ (u"࠭࡜ࡥ࠭ࠪ䍃"),count)
	if count: count = count[0]
	else: count = l111lll_ll_ (u"ࠧࠨ䍄")
	return True,title,link,img,count,duration,live,l11l1ll1llll_ll_
def l11l1ll1ll11_ll_(item,url=l111lll_ll_ (u"ࠨࠩ䍅"),index=l111lll_ll_ (u"ࠩࠪ䍆"),l11ll111l1l1_ll_=l111lll_ll_ (u"ࠪࠫ䍇")):
	succeeded,title,link,img,count,duration,live,l11l1ll1llll_ll_ = l11ll111l1ll_ll_(item)
	#l11l1l1ll_ll_(l111lll_ll_ (u"ࠫࠬ䍈"),str(item))
	#l1ll1l_ll_(link,url)
	#l1ll1l_ll_(index,l11ll111l1l1_ll_)
	#if l111lll_ll_ (u"ࠬ࠵ࡦࡦࡧࡧ࠳࡬ࡻࡩࡥࡧࡢࡦࡺ࡯࡬ࡥࡧࡵࠫ䍉") in url and index==l111lll_ll_ (u"࠭࠰ࠨ䍊"):
	#	l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍋"),l1l1l1l_ll_+title,url,144)
	#	return
	if not succeeded: return
	elif l111lll_ll_ (u"ࠨࡥࡲࡲࡹ࡯࡮ࡶࡣࡷ࡭ࡴࡴࡉࡵࡧࡰࡖࡪࡴࡤࡦࡴࡨࡶࠬ䍌") in str(item): return	# continuation not items
	elif l111lll_ll_ (u"ࠩࡶࡩࡦࡸࡣࡩࡒࡼࡺࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䍍") in str(item): return			# ads not items
	elif link==l111lll_ll_ (u"ࠪࠫ䍎") and l111lll_ll_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡣࡶࡻࡥࡳࡻࠪ䍏") in url: return			# separator l11l1ll1l11l_ll_ list not items
	elif title!=l111lll_ll_ (u"ࠬ࠭䍐") and link==l111lll_ll_ (u"࠭ࠧ䍑") and (l111lll_ll_ (u"ࠧࡴࡧࡤࡶࡨ࡮࡟ࡲࡷࡨࡶࡾ࠭䍒") in url or l111lll_ll_ (u"ࠨࡪࡲࡶ࡮ࢀ࡯࡯ࡶࡤࡰࡒࡵࡶࡪࡧࡏ࡭ࡸࡺࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䍓") in str(item) or url==l1ll1l1_ll_):
		title = l111lll_ll_ (u"ࠩࡀࡁࡂࠦࠧ䍔")+title+l111lll_ll_ (u"ࠪࠤࡂࡃ࠽ࠨ䍕")
		l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩ䍖"),l1l1l1l_ll_+title,l111lll_ll_ (u"ࠬ࠭䍗"),9999)
	elif title!=l111lll_ll_ (u"࠭ࠧ䍘") and l111lll_ll_ (u"ࠧ࡮ࡧࡶࡷࡦ࡭ࡥࡓࡧࡱࡨࡪࡸࡥࡳࠩ䍙") in str(item):
		l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡲࡰ࠭䍚"),l1l1l1l_ll_+title,l111lll_ll_ (u"ࠩࠪ䍛"),9999)
	elif l111lll_ll_ (u"ࠪ࠳࡫࡫ࡥࡥ࠱ࡷࡶࡪࡴࡤࡪࡰࡪࠫ䍜") in link and l111lll_ll_ (u"ࠫࡧࡶ࠽ࠨ䍝") not in link: return #l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ䍞"),l1l1l1l_ll_+title,link,146)
	elif title==l111lll_ll_ (u"࠭ࠧ䍟"): return
	elif live!=l111lll_ll_ (u"ࠧࠨ䍠"): l111_ll_(l111lll_ll_ (u"ࠨ࡮࡬ࡺࡪ࠭䍡"),l1l1l1l_ll_+live+title,link,143,img)
	elif l111lll_ll_ (u"ࠩ࡯࡭ࡸࡺ࠽ࠨ䍢") in link and l111lll_ll_ (u"ࠪ࡭ࡳࡪࡥࡹ࠿ࠪ䍣") not in link and l111lll_ll_ (u"ࠫࡹࡃ࠰ࠨ䍤") not in link:
		l11l1ll1ll1l_ll_ = re.findall(l111lll_ll_ (u"ࠬࡲࡩࡴࡶࡀࠬ࠳࠰࠿ࠪࠨࠪ䍥"),link+l111lll_ll_ (u"࠭ࠦࠨ䍦"),re.DOTALL)
		link = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡲ࡯ࡥࡾࡲࡩࡴࡶࡂࡰ࡮ࡹࡴ࠾ࠩ䍧")+l11l1ll1ll1l_ll_[0]
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ䍨"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࡏࡍࡘ࡚ࠧ䍩")+count+l111lll_ll_ (u"ࠪ࠾ࠥࠦࠧ䍪")+title,link,144,img)
	elif l111lll_ll_ (u"ࠫࡼࡧࡴࡤࡪࡂࡺࡂ࠭䍫") in link:
		if l111lll_ll_ (u"ࠬࡲࡩࡴࡶࡀࠫ䍬") in link and l111lll_ll_ (u"࠭ࡩ࡯ࡦࡨࡼࡂ࠭䍭") not in link:
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ䍮"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨࡎࡌࡗ࡙࠭䍯")+count+l111lll_ll_ (u"ࠩ࠽ࠤࠥ࠭䍰")+title,link,144,img)
		else: l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ䍱"),l1l1l1l_ll_+title,link,143,img,duration)
	else:
		type = l111lll_ll_ (u"ࠫࠬ䍲")
		if link==l111lll_ll_ (u"ࠬ࠭䍳"): link = url
		#if l111lll_ll_ (u"࠭ࡳࡴ࠿ࠪ䍴") in link: link = url
		#elif l111lll_ll_ (u"ࠧࡴࡪࡨࡰ࡫ࡥࡩࡥ࠿ࠪ䍵") in link: link = url		# not needed it will stop l11l1lll111l_ll_ channels l11l1ll1l111_ll_
		elif not any(value in link for value in [l111lll_ll_ (u"ࠨ࠱ࡹ࡭ࡩ࡫࡯ࡴࠩ䍶"),l111lll_ll_ (u"ࠩ࠲ࡴࡱࡧࡹ࡭࡫ࡶࡸࡸ࠭䍷"),l111lll_ll_ (u"ࠪ࠳ࡨ࡮ࡡ࡯ࡰࡨࡰࡸ࠭䍸"),l111lll_ll_ (u"ࠫ࠴࡬ࡥࡢࡶࡸࡶࡪࡪࠧ䍹"),l111lll_ll_ (u"ࠬࡹࡳ࠾ࠩ䍺"),l111lll_ll_ (u"࠭ࡢࡱ࠿ࠪ䍻")]):
			if l111lll_ll_ (u"ࠧ࠰ࡥ࡫ࡥࡳࡴࡥ࡭࠱ࠪ䍼")	in link or l111lll_ll_ (u"ࠨ࠱ࡦ࠳ࠬ䍽") in link: type = l111lll_ll_ (u"ࠩࡆࡌࡓࡒࠧ䍾")+count+l111lll_ll_ (u"ࠪ࠾ࠥࠦࠧ䍿")
			if l111lll_ll_ (u"ࠫ࠴ࡻࡳࡦࡴ࠲ࠫ䎀") in link: type = l111lll_ll_ (u"࡛ࠬࡓࡆࡔࠪ䎁")+count+l111lll_ll_ (u"࠭࠺ࠡࠢࠪ䎂")
			index,l11ll111l1l1_ll_ = l111lll_ll_ (u"ࠧࠨ䎃"),l111lll_ll_ (u"ࠨࠩ䎄")
		l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩ䎅"),l1l1l1l_ll_+type+title,link,144,img,index,l11ll111l1l1_ll_)
	return
def l11l1ll1lll1_ll_(url,l11ll111l1l1_ll_=l111lll_ll_ (u"ࠪࠫ䎆"),request=l111lll_ll_ (u"ࠫࠬ䎇")):
	#if l111lll_ll_ (u"ࠬࡥ࡟ࠨ䎈") in l11ll111l1l1_ll_: l11ll111l1l1_ll_ = l111lll_ll_ (u"࠭ࠧ䎉")
	#if l111lll_ll_ (u"ࠧࡴࡵࡀࠫ䎊") in url: url = url.split(l111lll_ll_ (u"ࠨࡵࡶࡁࠬ䎋"))[0]
	if request==l111lll_ll_ (u"ࠩࠪ䎌"): request = l111lll_ll_ (u"ࠪࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡊࡡࡵࡣࠪ䎍")
	global settings
	l1ll11l11_ll_ = l1ll11lll_ll_()
	l1ll11l1l_ll_ = {l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ䎎"):l1ll11l11_ll_,l111lll_ll_ (u"ࠬࡉ࡯ࡰ࡭࡬ࡩࠬ䎏"):l111lll_ll_ (u"࠭ࡐࡓࡇࡉࡁ࡭ࡲ࠽ࡢࡴࠪ䎐")}
	#l1ll11l1l_ll_ = headers.copy()
	if l111lll_ll_ (u"ࠧࡨࡷ࡬ࡨࡪࡅ࡫ࡦࡻࡀࠫ䎑") in url:
		l11l1lll11ll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡰ࡮࡫࡮ࡵࡸࡨࡶࡸ࡯࡯࡯ࠩ䎒"))
		data = {}
		data[l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥࡹࡶࠪ䎓")] = {l111lll_ll_ (u"ࠥࡧࡱ࡯ࡥ࡯ࡶࠥ䎔"):{l111lll_ll_ (u"ࠦ࡭ࡲࠢ䎕"):l111lll_ll_ (u"ࠧࡧࡲࠣ䎖"),l111lll_ll_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ䎗"):l111lll_ll_ (u"ࠢࡘࡇࡅࠦ䎘"),l111lll_ll_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ䎙"):l11l1lll11ll_ll_}}
		data = str(data)
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠩࡓࡓࡘ࡚ࠧ䎚"),url,data,l1ll11l1l_ll_,True,True,l111lll_ll_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ䎛"))
		#l1ll1l_ll_(url,str(data))
		html = response.content
	elif l111lll_ll_ (u"ࠫࡰ࡫ࡹ࠾ࠩ䎜") in url and l11ll111l1l1_ll_!=l111lll_ll_ (u"ࠬ࠭䎝"):
		settings.setSetting(l111lll_ll_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮ࡷ࡫ࡶ࡭ࡹࡵࡲࡅࡣࡷࡥࠬ䎞"),l11ll111l1l1_ll_)
		l11l1lll11ll_ll_ = settings.getSetting(l111lll_ll_ (u"ࠧࡺࡱࡸࡸࡺࡨࡥ࠯ࡥ࡯࡭ࡪࡴࡴࡷࡧࡵࡷ࡮ࡵ࡮ࠨ䎟"))
		token = settings.getSetting(l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡷࡳࡰ࡫࡮ࠨ䎠"))
		data = {l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡩ࡯ࡷࡤࡸ࡮ࡵ࡮ࠨ䎡"):token}
		data[l111lll_ll_ (u"ࠪࡧࡴࡴࡴࡦࡺࡷࠫ䎢")] = {l111lll_ll_ (u"ࠦࡨࡲࡩࡦࡰࡷࠦ䎣"):{l111lll_ll_ (u"ࠧࡼࡩࡴ࡫ࡷࡳࡷࡊࡡࡵࡣࠥ䎤"):l11ll111l1l1_ll_,l111lll_ll_ (u"ࠨࡣ࡭࡫ࡨࡲࡹࡔࡡ࡮ࡧࠥ䎥"):l111lll_ll_ (u"ࠢࡘࡇࡅࠦ䎦"),l111lll_ll_ (u"ࠣࡥ࡯࡭ࡪࡴࡴࡗࡧࡵࡷ࡮ࡵ࡮ࠣ䎧"):l11l1lll11ll_ll_}}
		data = str(data)
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠩࡓࡓࡘ࡚ࠧ䎨"),url,data,l1ll11l1l_ll_,True,True,l111lll_ll_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈ࠱ࡌࡋࡔࡠࡒࡄࡋࡊࡥࡄࡂࡖࡄ࠱࠶ࡹࡴࠨ䎩"))
		#l1ll1l_ll_(url,str(data))
		html = response.content
	elif l111lll_ll_ (u"ࠫࡨࡺ࡯࡬ࡧࡱࡁࠬ䎪") in url and l11ll111l1l1_ll_!=l111lll_ll_ (u"ࠬ࠭䎫"):
		l11l1lll11ll_ll_ = settings.getSetting(l111lll_ll_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤ࡮࡬ࡩࡳࡺࡶࡦࡴࡶ࡭ࡴࡴࠧ䎬"))
		l1ll11l1l_ll_.update({l111lll_ll_ (u"࡙ࠧ࠯࡜ࡳࡺ࡚ࡵࡣࡧ࠰ࡇࡱ࡯ࡥ࡯ࡶ࠰ࡒࡦࡳࡥࠨ䎭"):l111lll_ll_ (u"ࠨ࠳ࠪ䎮"),l111lll_ll_ (u"࡛ࠩ࠱࡞ࡵࡵࡕࡷࡥࡩ࠲ࡉ࡬ࡪࡧࡱࡸ࠲࡜ࡥࡳࡵ࡬ࡳࡳ࠭䎯"):l11l1lll11ll_ll_})
		l1ll11l1l_ll_.update({l111lll_ll_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ䎰"):l111lll_ll_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆ࠿ࠪ䎱")+l11ll111l1l1_ll_})
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠬࡍࡅࡕࠩ䎲"),url,l111lll_ll_ (u"࠭ࠧ䎳"),l1ll11l1l_ll_,l111lll_ll_ (u"ࠧࠨ䎴"),l111lll_ll_ (u"ࠨࠩ䎵"),l111lll_ll_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇ࠰ࡋࡊ࡚࡟ࡑࡃࡊࡉࡤࡊࡁࡕࡃ࠰࠶ࡳࡪࠧ䎶"))
		html = response.content
	else:
		response = l111111_ll_(l11111l1_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ䎷"),url,l111lll_ll_ (u"ࠫࠬ䎸"),l1ll11l1l_ll_,l111lll_ll_ (u"ࠬ࠭䎹"),l111lll_ll_ (u"࠭ࠧ䎺"),l111lll_ll_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅ࠮ࡉࡈࡘࡤࡖࡁࡈࡇࡢࡈࡆ࡚ࡁ࠮࠵ࡵࡨࠬ䎻"))
		html = response.content
	l11l1lll1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࠤࡹ࡭ࡸ࡯ࡴࡰࡴࡇࡥࡹࡧࠢ࠯ࠬࡂࠦ࠭࠴ࠪࡀࠫࠥࠫ䎼"),html,re.DOTALL|re.I)
	if l11l1lll1lll_ll_: settings.setSetting(l111lll_ll_ (u"ࠩࡼࡳࡺࡺࡵࡣࡧ࠱ࡺ࡮ࡹࡩࡵࡱࡵࡈࡦࡺࡡࠨ䎽"),l11l1lll1lll_ll_[0])
	key = re.findall(l111lll_ll_ (u"ࠪࠦ࡮ࡴ࡮ࡦࡴࡷࡹࡧ࡫ࡁࡱ࡫ࡎࡩࡾࠨ࠮ࠫࡁࠥࠬ࠳࠰࠿ࠪࠤࠪ䎾"),html,re.DOTALL|re.I)
	if key: settings.setSetting(l111lll_ll_ (u"ࠫࡾࡵࡵࡵࡷࡥࡩ࠳ࡱࡥࡺࠩ䎿"),key[0])
	continuation = re.findall(l111lll_ll_ (u"ࠬࠨࡣࡰࡰࡷ࡭ࡳࡻࡡࡵ࡫ࡲࡲࠧ࠴ࠪࡀࠤࠫ࠲࠯ࡅࠩࠣࠩ䏀"),html,re.DOTALL|re.I)
	if continuation: settings.setSetting(l111lll_ll_ (u"࠭ࡹࡰࡷࡷࡹࡧ࡫࠮ࡤࡱࡱࡸ࡮ࡴࡵࡢࡶ࡬ࡳࡳ࠭䏁"),continuation[0])
	l11l1lll11ll_ll_ = re.findall(l111lll_ll_ (u"ࠧࠣࡥࡹࡩࡷࠨ࠮ࠫࡁࠥࡺࡦࡲࡵࡦࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䏂"),html,re.DOTALL|re.I)
	if l11l1lll11ll_ll_: settings.setSetting(l111lll_ll_ (u"ࠨࡻࡲࡹࡹࡻࡢࡦ࠰ࡦࡰ࡮࡫࡮ࡵࡸࡨࡶࡸ࡯࡯࡯ࠩ䏃"),l11l1lll11ll_ll_[0])
	token = re.findall(l111lll_ll_ (u"ࠩࠥࡸࡴࡱࡥ࡯ࠤ࠱࠮ࡄࠨࠨ࠯ࠬࡂ࠭ࠧ࠭䏄"),html,re.DOTALL|re.I)
	if token: settings.setSetting(l111lll_ll_ (u"ࠪࡽࡴࡻࡴࡶࡤࡨ࠲ࡹࡵ࡫ࡦࡰࠪ䏅"),token[0])
	cookies = response.cookies.get_dict()
	if l111lll_ll_ (u"࡛ࠫࡏࡓࡊࡖࡒࡖࡤࡏࡎࡇࡑ࠴ࡣࡑࡏࡖࡆࠩ䏆") in cookies.keys():
		settings.setSetting(l111lll_ll_ (u"ࠬࡿ࡯ࡶࡶࡸࡦࡪ࠴ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ䏇"),cookies[l111lll_ll_ (u"࠭ࡖࡊࡕࡌࡘࡔࡘ࡟ࡊࡐࡉࡓ࠶ࡥࡌࡊࡘࡈࠫ䏈")])
	if request==l111lll_ll_ (u"ࠧࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠧ䏉") and l111lll_ll_ (u"ࠨࡻࡷࡍࡳ࡯ࡴࡪࡣ࡯ࡈࡦࡺࡡࠨ䏊") in html:
		#l1ll1l_ll_(url,html)
		l1lll111l1_ll_ = re.findall(l111lll_ll_ (u"ࠩࡺ࡭ࡳࡪ࡯ࡸ࡞࡞ࠦࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡄࡢࡶࡤࠦࡡࡣࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ䏋"),html,re.DOTALL)
		if not l1lll111l1_ll_: l1lll111l1_ll_ = re.findall(l111lll_ll_ (u"ࠪࡺࡦࡸࠠࡺࡶࡌࡲ࡮ࡺࡩࡢ࡮ࡇࡥࡹࡧࠠ࠾ࠢࠫࡿ࠳࠰࠿ࡾࠫ࠾ࠫ䏌"),html,re.DOTALL)
		l11ll1111111_ll_ = l111ll1lll_ll_(l1lll111l1_ll_[0])
	elif request==l111lll_ll_ (u"ࠫࡾࡺࡉ࡯࡫ࡷ࡭ࡦࡲࡇࡶ࡫ࡧࡩࡉࡧࡴࡢࠩ䏍") and l111lll_ll_ (u"ࠬࡿࡴࡊࡰ࡬ࡸ࡮ࡧ࡬ࡈࡷ࡬ࡨࡪࡊࡡࡵࡣࠪ䏎") in html:
		l1lll111l1_ll_ = re.findall(l111lll_ll_ (u"࠭ࡶࡢࡴࠣࡽࡹࡏ࡮ࡪࡶ࡬ࡥࡱࡍࡵࡪࡦࡨࡈࡦࡺࡡࠡ࠿ࠣࠬࢀ࠴ࠪࡀࡿࠬ࠿ࠬ䏏"),html,re.DOTALL)
		l11ll1111111_ll_ = l111ll1lll_ll_(l1lll111l1_ll_[0])
	elif l111lll_ll_ (u"ࠧ࠽࠱ࡶࡧࡷ࡯ࡰࡵࡀࠪ䏐") not in html: l11ll1111111_ll_ = l111ll1lll_ll_(html)
	else: l11ll1111111_ll_ = l111lll_ll_ (u"ࠨࠩ䏑")
	#with open(l111lll_ll_ (u"ࠩࡖ࠾ࡡࡢ࠰࠱࠲࠳ࡩࡲࡧࡤ࠯࡬ࡶࡳࡳ࠭䏒"),l111lll_ll_ (u"ࠪࡻࠬ䏓")) as f: f.write(str(l11ll1111111_ll_))
	#with open(l111lll_ll_ (u"ࠫࡘࡀ࡜࡝࠲࠳࠴࠵࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ䏔"),l111lll_ll_ (u"ࠬࡽࠧ䏕")) as f: f.write(html)
	return html,l11ll1111111_ll_
def l11ll1111lll_ll_(url):
	search = l1ll1_ll_()
	if search==l111lll_ll_ (u"࠭ࠧ䏖"): return
	search = search.replace(l111lll_ll_ (u"ࠧࠡࠩ䏗"),l111lll_ll_ (u"ࠨ࠭ࠪ䏘"))
	l1ll111_ll_ = url+l111lll_ll_ (u"ࠩ࠲ࡷࡪࡧࡲࡤࡪࡂࡵࡺ࡫ࡲࡺ࠿ࠪ䏙")+search
	l11ll1l11l_ll_(l1ll111_ll_)
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠪࠫ䏚"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠫࠬ䏛"): return
	search = search.replace(l111lll_ll_ (u"ࠬࠦࠧ䏜"),l111lll_ll_ (u"࠭ࠫࠨ䏝"))
	l11l1ll1l1ll_ll_ = [l111lll_ll_ (u"ࠧษั๋๊ࠥ็ไหำࠪ䏞")]
	l11l1ll1111l_ll_ = []
	l11l1l1lllll_ll_ = [l111lll_ll_ (u"ࠨࠩ䏟")]
	l11l1lllllll_ll_ = [l111lll_ll_ (u"ࠩࠪ䏠")]
	#l11l1ll1111l_ll_.append(l111lll_ll_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࡲࡦ࡮ࡨࡺࡦࡴࡣࡦࠩ䏡"))
	#l11l1lllllll_ll_.append(l111lll_ll_ (u"ࠫࠬ䏢"))
	#l1ll111_ll_ = l111lll_ll_ (u"ࠬࡶ࡬ࡶࡩ࡬ࡲ࠿࠵࠯ࡱ࡮ࡸ࡫࡮ࡴ࠮ࡷ࡫ࡧࡩࡴ࠴ࡹࡰࡷࡷࡹࡧ࡫࠯࡬ࡱࡧ࡭ࡴࡴ࠯ࡴࡧࡤࡶࡨ࡮࠯ࡲࡷࡨࡶࡾ࠵࠿ࡲ࠿ࠪ䏣")+search
	#xbmc.executebuiltin(l111lll_ll_ (u"࠭ࡄࡪࡣ࡯ࡳ࡬࠴ࡃ࡭ࡱࡶࡩ࠭ࡨࡵࡴࡻࡧ࡭ࡦࡲ࡯ࡨࠫࠪ䏤"))
	#xbmc.executebuiltin(l111lll_ll_ (u"ࠧࡂࡥࡷ࡭ࡻࡧࡴࡦ࡙࡬ࡲࡩࡵࡷࠩࡸ࡬ࡨࡪࡵࡳ࠭ࠩ䏥")+l1ll111_ll_+l111lll_ll_ (u"ࠨ࠮ࡵࡩࡹࡻࡲ࡯ࠫࠪ䏦"))
	l11l1ll1111l_ll_ = [l111lll_ll_ (u"ࠩหำํ์ࠠหำอ๎อ࠭䏧"),l111lll_ll_ (u"ࠪฮึะ๊ษࠢะือࠦๅะ๋ࠣห้฻ไสࠩ䏨"),l111lll_ll_ (u"ࠫฯืส๋สࠣัุฮࠠหษิ๎ำࠦวๅฬะ้๏๊ࠧ䏩"),l111lll_ll_ (u"ࠬะัห์หࠤาูศࠡ฻าำࠥอไๆึส๋ิอสࠨ䏪"),l111lll_ll_ (u"࠭สาฬํฬࠥำำษࠢส่ฯ่๊๋็ࠪ䏫")]
	l11l1lllllll_ll_ = [l111lll_ll_ (u"ࠧࠨ䏬"),l111lll_ll_ (u"ࠨࠨࡶࡴࡂࡉࡁࡂࠧ࠵࠹࠸ࡊࠧ䏭"),l111lll_ll_ (u"ࠩࠩࡷࡵࡃࡃࡂࡋࠨ࠶࠺࠹ࡄࠨ䏮"),l111lll_ll_ (u"ࠪࠪࡸࡶ࠽ࡄࡃࡐࠩ࠷࠻࠳ࡅࠩ䏯"),l111lll_ll_ (u"ࠫࠫࡹࡰ࠾ࡅࡄࡉࠪ࠸࠵࠴ࡆࠪ䏰")]
	if l1ll11_ll_:
		l11ll111l11l_ll_ = l1l1111_ll_(l111lll_ll_ (u"ࠬอฮหำࠣห้ะัห์หࠤฬ๊ๅ็ษึฬ࠿࠭䏱"), l11l1ll1111l_ll_)
		if l11ll111l11l_ll_ == -1: return
		l11ll11111ll_ll_ = l11l1lllllll_ll_[l11ll111l11l_ll_]
	else: l11ll11111ll_ll_ = l111lll_ll_ (u"࠭ࠧ䏲")
	l1ll111_ll_ = l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡴࡨࡷࡺࡲࡴࡴࡁࡶࡩࡦࡸࡣࡩࡡࡴࡹࡪࡸࡹ࠾ࠩ䏳")+search
	html,c = l11l1ll1lll1_ll_(l1ll111_ll_+l11ll11111ll_ll_)
	if c!=l111lll_ll_ (u"ࠨࠩ䏴"):
		d = c[l111lll_ll_ (u"ࠩࡦࡳࡳࡺࡥ࡯ࡶࡶࠫ䏵")][l111lll_ll_ (u"ࠪࡸࡼࡵࡃࡰ࡮ࡸࡱࡳ࡙ࡥࡢࡴࡦ࡬ࡗ࡫ࡳࡶ࡮ࡷࡷࡗ࡫࡮ࡥࡧࡵࡩࡷ࠭䏶")][l111lll_ll_ (u"ࠫࡵࡸࡩ࡮ࡣࡵࡽࡈࡵ࡮ࡵࡧࡱࡸࡸ࠭䏷")][l111lll_ll_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡒࡩࡴࡶࡕࡩࡳࡪࡥࡳࡧࡵࠫ䏸")][l111lll_ll_ (u"࠭ࡳࡶࡤࡐࡩࡳࡻࠧ䏹")][l111lll_ll_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࡓࡶࡤࡐࡩࡳࡻࡒࡦࡰࡧࡩࡷ࡫ࡲࠨ䏺")][l111lll_ll_ (u"ࠨࡩࡵࡳࡺࡶࡳࠨ䏻")]
		for l11l1l1llll1_ll_ in range(len(d)):
			group = d[l11l1l1llll1_ll_][l111lll_ll_ (u"ࠩࡶࡩࡦࡸࡣࡩࡈ࡬ࡰࡹ࡫ࡲࡈࡴࡲࡹࡵࡘࡥ࡯ࡦࡨࡶࡪࡸࠧ䏼")][l111lll_ll_ (u"ࠪࡪ࡮ࡲࡴࡦࡴࡶࠫ䏽")]
			for l11ll111l111_ll_ in range(len(group)):
				render = group[l11ll111l111_ll_][l111lll_ll_ (u"ࠫࡸ࡫ࡡࡳࡥ࡫ࡊ࡮ࡲࡴࡦࡴࡕࡩࡳࡪࡥࡳࡧࡵࠫ䏾")]
				if l111lll_ll_ (u"ࠬࡴࡡࡷ࡫ࡪࡥࡹ࡯࡯࡯ࡇࡱࡨࡵࡵࡩ࡯ࡶࠪ䏿") in render.keys():
					link = render[l111lll_ll_ (u"࠭࡮ࡢࡸ࡬࡫ࡦࡺࡩࡰࡰࡈࡲࡩࡶ࡯ࡪࡰࡷࠫ䐀")][l111lll_ll_ (u"ࠧࡤࡱࡰࡱࡦࡴࡤࡎࡧࡷࡥࡩࡧࡴࡢࠩ䐁")][l111lll_ll_ (u"ࠨࡹࡨࡦࡈࡵ࡭࡮ࡣࡱࡨࡒ࡫ࡴࡢࡦࡤࡸࡦ࠭䐂")][l111lll_ll_ (u"ࠩࡸࡶࡱ࠭䐃")]
					link = link.replace(l111lll_ll_ (u"ࠪࡠࡺ࠶࠰࠳࠸ࠪ䐄"),l111lll_ll_ (u"ࠫࠫ࠭䐅"))
					title = render[l111lll_ll_ (u"ࠬࡺ࡯ࡰ࡮ࡷ࡭ࡵ࠭䐆")]
					title = title.replace(l111lll_ll_ (u"࠭วๅสะฯࠥ฿ๆࠡࠩ䐇"),l111lll_ll_ (u"ࠧࠨ䐈"))
					if l111lll_ll_ (u"ࠨวีห้ฯࠠศๆไ่ฯืࠧ䐉") in title: continue
					if l111lll_ll_ (u"ࠩๅหห๋ษࠡฬื฾๏๊ࠧ䐊") in title: title = l111lll_ll_ (u"ࠪะ๏ีࠠๅๆ่ืู้ไศฬࠣࠫ䐋")+title
					if l111lll_ll_ (u"ࠫฯืส๋สࠣัุฮࠧ䐌") in title: continue
					title = title.replace(l111lll_ll_ (u"࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳࠢࠪ䐍"),l111lll_ll_ (u"࠭ࠧ䐎"))
					if l111lll_ll_ (u"ࠧࡓࡧࡰࡳࡻ࡫ࠧ䐏") in title: continue
					if l111lll_ll_ (u"ࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪ䐐") in title: title = l111lll_ll_ (u"ࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ䐑")+title
					if l111lll_ll_ (u"ࠪࡗࡴࡸࡴࠡࡤࡼࠫ䐒") in title: continue
					l11l1ll1l1ll_ll_.append(l1l1l11ll_ll_(title))
					l11l1l1lllll_ll_.append(link)
	l111lll_ll_ (u"ࠦࠧࠨࠊࠊࡧ࡯ࡷࡪࡀࠊࠊࠋ࡫ࡸࡲࡲ࡟ࡣ࡮ࡲࡧࡰࡹࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࠧࡧ࡫࡯ࡸࡪࡸ࠭ࡥࡴࡲࡴࡩࡵࡷ࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡩࡵࡧࡰ࠱ࡸ࡫ࡣࡵ࡫ࡲࡲࠬ࠲ࡨࡵ࡯࡯࠰ࡷ࡫࠮ࡅࡑࡗࡅࡑࡒࠩࠋࠋࠌࡦࡱࡵࡣ࡬ࠢࡀࠤ࡭ࡺ࡭࡭ࡡࡥࡰࡴࡩ࡫ࡴ࡝࠳ࡡࠏࠏࠉࡪࡶࡨࡱࡸࠦ࠽ࠡࡴࡨ࠲࡫࡯࡮ࡥࡣ࡯ࡰ࠭࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡵ࡫ࡷࡰࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࠭ࡤ࡯ࡳࡨࡱࠬࡳࡧ࠱ࡈࡔ࡚ࡁࡍࡎࠬࠎࠎࠏࡦࡰࡴࠣࡰ࡮ࡴ࡫࠭ࡶ࡬ࡸࡱ࡫ࠠࡪࡰࠣ࡭ࡹ࡫࡭ࡴ࠼ࠍࠍࠎࠏࡩࡧࠢࠪࡖࡪࡳ࡯ࡷࡧࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡤࡱࡱࡸ࡮ࡴࡵࡦࠌࠌࠍࠎࡺࡩࡵ࡮ࡨࠤࡂࠦࡴࡪࡶ࡯ࡩ࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧࡔࡧࡤࡶࡨ࡮ࠠࡧࡱࡵࠫ࠱࠭ࡓࡦࡣࡵࡧ࡭ࠦࡦࡰࡴ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧࠣࡁࠥࡺࡩࡵ࡮ࡨ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࡓࡰࡴࡷࠤࡧࡿࠧ࠭ࠩࡖࡳࡷࡺࠠࡣࡻ࠽ࠤࠥ࠭ࠩࠋࠋࠌࠍ࡮࡬ࠠࠨࡒ࡯ࡥࡾࡲࡩࡴࡶࠪࠤ࡮ࡴࠠࡵ࡫ࡷࡰࡪࡀࠠࡵ࡫ࡷࡰࡪࠦ࠽ࠡࠩฯ๎ิࠦไๅ็ึุ่๊วหࠢࠪ࠯ࡹ࡯ࡴ࡭ࡧࠍࠍࠎࠏ࡬ࡪࡰ࡮ࠤࡂࠦ࡬ࡪࡰ࡮࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭࡜ࡶ࠲࠳࠶࠻࠭ࠬࠨࠨࠪ࠭ࠏࠏࠉࠊ࡫ࡩࠤ࡙ࠬࡥࡢࡴࡦ࡬ࠥ࡬࡯ࡳ࠼ࠣࠤࠬࠦࡩ࡯ࠢࡷ࡭ࡹࡲࡥ࠻ࠌࠌࠍࠎࠏࡦࡪ࡮ࡨࡸࡪࡸࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸ࡫ࡡࡳࡥ࡫࠲ࡦࡶࡰࡦࡰࡧࠬࡱ࡯࡮࡬ࠫࠍࠍࠎࠏࡩࡧࠢࠪࡗࡴࡸࡴࠡࡤࡼ࠾ࠥࠦࠧࠡ࡫ࡱࠤࡹ࡯ࡴ࡭ࡧ࠽ࠎࠎࠏࠉࠊࡨ࡬ࡰࡪࡺࡥࡳࡎࡌࡗ࡙ࡥࡳࡰࡴࡷ࠲ࡦࡶࡰࡦࡰࡧࠬࡪࡹࡣࡢࡲࡨ࡙ࡓࡏࡃࡐࡆࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠭ࠏࠏࠉࠊࠋ࡯࡭ࡳࡱࡌࡊࡕࡗࡣࡸࡵࡲࡵ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡯࡭ࡳࡱࠩࠋࠋࠥࠦࠧ䐓")
	if l1ll11_ll_:
		l11l1lll1ll1_ll_ = l1l1111_ll_(l111lll_ll_ (u"ࠬอฮหำࠣห้็ไหำࠣห้๋ๆศีห࠾ࠬ䐔"),l11l1ll1l1ll_ll_)
		if l11l1lll1ll1_ll_ == -1: return
		l11l1llll1l1_ll_ = l11l1l1lllll_ll_[l11l1lll1ll1_ll_]
		if l11l1llll1l1_ll_!=l111lll_ll_ (u"࠭ࠧ䐕"): l11ll1_ll_ = l1ll1l1_ll_+l11l1llll1l1_ll_
		elif l11ll11111ll_ll_!=l111lll_ll_ (u"ࠧࠨ䐖"): l11ll1_ll_ = l1ll111_ll_+l11ll11111ll_ll_
		else: l11ll1_ll_ = l1ll111_ll_
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"ࠨࠩ䐗"))
	else: l11ll1_ll_ = l1ll111_ll_
	l11ll1l11l_ll_(l11ll1_ll_)
	return