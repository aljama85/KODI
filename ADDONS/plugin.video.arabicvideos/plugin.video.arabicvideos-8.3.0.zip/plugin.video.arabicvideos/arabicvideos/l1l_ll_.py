# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
headers = { l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨࠀ") : l111lll_ll_ (u"ࠬ࠭ࠁ") }
l1ll_ll_=l111lll_ll_ (u"࠭ࡁࡌࡑࡄࡑࠬࠂ")
l1l1l1l_ll_=l111lll_ll_ (u"ࠧࡠࡃࡎࡓࡤ࠭ࠃ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l1l11_ll_ = [l111lll_ll_ (u"ࠨใํ่๊࠭ࠄ"),l111lll_ll_ (u"ࠩๆ่๏ฮࠧࠅ"),l111lll_ll_ (u"ࠪห้฿ัืࠢส่ฬูศ้฻ํࠫࠆ"),l111lll_ll_ (u"ู๊ࠫัฮ์ฬࠫࠇ"),l111lll_ll_ (u"๋ࠬำาฯํ๋ࠬࠈ"),l111lll_ll_ (u"࠭ว฻่ํอࠬࠉ"),l111lll_ll_ (u"ࠧศ฻็ห๋࠭ࠊ"),l111lll_ll_ (u"ࠨๆๅหฦ࠭ࠋ")]
def l111l1l_ll_(mode,url,text):
	#l1ll1l_ll_(text,str(mode))
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==70: results = l11l1ll_ll_(url)
	elif mode==71: results = CATEGORIES(url)
	elif mode==72: results = l1l11l1_ll_(url,text)
	elif mode==73: results = l111l1_ll_(url)
	elif mode==74: results = l11_ll_(url)
	elif mode==79: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠩࠪࠌ")):
	l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪࠍ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫอำหࠡใํࠤฬ๊ๅ้ไ฼ࠫࠎ"),l111lll_ll_ (u"ࠬ࠭ࠏ"),79,l111lll_ll_ (u"࠭ࠧࠐ"),l111lll_ll_ (u"ࠧࠨࠑ"),l111lll_ll_ (u"ࠨࡡࡕࡉࡒࡋࡍࡃࡇࡕࡖࡊ࡙ࡕࡍࡖࡖࡣࠬࠒ"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩࠓ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪืู้ไสࠢสๅ้อๅࠨࠔ"),l111lll_ll_ (u"ࠫࠬࠕ"),79,l111lll_ll_ (u"ࠬ࠭ࠖ"),l111lll_ll_ (u"࠭ࠧࠗ"),l111lll_ll_ (u"ࠧิๆึ่ฮࠦวโๆส้ࠬ࠘"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ࠙"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩึ่ฬูไࠡ็้์฾ฯࠧࠚ"),l111lll_ll_ (u"ࠪࠫࠛ"),79,l111lll_ll_ (u"ࠫࠬࠜ"),l111lll_ll_ (u"ࠬ࠭ࠝ"),l111lll_ll_ (u"࠭ำๅี็อࠬࠞ"))
	#l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࠟ"),l1111l_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࠬࠠ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่๊๋๊ำหࠪࠡ"),l1ll1l1_ll_,72,l111lll_ll_ (u"ࠪࠫࠢ"),l111lll_ll_ (u"ࠫࠬࠣ"),l111lll_ll_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧࠤ"))
	#l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࠥ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫࠦ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็้ื๐ฯࠨࠧ"),l1ll1l1_ll_,72,l111lll_ll_ (u"ࠩࠪࠨ"),l111lll_ll_ (u"ࠪࠫࠩ"),l111lll_ll_ (u"ࠫࡲࡵࡲࡦࠩࠪ"))
	#l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࠫ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪࠬ")+l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆฦาออัࠨ࠭"),l1ll1l1_ll_,72,l111lll_ll_ (u"ࠨࠩ࠮"),l111lll_ll_ (u"ࠩࠪ࠯"),l111lll_ll_ (u"ࠪࡲࡪࡽࡳࠨ࠰"))
	#l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ࠱"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ࠲")+l1l1l1l_ll_+l111lll_ll_ (u"࠭วๅลัฬฬืࠧ࠳"),l1ll1l1_ll_,72,l111lll_ll_ (u"ࠧࠨ࠴"),l111lll_ll_ (u"ࠨࠩ࠵"),l111lll_ll_ (u"ࠩࡱࡩࡼࡹࠧ࠶"))
	l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ࠷"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ࠸"),l111lll_ll_ (u"ࠬ࠭࠹"),9999)
	l11lll1_ll_ = [l111lll_ll_ (u"࠭วๅๅอฬࠥ๎ࠠศๆสฬาอหࠨ࠺"),l111lll_ll_ (u"ࠧศๆๆ์ึูวหࠢส่ฯ฿ไ๋็ํอࠬ࠻"),l111lll_ll_ (u"ࠨษ็ว้฿วษࠩ࠼"),l111lll_ll_ (u"ࠩส่อืวๆฮࠪ࠽"),l111lll_ll_ (u"ࠪห้อฬ่ิฬࠤฬ๊ไ้ฯํอࠬ࠾"),l111lll_ll_ (u"ࠫฬ๊ี้ำࠣ์ࠥอไฯๆไ๎ฬะࠧ࠿"),l111lll_ll_ (u"ࠬอไๆืสี฾ฯࠠศๆะีฮ࠭ࡀ")]
	html = l111ll1_ll_(l11l1l_ll_,l1ll1l1_ll_,l111lll_ll_ (u"࠭ࠧࡁ"),headers,l111lll_ll_ (u"ࠧࠨࡂ"),l111lll_ll_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡎࡇࡑ࡙࠲࠷ࡳࡵࠩࡃ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡥ࡭࡬ࡥࡰࡢࡴࡷࡷࡤࡳࡥ࡯ࡷࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠢࡴ࡫ࡧࡩࡧࡧࡲࡠࡵࡨࡥࡷࡩࡨࠨࡄ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩࡅ"),block,re.DOTALL)
		for link,title in items:
			if title not in l11lll1_ll_:
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࡆ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩࡇ")+l1l1l1l_ll_+title,link,71)
	return html
def CATEGORIES(url):
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"࠭ࠧࡈ"),headers,l111lll_ll_ (u"ࠧࠨࡉ"),l111lll_ll_ (u"ࠨࡃࡎࡓࡆࡓ࠭ࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖ࠱࠶ࡹࡴࠨࡊ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡶࡩࡨࡺ࡟ࡱࡣࡵࡸࡸ࠮࠮ࠫࡁࠬࡀ࠴ࡪࡩࡷࡀࠪࡋ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡃ࠮࠮ࠫࡁࠬࡀࠬࡌ"),block,re.DOTALL)
		for link,title in items:
			title = title.strip(l111lll_ll_ (u"ࠫࠥ࠭ࡍ"))
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬࡎ"),l1l1l1l_ll_+title,link,72)
		l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ࡏ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧอ็ํ฽ࠥอไโำ๋฽ࠬࡐ"),url,72)
	else: l1l11l1_ll_(url,l111lll_ll_ (u"ࠨࠩࡑ"))
	return
def l1l11l1_ll_(url,type):
	#l1ll1l_ll_(url,type)
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠩࠪࡒ"),headers,True,l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡗࡍ࡙ࡒࡅࡔ࠯࠴ࡷࡹ࠭ࡓ"))
	items = []
	if type==l111lll_ll_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩ࠭ࡔ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡹࡥࡤࡶ࡬ࡳࡳࡥࡴࡪࡶ࡯ࡩࠥ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟ࡵ࡫ࡷࡰࡪ࠮࠮ࠫࡁࠬࡷࡺࡨࡪࡦࡥࡷࡷ࠲ࡩࡲࡰࡷࡶࡩࡱ࠭ࡕ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭ࡨࡳࡧࡩࡁࠧ࠮࠮ࠫࡁࠬࠦࡃࡂࡤࡪࡸࠣࡧࡱࡧࡳࡴ࠿ࠥࡷࡺࡨࡪࡦࡥࡷࡣࡧࡵࡸ࠯ࠬࡂࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡀ࡭࠹࠮ࠫࡁࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠸ࡄࠧࡖ"),block,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠧࡴࡧࡤࡶࡨ࡮ࠧࡗ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡣ࡮ࡳࡦࡳ࡟ࡳࡧࡶࡹࡱࡺࠨ࠯ࠬࡂ࠭ࡁࡹࡣࡳ࡫ࡳࡸࠬࡘ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡦࡦࡩ࡫ࡨࡴࡲࡹࡳࡪ࠭ࡪ࡯ࡤ࡫ࡪࡀࠠࡶࡴ࡯ࡠ࠭࠮࠮ࠫࡁࠬࡠ࠮࠴ࠪࡀ࠾࡫࠵ࡃ࠮࠮ࠫࡁࠬࡀ࠴࡮࠱࠿࡙ࠩ"),block,re.DOTALL)
		#l1ll1l_ll_(str(len(items)),block)
	elif type==l111lll_ll_ (u"ࠪࡱࡴࡸࡥࠨ࡚"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡸ࡫ࡣࡵ࡫ࡲࡲࡤࡺࡩࡵ࡮ࡨࠤࡲࡵࡲࡦࡡࡷ࡭ࡹࡲࡥࠩ࠰࠭ࡃ࠮࡬࡯ࡰࡶࡨࡶࡤࡨ࡯ࡵࡶࡲࡱࡤࡹࡥࡳࡸ࡬ࡧࡪࡹ࡛ࠧ"),html,re.DOTALL)
	#elif type==l111lll_ll_ (u"ࠬࡴࡥࡸࡵࠪ࡜"):
	#	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡳࡦࡥࡷ࡭ࡴࡴ࡟ࡵ࡫ࡷࡰࡪࠦ࡮ࡦࡹࡶࡣࡹ࡯ࡴ࡭ࡧࠫ࠲࠯ࡅࠩ࡯ࡧࡺࡷࡤࡳ࡯ࡳࡧࡢࡧ࡭ࡵࡩࡤࡧࡶࠫ࡝"),html,re.DOTALL)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡯ࡣࡹ࡭࡬ࡧࡴࡪࡱࡱࠬ࠳࠰࠿ࠪ࠾ࡶࡧࡷ࡯ࡰࡵࠩ࡞"),html,re.DOTALL)
	if not items and l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡦ࡬ࡺࠥࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣ࡬ࡨࡧࡹࡥࡢࡰࡺ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅ࠼ࡩ࠵࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡨ࠴ࡀࠪ࡟"),block,re.DOTALL)
	for link,img,title in items:
		title = title.strip(l111lll_ll_ (u"ࠩࠣࠫࡠ"))
		title = unescapeHTML(title)
		if any(value in title for value in l1l11_ll_): l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩࡡ"),l1l1l1l_ll_+title,link,73,img)
		else: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࡢ"),l1l1l1l_ll_+title,link,73,img)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤࠫ࠲࠯ࡅࠩ࠽࠱ࡸࡰࡃ࠭ࡣ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨ࠼࠰࡮࡬ࡂࡁࡲࡩࠡࡀ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦࡤ"),block,re.DOTALL)
		for link,title in items:
			l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧࡥ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨืไัฮࠦࠧࡦ")+title,link,72,l111lll_ll_ (u"ࠩࠪࡧ"),l111lll_ll_ (u"ࠪࠫࡨ"),type)
	return
def l1lllll_ll_(url):
	html = l111ll1_ll_(l11l1l_ll_,url,l111lll_ll_ (u"ࠫࠬࡩ"),headers,True,l111lll_ll_ (u"ࠬࡇࡋࡐࡃࡐ࠱ࡘࡋࡃࡕࡋࡒࡒࡘ࠳࠲࡯ࡦࠪࡪ"))
	l1ll111_ll_ = re.findall(l111lll_ll_ (u"࠭ࠢࡩࡴࡨࡪࠧ࠲ࠢࠩ࠰࠭ࡃ࠮ࠨࠧ࡫"),html,re.DOTALL)
	l1ll111_ll_ = l1ll111_ll_[1]
	return l1ll111_ll_
def l111l1_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"ࠧࡔࡇࡆࡘࡎࡕࡎࡔࠢ࠴࠵ࠬ࡬"))
	#l11l11_ll_ = [l111lll_ll_ (u"ࠨࡼ࡬ࡴࠬ࡭"),l111lll_ll_ (u"ࠩࡵࡥࡷ࠭࡮"),l111lll_ll_ (u"ࠪࡸࡽࡺࠧ࡯"),l111lll_ll_ (u"ࠫࡵࡪࡦࠨࡰ"),l111lll_ll_ (u"ࠬ࡮ࡴ࡮ࠩࡱ"),l111lll_ll_ (u"࠭ࡴࡢࡴࠪࡲ"),l111lll_ll_ (u"ࠧࡪࡵࡲࠫࡳ"),l111lll_ll_ (u"ࠨࡪࡷࡱࡱ࠭ࡴ")]
	html = l111ll1_ll_(l111l11_ll_,url,l111lll_ll_ (u"ࠩࠪࡵ"),headers,True,l111lll_ll_ (u"ࠪࡅࡐࡕࡁࡎ࠯ࡖࡉࡈ࡚ࡉࡐࡐࡖ࠱࠶ࡹࡴࠨࡶ"))
	l1ll1ll_ll_ = re.findall(l111lll_ll_ (u"ࠫࠧ࠮ࡨࡵࡶࡳࡷ࠯ࡀ࠯࠰ࡣ࡮ࡻࡦࡳ࠮࡯ࡧࡷ࠳ࡡࡽࠫ࠯ࠬࡂ࠭ࠧ࠭ࡷ"),html,re.DOTALL)
	l111l_ll_ = re.findall(l111lll_ll_ (u"ࠬࠨࠨࡩࡶࡷࡴࡸ࠰࠺࠰࠱ࡸࡲࡩ࡫ࡲࡶࡴ࡯࠲ࡨࡵ࡭࠰࡞ࡺ࠯࠳࠰࠿ࠪࠤࠪࡸ"),html,re.DOTALL)
	if l1ll1ll_ll_ or l111l_ll_:
		if l1ll1ll_ll_: l11ll1_ll_ = l1ll1ll_ll_[0]
		elif l111l_ll_: l11ll1_ll_ = l1lllll_ll_(l111l_ll_[0])
		l11ll1_ll_ = l1111_ll_(l11ll1_ll_)
		#l1ll1l_ll_(l11ll1_ll_,l111lll_ll_ (u"࠭ࡓࡆࡅࡗࡍࡔࡔࡓࠡ࠴࠵ࠫࡹ"))
		import l1l1lll_ll_
		if l111lll_ll_ (u"ࠧ࠰ࡵࡨࡶ࡮࡫ࡳ࠰ࠩࡺ") in l11ll1_ll_ or l111lll_ll_ (u"ࠨ࠱ࡶ࡬ࡴࡽࡳ࠰ࠩࡻ") in l11ll1_ll_: l1l1lll_ll_.l1l11ll_ll_(l11ll1_ll_)
		else: l1l1lll_ll_.l11_ll_(l11ll1_ll_)
		return
	l1llll_ll_ = re.findall(l111lll_ll_ (u"่ࠩัฯ๎้ࠡษ็ๅ๏๊ๅ࠯ࠬࡂࡂ࠳࠰࠿ࠩ࡞ࡺ࠮ࡄ࠯࡜ࡘࠬࡂࡀࠬࡼ"),html,re.DOTALL)
	if l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	#l1ll1l_ll_(url,html)
	items = re.findall(l111lll_ll_ (u"ࠪࡀࡧࡸࠠ࠰ࡀ࡟ࡲࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡶࡴࡦࡴࠠࡴࡶࡼࡰࡪࡃࠢࡤࡱ࡯ࡳࡷࡀ࠮ࠫࡁࠥࡂ࠭࠴ࠪࡀࠫ࠿࠳ࡸࡶࡡ࡯ࡀࠪࡽ"),html,re.DOTALL)
	for link,title in items:
		title = unescapeHTML(title)
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫࡾ"),l1l1l1l_ll_+title,link,73)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡹࡵࡣࡡࡷ࡭ࡹࡲࡥࠣ࠰࠭ࡃࡁ࡮࠱࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿࠳࡭࠷࠾࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡱࡦ࡯࡮ࡠ࡫ࡰ࡫ࠧ࠴ࠪࡀࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡣࡧ࠱࠸࠶࠰࠮࠴࠸࠴࠭࠴ࠪࡀࠫࡤ࡯ࡴ࠳ࡦࡦࡧࡧࡦࡦࡩ࡫ࠨࡿ"),html,re.DOTALL)
	if not l1lll_ll_:
		l1ll11l_ll_(l111lll_ll_ (u"࠭ฮุลࠣาฬืฬ๋ࠩࢀ"),l111lll_ll_ (u"ࠧๅษࠣ๎ําฯࠡ็็ๅࠥ็๊ะ์๋ࠫࢁ"))
		return
	name,img,block = l1lll_ll_[0]
	name = name.strip(l111lll_ll_ (u"ࠨࠢࠪࢂ"))
	if l111lll_ll_ (u"ࠩࡶࡹࡧࡥࡥࡱࡵ࡬ࡳࡩ࡫࡟ࡵ࡫ࡷࡰࡪ࠭ࢃ") in block:
		items = re.findall(l111lll_ll_ (u"ࠪࡷࡺࡨ࡟ࡦࡲࡶ࡭ࡴࡪࡥࡠࡶ࡬ࡸࡱ࡫ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼࠰ࡪ࠵ࡂ࠳࠰࠿ࡴࡷࡥࡣ࡫࡯࡬ࡦࡡࡷ࡭ࡹࡲࡥ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ࠫࢄ"),block,re.DOTALL)
	else:
		filenames = re.findall(l111lll_ll_ (u"ࠫࡸࡻࡢࡠࡨ࡬ࡰࡪࡥࡴࡪࡶ࡯ࡩࡡ࠭࠾ࠩ࠰࠭ࡃ࠮ࠦ࠭ࠡ࠾࡬ࡂࠬࢅ"),block,re.DOTALL)
		items = []
		for filename in filenames:
			items.append( (l111lll_ll_ (u"ࠬืวษูࠣห้ะิ฻์็ࠫࢆ"),filename) )
	if not items: items = [ (l111lll_ll_ (u"࠭ัศสฺࠤฬ๊สี฼ํ่ࠬࢇ"),l111lll_ll_ (u"ࠧࠨ࢈")) ]
	count = 0
	l1111ll_ll_,l11l111_ll_ = [],[]
	size = len(items)
	for title,filename in items:
		filetype = l111lll_ll_ (u"ࠨࠩࢉ")
		if l111lll_ll_ (u"ࠩࠣ࠱ࠥ࠭ࢊ") in filename: filename = filename.split(l111lll_ll_ (u"ࠪࠤ࠲ࠦࠧࢋ"))[0]
		else: filename = l111lll_ll_ (u"ࠫࡩࡻ࡭࡮ࡻ࠱ࡾ࡮ࡶࠧࢌ")
		if l111lll_ll_ (u"ࠬ࠴ࠧࢍ") in filename: filetype = filename.split(l111lll_ll_ (u"࠭࠮ࠨࢎ"))[-1]
		#if any(value in filetype for value in l11l11_ll_):
		#	if l111lll_ll_ (u"ࠧาษห฻ࠥอไหึ฽๎้࠭࢏") not in title: title = title + l111lll_ll_ (u"ࠨ࠼ࠪ࢐")
		title = title.replace(l111lll_ll_ (u"ࠩ࡟ࡲࠬ࢑"),l111lll_ll_ (u"ࠪࠫ࢒")).strip(l111lll_ll_ (u"ࠫࠥ࠭࢓"))
		l1111ll_ll_.append(title)
		l11l111_ll_.append(count)
		count += 1
	#l1ll1l_ll_(str(size),str(l11l111_ll_))
	if size>0:
		if any(value in name for value in l1l11_ll_):
			if size==1:
				selection = 0
			else:
				#l1l1111_ll_(l111lll_ll_ (u"ࠬ࠭࢔"),l1111ll_ll_)
				selection = l1l1111_ll_(l111lll_ll_ (u"࠭วฯฬิࠤฬ๊แ๋ัํ์ࠥอไๆ่สือࡀࠧ࢕"), l1111ll_ll_)
				if selection == -1: return
			l11_ll_(url+l111lll_ll_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪ࢖")+str(1+l11l111_ll_[size-selection-1]))
		else:
			for i in reversed(range(size)):
				#if l111lll_ll_ (u"ࠨ࠼ࠪࢗ") in l1111ll_ll_[i]: title = l1111ll_ll_[i].strip(l111lll_ll_ (u"ࠩ࠽ࠫ࢘")) + l111lll_ll_ (u"ࠪࠤ࠲ࠦๅๅใࠣห้็๊ะ์๋ࠤ฿๐ัࠡ็๋ะํี࢙ࠧ")
				#else: title = name + l111lll_ll_ (u"ࠫࠥ࠳ࠠࠨ࢚") + l1111ll_ll_[i]
				title = name + l111lll_ll_ (u"࢛ࠬࠦ࠭ࠡࠩ") + l1111ll_ll_[i]
				link = url + l111lll_ll_ (u"࠭࠿ࡴࡧࡦࡸ࡮ࡵ࡮࠾ࠩ࢜")+str(size-i)
				l111_ll_(l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭࢝"),l1l1l1l_ll_+title,link,74,img)
	else:
		l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧ࢞"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่ึอศุࠢ็๎ุࠦแ๋ัํ์ࠬ࢟"),l111lll_ll_ (u"ࠪࠫࢠ"),9999,img)
		#l1ll11l_ll_(l111lll_ll_ (u"ࠫำ฽รࠡะสีั๐ࠧࢡ"),l111lll_ll_ (u"ࠬอไาษห฻๊๊ࠥิࠢไ๎ิ๐่ࠨࢢ"))
	return
def l11_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"࠭ࠧࢣ"))
	l1ll111_ll_,episode = url.split(l111lll_ll_ (u"ࠧࡀࡵࡨࡧࡹ࡯࡯࡯࠿ࠪࢤ"))
	html = l111ll1_ll_(l111l11_ll_,l1ll111_ll_,l111lll_ll_ (u"ࠨࠩࢥ"),headers,True,l111lll_ll_ (u"ࠩࡄࡏࡔࡇࡍ࠮ࡒࡏࡅ࡞ࡥࡁࡌࡑࡄࡑ࠲࠷ࡳࡵࠩࢦ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡥࡩ࠳࠳࠱࠲࠰࠶࠺࠶࠮ࠫࡁࡤࡨ࠲࠹࠰࠱࠯࠵࠹࠵࠮࠮ࠫࡁࠬࡥࡰࡵ࠭ࡧࡧࡨࡨࡧࡧࡣ࡬ࠩࢧ"),html,re.DOTALL)
	l1l111_ll_ = l1lll_ll_[0].replace(l111lll_ll_ (u"ࠫࡡ࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠨࢨ"),l111lll_ll_ (u"ࠬࠨࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠡࡧࡳࡷࡴ࡯ࡤࡦࡡࡥࡳࡽ࠭ࢩ"))
	l1l111_ll_ = l1l111_ll_ + l111lll_ll_ (u"࠭ࡤࡪࡴࡨࡧࡹࡥ࡬ࡪࡰ࡮ࡣࡧࡵࡸࠨࢪ")
	l1lll1l_ll_ = re.findall(l111lll_ll_ (u"ࠧࡦࡲࡶࡳ࡮ࡪࡥࡠࡤࡲࡼ࠭࠴ࠪࡀࠫࡧ࡭ࡷ࡫ࡣࡵࡡ࡯࡭ࡳࡱ࡟ࡣࡱࡻࠫࢫ"),l1l111_ll_,re.DOTALL)
	episode = len(l1lll1l_ll_)-int(episode)
	block = l1lll1l_ll_[episode]
	l1l111l_ll_ = []
	l11ll1l_ll_ = {l111lll_ll_ (u"ࠨ࠳࠷࠶࠸࠶࠷࠶࠺࠹࠶ࠬࢬ"):l111lll_ll_ (u"ࠩࡧࡥ࡮ࡲࡹ࡮ࡱࡷ࡭ࡴࡴࠧࢭ"),l111lll_ll_ (u"ࠪ࠵࠹࠽࠷࠵࠺࠺࠺࠵࠷ࠧࢮ"):l111lll_ll_ (u"ࠫࡪࡹࡴࡳࡧࡤࡱࠬࢯ"),l111lll_ll_ (u"ࠬ࠷࠵࠱࠷࠶࠶࠽࠺࠰࠵ࠩࢰ"):l111lll_ll_ (u"࠭ࡳࡵࡴࡨࡥࡲࡧ࡮ࡨࡱࠪࢱ"),
		l111lll_ll_ (u"ࠧ࠲࠶࠵࠷࠵࠾࠰࠱࠳࠸ࠫࢲ"):l111lll_ll_ (u"ࠨࡨ࡯ࡥࡸ࡮ࡸࠨࢳ"),l111lll_ll_ (u"ࠩ࠴࠸࠺࠾࠱࠲࠹࠵࠽࠺࠭ࢴ"):l111lll_ll_ (u"ࠪࡳࡵ࡫࡮࡭ࡱࡤࡨࠬࢵ"),l111lll_ll_ (u"ࠫ࠶࠺࠲࠴࠲࠺࠽࠸࠶࠶ࠨࢶ"):l111lll_ll_ (u"ࠬࡼࡩ࡮ࡲ࡯ࡩࠬࢷ"),l111lll_ll_ (u"࠭࠱࠵࠵࠳࠴࠺࠸࠳࠸࠳ࠪࢸ"):l111lll_ll_ (u"ࠧࡰ࡭࠱ࡶࡺ࠭ࢹ"),
		l111lll_ll_ (u"ࠨ࠳࠷࠻࠼࠺࠸࠹࠴࠴࠷ࠬࢺ"):l111lll_ll_ (u"ࠩࡷ࡬ࡪࡼࡩࡥࠩࢻ"),l111lll_ll_ (u"ࠪ࠵࠺࠻࠸࠳࠹࠻࠴࠵࠼ࠧࢼ"):l111lll_ll_ (u"ࠫࡺࡷ࡬ࡰࡣࡧࠫࢽ"),l111lll_ll_ (u"ࠬ࠷࠴࠸࠹࠷࠼࠼࠿࠹࠱ࠩࢾ"):l111lll_ll_ (u"࠭ࡶࡪࡦࡷࡳࡩࡵࠧࢿ")}
	items = re.findall(l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥࡡࡥࡸࡳࡢࠧࠡࡶࡤࡶ࡬࡫ࡴ࠾࡞ࠪࡣࡧࡲࡡ࡯࡭࡟ࠫࠥ࡮ࡲࡦࡨࡀࡠࠬ࠮࠮ࠫࡁࠬࡠࠬ࠭ࣀ"),block,re.DOTALL)
	for link in items:
		l1l111l_ll_.append(link+l111lll_ll_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨࣁ"))
	items = re.findall(l111lll_ll_ (u"ࠩࡥࡥࡨࡱࡧࡳࡱࡸࡲࡩ࠳ࡩ࡮ࡣࡪࡩ࠿ࠦࡵࡳ࡮࡟ࠬ࠭࠴ࠪࡀࠫ࡟࠭࠳࠰࠿ࡩࡴࡨࡪࡂࡢࠧࠩ࠰࠭ࡃ࠮ࡢࠧࠨࣂ"),block,re.DOTALL)
	for l111ll_ll_,link in items:
		l111ll_ll_ = l111ll_ll_.split(l111lll_ll_ (u"ࠪ࠳ࠬࣃ"))[-1]
		l111ll_ll_ = l111ll_ll_.split(l111lll_ll_ (u"ࠫ࠳࠭ࣄ"))[0]
		if l111ll_ll_ in l11ll1l_ll_:
			l1l111l_ll_.append(link+l111lll_ll_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭ࣅ")+l11ll1l_ll_[l111ll_ll_]+l111lll_ll_ (u"࠭࡟ࡠࡡࡢࡣࡤࡥ࡟ࡢ࡭ࡲࡥࡲ࠭ࣆ"))
		else: l1l111l_ll_.append(link+l111lll_ll_ (u"ࠧࡀࡰࡤࡱࡪࡪ࠽ࠨࣇ")+l111ll_ll_+l111lll_ll_ (u"ࠨࡡࡢࡣࡤࡥ࡟ࡠࡡࡤ࡯ࡴࡧ࡭ࠨࣈ"))
	#l1l1111_ll_(l111lll_ll_ (u"ࠩࡓࡐࡆ࡟ࠠࡂࡍࡒࡅࡒ࠭ࣉ"),l1l111l_ll_)
	#return
	if len(l1l111l_ll_)==0:
		message = re.findall(l111lll_ll_ (u"ࠪࡷࡺࡨ࠭࡯ࡱ࠰ࡪ࡮ࡲࡥ࠯ࠬࡂࡠࡳ࠮࠮ࠫࡁࠬࡠࡳ࠭࣊"),block,re.DOTALL)
		if message: l1ll1l_ll_(l111lll_ll_ (u"ࠫึูวๅห้๋ࠣࠦวๅ็๋ๆ฾ࠦวๅษุ่๏࠭࣋"),message[0])
		else: l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ࣌"),l111lll_ll_ (u"࠭ไศࠢํ์ัีࠠๆๆไࠤๆ๐ฯ๋๊ࠪ࣍"))
	else:
		#l1l1111_ll_(l111lll_ll_ (u"ࠧࠨ࣎"),l1l111l_ll_)
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵ࣏ࠧ"))
	return
def l1lll1_ll_(search):
	#l1ll1l_ll_(search,l111lll_ll_ (u"࣐ࠩࠪ"))
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"࣑ࠪࠫ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"࣒ࠫࠬ"): return
	l1llll1_ll_ = search.replace(l111lll_ll_ (u"࣓ࠬࠦࠧ"),l111lll_ll_ (u"࠭ࠥ࠳࠲ࠪࣔ"))
	#l1ll1l_ll_(str(len(search)) , str(len(l1llll1_ll_)) )
	url = l1ll1l1_ll_ + l111lll_ll_ (u"ࠧ࠰ࡵࡨࡥࡷࡩࡨ࠰ࠩࣕ")+l1llll1_ll_
	results = l1l11l1_ll_(url,l111lll_ll_ (u"ࠨࡵࡨࡥࡷࡩࡨࠨࣖ"))
	return