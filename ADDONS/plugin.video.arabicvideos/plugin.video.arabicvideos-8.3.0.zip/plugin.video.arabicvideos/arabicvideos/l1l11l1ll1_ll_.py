# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"࠭ࡆࡂࡌࡈࡖࡘࡎࡏࡘࠩ᠁")
l1l1l1l_ll_=l111lll_ll_ (u"ࠧࡠࡈࡍࡗࡤ࠭᠂")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ࠨษ็ฮฺ์๊โษอࠫ᠃"),l111lll_ll_ (u"ࠩสู๊อมࠡฯึหอ࠭᠄"),l111lll_ll_ (u"ࠪ฻้ฮวหࠢส่ื๎๑ศำࠪ᠅")]
#headers = {l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ᠆"):l111lll_ll_ (u"ࠬ࠭᠇")}
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==390: results = l11l1ll_ll_(url)
	elif mode==391: results = l1l11l1_ll_(url,text)
	elif mode==392: results = l11_ll_(url)
	elif mode==393: results = l1l11ll_ll_(url)
	elif mode==399: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"࠭ࠧ᠈")):
	if l1111l_ll_==l111lll_ll_ (u"ࠧࠨ᠉"):
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠊"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩหัะࠦแ๋ࠢส่๊๎โฺࠩ᠋"),l111lll_ll_ (u"ࠪࠫ᠌"),399,l111lll_ll_ (u"ࠫࠬ᠍"),l111lll_ll_ (u"ࠬ࠭᠎"),l111lll_ll_ (u"࠭࡟ࡓࡇࡐࡉࡒࡈࡅࡓࡔࡈࡗ࡚ࡒࡔࡔࡡࠪ᠏"))
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬ᠐"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫ᠑"),l111lll_ll_ (u"ࠩࠪ᠒"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ᠓"),l1ll1l1_ll_,l111lll_ll_ (u"ࠫࠬ᠔"),l111lll_ll_ (u"ࠬ࠭᠕"),l111lll_ll_ (u"࠭ࠧ᠖"),l111lll_ll_ (u"ࠧࠨ᠗"),l111lll_ll_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭᠘"))
	html = response.content
	items = re.findall(l111lll_ll_ (u"ࠩ࠿࡬ࡪࡧࡤࡦࡴࡁ࠲࠯ࡅ࠼ࡩ࠴ࡁࠬ࠳࠰࠿ࠪ࠾ࠪ᠙"),html,re.DOTALL)
	for seq in range(len(items)):
		title = items[seq]
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ᠚"),l1111l_ll_+l111lll_ll_ (u"ࠫࡤࡥ࡟ࠨ᠛")+l1l1l1l_ll_+title,l1ll1l1_ll_,391,l111lll_ll_ (u"ࠬ࠭᠜"),l111lll_ll_ (u"࠭ࠧ᠝"),l111lll_ll_ (u"ࠧ࡭ࡣࡷࡩࡸࡺࠧ᠞")+str(seq))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ᠟"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่๊๋๊ำหࠪᠠ"),l1ll1l1_ll_,391,l111lll_ll_ (u"ࠪࠫᠡ"),l111lll_ll_ (u"ࠫࠬᠢ"),l111lll_ll_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧᠣ"))
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᠤ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧฤ฻็ํࠥอไฤใ็ห๊ࠦสใ์ํ้ฬ๑ࠧᠥ"),l1ll1l1_ll_,391,l111lll_ll_ (u"ࠨࠩᠦ"),l111lll_ll_ (u"ࠩࠪᠧ"),l111lll_ll_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬᠨ"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᠩ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬษูๅ๋ࠣห้๋ำๅี็หฯࠦสใ์ํ้ฬ๑ࠧᠪ"),l1ll1l1_ll_,391,l111lll_ll_ (u"࠭ࠧᠫ"),l111lll_ll_ (u"ࠧࠨᠬ"),l111lll_ll_ (u"ࠨࡶࡲࡴࡤ࡯࡭ࡥࡤࡢࡷࡪࡸࡩࡦࡵࠪᠭ"))
	l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᠮ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪวๆ๊วๆ่้ࠢ๏ุษࠨᠯ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡳ࡯ࡷ࡫ࡨࡷࠬᠰ"),391,l111lll_ll_ (u"ࠬ࠭ᠱ"),l111lll_ll_ (u"࠭ࠧᠲ"),l111lll_ll_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥࡡࡰࡳࡻ࡯ࡥࡴࠩᠳ"))
	l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᠴ"),l1l1l1l_ll_+l111lll_ll_ (u"่ࠩืู้ไศฬ้๊ࠣ๐าสࠩᠵ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡹࡼࡳࡩࡱࡺࡷࠬᠶ"),391,l111lll_ll_ (u"ࠫࠬᠷ"),l111lll_ll_ (u"ࠬ࠭ᠸ"),l111lll_ll_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡶࡹࡷ࡭ࡵࡷࡴࠩᠹ"))
	block = l111lll_ll_ (u"ࠧࠨᠺ")
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣ࡯ࡨࡲࡺࠨࠨ࠯ࠬࡂ࠭࡮ࡪ࠽ࠣࡥࡲࡲࡹ࡫࡮ࡦࡦࡲࡶࠧ࠭ᠻ"),html,re.DOTALL)
	if l1lll_ll_: block += l1lll_ll_[0]
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭ᠼ"),l1ll1l1_ll_+l111lll_ll_ (u"ࠪ࠳ࡲࡵࡶࡪࡧࡶࠫᠽ"),l111lll_ll_ (u"ࠫࠬᠾ"),l111lll_ll_ (u"ࠬ࠭ᠿ"),l111lll_ll_ (u"࠭ࠧᡀ"),l111lll_ll_ (u"ࠧࠨᡁ"),l111lll_ll_ (u"ࠨࡈࡄࡎࡊࡘࡓࡉࡑ࡚࠱ࡒࡋࡎࡖ࠯࠵ࡲࡩ࠭ᡂ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡵࡩࡱ࡫ࡡࡴࡧࡶࠦ࠭࠴ࠪࡀࠫࡤࡷ࡮ࡪࡥࠨᡃ"),html,re.DOTALL)
	if l1lll_ll_: block += l1lll_ll_[0]
	if l1111l_ll_==l111lll_ll_ (u"ࠪࠫᡄ"): l111_ll_(l111lll_ll_ (u"ࠫࡱ࡯࡮࡬ࠩᡅ"),l111lll_ll_ (u"ࠬࡡࡃࡐࡎࡒࡖࠥࡌࡆࡄ࠺࠼࠴࠵࠾࡝࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࡛࠰ࡅࡒࡐࡔࡘ࡝ࠨᡆ"),l111lll_ll_ (u"࠭ࠧᡇ"),9999)
	items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᡈ"),block,re.DOTALL)
	first = True
	for link,title in items:
		title = unescapeHTML(title)
		if title==l111lll_ll_ (u"ࠨษ็ว฾๊้ࠡ็ืห์ีษࠨᡉ"):
			if first:
				title = l111lll_ll_ (u"ࠩส่ฬ็ไศ็ࠣࠫᡊ")+title
				first = False
			else: title = l111lll_ll_ (u"ࠪห้๋ำๅี็หฯࠦࠧᡋ")+title
		if title not in l11lll1_ll_:
			if title==l111lll_ll_ (u"ࠫศ็ไศ็ࠪᡌ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡍ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪᡎ")+l1l1l1l_ll_+title,l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰࡯ࡲࡺ࡮࡫ࡳࠨᡏ"),391,l111lll_ll_ (u"ࠨࠩᡐ"),l111lll_ll_ (u"ࠩࠪᡑ"),l111lll_ll_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨᡒ"))
			elif title==l111lll_ll_ (u"ู๊ࠫไิๆสฮࠬᡓ"): l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬᡔ"),l1111l_ll_+l111lll_ll_ (u"࠭࡟ࡠࡡࠪᡕ")+l1l1l1l_ll_+title,l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰ࡶࡹࡷ࡭ࡵࡷࡴࠩᡖ"),391,l111lll_ll_ (u"ࠨࠩᡗ"),l111lll_ll_ (u"ࠩࠪᡘ"),l111lll_ll_ (u"ࠪࡥࡱࡲ࡟࡮ࡱࡹ࡭ࡪࡹ࡟ࡵࡸࡶ࡬ࡴࡽࡳࠨᡙ"))
			else: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᡚ"),l1111l_ll_+l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩᡛ")+l1l1l1l_ll_+title,link,391)
	return html
def l1l11l1_ll_(url,type):
	#l1ll1l_ll_(url,type)
	#l1l1l1111_ll_(html)
	block,items = [],[]
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪᡜ"),url,l111lll_ll_ (u"ࠧࠨᡝ"),l111lll_ll_ (u"ࠨࠩᡞ"),l111lll_ll_ (u"ࠩࠪᡟ"),l111lll_ll_ (u"ࠪࠫᡠ"),l111lll_ll_ (u"ࠫࡋࡇࡊࡆࡔࡖࡌࡔ࡝࠭ࡕࡋࡗࡐࡊ࡙࠭࠲ࡵࡷࠫᡡ"))
	html = response.content
	if type in [l111lll_ll_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪ࡟࡮ࡱࡹ࡭ࡪࡹࠧᡢ"),l111lll_ll_ (u"࠭ࡦࡦࡣࡷࡹࡷ࡫ࡤࡠࡶࡹࡷ࡭ࡵࡷࡴࠩᡣ")]:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡩࡥ࠿ࠥࡥࡷࡩࡨࡪࡸࡨ࠱ࡨࡵ࡮ࡵࡧࡱࡸࠧ࠭ᡤ"),html,re.DOTALL)
		if l1lll_ll_: block = l1lll_ll_[0]
		#l1ll1l_ll_(url,block)
	elif type==l111lll_ll_ (u"ࠨࡣ࡯ࡰࡤࡳ࡯ࡷ࡫ࡨࡷࡤࡺࡶࡴࡪࡲࡻࡸ࠭ᡥ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨࡡࡳࡥ࡫࡭ࡻ࡫࠭ࡤࡱࡱࡸࡪࡴࡴࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡰࡢࡩ࡬ࡲࡦࡺࡩࡰࡰࠥࠫᡦ"),html,re.DOTALL)
		if l1lll_ll_: block = l1lll_ll_[0]
	elif type==l111lll_ll_ (u"ࠪࡸࡴࡶ࡟ࡪ࡯ࡧࡦࡤࡳ࡯ࡷ࡫ࡨࡷࠬᡧ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠦࡨࡲࡡࡴࡵࡀࠫࡹࡵࡰ࠮࡫ࡰࡨࡧ࠳࡬ࡪࡵࡷࠤࡹࡲࡥࡧࡶࠫ࠲࠯ࡅࠩࡤ࡮ࡤࡷࡸࡃࠧࡵࡱࡳ࠱࡮ࡳࡤࡣ࠯࡯࡭ࡸࡺࠠࡵࡴ࡬࡫࡭ࡺࠢᡨ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			#l1ll1l_ll_(str(len(block)),type)
			items = re.findall(l111lll_ll_ (u"ࠧ࡯࡭ࡨࠢࡶࡶࡨࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁ࡫ࡶࡪ࡬࠽ࠨࠪ࠱࠮ࡄ࠯ࠧ࠿ࠪ࠱࠮ࡄ࠯࠼ࠣᡩ"),block,re.DOTALL)
	elif type==l111lll_ll_ (u"࠭ࡴࡰࡲࡢ࡭ࡲࡪࡢࡠࡵࡨࡶ࡮࡫ࡳࠨᡪ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠢࡤ࡮ࡤࡷࡸࡃࠧࡵࡱࡳ࠱࡮ࡳࡤࡣ࠯࡯࡭ࡸࡺࠠࡵࡴ࡬࡫࡭ࡺࠨ࠯ࠬࡂ࠭࡫ࡵ࡯ࡵࡧࡵࠦᡫ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			#l1ll1l_ll_(str(len(block)),type)
			items = re.findall(l111lll_ll_ (u"ࠣ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠪࠬ࠳࠰࠿ࠪࠩ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠫ࠭࠴ࠪࡀࠫࠪࡂ࠭࠴ࠪࡀࠫ࠿ࠦᡬ"),block,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠩࡶࡩࡦࡸࡣࡩࠩᡭ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡷࡪࡧࡲࡤࡪ࠰ࡴࡦ࡭ࡥࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡳࡪࡦࡨࡦࡦࡸࠧᡮ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			items = re.findall(l111lll_ll_ (u"ࠫ࡮ࡳࡧࠡࡵࡵࡧࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᡯ"),block,re.DOTALL)
	elif type==l111lll_ll_ (u"ࠬࡹࡩࡥࡧࡵࠫᡰ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡷࡪࡦࡪࡩࡹ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࡻ࡮ࡪࡧࡦࡶࠪᡱ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		z = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡂࡨ࠴ࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡲ"),block,re.DOTALL)
		l1l111l_ll_,l1l11ll11_ll_,l1111ll_ll_ = zip(*z)
		items = zip(l1l11ll11_ll_,l1l111l_ll_,l1111ll_ll_)
	elif type==l111lll_ll_ (u"ࠨࡨࡨࡥࡹࡻࡲࡦࡦࠪᡳ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࡬ࡨࡂࠨࡳ࡭࡫ࡧࡩࡷ࠳࡭ࡰࡸ࡬ࡩࡸ࠳ࡴࡷࡵ࡫ࡳࡼࡹࠢࠩ࠰࠭ࡃ࠮ࡂࡨࡦࡣࡧࡩࡷࡄࠧᡴ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀࠤࡷ࡭ࡹࡲࡥࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩᡵ"),block,re.DOTALL)
	elif l111lll_ll_ (u"ࠫࡱࡧࡴࡦࡵࡷࠫᡶ") in type:
		seq = int(type[-1:])
		html = html.replace(l111lll_ll_ (u"ࠬࡂࡨࡦࡣࡧࡩࡷࡄࠧᡷ"),l111lll_ll_ (u"࠭࠼ࡦࡰࡧࡂࡁࡹࡴࡢࡴࡷࡂࠬᡸ"))
		html = html.replace(l111lll_ll_ (u"ࠧ࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃࡂ࠯ࡥ࡫ࡹࡂࠬ᡹"),l111lll_ll_ (u"ࠨ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄ࠼࠰ࡦ࡬ࡺࡃࡂࡥ࡯ࡦࡁࠫ᡺"))
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠩ࠿ࡷࡹࡧࡲࡵࡀࠫ࠲࠯ࡅࠩ࠽ࡧࡱࡨࡃ࠭᡻"),html,re.DOTALL)
		block = l1lll_ll_[seq]
		if seq==6:
			z = re.findall(l111lll_ll_ (u"ࠪ࡭ࡲ࡭ࠠࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠥࡧ࡬ࡵ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥࠫ᡼"),block,re.DOTALL)
			l1l11ll11_ll_,l1111ll_ll_,l1l111l_ll_ = zip(*z)
			items = zip(l1l11ll11_ll_,l1l111l_ll_,l1111ll_ll_)
	else:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡨࡵ࡮ࡵࡧࡱࡸࠧ࠮࠮ࠫࡁࠬࡧࡱࡧࡳࡴ࠿ࠥࠬࡵࡧࡧࡪࡰࡤࡸ࡮ࡵ࡮ࡽࡵ࡬ࡨࡪࡨࡡࡳࠫࠪ᡽"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0][0]
			if l111lll_ll_ (u"ࠬ࠵ࡣࡰ࡮࡯ࡩࡨࡺࡩࡰࡰ࠲ࠫ᡾") in url:
				items = re.findall(l111lll_ll_ (u"࠭ࡩ࡮ࡩࠣࡷࡷࡩ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣࡀࠫ࠲࠯ࡅࠩ࠽ࠩ᡿"),block,re.DOTALL)
			elif l111lll_ll_ (u"ࠧ࠰ࡳࡸࡥࡱ࡯ࡴࡺ࠱ࠪᢀ") in url:
				items = re.findall(l111lll_ll_ (u"ࠨ࡫ࡰ࡫ࠥࡹࡲࡤ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࡮ࡲࡦࡨࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࠢࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᢁ"),block,re.DOTALL)
	#l1ll1l_ll_(str(len(items)),type)
	if not items and block:
		items = re.findall(l111lll_ll_ (u"ࠩ࡬ࡱ࡬ࠦࡳࡳࡥࡀࠦ࠭࠴ࠪࡀࠫࠥ࠲࠯ࡅࡨࡳࡧࡩࡁ࠳࠰࠿ࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡤࡪࡸࡁࠫᢂ"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for img,link,title in items:
		if l111lll_ll_ (u"ࠪࡷࡪࡸࡩࡦࠩᢃ") in title:
			title = re.findall(l111lll_ll_ (u"ࠫࡣ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡧࡵ࡭ࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᢄ"),title,re.DOTALL)
			title = title[0][1]#+l111lll_ll_ (u"ࠬࠦ࠭ࠡࠩᢅ")+title[0][0]
			if title in l1ll11ll_ll_: continue
			l1ll11ll_ll_.append(title)
			title = l111lll_ll_ (u"࠭࡟ࡎࡑࡇࡣࠬᢆ")+title
		l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠧ࡟ࠪ࠱࠮ࡄ࠯࠼ࠨᢇ"),title,re.DOTALL)
		if l11ll111_ll_: title = l11ll111_ll_[0]
		title = unescapeHTML(title)
		if l111lll_ll_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࠫᢈ") in link: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᢉ"),l1l1l1l_ll_+title,link,393,img)
		elif l111lll_ll_ (u"ࠪ࠳ࡪࡶࡩࡴࡱࡧࡩࡸ࠵ࠧᢊ") in link: l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫᢋ"),l1l1l1l_ll_+title,link,393,img)
		elif l111lll_ll_ (u"ࠬ࠵ࡳࡦࡣࡶࡳࡳࡹ࠯ࠨᢌ") in link: l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ᢍ"),l1l1l1l_ll_+title,link,393,img)
		elif l111lll_ll_ (u"ࠧ࠰ࡥࡲࡰࡱ࡫ࡣࡵ࡫ࡲࡲ࠴࠭ᢎ") in link: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢏ"),l1l1l1l_ll_+title,link,391,img)
		else: l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨᢐ"),l1l1l1l_ll_+title,link,392,img)
	if type not in [l111lll_ll_ (u"ࠪࡪࡪࡧࡴࡶࡴࡨࡨࡤࡳ࡯ࡷ࡫ࡨࡷࠬᢑ"),l111lll_ll_ (u"ࠫ࡫࡫ࡡࡵࡷࡵࡩࡩࡥࡴࡷࡵ࡫ࡳࡼࡹࠧᢒ")]:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡶࡡࡨ࡫ࡱࡥࡹ࡯࡯࡯ࠤ࠱࠮ࡄ฻แฮหࠣࠬ࠳࠰࠿่๊ࠪࠢࠥ࠮࠮ࠫࡁࠬࡀ࠭࠴ࠪࡀࠫ࠿࠳ࡩ࡯ࡶ࠿ࠩᢓ"),html,re.DOTALL)
		if l1lll_ll_:
			current = l1lll_ll_[0][0]
			last = l1lll_ll_[0][1]
			block = l1lll_ll_[0][2]
			items = re.findall(l111lll_ll_ (u"ࠨࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿࠿ࠪ࠱࠮ࡄ࠯࠼ࠣᢔ"),block,re.DOTALL)
			for link,title in items:
				if title==l111lll_ll_ (u"ࠧࠨᢕ") or title==last: continue
				l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨᢖ"),l1l1l1l_ll_+l111lll_ll_ (u"ุࠩๅาฯࠠࠨᢗ")+title,link,391,l111lll_ll_ (u"ࠪࠫᢘ"),l111lll_ll_ (u"ࠫࠬᢙ"),type)
			#if title==last:
			link = link.replace(l111lll_ll_ (u"ࠬ࠵ࡰࡢࡩࡨ࠳ࠬᢚ")+title+l111lll_ll_ (u"࠭࠯ࠨᢛ"),l111lll_ll_ (u"ࠧ࠰ࡲࡤ࡫ࡪ࠵ࠧᢜ")+last+l111lll_ll_ (u"ࠨ࠱ࠪᢝ"))
			l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩᢞ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪหำืࠠึใะอࠥ࠭ᢟ")+last,link,391,l111lll_ll_ (u"ࠫࠬᢠ"),l111lll_ll_ (u"ࠬ࠭ᢡ"),type)
	return
def l1l11ll_ll_(url):
	#l1ll1l_ll_(url,l111lll_ll_ (u"࠭ࠧᢢ"))
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫᢣ"),url,l111lll_ll_ (u"ࠨࠩᢤ"),l111lll_ll_ (u"ࠩࠪᢥ"),l111lll_ll_ (u"ࠪࠫᢦ"),l111lll_ll_ (u"ࠫࠬᢧ"),l111lll_ll_ (u"ࠬࡌࡁࡋࡇࡕࡗࡍࡕࡗ࠮ࡇࡓࡍࡘࡕࡄࡆࡕ࠰࠵ࡸࡺࠧᢨ"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡃࠡࡴࡤࡸࡪࡪࠢ࠯ࠬࡂࡂ࠭࠴ࠪࡀࠫ࠿ᢩࠫ"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	if l111lll_ll_ (u"ࠧ࠰ࡧࡳ࡭ࡸࡵࡤࡦࡵ࠲ࠫᢪ") in url or l111lll_ll_ (u"ࠨ࠱ࡷࡺࡸ࡮࡯ࡸࡵ࠲ࠫ᢫") in url:# or l111lll_ll_ (u"ࠩ࠲ࡷࡪࡧࡳࡰࡰࡶ࠳ࠬ᢬") in url:
		l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࠫࠬࡩ࡬ࡢࡵࡶࡁࠬ࡯ࡴࡦ࡯ࠪࡂࡁࡧࠠࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭ࠧࠨ᢭"),html,re.DOTALL)
		if l1ll111_ll_:
			l1ll111_ll_ = l1ll111_ll_[1]
			l1l11ll_ll_(l1ll111_ll_)
			return
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠫࠬ࠭ࡣ࡭ࡣࡶࡷࡂࡡࠧࠣ࡟ࡨࡴ࡮ࡹ࡯ࡥ࡫ࡲࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧࠨࠩ᢮"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠬ࠭ࠧࡴࡴࡦࡁࠬ࠮࠮ࠫࡁࠬࠫ࠳࠰࠿ࡤ࡮ࡤࡷࡸࡃࠧ࡯ࡷࡰࡩࡷࡧ࡮ࡥࡱࠪࡂ࠭࠴ࠪࡀࠫ࠿࠲࠯ࡅࡨࡳࡧࡩࡁࠬ࠮࠮ࠫࡁࠬࠫࡃ࠮࠮ࠫࡁࠬࡀࠬ࠭ࠧ᢯"),block,re.DOTALL)
		for img,episode,link,name in items:
			title = episode+l111lll_ll_ (u"࠭ࠠ࠻ࠢࠪᢰ")+name+l111lll_ll_ (u"ࠧࠡษ็ั้่ษࠨᢱ")
			l111_ll_(l111lll_ll_ (u"ࠨࡸ࡬ࡨࡪࡵࠧᢲ"),l1l1l1l_ll_+title,link,392)
	return
def l11_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠩࡊࡉ࡙࠭ᢳ"),url,l111lll_ll_ (u"ࠪࠫᢴ"),l111lll_ll_ (u"ࠫࠬᢵ"),l111lll_ll_ (u"ࠬ࠭ᢶ"),l111lll_ll_ (u"࠭ࠧᢷ"),l111lll_ll_ (u"ࠧࡇࡃࡍࡉࡗ࡙ࡈࡐ࡙࠰ࡔࡑࡇ࡙࠮࠳ࡶࡸࠬᢸ"))
	html = response.content
	l1llll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡅࠣࡶࡦࡺࡥࡥࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ᢹ"),html,re.DOTALL)
	if l1llll_ll_ and l1l1ll_ll_(l1ll_ll_,url,l1llll_ll_): return
	l1l111l_ll_ = []
	# watch links
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠤࠥࠦ࡮ࡪ࠽ࠣࡲ࡯ࡥࡾ࡫ࡲ࠮ࡱࡳࡸ࡮ࡵ࡮࠮࠳ࠥࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡜ࠤࡿࠫࡢ࠮ࡳࡩࡧࡤࡨࡪࡸࡼࡱࡣࡪࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠯࡛ࠣࡾࠪࡡࠧࠨࠢᢺ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0][0]
		items = re.findall(l111lll_ll_ (u"ࠪࡨࡦࡺࡡ࠮ࡶࡼࡴࡪࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠠࡥࡣࡷࡥ࠲ࡶ࡯ࡴࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠤࡩࡧࡴࡢ࠯ࡱࡹࡲ࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡧࡱࡧࡳࡴ࠿ࠥࡺ࡮ࡪ࡟ࡵ࡫ࡷࡰࡪࠨ࠾ࠩ࠰࠭ࡃ࠮ࡂࠧᢻ"),block,re.DOTALL)
		for type,post,l1l11ll111_ll_,title in items:
			#link = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡹࡨࡰࡹ࠱ࡥࡱ࡬ࡡ࡫ࡧࡵࡸࡻ࠴ࡣࡰ࡯࠲ࡻࡵ࠳ࡡࡥ࡯࡬ࡲ࠴ࡧࡤ࡮࡫ࡱ࠱ࡦࡰࡡࡹ࠰ࡳ࡬ࡵ࠭ᢼ")
			link = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡷࡱ࠯ࡤࡨࡲ࡯࡮࠰ࡣࡧࡱ࡮ࡴ࠭ࡢ࡬ࡤࡼ࠳ࡶࡨࡱࡁࡤࡧࡹ࡯࡯࡯࠿ࡧࡳࡴࡥࡰ࡭ࡣࡼࡩࡷࡥࡡ࡫ࡣࡻࠪࡵࡵࡳࡵ࠿ࠪᢽ")+post+l111lll_ll_ (u"࠭ࠦ࡯ࡷࡰࡩࡂ࠭ᢾ")+l1l11ll111_ll_+l111lll_ll_ (u"ࠧࠧࡶࡼࡴࡪࡃࠧᢿ")+type
			link = link+l111lll_ll_ (u"ࠨࡁࡱࡥࡲ࡫ࡤ࠾ࠩᣀ")+title+l111lll_ll_ (u"ࠩࡢࡣࡼࡧࡴࡤࡪࠪᣁ")
			l1l111l_ll_.append(link)
	# download links
	#l1l1l1111_ll_(html)
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠥࠦࠧ࡯ࡤ࠾ࠩࡧࡳࡼࡴ࡬ࡰࡣࡧࠫࠥࡩ࡬ࡢࡵࡶࠬ࠳࠰࠿ࠪࡥ࡯ࡥࡸࡹ࠽࡜ࠤࡿࠫࡢࡹࡢࡰࡺ࡞ࠦࢁ࠭࡝ࠣࠤࠥᣂ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠦ࡮ࡳࡧࠡࡵࡵࡧࡂ࠭ࠨ࠯ࠬࡂ࠭ࠬ࠴ࠪࡀࡪࡵࡩ࡫ࡃࠧࠩ࠰࠭ࡃ࠮࠭࠮ࠫࡁࠪࡵࡺࡧ࡬ࡪࡶࡼࠫࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿࠽ࡶࡧࡂ࠭࠴ࠪࡀࠫ࠿ࠦᣃ"),block,re.DOTALL)
		#l1ll1l_ll_(str(items),str(block))
		for img,link,quality,lang in items:
			if l111lll_ll_ (u"ࠬࡃࠧᣄ") in img:
				host = img.split(l111lll_ll_ (u"࠭࠽ࠨᣅ"))[1]
				title = l1l11l1lll_ll_(host,True)
			else: title = l111lll_ll_ (u"ࠧࠨᣆ")
			title = lang+l111lll_ll_ (u"ࠨࠢࠪᣇ")+title
			link = link+l111lll_ll_ (u"ࠩࡂࡲࡦࡳࡥࡥ࠿ࠪᣈ")+title+l111lll_ll_ (u"ࠪࡣࡤࡪ࡯ࡸࡰ࡯ࡳࡦࡪ࡟ࡠࡡࡢࠫᣉ")+quality
			l1l111l_ll_.append(link)
	selection = l1l1111_ll_(l111lll_ll_ (u"ࠫศิสาࠢส่อำหࠡษ็้๋อำษࠩᣊ"), l1l111l_ll_)
	if len(l1l111l_ll_)==0:
		l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨᣋ"),l111lll_ll_ (u"࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭ᣌ"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ࠭ᣍ"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠨࠩᣎ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠩࠪᣏ"): return
	search = search.replace(l111lll_ll_ (u"ࠪࠤࠬᣐ"),l111lll_ll_ (u"ࠫ࠰࠭ᣑ"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵࠿ࡴ࠿ࠪᣒ")+search
	l1l11l1_ll_(url,l111lll_ll_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭ᣓ"))
	return