# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1ll_ll_=l111lll_ll_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅࠩๆ")
headers = {l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ็"):l111lll_ll_ (u"่ࠩࠪ")}
l1l1l1l_ll_=l111lll_ll_ (u"ࠪࡣࡆࡘࡓࡠ้ࠩ")
l1ll1l1_ll_ = l11l11l_ll_[l1ll_ll_][0]
l11lll1_ll_ = [l111lll_ll_ (u"ࠫฬ๊ัว์ึ๎ฮ๊࠭"),l111lll_ll_ (u"ࠬอไๆุสๅࠥำฯ๋อส๏๋ࠬ"),l111lll_ll_ (u"࠭ๅึษิ฽์࠭์"),l111lll_ll_ (u"ࠧศ฻็ู๊๋ࠥ็ษࠣ⠗ࠥࡌ࡯ࡳࠢࡤࡨࡸ࠭ํ"),l111lll_ll_ (u"ࠨ็๋ฬฬ๐ไศฬࠪ๎"),l111lll_ll_ (u"ࠩหีฬ๋ฬࠡๅ่ฬ๏๎สาࠩ๏"),l111lll_ll_ (u"ࠪห้฿วษࠢๆ้อ๐่หำࠪ๐"),l111lll_ll_ (u"ࠫฬูไศ็ํหฯ࠭๑"),l111lll_ll_ (u"ࠬอฮา๋ࠪ๒"),l111lll_ll_ (u"࠭วใีส้ࠥอฮา์ࠪ๓"),l111lll_ll_ (u"ࠧศึอีฬ้วหࠩ๔")]
def l111l1l_ll_(mode,url,text):
	#l1l1l11_ll_(l1ll_ll_,l1l1l_ll_,mode,l11l1l1_ll_)
	if   mode==250: results = l11l1ll_ll_(url)
	elif mode==251: results = l1l11l1_ll_(url,text)
	elif mode==252: results = l11_ll_(url)
	elif mode==253: results = l1l11ll_ll_(url)
	elif mode==254: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨ๕")+text)
	elif mode==255: results = l1111l1_ll_(url,l111lll_ll_ (u"ࠩࡉࡍࡑ࡚ࡅࡓࡕࡢࡣࡤ࠭๖")+text)
	elif mode==256: results = l1l1l11l1_ll_(url,text)
	elif mode==259: results = l1lll1_ll_(text)
	else: results = False
	return results
def l11l1ll_ll_(l1111l_ll_=l111lll_ll_ (u"ࠪࠫ๗")):
	if l1111l_ll_==l111lll_ll_ (u"ࠫࠬ๘"):
		l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๙"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ศฮอࠣๅ๏ࠦวๅ็๋ๆ฾࠭๚"),l111lll_ll_ (u"ࠧࠨ๛"),259,l111lll_ll_ (u"ࠨࠩ๜"),l111lll_ll_ (u"ࠩࠪ๝"),l111lll_ll_ (u"ࠪࡣࡗࡋࡍࡆࡏࡅࡉࡗࡘࡅࡔࡗࡏࡘࡘࡥࠧ๞"))
		l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ๟"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬ็ไหำ้ࠣาีฯࠨ๠"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯ࡤࡣࡷࡩ࡬ࡵࡲࡺ࠱สาึ๏ࠧ๡"),254)
		l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧ๢"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨใ็ฮึࠦใศ็็ࠫ๣"),l1ll1l1_ll_+l111lll_ll_ (u"ࠩ࠲ࡧࡦࡺࡥࡨࡱࡵࡽ࠴อฮา๋ࠪ๤"),255)
		l111_ll_(l111lll_ll_ (u"ࠪࡰ࡮ࡴ࡫ࠨ๥"),l111lll_ll_ (u"ࠫࡠࡉࡏࡍࡑࡕࠤࡋࡌࡃ࠹࠻࠳࠴࠽ࡣ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡡ࠯ࡄࡑࡏࡓࡗࡣࠧ๦"),l111lll_ll_ (u"ࠬ࠭๧"),9999)
	l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭๨"),l1l1l1l_ll_+l111lll_ll_ (u"ࠧศๆฺ่ฬ็ࠠฮัํฯฬ๑ࠧ๩"),l1ll1l1_ll_+l111lll_ll_ (u"ࠨ࠱࡯ࡥࡸࡺࡥࡴࡶࠪ๪"),251,l111lll_ll_ (u"ࠩࠪ๫"),l111lll_ll_ (u"ࠪࠫ๬"),l111lll_ll_ (u"ࠫࡱࡧࡳࡵࡧࡶࡸࠬ๭"))
	l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ๮"),l1l1l1l_ll_+l111lll_ll_ (u"࠭ฬะ์าࠤฬ๊วโๆส้ࠬ๯"),l1ll1l1_ll_+l111lll_ll_ (u"ࠧ࠰࡯ࡤ࡭ࡳ࠭๰"),256,l111lll_ll_ (u"ࠨࠩ๱"),l111lll_ll_ (u"ࠩࠪ๲"),l111lll_ll_ (u"ࠪࡲࡪࡽ࡟࡮ࡱࡹ࡭ࡪࡹࠧ๳"))
	l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫ๴"),l1l1l1l_ll_+l111lll_ll_ (u"ࠬาฯ๋ัࠣห้ำไใษอࠫ๵"),l1ll1l1_ll_+l111lll_ll_ (u"࠭࠯࡮ࡣ࡬ࡲࠬ๶"),256,l111lll_ll_ (u"ࠧࠨ๷"),l111lll_ll_ (u"ࠨࠩ๸"),l111lll_ll_ (u"ࠩࡱࡩࡼࡥࡥࡱ࡫ࡶࡳࡩ࡫ࡳࠨ๹"))
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ๺"),l1ll1l1_ll_+l111lll_ll_ (u"ࠫ࠴ࡳࡡࡪࡰࠪ๻"),l111lll_ll_ (u"ࠬ࠭๼"),l111lll_ll_ (u"࠭ࠧ๽"),l111lll_ll_ (u"ࠧࠨ๾"),l111lll_ll_ (u"ࠨࠩ๿"),l111lll_ll_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱ࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭຀"))
	html = response.content
	l1l1ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡪࡴࡵࡉࡧࡤࡨࡪࡸࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡥ࡫ࡹࡂࠬກ"),html,re.DOTALL)
	l11l1l11_ll_ = l1l1ll111_ll_[0]
	l1llll111_ll_ = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡄࠨ࠯ࠬࡂ࠭ࡁ࠭ຂ"),l11l1l11_ll_,re.DOTALL)
	for link,title in l1llll111_ll_:
		title = unescapeHTML(title)
		if title not in l11lll1_ll_ and title!=l111lll_ll_ (u"ࠬ࠭຃"):
			l111_ll_(l111lll_ll_ (u"࠭ࡦࡰ࡮ࡧࡩࡷ࠭ຄ"),l1111l_ll_+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ຅")+l1l1l1l_ll_+title,link,256)
	return html
def l1l1l11l1_ll_(url,type):
	#l1ll1l_ll_(url,type)
	#l1l1l1111_ll_(html)
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬຆ"),url,l111lll_ll_ (u"ࠩࠪງ"),l111lll_ll_ (u"ࠪࠫຈ"),l111lll_ll_ (u"ࠫࠬຉ"),l111lll_ll_ (u"ࠬ࠭ຊ"),l111lll_ll_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡕࡘࡆࡒࡋࡎࡖ࠯࠴ࡷࡹ࠭຋"))
	html = response.content
	if l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡎࡣ࡬ࡲࡘࡲࡩࡥࡧࡶࠫຌ") in html: l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨຍ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩส่๊๋๊ำหࠪຎ"),url,251,l111lll_ll_ (u"ࠪࠫຏ"),l111lll_ll_ (u"ࠫࠬຐ"),l111lll_ll_ (u"ࠬ࡬ࡥࡢࡶࡸࡶࡪࡪࠧຑ"))
	if l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡓ࡭࡫ࡧࡩࡷࡏ࡮ࡔࡧࡦࡸ࡮ࡵ࡮ࠨຒ") in html: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧຓ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ห่ััࠡ็ืห์ีษࠨດ"),url,251,l111lll_ll_ (u"ࠩࠪຕ"),l111lll_ll_ (u"ࠪࠫຖ"),l111lll_ll_ (u"ࠫࡲࡵࡳࡵࠩທ"))
	if l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧࡒࡩ࡯࡭ࡶࡐ࡮ࡹࡴࠨຘ") in html:
		l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬນ"),html,re.DOTALL)
		if l1lll_ll_:
			block = l1lll_ll_[0]
			if len(l1lll_ll_)>1 and type==l111lll_ll_ (u"ࠧ࡯ࡧࡺࡣࡪࡶࡩࡴࡱࡧࡩࡸ࠭ບ"): block = l1lll_ll_[1]
			items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠨ࠯ࠬࡂ࠭ࡁ࠵ࡡ࠿ࠩປ"),block,re.DOTALL)
			#l1ll1l_ll_(str(len(items)),l111lll_ll_ (u"ࠩࠪຜ"))
			for link,title in items:
				l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠪࡀ࠴࡯࠾࠯ࠬࡂࡀࡸࡶࡡ࡯ࡀࠫ࠲࠯ࡅࠩ࠽ࠩຝ"),title,re.DOTALL)
				if l111lll_ll_ (u"ࠫࡁࡹࡴࡳࡱࡱ࡫ࡃ࠭ພ") in title: l11ll111_ll_ = re.findall(l111lll_ll_ (u"ࠬࡂ࠯ࡪࡀࠫ࠲࠯ࡅࠩ࠽ࠩຟ"),title,re.DOTALL)
				if not l11ll111_ll_: l11ll111_ll_ = re.findall(l111lll_ll_ (u"࠭ࡡ࡭ࡶࡀࠦ࠭࠴ࠪࡀࠫࠥࠫຠ"),title,re.DOTALL)
				if l11ll111_ll_:
					l11ll111_ll_ = l11ll111_ll_[0]
					if l111lll_ll_ (u"ࠧ࡬ࡧࡼࡁࠬມ") in link: type = link.split(l111lll_ll_ (u"ࠨ࡭ࡨࡽࡂ࠭ຢ"))[1]
					else: type = l111lll_ll_ (u"ࠩࡱࡩࡼ࡫ࡳࡵࠩຣ")
					l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ຤"),l1l1l1l_ll_+l11ll111_ll_,link,251,l111lll_ll_ (u"ࠫࠬລ"),l111lll_ll_ (u"ࠬ࠭຦"),type)
	return
def l1l11l1_ll_(url,type):
	#l1ll1l_ll_(url,type)
	#l1l1l1111_ll_(html)
	if type==l111lll_ll_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧວ"):
		if l111lll_ll_ (u"ࠧࡀࠩຨ") in url:
			l1ll111_ll_,data = url.split(l111lll_ll_ (u"ࠨࡁࠪຩ"))
			data2 = {}
			lines = data.split(l111lll_ll_ (u"ࠩࠩࠫສ"))
			for line in lines:
				key,value = line.split(l111lll_ll_ (u"ࠪࡁࠬຫ"))
				data2[key] = value
		else: l1ll111_ll_,data2 = url,l111lll_ll_ (u"ࠫࠬຬ")
		response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠬࡖࡏࡔࡖࠪອ"),l1ll111_ll_,data2,l111lll_ll_ (u"࠭ࠧຮ"),l111lll_ll_ (u"ࠧࠨຯ"),l111lll_ll_ (u"ࠨࠩະ"),l111lll_ll_ (u"ࠩࡄࡖࡆࡈࡓࡆࡇࡇ࠱࡙ࡏࡔࡍࡇࡖ࠱࠶ࡹࡴࠨັ"))
	else: response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧາ"),url,l111lll_ll_ (u"ࠫࠬຳ"),l111lll_ll_ (u"ࠬ࠭ິ"),l111lll_ll_ (u"࠭ࠧີ"),l111lll_ll_ (u"ࠧࠨຶ"),l111lll_ll_ (u"ࠨࡃࡕࡅࡇ࡙ࡅࡆࡆ࠰ࡘࡎ࡚ࡌࡆࡕ࠰࠶ࡳࡪࠧື"))
	html = response.content
	if type==l111lll_ll_ (u"ࠩࡩࡩࡦࡺࡵࡳࡧࡧຸࠫ"):
		l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠪࡧࡱࡧࡳࡴ࠿ࠥࡑࡦ࡯࡮ࡔ࡮࡬ࡨࡪࡹࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺູࠧ"),html,re.DOTALL)
		block = l1lll_ll_[0]
		z = re.findall(l111lll_ll_ (u"ࠫ࡭ࡸࡥࡧ࠿ࠥࠬ࠳࠰࠿ࠪࠤࠣࡸ࡮ࡺ࡬ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄ࠮ࡳࡳࡥࡿࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫ࠩ࠾ࠤࠫ࠲࠯ࡅ຺ࠩࠣࠩ"),block,re.DOTALL)
		if z:
			l1l111l_ll_,l1111ll_ll_,l1l111l1l_ll_,l1l11ll11_ll_ = zip(*z)
			items = zip(l1l111l_ll_,l1l11ll11_ll_,l1111ll_ll_)
		else: items = []
	else:
		if type==l111lll_ll_ (u"ࠬ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ົ"): l1lll_ll_ = [html]
		elif type==l111lll_ll_ (u"࠭࡭ࡰࡵࡷࠫຼ"): l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡔ࡮࡬ࡨࡪࡸࡉ࡯ࡕࡨࡧࡹ࡯࡯࡯ࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡌࡪࡰ࡮ࡷࡑ࡯ࡳࡵࠩຽ"),html,re.DOTALL)
		else: l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡄ࡯ࡳࡨࡱࡳ࠮ࡗࡏࠦ࠭࠴ࠪࡀࠫࡦࡰࡦࡹࡳ࠾ࠤࡄࡦࡴࡋ࡬ࡔࡧࡨࡨࠧ࠭຾"),html,re.DOTALL)
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠩ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮࡫ࡰࡥ࡬࡫࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠡࡣ࡯ࡸࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠭຿"),block,re.DOTALL)
		#items = re.findall(l111lll_ll_ (u"ࠪ࡬ࡷ࡫ࡦ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡦࡲࡴ࠾ࠤࠫ࠲࠯ࡅࠩࠣ࠰࠭ࡃࡸࡸࡣ࠾ࠤࠫ࠲࠯ࡅࠩࠣࠩເ"),block,re.DOTALL)
	l1ll11ll_ll_ = []
	for link,img,title in items:
		#l1ll1l_ll_(title,l111lll_ll_ (u"ࠫࠬແ"))
		title = unescapeHTML(title)
		if l111lll_ll_ (u"ࠬอไฮๆๅอࠬໂ") in title:
			episode = re.findall(l111lll_ll_ (u"࠭ࠨ࠯ࠬࡂ࠭ࠥอไฮๆๅอࠥࡢࡤࠬࠩໃ"),title,re.DOTALL)
			if episode:
				title = l111lll_ll_ (u"ࠧࡠࡏࡒࡈࡤ࠭ໄ") + episode[0]
				if title not in l1ll11ll_ll_:
					l1ll11ll_ll_.append(title)
					l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨ໅"),l1l1l1l_ll_+title,link,253,img)
			else: l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨໆ"),l1l1l1l_ll_+title,link,252,img)
		elif l111lll_ll_ (u"ࠪ࠳ࡸ࡫࡬ࡢࡴࡼ࠳ࠬ໇") in link or l111lll_ll_ (u"ู๊ࠫไิๆ່ࠪ") in title:
			l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶ້ࠬ"),l1l1l1l_ll_+title,link,253,img)
		else: l111_ll_(l111lll_ll_ (u"࠭ࡶࡪࡦࡨࡳ໊ࠬ"),l1l1l1l_ll_+title,link,252,img)
	if type not in [l111lll_ll_ (u"ࠧࡧࡧࡤࡸࡺࡸࡥࡥ໋ࠩ"),l111lll_ll_ (u"ࠨ࡯ࡲࡷࡹ࠭໌")]:
		items = re.findall(l111lll_ll_ (u"ࠩࡳࡥ࡬࡫࠭࡯ࡷࡰࡦࡪࡸࡳࠣࠢ࡫ࡶࡪ࡬࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠿ࠪ࠱࠮ࡄ࠯࠼ࠨໍ"),html,re.DOTALL)
		for link,title in items:
			link = l1ll1l1_ll_+link
			link = unescapeHTML(link)
			title = unescapeHTML(title)
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ໎"),l1l1l1l_ll_+l111lll_ll_ (u"ฺࠫ็อสࠢࠪ໏")+title,link,251,l111lll_ll_ (u"ࠬ࠭໐"),l111lll_ll_ (u"࠭ࠧ໑"),type)
	return
def l1l11ll_ll_(url):
	response = l111111_ll_(l111l11_ll_,l111lll_ll_ (u"ࠧࡈࡇࡗࠫ໒"),url,l111lll_ll_ (u"ࠨࠩ໓"),l111lll_ll_ (u"ࠩࠪ໔"),l111lll_ll_ (u"ࠪࠫ໕"),l111lll_ll_ (u"ࠫࠬ໖"),l111lll_ll_ (u"ࠬࡇࡒࡂࡄࡖࡉࡊࡊ࠭ࡆࡒࡌࡗࡔࡊࡅࡔ࠯࠴ࡷࡹ࠭໗"))
	html = response.content
	item = re.findall(l111lll_ll_ (u"࠭ࡢࡢࡥ࡮࡫ࡷࡵࡵ࡯ࡦ࠰࡭ࡲࡧࡧࡦ࠼ࠣࡹࡷࡲ࡜ࠩࠪ࠱࠮ࡄ࠯࡜ࠪ࠰࠭ࡃࡨࡲࡡࡴࡵࡀ࡙ࠦ࡯ࡴ࡭ࡧࠥࡂ࠭࠴ࠪࡀࠫ࠿ࠫ໘"),html,re.DOTALL)
	img,name = item[0]
	if l111lll_ll_ (u"ࠧศๆะ่็ฯࠧ໙") in name: name = name.split(l111lll_ll_ (u"ࠨษ็ั้่ษࠨ໚"))[0].strip(l111lll_ll_ (u"ࠩࠣࠫ໛"))
	elif l111lll_ll_ (u"ࠪั้่ษࠨໜ") in name: name = name.split(l111lll_ll_ (u"ࠫา๊โสࠩໝ"))[0].strip(l111lll_ll_ (u"ࠬࠦࠧໞ"))
	l1lll_ll_ = re.findall(l111lll_ll_ (u"࠭ࡣ࡭ࡣࡶࡷࡂࠨࡅࡱ࡫ࡶࡳࡩ࡫ࡳࡂࡴࡨࡥࠧ࠮࠮ࠫࡁࠬࡷࡹࡿ࡬ࡦ࠿ࠥࡧࡱ࡫ࡡࡳ࠼ࠣࡦࡴࡺࡨ࠼ࠤࠪໟ"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠧࡩࡴࡨࡪࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀࠬ໠"),block,re.DOTALL)
		for link,episode in reversed(items):
			title = name+l111lll_ll_ (u"ࠨࠢ࠰ࠤฬ๊อๅไฬࠤึ่ๅࠡࠩ໡")+episode
			l111_ll_(l111lll_ll_ (u"ࠩࡹ࡭ࡩ࡫࡯ࠨ໢"),l1l1l1l_ll_+title,link,252,img)
	else: l111_ll_(l111lll_ll_ (u"ࠪࡺ࡮ࡪࡥࡰࠩ໣"),l1l1l1l_ll_+l111lll_ll_ (u"๊๊ࠫแࠡษ็ฮูเ๊ๅࠩ໤"),url,252,img)
	return
def l11_ll_(url):
	l1l11l1ll_ll_ = url+l111lll_ll_ (u"ࠬࡽࡡࡵࡥ࡫࠳ࠬ໥")
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"࠭ࡇࡆࡖࠪ໦"),l1l11l1ll_ll_,l111lll_ll_ (u"ࠧࠨ໧"),l111lll_ll_ (u"ࠨࠩ໨"),l111lll_ll_ (u"ࠩࠪ໩"),l111lll_ll_ (u"ࠪࠫ໪"),l111lll_ll_ (u"ࠫࡆࡘࡁࡃࡕࡈࡉࡉ࠳ࡐࡍࡃ࡜࠱࠶ࡹࡴࠨ໫"))
	html = response.content
	l1l111l_ll_ = []
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠬࡩ࡬ࡢࡵࡶࡁࠧ࡬ࡡ࡭ࠢࡩࡥ࠲ࡶ࡬ࡢࡻࠥࠬ࠳࠰࠿ࠪ࠾࠲ࡨ࡮ࡼ࠾ࠨ໬"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"࠭࠼ࡴࡲࡤࡲࡃ࠮࠮ࠫࡁࠬࡀ࠳࠰࠿ࡴࡴࡦࡁࠧ࠮࠮ࠫࡁࠬࠦࠬ໭"),block,re.DOTALL|re.IGNORECASE)
		for title,link in items:
			if link==l111lll_ll_ (u"ࠧࠨ໮"): continue
			link = l1111_ll_(link)
			if l111lll_ll_ (u"ࠨࡪࡷࡸࡵ࠭໯") not in link: link = l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺ࠨ໰")+link
			quality = re.findall(l111lll_ll_ (u"ࠪࡠࡩࡢࡤ࡝ࡦ࠮ࠫ໱"),title,re.DOTALL)
			if quality:
				quality = quality[0]
				if quality in title:
					title = title.replace(quality+l111lll_ll_ (u"ࠫࡵ࠭໲"),l111lll_ll_ (u"ࠬ࠭໳")).replace(quality,l111lll_ll_ (u"࠭ࠧ໴"))
					title = title.replace(l111lll_ll_ (u"ࠧ࠮ࠢࠪ໵"),l111lll_ll_ (u"ࠨࠩ໶")).strip(l111lll_ll_ (u"ࠩࠣࠫ໷"))
				quality = l111lll_ll_ (u"ࠪࡣࡤࡥ࡟ࠨ໸")+quality
			else: quality = l111lll_ll_ (u"ࠫࠬ໹")
			title = l1l1l111l_ll_(title,link)
			link = link+l111lll_ll_ (u"ࠬࡅ࡮ࡢ࡯ࡨࡨࡂ࠭໺")+title+l111lll_ll_ (u"࠭࡟ࡠࡹࡤࡸࡨ࡮ࠧ໻")+quality
			l1l111l_ll_.append(link)
	l1l11l1l1_ll_ = url+l111lll_ll_ (u"ࠧࡥࡱࡺࡲࡱࡵࡡࡥ࠱ࠪ໼")
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ໽"),l1l11l1l1_ll_,l111lll_ll_ (u"ࠩࠪ໾"),l111lll_ll_ (u"ࠪࠫ໿"),l111lll_ll_ (u"ࠫࠬༀ"),l111lll_ll_ (u"ࠬ࠭༁"),l111lll_ll_ (u"࠭ࡁࡓࡃࡅࡗࡊࡋࡄ࠮ࡒࡏࡅ࡞࠳࠲࡯ࡦࠪ༂"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠧࡤ࡮ࡤࡷࡸࡃࠢࡅࡱࡺࡲࡱࡵࡡࡥࡃࡵࡩࡦࠨࠨ࠯ࠬࡂ࠭ࡨࡲࡡࡴࡵࡀࠦࡑ࡯࡮࡬ࡵࡏ࡭ࡸࡺࠢࠨ༃"),html,re.DOTALL)
	if l1lll_ll_:
		block = l1lll_ll_[0]
		items = re.findall(l111lll_ll_ (u"ࠨࡪࡵࡩ࡫ࡃࠢࠩ࠰࠭ࡃ࠮ࠨ࠮ࠫࡁ࠿ࡷࡵࡧ࡮࠿ࠪ࠱࠮ࡄ࠯࠼࠯ࠬࡂࡀࡵࡄࠨ࠯ࠬࡂ࠭ࡁ࠭༄"),block,re.DOTALL)
		for link,title,quality in items:
			if link==l111lll_ll_ (u"ࠩࠪ༅"): continue
			link = l1111_ll_(link)
			title = l1l1l111l_ll_(title,link)
			link = link+l111lll_ll_ (u"ࠪࡃࡳࡧ࡭ࡦࡦࡀࠫ༆")+title+l111lll_ll_ (u"ࠫࡤࡥࡤࡰࡹࡱࡰࡴࡧࡤࡠࡡࡢࡣࠬ༇")+quality
			l1l111l_ll_.append(link)
	#selection = l1l1111_ll_(l111lll_ll_ (u"ࠬษฮหำࠣห้ฮอฬࠢส่๊์วิสࠪ༈"), l1l111l_ll_)
	l1l111lll_ll_ = str(l1l111l_ll_)
	#l1111l1l_ll_(l111lll_ll_ (u"࠭ࠧ༉"),l1l111lll_ll_)
	l11l11_ll_ = [l111lll_ll_ (u"ࠧ࠯ࡼ࡬ࡴࡄ࠭༊"),l111lll_ll_ (u"ࠨ࠰ࡵࡥࡷࡅࠧ་"),l111lll_ll_ (u"ࠩ࠱ࡸࡽࡺ࠿ࠨ༌"),l111lll_ll_ (u"ࠪ࠲ࡵࡪࡦࡀࠩ།"),l111lll_ll_ (u"ࠫ࠳ࡺࡡࡳࡁࠪ༎"),l111lll_ll_ (u"ࠬ࠴ࡩࡴࡱࡂࠫ༏"),l111lll_ll_ (u"࠭࠮ࡻ࡫ࡳ࠲ࠬ༐"),l111lll_ll_ (u"ࠧ࠯ࡴࡤࡶ࠳࠭༑"),l111lll_ll_ (u"ࠨ࠰ࡷࡼࡹ࠴ࠧ༒"),l111lll_ll_ (u"ࠩ࠱ࡴࡩ࡬࠮ࠨ༓"),l111lll_ll_ (u"ࠪ࠲ࡹࡧࡲ࠯ࠩ༔"),l111lll_ll_ (u"ࠫ࠳࡯ࡳࡰ࠰ࠪ༕")]
	if len(l1l111l_ll_)==0 or any(value in l1l111lll_ll_ for value in l11l11_ll_):
		l1ll1l_ll_(l111lll_ll_ (u"ࠬืำศๆฬࠤ๊์ࠠศๆ่ฬึ๋ฬࠨ༖"),l111lll_ll_ (u"࠭วๅำสฬ฼ࠦไ๋ีࠣๅ๏ํࠠโ์า๎ํ࠭༗"))
	else:
		import l1_ll_
		l1_ll_.l11_ll_(l1l111l_ll_,l1ll_ll_,l111lll_ll_ (u"ࠧࡷ࡫ࡧࡩࡴ༘࠭"))
	return
def l1lll1_ll_(search):
	search,options,l1ll11_ll_ = l1lll11_ll_(search)
	if search==l111lll_ll_ (u"ࠨ༙ࠩ"): search = l1ll1_ll_()
	if search==l111lll_ll_ (u"ࠩࠪ༚"): return
	search = search.replace(l111lll_ll_ (u"ࠪࠤࠬ༛"),l111lll_ll_ (u"ࠫ࠰࠭༜"))
	url = l1ll1l1_ll_+l111lll_ll_ (u"ࠬ࠵ࡦࡪࡰࡧ࠳ࡄ࡬ࡩ࡯ࡦࡀࠫ༝")+search
	l1l11l1_ll_(url,l111lll_ll_ (u"࠭ࡳࡦࡣࡵࡧ࡭࠭༞"))
	return
def l1111l1_ll_(url,filter):
	#l1ll1l_ll_(filter,url)
	l1ll11l1l_ll_ = {l111lll_ll_ (u"ࠧࡓࡧࡩࡩࡷ࡫ࡲࠨ༟"):url,l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ༠"):l111lll_ll_ (u"ࠩࠪ༡")}
	l1ll11l1l_ll_ = l111lll_ll_ (u"ࠪࠫ༢")
	filter = filter.replace(l111lll_ll_ (u"ࠫࡤࡌࡏࡓࡉࡈࡘࡗࡋࡓࡖࡎࡗࡗࡤ࠭༣"),l111lll_ll_ (u"ࠬ࠭༤"))
	if l111lll_ll_ (u"࠭࠿ࡀࠩ༥") in url: url = url.split(l111lll_ll_ (u"ࠧ࠰࠱ࡪࡩࡹࡶ࡯ࡴࡶࡶࡃࡄ࠭༦"))[0]
	type,filter = filter.split(l111lll_ll_ (u"ࠨࡡࡢࡣࠬ༧"),1)
	if filter==l111lll_ll_ (u"ࠩࠪ༨"): l1l1l1ll_ll_,l1l1l1l1_ll_ = l111lll_ll_ (u"ࠪࠫ༩"),l111lll_ll_ (u"ࠫࠬ༪")
	else: l1l1l1ll_ll_,l1l1l1l1_ll_ = filter.split(l111lll_ll_ (u"ࠬࡥ࡟ࡠࠩ༫"))
	if type==l111lll_ll_ (u"࠭ࡃࡂࡖࡈࡋࡔࡘࡉࡆࡕࠪ༬"):
		if l1l11lll1_ll_[0]+l111lll_ll_ (u"ࠧ࠾࠿ࠪ༭") not in l1l1l1ll_ll_: category = l1l11lll1_ll_[0]
		for i in range(len(l1l11lll1_ll_[0:-1])):
			if l1l11lll1_ll_[i]+l111lll_ll_ (u"ࠨ࠿ࡀࠫ༮") in l1l1l1ll_ll_: category = l1l11lll1_ll_[i+1]
		l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠩࠩࠪࠬ༯")+category+l111lll_ll_ (u"ࠪࡁࡂ࠶ࠧ༰")
		l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠫࠫࠬࠧ༱")+category+l111lll_ll_ (u"ࠬࡃ࠽࠱ࠩ༲")
		l1l1llll_ll_ = l1lll11l_ll_.strip(l111lll_ll_ (u"࠭ࠦࠧࠩ༳"))+l111lll_ll_ (u"ࠧࡠࡡࡢࠫ༴")+l1ll1l11_ll_.strip(l111lll_ll_ (u"ࠨࠨ༵ࠩࠫ"))
		l1l11ll1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣ࡫࡯࡬ࡵࡧࡵࡷࠬ༶"))
		l1ll111_ll_ = url+l111lll_ll_ (u"ࠪ࠳࠴࡭ࡥࡵࡲࡲࡷࡹࡹ࠿ࡀ༷ࠩ")+l1l11ll1_ll_
	elif type==l111lll_ll_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬ༸"):
		l1l1111l_ll_ = l1l1l111_ll_(l1l1l1ll_ll_,l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹ༹ࠧ"))
		l1l1111l_ll_ = l1111_ll_(l1l1111l_ll_)
		if l1l1l1l1_ll_!=l111lll_ll_ (u"࠭ࠧ༺"): l1l1l1l1_ll_ = l1l1l111_ll_(l1l1l1l1_ll_,l111lll_ll_ (u"ࠧ࡮ࡱࡧ࡭࡫࡯ࡥࡥࡡࡩ࡭ࡱࡺࡥࡳࡵࠪ༻"))
		if l1l1l1l1_ll_==l111lll_ll_ (u"ࠨࠩ༼"): l1ll111_ll_ = url
		else: l1ll111_ll_ = url+l111lll_ll_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸࡅ࠿ࠨ༽")+l1l1l1l1_ll_
		l1l11llll_ll_ = l1l11ll1l_ll_(l1ll111_ll_)
		l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ༾"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫศ฾็ศำࠣๆฬฬๅสࠢส่ๆ๐ฯ๋๊ࠣห้ะ๊ࠡฬ่ࠤฬิส๋ษิ๋ฬࠦࠧ༿"),l1l11llll_ll_,251,l111lll_ll_ (u"ࠬ࠭ཀ"),l111lll_ll_ (u"࠭ࠧཁ"),l111lll_ll_ (u"ࠧࡧ࡫࡯ࡸࡪࡸࡳࠨག"))
		l111_ll_(l111lll_ll_ (u"ࠨࡨࡲࡰࡩ࡫ࡲࠨགྷ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠩࠣ࡟ࡠࠦࠠࠡࠩང")+l1l1111l_ll_+l111lll_ll_ (u"ࠪࠤࠥࠦ࡝࡞ࠩཅ"),l1l11llll_ll_,251,l111lll_ll_ (u"ࠫࠬཆ"),l111lll_ll_ (u"ࠬ࠭ཇ"),l111lll_ll_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧ཈"))
		l111_ll_(l111lll_ll_ (u"ࠧ࡭࡫ࡱ࡯ࠬཉ"),l111lll_ll_ (u"ࠨ࡝ࡆࡓࡑࡕࡒࠡࡈࡉࡇ࠽࠿࠰࠱࠺ࡠࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿࡞࠳ࡈࡕࡌࡐࡔࡠࠫཊ"),l111lll_ll_ (u"ࠩࠪཋ"),9999)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡔࡔ࡙ࡔࠨཌ"),url,l111lll_ll_ (u"ࠫࠬཌྷ"),l1ll11l1l_ll_,l111lll_ll_ (u"ࠬ࠭ཎ"),l111lll_ll_ (u"࠭ࠧཏ"),l111lll_ll_ (u"ࠧࡂࡔࡄࡆࡘࡋࡅࡅ࠯ࡉࡍࡑ࡚ࡅࡓࡕࡢࡑࡊࡔࡕ࠮࠳ࡶࡸࠬཐ"))
	html = response.content
	l1lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡥ࡯ࡥࡸࡹ࠽ࠣࡖࡤࡼࡕࡧࡧࡦࡈ࡬ࡰࡹ࡫ࡲࠣࠪ࠱࠮ࡄ࠯ࡣ࡭ࡣࡶࡷࡂࠨࡔࡦࡴࡰࡆ࡙ࡔࡳࠣࠩད"),html,re.DOTALL)
	block = l1lll_ll_[0]
	l1l1111ll_ll_ = re.findall(l111lll_ll_ (u"ࠩࡦࡰࡦࡹࡳ࠾ࠤࡗࡥࡽࡖࡡࡨࡧࡉ࡭ࡱࡺࡥࡳࡋࡷࡩࡲࠨ࠮ࠫࡁ࠿ࡩࡲࡄࠨ࠯ࠬࡂ࠭ࡁ࠵ࡥ࡮ࡀ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢࠩ࠰࠭ࡃ࠮ࡂ࠯ࡶ࡮ࡁࡀ࠴ࡪࡩࡷࡀ࠿࠳ࡩ࡯ࡶ࠿ࠩདྷ"),block+l111lll_ll_ (u"ࠪࡀ࠴ࡻ࡬࠿࠾࠲ࡨ࡮ࡼ࠾࠽࠱ࡧ࡭ࡻࡄࠧན"),re.DOTALL)
	l1l1111l1_ll_ = re.findall(l111lll_ll_ (u"ࠫࡨࡲࡡࡴࡵࡀࠦࡗࡧࡴࡪࡰࡪࡊ࡮ࡲࡴࡦࡴࠥ࠲࠯ࡅ࠼ࡩ࠶ࡁࠬ࠳࠰࠿ࠪ࠾࠲࡬࠹ࡄ࠮ࠫࡁࠫࡀࡺࡲ࠾ࠪࠪ࠱࠮ࡄ࠯࠼࠰ࡷ࡯ࡂࠬཔ"),block,re.DOTALL)
	l11111l_ll_ = l1l1111ll_ll_+l1l1111l1_ll_
	dict = {}
	for name,l1lllll1_ll_,block in l11111l_ll_:
		#if l111lll_ll_ (u"ࠬ࡯࡮ࡵࡧࡵࡩࡸࡺࠧཕ") in l1lllll1_ll_: continue
		items = re.findall(l111lll_ll_ (u"࠭ࡤࡢࡶࡤ࠱ࡳࡧ࡭ࡦ࠿ࠥࠬ࠳࠰࠿ࠪࠤ࠱࠮ࡄࡪࡡࡵࡣ࠰ࡸࡦࡾ࠽ࠣࠪ࠱࠮ࡄ࠯ࠢ࠯ࠬࡂࡨࡦࡺࡡ࠮ࡶࡨࡶࡲࡃࠢࠩ࠰࠭ࡃ࠮ࠨࠧབ"),block,re.DOTALL)
		if name==l111lll_ll_ (u"ࠧศะิํࠬབྷ"): name = l111lll_ll_ (u"ࠨษ็ห็ูวๆࠩམ")
		if not items:
			l1llll111_ll_ = re.findall(l111lll_ll_ (u"ࠩࡧࡥࡹࡧ࠭ࡳࡣࡷࡩࡂࠨࠨ࠯ࠬࡂ࠭ࠧ࠴ࠪࡀ࠾ࡨࡱࡃ࠮࠮ࠫࡁࠬࡀ࠴࡫࡭࠿ࠩཙ"),block,re.DOTALL)
			items = []
			for option,value in l1llll111_ll_: items.append([option,l111lll_ll_ (u"ࠪࠫཚ"),value])
			l1lllll1_ll_ = l111lll_ll_ (u"ࠫࡷࡧࡴࡦࠩཛ")
			name = l111lll_ll_ (u"ࠬอไหไํ๎๊࠭ཛྷ")
		else: l1lllll1_ll_ = items[0][1]
		if l111lll_ll_ (u"࠭࠽࠾ࠩཝ") not in l1ll111_ll_: l1ll111_ll_ = url
		if type==l111lll_ll_ (u"ࠧࡄࡃࡗࡉࡌࡕࡒࡊࡇࡖࠫཞ"):
			if category!=l1lllll1_ll_: continue
			elif len(items)<=1:
				if l1lllll1_ll_==l1l11lll1_ll_[-1]: l1l11l1_ll_(l1ll111_ll_)
				else: l1111l1_ll_(l1ll111_ll_,l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࡤࡥ࡟ࠨཟ")+l1l1llll_ll_)
				return
			else:
				l1l11llll_ll_ = l1l11ll1l_ll_(l1ll111_ll_)
				if l1lllll1_ll_==l1l11lll1_ll_[-1]: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩའ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠪห้าๅ๋฻ࠣࠫཡ"),l1l11llll_ll_,251,l111lll_ll_ (u"ࠫࠬར"),l111lll_ll_ (u"ࠬ࠭ལ"),l111lll_ll_ (u"࠭ࡦࡪ࡮ࡷࡩࡷࡹࠧཤ"))
				else: l111_ll_(l111lll_ll_ (u"ࠧࡧࡱ࡯ࡨࡪࡸࠧཥ"),l1l1l1l_ll_+l111lll_ll_ (u"ࠨษ็ะ๊๐ูࠡࠩས"),l1ll111_ll_,254,l111lll_ll_ (u"ࠩࠪཧ"),l111lll_ll_ (u"ࠪࠫཨ"),l1l1llll_ll_)
		elif type==l111lll_ll_ (u"ࠫࡋࡏࡌࡕࡇࡕࡗࠬཀྵ"):
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠬࠬࠦࠨཪ")+l1lllll1_ll_+l111lll_ll_ (u"࠭࠽࠾࠲ࠪཫ")
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠧࠧࠨࠪཬ")+l1lllll1_ll_+l111lll_ll_ (u"ࠨ࠿ࡀ࠴ࠬ཭")
			l1l1llll_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤ࠭཮")+l1ll1l11_ll_
			l111_ll_(l111lll_ll_ (u"ࠪࡪࡴࡲࡤࡦࡴࠪ཯"),l1l1l1l_ll_+l111lll_ll_ (u"ࠫฬ๊ฬๆ์฼ࠤ࠿࠭཰")+name,l1ll111_ll_,255,l111lll_ll_ (u"ཱࠬ࠭"),l111lll_ll_ (u"ི࠭ࠧ"),l1l1llll_ll_+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠཱིࠩ"))
		dict[l1lllll1_ll_] = {}
		for option,dummy,value in items:
			if option in l11lll1_ll_: continue
			if l111lll_ll_ (u"ࠨษ็็้ུ࠭") in option: continue
			#if l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶཱུࠧ") in option: continue
			#if l111lll_ll_ (u"ࠪࡲ࠲ࡧࠧྲྀ") in value: continue
			l1l11l11l_ll_,l11ll111_ll_ = option,option
			l11ll111_ll_ = name+l111lll_ll_ (u"ࠫ࠿ࠦࠧཷ")+l1l11l11l_ll_
			dict[l1lllll1_ll_][value] = l11ll111_ll_
			l1lll11l_ll_ = l1l1l1ll_ll_+l111lll_ll_ (u"ࠬࠬࠦࠨླྀ")+l1lllll1_ll_+l111lll_ll_ (u"࠭࠽࠾ࠩཹ")+l1l11l11l_ll_
			l1ll1l11_ll_ = l1l1l1l1_ll_+l111lll_ll_ (u"ࠧࠧࠨེࠪ")+l1lllll1_ll_+l111lll_ll_ (u"ࠨ࠿ࡀཻࠫ")+value
			l1llll1l_ll_ = l1lll11l_ll_+l111lll_ll_ (u"ࠩࡢࡣࡤོ࠭")+l1ll1l11_ll_
			if type==l111lll_ll_ (u"ࠪࡊࡎࡒࡔࡆࡔࡖཽࠫ"):
				l111_ll_(l111lll_ll_ (u"ࠫ࡫ࡵ࡬ࡥࡧࡵࠫཾ"),l1l1l1l_ll_+l11ll111_ll_,url,255,l111lll_ll_ (u"ࠬ࠭ཿ"),l111lll_ll_ (u"ྀ࠭ࠧ"),l1llll1l_ll_+l111lll_ll_ (u"ࠧࡠࡈࡒࡖࡌࡋࡔࡓࡇࡖ࡙ࡑ࡚ࡓࡠཱྀࠩ"))
			elif type==l111lll_ll_ (u"ࠨࡅࡄࡘࡊࡍࡏࡓࡋࡈࡗࠬྂ") and l1l11lll1_ll_[-2]+l111lll_ll_ (u"ࠩࡀࡁࠬྃ") in l1l1l1ll_ll_:
				l1l11ll1_ll_ = l1l1l111_ll_(l1ll1l11_ll_,l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ྄࠭"))
				#l1ll1l_ll_(l1l11ll1_ll_,l1ll1l11_ll_)
				l11ll1_ll_ = url+l111lll_ll_ (u"ࠫ࠴࠵ࡧࡦࡶࡳࡳࡸࡺࡳࡀࡁࠪ྅")+l1l11ll1_ll_
				l1l11llll_ll_ = l1l11ll1l_ll_(l11ll1_ll_)
				l111_ll_(l111lll_ll_ (u"ࠬ࡬࡯࡭ࡦࡨࡶࠬ྆"),l1l1l1l_ll_+l11ll111_ll_,l1l11llll_ll_,251,l111lll_ll_ (u"࠭ࠧ྇"),l111lll_ll_ (u"ࠧࠨྈ"),l111lll_ll_ (u"ࠨࡨ࡬ࡰࡹ࡫ࡲࡴࠩྉ"))
			else: l111_ll_(l111lll_ll_ (u"ࠩࡩࡳࡱࡪࡥࡳࠩྊ"),l1l1l1l_ll_+l11ll111_ll_,url,254,l111lll_ll_ (u"ࠪࠫྋ"),l111lll_ll_ (u"ࠫࠬྌ"),l1llll1l_ll_)
	return
l1l11lll1_ll_ = [l111lll_ll_ (u"ࠬࡩࡡࡵࡧࡪࡳࡷࡿࠧྍ"),l111lll_ll_ (u"࠭ࡣࡰࡷࡱࡸࡷࡿࠧྎ"),l111lll_ll_ (u"ࠧࡳࡧ࡯ࡩࡦࡹࡥ࠮ࡻࡨࡥࡷ࠭ྏ")]
l1l111ll1_ll_ = [l111lll_ll_ (u"ࠨࡥࡤࡸࡪ࡭࡯ࡳࡻࠪྐ"),l111lll_ll_ (u"ࠩࡦࡳࡺࡴࡴࡳࡻࠪྑ"),l111lll_ll_ (u"ࠪ࡫ࡪࡴࡲࡦࠩྒ"),l111lll_ll_ (u"ࠫࡷ࡫࡬ࡦࡣࡶࡩ࠲ࡿࡥࡢࡴࠪྒྷ"),l111lll_ll_ (u"ࠬࡲࡡ࡯ࡩࡸࡥ࡬࡫ࠧྔ"),l111lll_ll_ (u"࠭ࡱࡶࡣ࡯࡭ࡹࡿࠧྕ"),l111lll_ll_ (u"ࠧࡳࡣࡷࡩࠬྖ")]
def l1l11ll1l_ll_(url):
	l1l11l111_ll_ = l111lll_ll_ (u"ࠨ࠱ࡺࡴ࠲ࡩ࡯࡯ࡶࡨࡲࡹ࠵ࡴࡩࡧࡰࡩࡸ࠵ࡅ࡭ࡵ࡫ࡥ࡮ࡱࡨ࠳࠲࠵࠵࠴ࡇࡪࡢࡺࡤࡸ࠴ࡎ࡯࡮ࡧ࠲ࡊ࡮ࡲࡴࡦࡴ࡬ࡲ࡬ࡎ࡯࡮ࡧ࠱ࡴ࡭ࡶࠧྗ")
	url = url.replace(l111lll_ll_ (u"ࠩ࠲࠳࡬࡫ࡴࡱࡱࡶࡸࡸ࠭྘"),l1l11l111_ll_)
	url = url.replace(l111lll_ll_ (u"ࠪ࠳ࡨࡧࡴࡦࡩࡲࡶࡾ࠵วฯำ์ࠫྙ"),l111lll_ll_ (u"ࠫࠬྚ"))
	if l1l11l111_ll_ not in url: url = url+l1l11l111_ll_
	url = url.replace(l111lll_ll_ (u"ࠬࡸࡥ࡭ࡧࡤࡷࡪ࠳ࡹࡦࡣࡵࠫྛ"),l111lll_ll_ (u"࠭ࡹࡦࡣࡵࠫྜ"))
	url = url.replace(l111lll_ll_ (u"ࠧࡀࡁࠪྜྷ"),l111lll_ll_ (u"ࠨࡁࠪྞ"))
	url = url.replace(l111lll_ll_ (u"ࠩࠩࠪࠬྟ"),l111lll_ll_ (u"ࠪࠪࠬྠ"))
	url = url.replace(l111lll_ll_ (u"ࠫࡂࡃࠧྡ"),l111lll_ll_ (u"ࠬࡃࠧྡྷ"))
	#l1ll1l_ll_(l111lll_ll_ (u"࠭ࠧྣ"),l111lll_ll_ (u"ࠧࡑࡔࡈࡔࡆࡘࡅࡠࡈࡌࡐ࡙ࡋࡒࡠࡈࡌࡒࡆࡒ࡟ࡖࡔࡏࠫྤ"))
	return url
def l1l1l111_ll_(filters,mode):
	#l1ll1l_ll_(filters,l111lll_ll_ (u"ࠨࡋࡑࠤࠥࠦࠠࠨྥ")+mode)
	# mode==l111lll_ll_ (u"ࠩࡰࡳࡩ࡯ࡦࡪࡧࡧࡣࡻࡧ࡬ࡶࡧࡶࠫྦ")		l1ll1ll1_ll_ l1ll111l_ll_ empty values
	# mode==l111lll_ll_ (u"ࠪࡱࡴࡪࡩࡧ࡫ࡨࡨࡤ࡬ࡩ࡭ࡶࡨࡶࡸ࠭ྦྷ")		l1ll1ll1_ll_ l1ll111l_ll_ empty filters
	# mode==l111lll_ll_ (u"ࠫࡦࡲ࡬ࠨྨ")					all filters (l1l11l11_ll_ empty filter)
	filters = filters.strip(l111lll_ll_ (u"ࠬࠬࠦࠨྩ"))
	l1l1ll11_ll_,l1llll11_ll_ = {},l111lll_ll_ (u"࠭ࠧྪ")
	if l111lll_ll_ (u"ࠧ࠾࠿ࠪྫ") in filters:
		items = filters.split(l111lll_ll_ (u"ࠨࠨࠩࠫྫྷ"))
		for item in items:
			var,value = item.split(l111lll_ll_ (u"ࠩࡀࡁࠬྭ"))
			l1l1ll11_ll_[var] = value
	for key in l1l111ll1_ll_:
		if key in l1l1ll11_ll_.keys(): value = l1l1ll11_ll_[key]
		else: value = l111lll_ll_ (u"ࠪ࠴ࠬྮ")
		if l111lll_ll_ (u"ࠫࠪ࠭ྯ") not in value: value = l1lll111_ll_(value)
		if mode==l111lll_ll_ (u"ࠬࡳ࡯ࡥ࡫ࡩ࡭ࡪࡪ࡟ࡷࡣ࡯ࡹࡪࡹࠧྰ") and value!=l111lll_ll_ (u"࠭࠰ࠨྱ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠧࠡ࠭ࠣࠫྲ")+value
		elif mode==l111lll_ll_ (u"ࠨ࡯ࡲࡨ࡮࡬ࡩࡦࡦࡢࡪ࡮ࡲࡴࡦࡴࡶࠫླ") and value!=l111lll_ll_ (u"ࠩ࠳ࠫྴ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"ࠪࠪࠫ࠭ྵ")+key+l111lll_ll_ (u"ࠫࡂࡃࠧྶ")+value
		elif mode==l111lll_ll_ (u"ࠬࡧ࡬࡭ࠩྷ"): l1llll11_ll_ = l1llll11_ll_+l111lll_ll_ (u"࠭ࠦࠧࠩྸ")+key+l111lll_ll_ (u"ࠧ࠾࠿ࠪྐྵ")+value
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠨࠢ࠮ࠤࠬྺ"))
	l1llll11_ll_ = l1llll11_ll_.strip(l111lll_ll_ (u"ࠩࠩࠪࠬྻ"))
	#l1ll1l_ll_(l1llll11_ll_,l111lll_ll_ (u"ࠪࡓ࡚࡚ࠧྼ"))
	return l1llll11_ll_