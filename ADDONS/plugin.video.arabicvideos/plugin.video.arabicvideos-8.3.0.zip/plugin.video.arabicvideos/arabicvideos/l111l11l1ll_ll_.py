# coding: UTF-8
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
def l111l1l1ll1_ll_(url,data=l111lll_ll_ (u"ࠩࠪ❰"),headers=l111lll_ll_ (u"ࠪࠫ❱"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠫࠬ❲")):
	#url = url + l111lll_ll_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁ࡭ࡺࡴࡱ࠼࠲࠳࠶࠾࠸࠯࠳࠹࠺࠳࠻࠹࠯࠳࠺࠾࠽࠷࠱࠹ࠩ❳")
	proxies,timeout = {},40
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1ll1ll111l_ll_(url)
	#l1ll1l_ll_(l1ll111_ll_,l111lll_ll_ (u"࠭ࠧ❴"))
	#l1ll111_ll_ = l1lll111_ll_(l1ll111_ll_)
	html,code,reason,l111ll1l1ll_ll_ = None,None,None,l1ll111_ll_
	if l11lll1llll_ll_!=None:
		import socket
		l11l1l111ll_ll_ = socket.create_connection
		def l1lll11l11l_ll_(address,*args,**kwargs):
			host,port = address
			ip = l11l111l111_ll_(host,l11lll1llll_ll_)
			if ip: host = ip[0]
			address = (host,port)
			return l11l1l111ll_ll_(address,*args,**kwargs)
		socket.create_connection = l1lll11l11l_ll_
	if l11ll1ll11l_ll_!=None:
		if headers==l111lll_ll_ (u"ࠧࠨ❵"): headers = { l111lll_ll_ (u"ࠨࡗࡶࡩࡷ࠳ࡁࡨࡧࡱࡸࠬ❶") : l111lll_ll_ (u"ࠩࠪ❷") }
		elif l111lll_ll_ (u"࡙ࠪࡸ࡫ࡲ࠮ࡃࡪࡩࡳࡺࠧ❸") not in headers: headers[l111lll_ll_ (u"࡚ࠫࡹࡥࡳ࠯ࡄ࡫ࡪࡴࡴࠨ❹")] = l111lll_ll_ (u"ࠬ࠭❺")
		if l11ll1ll11l_ll_==l111lll_ll_ (u"࠭ࠧ❻"): l111ll111ll_ll_,l11ll1ll11l_ll_ = l111l1lllll_ll_()
		proxies = {l111lll_ll_ (u"ࠢࡩࡶࡷࡴࠧ❼"):l11ll1ll11l_ll_,l111lll_ll_ (u"ࠣࡪࡷࡸࡵࡹࠢ❽"):l11ll1ll11l_ll_}
		l111l1l1lll_ll_ = l11llll11l1_ll_.ProxyHandler(proxies)
		opener = l11llll11l1_ll_.build_opener(l111l1l1lll_ll_)
		l11llll11l1_ll_.install_opener(opener)
	l111lll_ll_ (u"ࠤࠥࠦࠒࠐࠉࡪࡨࠣࠤࠥࡶࡲࡰࡺࡼࡹࡷࡲ࠽࠾ࡐࡲࡲࡪࠦࡡ࡯ࡦࠣࡨࡳࡹࡵࡳ࡮ࡀࡁࡓࡵ࡮ࡦ࠼ࠣࡳࡵ࡫࡮ࡦࡴࠣࡁࠥࡻࡲ࡭࡮࡬ࡦ࠷࠴ࡢࡶ࡫࡯ࡨࡤࡵࡰࡦࡰࡨࡶ࠭࠯ࠍࠋࠋࡨࡰ࡮࡬ࠠࡱࡴࡲࡼࡾࡻࡲ࡭ࠣࡀࡒࡴࡴࡥࠡࡣࡱࡨࠥࡪ࡮ࡴࡷࡵࡰࡂࡃࡎࡰࡰࡨ࠾ࠥࡵࡰࡦࡰࡨࡶࠥࡃࠠࡶࡴ࡯ࡰ࡮ࡨ࠲࠯ࡤࡸ࡭ࡱࡪ࡟ࡰࡲࡨࡲࡪࡸࠨࡎࡻࡓࡶࡴࡾࡹࡉࡣࡱࡨࡱ࡫ࡲࠪࠏࠍࠍࡪࡲࡩࡧࠢࡳࡶࡴࡾࡹࡶࡴ࡯ࡁࡂࡔ࡯࡯ࡧࠣࡥࡳࡪࠠࡥࡰࡶࡹࡷࡲࠡ࠾ࡐࡲࡲࡪࡀࠠࡰࡲࡨࡲࡪࡸࠠ࠾ࠢࡸࡶࡱࡲࡩࡣ࠴࠱ࡦࡺ࡯࡬ࡥࡡࡲࡴࡪࡴࡥࡳࠪࡐࡽࡍ࡚ࡔࡑࡕࡋࡥࡳࡪ࡬ࡦࡴ࠯ࡑࡾࡎࡔࡕࡒࡋࡥࡳࡪ࡬ࡦࡴࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡵࡸ࡯ࡹࡻࡸࡶࡱࠧ࠽ࡏࡱࡱࡩࠥࡧ࡮ࡥࠢࡧࡲࡸࡻࡲ࡭ࠣࡀࡒࡴࡴࡥ࠻ࠢࡲࡴࡪࡴࡥࡳࠢࡀࠤࡺࡸ࡬࡭࡫ࡥ࠶࠳ࡨࡵࡪ࡮ࡧࡣࡴࡶࡥ࡯ࡧࡵࠬࡒࡿࡐࡳࡱࡻࡽࡍࡧ࡮ࡥ࡮ࡨࡶ࠱ࡓࡹࡉࡖࡗࡔࡘࡎࡡ࡯ࡦ࡯ࡩࡷ࠲ࡍࡺࡊࡗࡘࡕࡎࡡ࡯ࡦ࡯ࡩࡷ࠯ࠍࠋࠋࠦࡳࡱࡪ࡟ࡰࡲࡨࡲࡪࡸࠠ࠾ࠢࡸࡶࡱࡲࡩࡣ࠴࠱ࡣࡴࡶࡥ࡯ࡧࡵࠑࠏࠏࡵࡳ࡮࡯࡭ࡧ࠸࠮ࡪࡰࡶࡸࡦࡲ࡬ࡠࡱࡳࡩࡳ࡫ࡲࠩࡱࡳࡩࡳ࡫ࡲࠪࠏࠍࠍࠧࠨࠢ❾")
	if   headers==l111lll_ll_ (u"ࠪࠫ❿"): headers = {}
	if   data==l111lll_ll_ (u"ࠫࠬ➀"): request = l11llll11l1_ll_.Request(l1ll111_ll_,headers=headers)
	elif data!=l111lll_ll_ (u"ࠬ࠭➁"): request = l11llll11l1_ll_.Request(l1ll111_ll_,headers=headers,data=data)
	l111lll_ll_ (u"ࠨࠢࠣࠏࠍࠍ࡮࡬ࠠࠡࠢࡧࡥࡹࡧ࠽࠾ࠩࠪࠤࡦࡴࡤࠡࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡀࠫࠬࡀࠠࡳࡧࡴࡹࡪࡹࡴࠡ࠿ࠣࡹࡷࡲ࡬ࡪࡤ࠵࠲ࡗ࡫ࡱࡶࡧࡶࡸ࠭ࡻࡲ࡭࠴ࠬࠑࠏࠏࡥ࡭࡫ࡩࠤࡩࡧࡴࡢ࠿ࡀࠫࠬࠦࡡ࡯ࡦࠣ࡬ࡪࡧࡤࡦࡴࡶࠥࡂ࠭ࠧ࠻ࠢࡵࡩࡶࡻࡥࡴࡶࠣࡁࠥࡻࡲ࡭࡮࡬ࡦ࠷࠴ࡒࡦࡳࡸࡩࡸࡺࠨࡶࡴ࡯࠶࠱࡮ࡥࡢࡦࡨࡶࡸࡃࡨࡦࡣࡧࡩࡷࡹࠩࠎࠌࠌࡩࡱ࡯ࡦࠡࡦࡤࡸࡦࠧ࠽ࠨࠩࠣࡥࡳࡪࠠࡩࡧࡤࡨࡪࡸࡳ࠾࠿ࠪࠫ࠿ࠦࡲࡦࡳࡸࡩࡸࡺࠠ࠾ࠢࡸࡶࡱࡲࡩࡣ࠴࠱ࡖࡪࡷࡵࡦࡵࡷࠬࡺࡸ࡬࠳࠮ࡧࡥࡹࡧ࠽ࡥࡣࡷࡥ࠮ࠓࠊࠊࡧ࡯࡭࡫ࠦࡤࡢࡶࡤࠥࡂ࠭ࠧࠡࡣࡱࡨࠥ࡮ࡥࡢࡦࡨࡶࡸࠧ࠽ࠨࠩ࠽ࠤࡷ࡫ࡱࡶࡧࡶࡸࠥࡃࠠࡶࡴ࡯ࡰ࡮ࡨ࠲࠯ࡔࡨࡵࡺ࡫ࡳࡵࠪࡸࡶࡱ࠸ࠬࡩࡧࡤࡨࡪࡸࡳ࠾ࡪࡨࡥࡩ࡫ࡲࡴ࠮ࡧࡥࡹࡧ࠽ࡥࡣࡷࡥ࠮ࠓࠊࠊࠤࠥࠦ➂")
	try:
		if l11ll1ll11l_ll_!=None or l11lll1llll_ll_!=None or l11l1llll1l_ll_!=None:
			# if l111llll1_ll_ proxies l1ll1l11l1l_ll_ timeout=10
			if l1ll111_ll_==l111lll_ll_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡹࡺࡻ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮ࠩ➃"): timeout = 10
			response = l11llll11l1_ll_.urlopen(request,timeout=timeout)
		else:
			#ctx = ssl.create_default_context()
			#ctx.check_hostname = False
			#ctx.verify_mode = ssl.CERT_NONE
			#ctx = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
			ctx = ssl._create_unverified_context()
			response = l11llll11l1_ll_.urlopen(request,timeout=timeout,context=ctx)
		#l11llll11l1_ll_.install_opener(l111llll1l1_ll_)
		code = response.code
		reason = response.msg
		html = response.read()
		#final_url = response.url
		response.close
		# error code
		#		code = response.code
		#		code = response.getcode()
		# final url l1ll11l111_ll_ all l111lllllll_ll_
		#		l111ll1l1ll_ll_ = response.geturl()
		#		l111ll1l1ll_ll_ = response.url
		# headers & cookies
		#		headers = response.headers
		#		headers = response.info()
	except Exception as e:
		#xbmc.log(str(dir(e)), level=xbmc.LOGNOTICE)
		#xbmc.log(str(url), level=xbmc.LOGNOTICE)
		#xbmc.log(str(data), level=xbmc.LOGNOTICE)
		#xbmc.log(str(headers), level=xbmc.LOGNOTICE)
		#l1ll1l_ll_(url,l111lll_ll_ (u"ࠨࠩ➄"))
		#final_url = response.url
		if l111lll_ll_ (u"ࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬ➅") not in l1ll111_ll_:
			traceback.print_exc(file=sys.stderr)
		if l111lll_ll_ (u"ࠪࡸ࡮ࡳࡥࡰࡷࡷࠫ➆") in str(type(e)).lower():
			code = -1
			reason = e.message
		elif l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡧࡵࡶࡴࡸࠧ➇") in str(type(e)).lower():
			code = e.code
			reason = e.reason
		# l111lll_ll_ (u"ࠬࡹ࡯ࡤ࡭ࡨࡸࠬ➈") errors l111l11ll11_ll_ l111l11lll1_ll_ l111lll1111_ll_ l111lll_ll_ (u"࠭ࡵࡳ࡮ࡨࡶࡷࡵࡲࠨ➉") errors
		elif hasattr(e,l111lll_ll_ (u"ࠧࡳࡧࡤࡷࡴࡴࠧ➊")) and l111lll_ll_ (u"ࠨࡵࡲࡧࡰ࡫ࡴࠨ➋") in str(type(e.reason)).lower():
			code = e.reason.errno
			reason = e.reason.strerror
		elif l111lll_ll_ (u"ࠩࡸࡶࡱ࡫ࡲࡳࡱࡵࠫ➌") in str(type(e)).lower():
			code = e.errno
			reason = e.reason
		if code==None:
			code = -1
		if reason==None:
			reason = l111lll_ll_ (u"࡙ࠪࡳࡱ࡮ࡰࡹࡱࠤࡪࡸࡲࡰࡴࠣࠬࠥࡘࡡࡪࡵࡨࡨࠥࡨࡹ࠻ࠢࠪ➍")
			try: reason += e.__class__.__module__
			except: reason += l111lll_ll_ (u"࡚ࠫࡴ࡫࡯ࡱࡺࡲࡒࡵࡤࡶ࡮ࡨࠫ➎")
			try: reason += l111lll_ll_ (u"ࠬ࠴ࠧ➏")+e.__class__.__name__
			except: reason += l111lll_ll_ (u"࠭࠮ࡖࡰ࡮ࡲࡴࡽ࡮ࡄ࡮ࡤࡷࡸ࠭➐")
			reason += l111lll_ll_ (u"ࠧࠡࠫࠪ➑")
		if html==None:
			if hasattr(e,l111lll_ll_ (u"ࠨࡴࡨࡥࡩ࠭➒")): html = e.read()
			else: html = l111lll_ll_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥ࠺ࠨ➓")+str(code)+l111lll_ll_ (u"ࠪ࠾ࠬ➔")+str(reason)
	l1l1l111lll_ll_ = html.lower()
	l1l11l11l1l_ll_ = (code!=200 and int(code/100)*100!=300)
	l1l11l11ll1_ll_ = (l111lll_ll_ (u"ࠫࡨࡲ࡯ࡶࡦࡩࡰࡦࡸࡥࠨ➕") in l1l1l111lll_ll_ and l111lll_ll_ (u"ࠬࡸࡡࡺࠢ࡬ࡨ࠿ࠦࠧ➖") in l1l1l111lll_ll_)
	l1l111111ll_ll_ = (l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ➗") in l1l1l111lll_ll_)
	l1111lllll1_ll_ = (l111lll_ll_ (u"ࠧ࠶ࠢࡶࡩࡨ࠭➘") in l1l1l111lll_ll_)
	if l1l11l11l1l_ll_ or l1l11l11ll1_ll_ or l1l111111ll_ll_ or l1111lllll1_ll_:
		if l1l11l11ll1_ll_:
			l11llll11ll_ll_ = l111lll_ll_ (u"ࠨࡄ࡯ࡳࡨࡱࡥࡥࠢࡥࡽࠥࡉ࡬ࡰࡷࡧࡪࡱࡧࡲࡦࠩ➙")
			if l111lll_ll_ (u"ࠩࡵࡩࡨࡧࡰࡵࡥ࡫ࡥࠬ➚") in l1l1l111lll_ll_: l11llll11ll_ll_ += l111lll_ll_ (u"ࠪࠤ࡚ࡹࡩ࡯ࡩࠣࡋࡴࡵࡧ࡭ࡧࠣࡶࡪࡉࡁࡑࡖࡆࡌࡆ࠭➛")
			reason = l11llll11ll_ll_+l111lll_ll_ (u"ࠫࠥ࠮ࠠࠨ➜")+reason+l111lll_ll_ (u"ࠬࠦࠩࠨ➝")
		elif l1111lllll1_ll_:
			l111l1l1l1l_ll_ = l111lll_ll_ (u"࠭ࡂ࡭ࡱࡦ࡯ࡪࡪࠠࡣࡻࠣ࠹ࠥࡹࡥࡤࡱࡱࡨࡸࠦࡢࡳࡱࡺࡷࡪࡸࠠࡤࡪࡨࡧࡰ࠭➞")
			reason = l111l1l1l1l_ll_+l111lll_ll_ (u"ࠧࠡࠪࠣࠫ➟")+reason+l111lll_ll_ (u"ࠨࠢࠬࠫ➠")
		html = l111lll_ll_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥ࠺ࠨ➡")+str(code)+l111lll_ll_ (u"ࠪ࠾ࠬ➢")+reason
		message,send,l1111l1l11_ll_ = l111lll_ll_ (u"ࠫࠬ➣"),l111lll_ll_ (u"ࠬࡴ࡯ࠨ➤"),False
		l111lll_ll_ (u"ࠨࠢࠣࠏࠍࠍࠎ࡯ࡦࠡࠩࡪࡳࡴ࡭࡬ࡦ࠯ࡤࡲࡦࡲࡹࡵ࡫ࡦࡷࠬࠦࡩ࡯ࠢࡸࡶࡱ࠸࠺ࠡࡵࡨࡲࡩࠦ࠽ࠡࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸࠓࠊࠊࠋ࡬ࡪࠥࡹࡨࡰࡹࡇ࡭ࡦࡲ࡯ࡨࡵࡀࡁࠬࡿࡥࡴࠩ࠽ࠑࠏࠏࠉࠊࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࠬิืฤࠢไ๎ࠥอไศฬุห้࠭ࠬࡩࡶࡰࡰ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦࡣࡰࡦࡨࡁࡂ࠻࠰࠳ࠢࡲࡶࠥࡩ࡯ࡥࡧࡀࡁ࠼ࡀࠍࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋ࡚ࠩࠩࡩࡧࡹࡩࡵࡧࠣ࡭ࡸࠦ࡮ࡰࡶࠣࡥࡻࡧࡩ࡭ࡣࡥࡰࡪ࠭ࠬࠨๆสࠤ๏๋ใ็ࠢส่ํ฻่ๅࠢส่๎ࠦวๅ็๋ๆ฾่ࠦศๆึฬอࠦโะࠢํ็ํ์ࠠๆ่ࠣะ์อาไࠢส์๋ࠥๆࠡษ็ห๋ะั็์อࠤฬ๊ฮศืฬࠤอ้ࠠศ๊้๋ࠣࠦวๅ็๋ๆ฾ࠦใ้่๊ࠤ๊เไใࠢ็ฺ่๐ว็หࠣหํࠦวๅฬะำ๏ัࠠๅาสࠤ๏ืฬ๊ࠢส่๊ำว้ๆฬࠤ้ออใษࠪ࠭ࠒࠐࠉࠊࠋࠌࡷࡪࡴࡤࠡ࠿ࠣࠫࡳࡵࠧࠎࠌࠌࠍࠎ࡫࡬ࡪࡨࠣࡧࡴࡪࡥ࠾࠿࠷࠴࠹ࡀࠍࠋࠋࠌࠍࠎࡊࡉࡂࡎࡒࡋࡤࡕࡋࠩࠩࡉ࡭ࡱ࡫ࠠ࡯ࡱࡷࠤ࡫ࡵࡵ࡯ࡦࠪ࠰ࠬอไๆๆไࠤ฿๐ัࠡ็๋ะํี้ࠠษ็ือฮࠠ฻ษ็ฬฬࠦ็้่๊ࠢࠥอไๆืาีࠥ๎ๅ็ࠢส่๊๎โฺࠢส่ฬ฻ไ๋ࠢส่ี๐๋ࠠ฼ำ๎ࠥํะศࠢส่อืๆศ็ฯࠫ࠮ࠓࠊࠊࠋࠌ࡭࡫ࠦࡳࡦࡰࡧࡁࡂ࠭ࡹࡦࡵࠪ࠾ࠒࠐࠉࠊࠋࠌࡽࡪࡹࠠ࠾ࠢࡇࡍࡆࡒࡏࡈࡡ࡜ࡉࡘࡔࡏࠩࠩึศฬ๊๊่ࠧ࠭ࠩࠥะัษัࠣห฻อแสࠢิืฬ๊ษࠡ็฼ࠤฬ๊ฮุล่่ࠣ๐ࠠหึิัࠥ็๊่ษࠣ็๏็้ࠠษํ๊ࠥำีๅࠢส่ำ฽ร๊ࠡอีุ๊ࠠศๆอๅฬ฻๊ๅࠢส่๎ࠦวๅ็หี๊าࠠภࠩ࠯ࠫࠬ࠲ࠧࠨ࠮ࠪ็้อ้ࠧ࠭ࠩ฽๊࠭ࠩࠎࠌࠌࠍࠎࠏࡩࡧࠢࡼࡩࡸࡀࠠ࡮ࡧࡶࡷࡦ࡭ࡥࠡ࠿ࠣࠫࠥࡢ࡜࡯࡞࡟ࡲࠬࠦࠫࠡࡍࡈ࡝ࡇࡕࡁࡓࡆࠫࠫ࡜ࡸࡩࡵࡧࠣࡥࠥࡳࡥࡴࡵࡤ࡫ࡪࠦࠠࠡษๆฮอࠦัิษ็อࠬ࠯ࠍࠋࠋࠌ࡭࡫ࠦࡳࡦࡰࡧࡁࡂ࠭ࡹࡦࡵࠪ࠾࡙ࠥࡅࡏࡆࡢࡉࡒࡇࡉࡍࠪࠪࡉࡷࡸ࡯ࡳ࠼ࠣࡊࡷࡵ࡭ࠡࡃࡵࡥࡧ࡯ࡣࠡࡘ࡬ࡨࡪࡵࡳࠨ࠮࡫ࡸࡲࡲࠫ࡮ࡧࡶࡷࡦ࡭ࡥ࠭ࡵ࡫ࡳࡼࡊࡩࡢ࡮ࡲ࡫ࡸ࠲ࡵࡳ࡮࠯ࡷࡴࡻࡲࡤࡧࠬࠑࠏࠏࠉࠣࠤࠥ➥")
		#if l111lll_ll_ (u"ࠧࡨࡱࡲ࡫ࡱ࡫࠭ࡢࡰࡤࡰࡾࡺࡩࡤࡵࠪ➦") not in url:
		#if code==502:
		#	l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭➧"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤ࡛ࠥࡒࡍࠢࡔࡹࡴࡺࡥࠡࡇࡵࡶࡴࡸࠠࠡࠢࡆࡳࡩ࡫࠺ࠡ࡝ࠣࠫ➨")+str(code)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ➩")+reason+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭➪")+source+l111lll_ll_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ➫")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡋ࡯࡮ࡢ࡮࡙ࠣࡗࡒ࠺ࠡ࡝ࠣࠫ➬")+final_url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ➭"))
		#	html = l111l1lll11_ll_(final_url,data,headers,l1111l1l11_ll_,source)
		#	return html
		if code in [7,11001,10054] and l11lll1llll_ll_==None:
			l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭➮"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡊࡎࡔࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭➯")+str(code)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ➰")+reason+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭➱")+source+l111lll_ll_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ➲")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠩ➳"))
			url = url+l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡉࡔࡓࡖࡴ࡯ࡁࠬ➴")
			html = l111l1lll11_ll_(url,data,headers,l1111l1l11_ll_,source)
			return html
		if code==8 and l11l1llll1l_ll_==None:
			l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭➵"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤ࡙ࠥࡓࡍࠢࡉࡥ࡮ࡲࡥࡥࠢࠣࠤࡈࡵࡤࡦ࠼ࠣ࡟ࠥ࠭➶")+str(code)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮࠻ࠢ࡞ࠤࠬ➷")+reason+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭➸")+source+l111lll_ll_ (u"ࠬࠦ࡝࡙ࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ➹")+url+l111lll_ll_ (u"࠭ࠠ࡞ࠩ➺"))
			url = url+l111lll_ll_ (u"ࠧࡽࡾࡐࡽࡘ࡙ࡌࡖࡴ࡯ࡁࠬ➻")
			html = l111l1lll11_ll_(url,data,headers,l1111l1l11_ll_,source)
			return html
		else:
			l1111l1l_ll_(l111lll_ll_ (u"ࠨࡇࡕࡖࡔࡘ࡟ࡍࡋࡑࡉࡘ࠭➼"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠩࠣࠤࠥࡌࡡࡪ࡮ࡨࡨࠥࡕࡰࡦࡰ࡬ࡲ࡬ࠦࡕࡓࡎࠣࠤࠥࡉ࡯ࡥࡧ࠽ࠤࡠࠦࠧ➽")+str(code)+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡔࡨࡥࡸࡵ࡮ࠡ࠼࡞ࠤࠬ➾")+reason+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼ࠣ࡟ࠥ࠭➿")+source+l111lll_ll_ (u"ࠬࠦ࡝ࠨ⟀")+l111lll_ll_ (u"࠭ࠠࠡࠢࡘࡖࡑࡀࠠ࡜ࠢࠪ⟁")+url+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⟂"))
		l11l1llll11_ll_(source,code,reason)
	#l1ll1l_ll_(l111lll_ll_ (u"ࠨࠩ⟃"),html)
	return html
def l111ll1lll1_ll_(url,data=l111lll_ll_ (u"ࠩࠪ⟄"),headers=l111lll_ll_ (u"ࠪࠫ⟅"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠫࠬ⟆")):
	html = l111ll1l1l1_ll_(url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳࡯ࡱࡧࡱ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘࡊࡇࡖ࠱࠶ࡹࡴࠨ⟇"))
	if l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ⟈") in html:
		html = l111llll11l_ll_(url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡱࡳࡩࡳ࡛ࡒࡍࡡ࡚ࡉࡇࡖࡒࡐ࡚ࡌࡉࡘ࠳࠲࡯ࡦࠪ⟉"))
		if l111lll_ll_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤ࠭⟊") in html:
			reason = l111lll_ll_ (u"࡚ࠩࡩࡧࠦࡐࡳࡱࡻࡽࠥ࡬ࡡࡪ࡮ࡨࡨࠬ⟋")
			code = -1
			l1111l1l_ll_(l111lll_ll_ (u"ࠪࡉࡗࡘࡏࡓࡡࡏࡍࡓࡋࡓࠨ⟌"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠫࠥࠦࠠࡇࡣ࡬ࡰࡪࡪࠠࡰࡲࡨࡲ࡮ࡴࡧࠡࡷࡵࡰࠥࠦࠠࡄࡱࡧࡩ࠿࡛ࠦࠡࠩ⟍")+str(code)+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡖࡪࡧࡳࡰࡰ࠽ࠤࡠࠦࠧ⟎")+reason+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡘࡵࡵࡳࡥࡨ࠾ࠥࡡࠠࠨ⟏")+source+l111lll_ll_ (u"ࠧࠡ࡟ࠪ⟐")+l111lll_ll_ (u"ࠨࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⟑")+url+l111lll_ll_ (u"ࠩࠣࡡࠬ⟒"))
			l11l1llll11_ll_(source,code,reason)
	return html
def l111l1ll1l1_ll_(url,data=l111lll_ll_ (u"ࠪࠫ⟓"),headers=l111lll_ll_ (u"ࠫࠬ⟔"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠬ࠭⟕")):
	#html = l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ⟖")
	if source==l111lll_ll_ (u"ࠧࡔࡇࡕ࡚ࡎࡉࡅࡔ࠯ࡗࡉࡘ࡚࡟ࡂࡎࡏࡣ࡜ࡋࡂࡔࡋࡗࡉࡘ࠳࠲࡯ࡦࠪ⟗"): html = l111lll_ll_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤ࠭⟘")
	else: html = l111ll1_ll_(l1l11lll_ll_,url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡳࡵ࡫࡮ࡖࡔࡏࡣࡕࡘࡏ࡙࡛࠰࠵ࡸࡺࠧ⟙"))
	if l111lll_ll_ (u"ࠪࡣࡤࡥࡅࡳࡴࡲࡶࡤࡥ࡟ࠨ⟚") in html:
		html = l111ll1ll1l_ll_(url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡵࡰࡦࡰࡘࡖࡑࡥࡐࡓࡑ࡛࡝࠲࠸࡮ࡥࠩ⟛"))
		if l111lll_ll_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ⟜") in html:
			html = l111ll1lll1_ll_(url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡰࡲࡨࡲ࡚ࡘࡌࡠࡒࡕࡓ࡝࡟࠭࠴ࡴࡧࠫ⟝"))
			if l111lll_ll_ (u"ࠧࡠࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࡣࠬ⟞") in html:
				reason = l111lll_ll_ (u"ࠨࡒࡵࡳࡽࡿࠠࡧࡣ࡬ࡰࡪࡪࠧ⟟")
				code = -1
				l1111l1l_ll_(l111lll_ll_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ⟠"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦ࡯ࡱࡧࡱ࡭ࡳ࡭ࠠࡶࡴ࡯ࠤࠥࠦࡃࡰࡦࡨ࠾ࠥࡡࠠࠨ⟡")+str(code)+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢࡕࡩࡦࡹ࡯࡯࠼ࠣ࡟ࠥ࠭⟢")+reason+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡗࡴࡻࡲࡤࡧ࠽ࠤࡠࠦࠧ⟣")+source+l111lll_ll_ (u"࠭ࠠ࡞ࠩ⟤")+l111lll_ll_ (u"࡙ࠧࠡࠢࠣࡗࡒ࠺ࠡ࡝ࠣࠫ⟥")+url+l111lll_ll_ (u"ࠨࠢࡠࠫ⟦"))
				l11l1llll11_ll_(source,code,reason)
	return html
def l111ll1ll1l_ll_(url,data=l111lll_ll_ (u"ࠩࠪ⟧"),headers=l111lll_ll_ (u"ࠪࠫ⟨"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠫࠬ⟩")):
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1ll1ll111l_ll_(url)
	if l11ll1ll11l_ll_==None: url = url+l111lll_ll_ (u"ࠬࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ⟪")
	html = l111ll1_ll_(l1l11lll_ll_,url,data,headers,l1111l1l11_ll_,l111lll_ll_ (u"࠭ࡌࡊࡄࡕࡅࡗ࡟࠭ࡰࡲࡨࡲ࡚ࡘࡌࡠࡊࡗࡘࡕ࡙ࡐࡓࡑ࡛ࡍࡊ࡙࠭࠲ࡵࡷࠫ⟫"))
	if l111lll_ll_ (u"ࠧࡠࡡࡢࡉࡷࡸ࡯ࡳࡡࡢࡣࠬ⟬") in html: code = int(html.split(l111lll_ll_ (u"ࠨ࠼ࠪ⟭"))[1])
	else: code = 200
	if code!=200 and int(code/100)*100!=300:
		source = l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡳࡵ࡫࡮ࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ⟮")
		reason = l111lll_ll_ (u"ࠪࡌ࡙࡚ࡐࡔࠢࡳࡶࡴࡾࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠨ⟯")
		code = -1
		l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⟰"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡱࡳࡩࡳ࡯࡮ࡨࠢࡸࡶࡱࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ⟱")+str(code)+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ⟲")+reason+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ⟳")+source+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡕࡓࡎ࠽ࠤࡠࠦࠧ⟴")+url+l111lll_ll_ (u"ࠩࠣࡡࠬ⟵"))
		html = l111lll_ll_ (u"ࠪࡣࡤࡥࡅࡳࡴࡲࡶࡤࡥ࡟࠻ࠩ⟶")+str(code)+l111lll_ll_ (u"ࠫ࠿࠭⟷")+reason
	return html
def l111ll1l1l1_ll_(url,data=l111lll_ll_ (u"ࠬ࠭⟸"),headers=l111lll_ll_ (u"࠭ࠧ⟹"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠧࠨ⟺")):
	# Proxy + l111l1l111l_ll_
	# http://l1111llll1l_ll_.to		http://69.64.52.22
	# cookie will l111l1l11l1_ll_ l1ll11l111_ll_ 30 l111l111l11_ll_ (l1ll1ll1_ll_ if not l1l1lll111l_ll_ l111l1lll1l_ll_ these 30 minutes)
	response = l111111_ll_(l1l1l11ll1l_ll_,l111lll_ll_ (u"ࠨࡉࡈࡘࠬ⟻"), l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱ࡺࡩࡧࡶࡲࡰࡺࡼ࠲ࡹࡵࠧ⟼"),l111lll_ll_ (u"ࠪࠫ⟽"),l111lll_ll_ (u"ࠫࠬ⟾"),False,False,l111lll_ll_ (u"ࠬࡒࡉࡃࡔࡄࡖ࡞࠳࡯ࡱࡧࡱ࡙ࡗࡒ࡟ࡘࡇࡅࡔࡗࡕࡘ࡚ࡖࡒ࠱࠶ࡹࡴࠨ⟿"))
	l1l111l1_ll_ = response.content
	cookies = response.cookies.get_dict()
	s = cookies[l111lll_ll_ (u"࠭ࡳࠨ⠀")]
	l111l1111l1_ll_ = l111lll_ll_ (u"ࠧࡴ࠿ࠪ⠁") + s
	l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠨࡅࡲࡳࡰ࡯ࡥࠨ⠂") : l111l1111l1_ll_ }
	if headers==l111lll_ll_ (u"ࠩࠪ⠃"): l111l11llll_ll_ = {}
	else: l111l11llll_ll_ = headers
	if l111lll_ll_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ⠄") in l111l11llll_ll_: l111l11llll_ll_[l111lll_ll_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ⠅")] += l111lll_ll_ (u"ࠬࡁࠧ⠆") + l111l1111l1_ll_
	else: l111l11llll_ll_[l111lll_ll_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭⠇")] = l111l1111l1_ll_
	html = l111ll1_ll_(l1l11lll_ll_,l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯ࡸࡧࡥࡴࡷࡵࡸࡺ࠰ࡷࡳ࠴ࡨࡲࡰࡹࡶࡩ࠳ࡶࡨࡱࡁࡸࡁࠬ⠈")+l1lll111_ll_(url)+l111lll_ll_ (u"ࠨࠨࡥࡁ࠶࠸࠸ࠨ⠉"),data,l111l11llll_ll_,l1111l1l11_ll_,l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡳࡵ࡫࡮ࡖࡔࡏࡣ࡜ࡋࡂࡑࡔࡒ࡜࡞࡚ࡏ࠮࠴ࡱࡨࠬ⠊"))
	html = l1111_ll_(html).replace(l111lll_ll_ (u"ࠪ࠳ࡧࡸ࡯ࡸࡵࡨ࠲ࡵ࡮ࡰࡀࡷࡀࠫ⠋")+url,l111lll_ll_ (u"ࠫࠬ⠌")).replace(l111lll_ll_ (u"ࠬ࠵ࡢࡳࡱࡺࡷࡪ࠴ࡰࡩࡲࡂࡹࡂ࠭⠍"),l111lll_ll_ (u"࠭ࠧ⠎")).replace(l111lll_ll_ (u"ࠧࠧࡣࡰࡴࡀࡨ࠽࠲࠴࠻ࠫ⠏"),l111lll_ll_ (u"ࠨࠩ⠐"))
	#xbmc.log(html, level=xbmc.LOGNOTICE)
	if l111lll_ll_ (u"ࠩ࠿ࠥ࠲࠳ࠠࡄࡑࡑࡘࡊࡔࡔࠡࡕࡗࡅࡗ࡚ࠠ࠮࠯ࡁࠫ⠑").lower() in html.lower() or l111lll_ll_ (u"ࠪࡣࡤࡥࡅࡳࡴࡲࡶࡤࡥ࡟ࠨ⠒") in html:
		source = l111lll_ll_ (u"ࠫࡑࡏࡂࡓࡃࡕ࡝࠲ࡵࡰࡦࡰࡘࡖࡑࡥࡗࡆࡄࡓࡖࡔ࡞࡙ࡕࡑ࠰࠸ࡹ࡮ࠧ⠓")
		reason = l111lll_ll_ (u"ࠬ࡝ࡅࡃࡒࡕࡓ࡝࡟ࡔࡐࠢࡳࡶࡴࡾࡹࠡࡨࡤ࡭ࡱ࡫ࡤࠨ⠔")
		code = -1
		l1111l1l_ll_(l111lll_ll_ (u"࠭ࡅࡓࡔࡒࡖࡤࡒࡉࡏࡇࡖࠫ⠕"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠧࠡࠢࠣࡊࡦ࡯࡬ࡦࡦࠣࡳࡵ࡫࡮ࡪࡰࡪࠤࡺࡸ࡬ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ⠖")+str(code)+l111lll_ll_ (u"ࠨࠢࡠࠤࠥࠦࡒࡦࡣࡶࡳࡳࡀࠠ࡜ࠢࠪ⠗")+reason+l111lll_ll_ (u"ࠩࠣࡡࠥࠦࠠࡔࡱࡸࡶࡨ࡫࠺ࠡ࡝ࠣࠫ⠘")+source+l111lll_ll_ (u"ࠪࠤࡢࠦࠠࠡࡗࡕࡐ࠿࡛ࠦࠡࠩ⠙")+url+l111lll_ll_ (u"ࠫࠥࡣࠧ⠚"))
		html = l111lll_ll_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡ࠽ࠫ⠛")+str(code)+l111lll_ll_ (u"࠭࠺ࠨ⠜")+reason
	return html
def l111llll11l_ll_(url,data=l111lll_ll_ (u"ࠧࠨ⠝"),headers=l111lll_ll_ (u"ࠨࠩ⠞"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠩࠪ⠟")):
	# Proxy + l111l1l111l_ll_
	# http://l111llllll1_ll_.l1lll1l11_ll_			http://37.187.147.158
	# cookie l1ll1l11l1_ll_ not l111l1l11l1_ll_ (l111l1l1l11_ll_ for 3 days)
	# servers will l111l1l11l1_ll_ l1ll11l111_ll_ 20 l111l111l11_ll_ (even if l1l1lll111l_ll_ l111l1lll1l_ll_ these 20 minutes)
	response = l111111_ll_(l11l1l_ll_,l111lll_ll_ (u"ࠪࡋࡊ࡚ࠧ⠠"), l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡰࡶࡲࡰࡺࡼ࠲ࡨࡵ࡭ࠨ⠡"),l111lll_ll_ (u"ࠬ࠭⠢"),l111lll_ll_ (u"࠭ࠧ⠣"),False,False,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡱࡳࡩࡳ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠷ࡳࡵࠩ⠤"))
	l1l111l1_ll_ = response.content
	cookies = response.cookies.get_dict()
	l111lll1l1l_ll_ = cookies[l111lll_ll_ (u"ࠨࡍࡓࡣࡉࡇࡔ࠳ࡡࡢࠫ⠥")]
	l111l1111l1_ll_ = l111lll_ll_ (u"ࠩࡎࡔࡤࡊࡁࡕ࠴ࡢࡣࡂ࠭⠦") + l111lll1l1l_ll_
	l1ll11l1l_ll_ = { l111lll_ll_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ⠧") : l111l1111l1_ll_ }
	#payload = { l111lll_ll_ (u"ࠫࡵࡧࡧࡦࠩ⠨") : l1lll111_ll_(url) }
	#data2 = l1lll11ll_ll_(payload)
	l1l111l1_ll_ = l111ll1_ll_(l1l1l11ll1l_ll_,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴ࡱࡰࡳࡱࡻࡽ࠳ࡩ࡯࡮࠱ࡧࡳࡵࡸ࡯ࡹࡻ࠱࡮ࡸࡶ࠿ࡱࡣࡪࡩࡂ࠭⠩")+l1lll111_ll_(url),l111lll_ll_ (u"࠭ࠧ⠪"),l1ll11l1l_ll_,False,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡱࡳࡩࡳ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠸࡮ࡥࠩ⠫"))
	l111ll11lll_ll_ = re.findall(l111lll_ll_ (u"ࠨࡷࡵࡰࡂ࠮࠮ࠫࡁࠬࠦࠬ⠬"),l1l111l1_ll_,re.DOTALL)
	if l111ll11lll_ll_:
		l111ll11lll_ll_ = l111ll11lll_ll_[0]
		if headers==l111lll_ll_ (u"ࠩࠪ⠭"): l111l11llll_ll_ = {}
		else: l111l11llll_ll_ = headers
		if l111lll_ll_ (u"ࠪࡇࡴࡵ࡫ࡪࡧࠪ⠮") in l111l11llll_ll_: l111l11llll_ll_[l111lll_ll_ (u"ࠫࡈࡵ࡯࡬࡫ࡨࠫ⠯")] += l111lll_ll_ (u"ࠬࡁࠧ⠰") + l111l1111l1_ll_
		else: l111l11llll_ll_[l111lll_ll_ (u"࠭ࡃࡰࡱ࡮࡭ࡪ࠭⠱")] = l111l1111l1_ll_
		html = l111ll1_ll_(l1l11lll_ll_,l111ll11lll_ll_,data,l111l11llll_ll_,l1111l1l11_ll_,l111lll_ll_ (u"ࠧࡍࡋࡅࡖࡆࡘ࡙࠮ࡱࡳࡩࡳ࡛ࡒࡍࡡࡎࡔࡗࡕࡘ࡚ࡅࡒࡑ࠲࠹ࡲࡥࠩ⠲"))
	else:	#if not l111ll11lll_ll_:# or l111lll_ll_ (u"ࠨ࡭ࡳࡶࡴࡾࡹ࠯ࡥࡲࡱࠬ⠳").lower() not in html.lower():
		source = l111lll_ll_ (u"ࠩࡏࡍࡇࡘࡁࡓ࡛࠰ࡳࡵ࡫࡮ࡖࡔࡏࡣࡐࡖࡒࡐ࡚࡜ࡇࡔࡓ࠭࠵ࡶ࡫ࠫ⠴")
		reason = l111lll_ll_ (u"ࠪࡏࡕࡘࡏ࡙࡛ࡆࡓࡒࠦࡰࡳࡱࡻࡽࠥ࡬ࡡࡪ࡮ࡨࡨࠬ⠵")
		code = -1
		l1111l1l_ll_(l111lll_ll_ (u"ࠫࡊࡘࡒࡐࡔࡢࡐࡎࡔࡅࡔࠩ⠶"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠬࠦࠠࠡࡈࡤ࡭ࡱ࡫ࡤࠡࡱࡳࡩࡳ࡯࡮ࡨࠢࡸࡶࡱࠦࠠࠡࡅࡲࡨࡪࡀࠠ࡜ࠢࠪ⠷")+str(code)+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ⠸")+reason+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡙ࠥ࡯ࡶࡴࡦࡩ࠿࡛ࠦࠡࠩ⠹")+source+l111lll_ll_ (u"ࠨࠢࡠࠫ⠺")+l111lll_ll_ (u"ࠩࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭⠻")+url+l111lll_ll_ (u"ࠪࠤࡢ࠭⠼"))
		html = l111lll_ll_ (u"ࠫࡤࡥ࡟ࡆࡴࡵࡳࡷࡥ࡟ࡠ࠼ࠪ⠽")+str(code)+l111lll_ll_ (u"ࠬࡀࠧ⠾")+reason
	return html
def l111ll1ll11_ll_(l111ll1l111_ll_,method,url,data=l111lll_ll_ (u"࠭ࠧ⠿"),headers=l111lll_ll_ (u"ࠧࠨ⡀"),allow_redirects=True,l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠨࠩ⡁")):
	if l111ll1l111_ll_==0: return l1l11ll11ll_ll_(method,url,data,headers,allow_redirects,l1111l1l11_ll_,source)
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1ll1ll111l_ll_(url)
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	c = conn.cursor()
	conn.text_factory = str
	t = (l1ll111_ll_,str(data),str(headers),str(allow_redirects),source)
	c.execute(l111lll_ll_ (u"ࠩࡖࡉࡑࡋࡃࡕࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࠤࡋࡘࡏࡎࠢࡵࡩࡸࡶ࡯࡯ࡵࡨࡧࡦࡩࡨࡦ࡚ࠢࡌࡊࡘࡅࠡࡷࡵࡰࡂࡅࠠࡂࡐࡇࠤࡩࡧࡴࡢ࠿ࡂࠤࡆࡔࡄࠡࡪࡨࡥࡩ࡫ࡲࡴ࠿ࡂࠤࡆࡔࡄࠡࡣ࡯ࡰࡴࡽ࡟ࡳࡧࡧ࡭ࡷ࡫ࡣࡵࡵࡀࡃࠥࡇࡎࡅࠢࡶࡳࡺࡸࡣࡦ࠿ࡂࠫ⡂"), t)
	rows = c.fetchall()
	conn.close()
	if rows:
		#message = l111lll_ll_ (u"ࠪࡪࡴࡻ࡮ࡥࠢ࡬ࡲࠥࡩࡡࡤࡪࡨࠫ⡃")
		compressed = rows[0][0]
		text = zlib.decompress(compressed)
		response = l111l1llll1_ll_.loads(text)
	else:
		#message = l111lll_ll_ (u"ࠫࡳࡵࡴࠡࡨࡲࡹࡳࡪࠠࡪࡰࠣࡧࡦࡩࡨࡦࠩ⡄")
		response = l1l11ll11ll_ll_(method,l1ll111_ll_,data,headers,allow_redirects,l1111l1l11_ll_,source)
		html = response.content
		if l111lll_ll_ (u"ࠬࡥ࡟ࡠࡇࡵࡶࡴࡸ࡟ࡠࡡࠪ⡅") not in html:
			conn = sqlite3.connect(l1l1lll11l1_ll_)
			c = conn.cursor()
			conn.text_factory = str
			text = l111l1llll1_ll_.dumps(response)
			compressed = zlib.compress(text)
			t = (now+l111ll1l111_ll_,l1ll111_ll_,str(data),str(headers),str(allow_redirects),source,sqlite3.Binary(compressed))
			c.execute(l111lll_ll_ (u"ࠨࡉࡏࡕࡈࡖ࡙ࠦࡉࡏࡖࡒࠤࡷ࡫ࡳࡱࡱࡱࡷࡪࡩࡡࡤࡪࡨࠤ࡛ࡇࡌࡖࡇࡖࠤ࠭ࡅࠬࡀ࠮ࡂ࠰ࡄ࠲࠿࠭ࡁ࠯ࡃ࠮ࠨ⡆"),t)
			conn.commit()
			conn.close()
	#l1ll11l_ll_(message,l111lll_ll_ (u"ࠧࠨ⡇"))
	return response
def l111l1ll111_ll_(l111ll1l111_ll_,url,data=l111lll_ll_ (u"ࠨࠩ⡈"),headers=l111lll_ll_ (u"ࠩࠪ⡉"),l1111l1l11_ll_=True,source=l111lll_ll_ (u"ࠪࠫ⡊")):
	#url = url+l111lll_ll_ (u"ࠫࢁࢂࡍࡺࡒࡵࡳࡽࡿࡕࡳ࡮ࡀ࡬ࡹࡺࡰ࠻࠱࠲࠸࠶࠴࠳࠴࠰࠵࠵࠷࠴࠶࠹࠼࠷࠵࠹࠻ࠧ⡋")
	#l111ll1l111_ll_ = 0
	#t1 = time.time()
	#l1ll1l_ll_(l1111_ll_(url),source+l111lll_ll_ (u"ࠬࠦࠠࠡࠢࠣࡧࡦࡩࡨࡦࠪ࡫ࡳࡺࡸࡳࠪ࠿ࠪ⡌")+str(l111ll1l111_ll_/60/60))
	#l111l1l11ll_ll_ = time.ctime(now)
	#xbmc.log(l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"࠭ࠠࠡࠢࡲࡴࡪࡴࡩ࡯ࡩࠣࡹࡷࡲࠠࠡࠢࡖࡳࡺࡸࡣࡦ࠼࡞ࠫ⡍")+source+l111lll_ll_ (u"ࠧ࡞ࠢࠣࠤ࡚ࡘࡌ࠻ࠢ࡞ࠤࠬ⡎")+url+l111lll_ll_ (u"ࠨࠢࡠࠫ⡏"), level=xbmc.LOGNOTICE)
	#xbmc.log(l111lll_ll_ (u"࡚࡛ࠩ࡜࡝࠺ࠡ࠳࠴࠵࠶ࡀࠧ⡐"), level=xbmc.LOGNOTICE)
	if l111ll1l111_ll_==0: return l111l1lll11_ll_(url,data,headers,l1111l1l11_ll_,source)
	#xbmc.log(l111lll_ll_ (u"࡛ࠪ࡜࡝ࡗ࠻ࠢ࠵࠶࠷࠸࠺ࠨ⡑"), level=xbmc.LOGNOTICE)
	l1ll111_ll_,l11ll1ll11l_ll_,l11lll1llll_ll_,l11l1llll1l_ll_ = l1ll1ll111l_ll_(url)
	#xbmc.log(l111lll_ll_ (u"ࠫ࡜࡝ࡗࡘ࠼ࠣ࠷࠸࠹࠳࠻ࠩ⡒"), level=xbmc.LOGNOTICE)
	conn = sqlite3.connect(l1l1lll11l1_ll_)
	c = conn.cursor()
	conn.text_factory = str
	#conn.text_factory = lambda x: unicode(x, l111lll_ll_ (u"ࠧࡻࡴࡧ࠯࠻ࠦ⡓"), l111lll_ll_ (u"ࠨࡩࡨࡰࡲࡶࡪࠨ⡔"))
	t = (l1ll111_ll_,str(data),str(headers),source)
	c.execute(l111lll_ll_ (u"ࠧࡔࡇࡏࡉࡈ࡚ࠠࡩࡶࡰࡰࠥࡌࡒࡐࡏࠣ࡬ࡹࡳ࡬ࡤࡣࡦ࡬ࡪࠦࡗࡉࡇࡕࡉࠥࡻࡲ࡭࠿ࡂࠤࡆࡔࡄࠡࡦࡤࡸࡦࡃ࠿ࠡࡃࡑࡈࠥ࡮ࡥࡢࡦࡨࡶࡸࡃ࠿ࠡࡃࡑࡈࠥࡹ࡯ࡶࡴࡦࡩࡂࡅࠧ⡕"), t)
	rows = c.fetchall()
	#html = repr(rows[0][0])
	conn.close()
	#xbmc.log(l111lll_ll_ (u"ࠨ࡙࡚࡛࡜ࡀࠠ࠵࠶࠷࠸࠿࠭⡖"), level=xbmc.LOGNOTICE)
	if rows:
		#message = l111lll_ll_ (u"ࠩࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࡨࡧࡣࡩࡧࠪ⡗")
		html = rows[0][0]
		#html = base64.b64decode(html)
		#xbmc.log(l111lll_ll_ (u"࡛ࠪ࡜࡝ࡗ࠻ࠢ࠼࠽࠾࠿࠺ࠨ⡘"), level=xbmc.LOGNOTICE)
		html = zlib.decompress(html)
		#xbmc.log(l111lll_ll_ (u"ࠫ࡜࡝ࡗࡘ࠼ࠣ࠹࠺࠻࠵࠻ࠩ⡙"), level=xbmc.LOGNOTICE)
	else:
		#message = l111lll_ll_ (u"ࠬࡴ࡯ࡵࠢࡩࡳࡺࡴࡤࠡ࡫ࡱࠤࡨࡧࡣࡩࡧࠪ⡚")
		#xbmc.log(l111lll_ll_ (u"࠭ࡗࡘ࡙࡚࠾ࠥࡇࡁࡂࡃ࠽ࠫ⡛"), level=xbmc.LOGNOTICE)
		html = l111l1lll11_ll_(l1ll111_ll_,data,headers,l1111l1l11_ll_,source)
		#xbmc.log(l111lll_ll_ (u"ࠧࡘ࡙࡚࡛࠿ࠦ࠶࠷࠸࠹࠾ࠬ⡜"), level=xbmc.LOGNOTICE)
		if l111lll_ll_ (u"ࠨࡡࡢࡣࡊࡸࡲࡰࡴࡢࡣࡤ࠭⡝") not in html:
			#xbmc.log(l111lll_ll_ (u"࡚࡛ࠩ࡜࡝࠺ࠡࡄࡅࡆࡇࡀࠧ⡞"), level=xbmc.LOGNOTICE)
			conn = sqlite3.connect(l1l1lll11l1_ll_)
			c = conn.cursor()
			conn.text_factory = str
			#l1l111l1_ll_ = base64.b64encode(html)
			#xbmc.log(l111lll_ll_ (u"࡛ࠪ࡜࡝ࡗ࠻ࠢࡆࡇࡈࡉ࠺ࠨ⡟"), level=xbmc.LOGNOTICE)
			compressed = zlib.compress(html)
			t = (now+l111ll1l111_ll_,l1ll111_ll_,str(data),str(headers),source,sqlite3.Binary(compressed))
			c.execute(l111lll_ll_ (u"ࠦࡎࡔࡓࡆࡔࡗࠤࡎࡔࡔࡐࠢ࡫ࡸࡲࡲࡣࡢࡥ࡫ࡩࠥ࡜ࡁࡍࡗࡈࡗࠥ࠮࠿࠭ࡁ࠯ࡃ࠱ࡅࠬࡀ࠮ࡂ࠭ࠧ⡠"),t)
			#xbmc.log(l111lll_ll_ (u"ࠬ࡝ࡗࡘ࡙࠽ࠤࡉࡊࡄࡅ࠼ࠪ⡡"), level=xbmc.LOGNOTICE)
			conn.commit()
			conn.close()
		#xbmc.log(l111lll_ll_ (u"࠭ࡗࡘ࡙࡚࠾ࠥ࠽࠷࠸࠹࠽ࠫ⡢"), level=xbmc.LOGNOTICE)
	#l1lll1l1l1_ll_ = time.time()
	#l1ll11l_ll_(message,str(int(l1lll1l1l1_ll_-t1))+l111lll_ll_ (u"ࠧࠡ࡯ࡶࠫ⡣"))
	#xbmc.log(l111lll_ll_ (u"ࠨ࡙࡚࡛࡜ࡀࠠ࠹࠺࠻࠼࠿࠭⡤"), level=xbmc.LOGNOTICE)
	return html
def l111l11l1l1_ll_():
	headers = { l111lll_ll_ (u"ࠩࡘࡷࡪࡸ࠭ࡂࡩࡨࡲࡹ࠭⡥") : l111lll_ll_ (u"ࠪࠫ⡦") }
	l111ll1l11l_ll_,l111llll1ll_ll_ = [],[]
	threads = l11ll11lll_ll_(True)
	for id in l11llll1_ll_:
		l111ll111ll_ll_,l11ll1ll11l_ll_ = l11llll1_ll_[id]
		url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡽࡷࡸ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲࢂࡼࡎࡻࡓࡶࡴࡾࡹࡖࡴ࡯ࡁࠬ⡧")+l11ll1ll11l_ll_
		threads.start_new_thread(l111lll_ll_ (u"ࠬࡶࡲࡰࡺࡼࡣࠬ⡨")+str(id),l111ll1_ll_,l1l11lll_ll_,url,l111lll_ll_ (u"࠭ࠧ⡩"),headers,l111lll_ll_ (u"ࠧࠨ⡪"),l111lll_ll_ (u"ࠨࡎࡌࡆࡗࡇࡒ࡚࠯ࡆࡌࡊࡉࡋࡠࡊࡗࡘࡕ࡙࡟ࡑࡔࡒ࡜ࡎࡋࡓ࠮࠳ࡶࡸࠬ⡫"))
	threads.l11ll11ll1_ll_()
	l11ll11111_ll_,l11lll11l1l_ll_ =	threads.l11ll11111_ll_,threads.l11lll11l1l_ll_
	l1ll11l1l11_ll_ = threads.l1ll11l1l11_ll_
	for id in l11lll11l1l_ll_:
		html = l11ll11111_ll_[id]
		if l111lll_ll_ (u"ࠩࡢࡣࡤࡋࡲࡳࡱࡵࡣࡤࡥࠧ⡬") not in html:
			l111llll1ll_ll_.append(l1ll11l1l11_ll_[id])
			id = int(id.replace(l111lll_ll_ (u"ࠪࡴࡷࡵࡸࡺࡡࠪ⡭"),l111lll_ll_ (u"ࠫࠬ⡮")))
			l111ll1l11l_ll_.append(id)
	for id in l11llll1_ll_:
		html = l11ll11111_ll_[l111lll_ll_ (u"ࠬࡶࡲࡰࡺࡼࡣࠬ⡯")+str(id)]
		if l111lll_ll_ (u"࠭࡟ࡠࡡࡈࡶࡷࡵࡲࡠࡡࡢࠫ⡰") in html:
			name,url = l11llll1_ll_[id]
			if html.count(l111lll_ll_ (u"ࠧ࠻ࠩ⡱"))>=2:
				dummy,code,reason = html.split(l111lll_ll_ (u"ࠨ࠼ࠪ⡲"))
			l1111l1l_ll_(l111lll_ll_ (u"ࠩࡈࡖࡗࡕࡒࡠࡎࡌࡒࡊ࡙ࠧ⡳"),l111111l_ll_(l1ll_ll_)+l111lll_ll_ (u"ࠪࠤࠥࠦࡆࡢ࡫࡯ࡩࡩࠦࡴࡦࡵࡷ࡭ࡳ࡭ࠠࡱࡴࡲࡼࡾࠦࠠࠡࡐࡤࡱࡪࡀࠠ࡜ࠢࠪ⡴")+name+l111lll_ll_ (u"ࠫࠥࡣࠠࠡࠢ࡬ࡨ࠿࡛ࠦࠡࠩ⡵")+str(id)+l111lll_ll_ (u"ࠬࠦ࡝ࠡࠢࠣࡇࡴࡪࡥ࠻ࠢ࡞ࠤࠬ⡶")+str(code)+l111lll_ll_ (u"࠭ࠠ࡞ࠢࠣࠤࡗ࡫ࡡࡴࡱࡱ࠾ࠥࡡࠠࠨ⡷")+reason+l111lll_ll_ (u"ࠧࠡ࡟ࠣࠤ࡛ࠥࡒࡍ࠼ࠣ࡟ࠥ࠭⡸")+url+l111lll_ll_ (u"ࠨࠢࡠࠫ⡹"))
	if l111ll1l11l_ll_:
		z = zip(l111ll1l11l_ll_,l111llll1ll_ll_)
		z = sorted(z, reverse=False, key=lambda key: key[1])
		l111ll1l11l_ll_,l111llll1ll_ll_ = zip(*z)
	return l111ll1l11l_ll_,l111llll1ll_ll_
def l111l1lllll_ll_(number=None):
	if number==None: number = random.randrange(0,len(l11llll1_ll_)) # (0,6) l1ll1l1111l_ll_ 6 servers
	l111ll111ll_ll_,l11ll1ll11l_ll_ = l11llll1_ll_[number] # 6 l1ll1l1111l_ll_ 7th server
	return l111ll111ll_ll_,l11ll1ll11l_ll_
# l111ll1111l_ll_ l1ll111ll1_ll_ l111l111lll_ll_ from http://free-proxy.l111lll1l11_ll_
l11llll1_ll_ = {
		 0:(l111lll_ll_ (u"ࠩไีู๋วࠡ࠳ࠪ⡺")			,l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠹࠶࠴࠷࠺࠰࠵࠺࠳࠺࠰࠻࠺࠳ࠫ⡻"))		# HTTPS l111lll1ll1_ll_	4564kB/s 100% 4ms
		,1:(l111lll_ll_ (u"ࠫๆืๆิษࠣ࠶ࠬ⡼")			,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠻࠱࠯࠹࠼࠲࠷࠼࠮࠵࠲࠽࠼࠵࠾࠰ࠨ⡽"))		# HTTPS l111lll1ll1_ll_	5291kB/s 100% 9ms
		,2:(l111lll_ll_ (u"࠭ใ็ัสࠤ่๐ศ๋ๅࠪ⡾")		,l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠻࠻࠲࠺࠶࠮࠲࠶࠺࠲࠶࠻࠸࠻࠵࠴࠶࠽࠭⡿"))	# HTTPS l11l1111111_ll_	3725kB/s 100% 13ms
		,3:(l111lll_ll_ (u"ࠨษ็๎ํ์ว็ࠢ࠵ࠫ⢀")			,l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠴࠻࠽࠴࠱࠳࠺࠱࠶࠷࠿࠮࠲࠴࠵࠾࠽࠶ࠧ⢁"))	# HTTPS l111l111111_ll_	3078kB/s 100% 37ms
		,4:(l111lll_ll_ (u"ࠪห๊๐ัไษ๊ࠣ๏๎ฬ๋ำึ๎ࠬ⢂")	,l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠿࠸࠯࠴࠴࠵࠳࠷࠰࠳࠰࠴࠹࠺ࡀ࠸࠱࠺࠳ࠫ⢃"))	# HTTPS l111lllll11_ll_		4675kB/s 100% 46ms
		,5:(l111lll_ll_ (u"ࠬอๅ๋ำๆห๋ࠥวิึํ์ุะำࠨ⢄")	,l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠱࠵࠲࠱࠼࠷࠴࠶࠴࠰࠴࠷࠿࠾࠰࠹࠲ࠪ⢅"))	# HTTPS l111lllll11_ll_		5879kB/s 100% 57ms
		,6:(l111lll_ll_ (u"ࠧศ็ํี่อࠠ็์๋๎ํืใࠨ⢆")	,l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠸࠽࠳࠸࠰࠴࠰࠻࠻࠳࠷࠳࠱࠼࠶࠵࠷࠾ࠧ⢇"))	# HTTPS l111lllll11_ll_		6057kB/s 100% 118ms
		,7:(l111lll_ll_ (u"ࠩส้๏ืใศุ่ࠢ๏เว็ࠩ⢈")		,l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠺࠻࠮࠲࠵࠻࠲࠶࠺࠱࠯࠸࠻࠾࠽࠶࠸࠱ࠩ⢉"))	# HTTPS l111lllll11_ll_		4445kB/s 100% 132ms
		,8:(l111lll_ll_ (u"่ࠫ์ฯศࠢส์๋ะวา์๋ࠫ⢊")		,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠷࠴࠺࠰࠵࠸࠽࠴࠵࠺࠰࠴࠴࠹ࡀ࠸࠱࠺࠳ࠫ⢋"))	# HTTPS l11l1111111_ll_	3447kB/s 100% 175ms
		,9:(l111lll_ll_ (u"࠭วๆ์ิ็ฬࠦใศๆํๅํืๆ๋ษࠪ⢌")	,l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠷࠼࠲࠷࠶࠳࠯࠴࠳࠸࠳࠷࠰࠲࠼࠻࠼࠽࠾ࠧ⢍"))	# HTTPS l111lllll11_ll_		1514kB/s 100% 352ms
		,10:(l111lll_ll_ (u"ࠨษ็้ฬ์๊ศࠩ⢎")			,l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠸࠲࠾࠴࠱࠵࠴࠱࠵࠷࠺࠺࠴࠳࠵࠼ࠬ⢏"))		# HTTPS l111lllll1l_ll_	1121kB/s 100% 385ms
		,11:(l111lll_ll_ (u"ࠪหํืศศࠩ⢐")			,l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠸࠻࠮࠳࠲࠷࠲࠷࠺࠱࠯࠹࠹࠾࠸࠷࠲࠹ࠩ⢑"))	# HTTPS l111ll1llll_ll_	1271kB/s 100% 484ms
		,12:(l111lll_ll_ (u"ࠬฮัู๋ส๊๏อࠧ⢒")			,l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠴࠶࠰࠺࠻࠳࠿࠰࠯࠴࠴࠻࠿࠾࠰࠹࠲ࠪ⢓"))	# HTTPS l111l11111l_ll_		1183kB/s 100% 501ms
		,13:(l111lll_ll_ (u"ࠧา๊ึ๎ฬ࠭⢔")			,l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠼࠹࠳࠷࠸࠳࠰࠴࠷࠺࠴࠲࠴࠹࠽࠷࠶࠸࠸ࠨ⢕"))	# HTTPS l111l11ll1l_ll_	819kB/s  100% 653ms
		,14:(l111lll_ll_ (u"ࠩส่๏๎ๆศ่ࠣ࠵ࠬ⢖")		,l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠵࠼࠾࠮࠲࠴࠻࠲࠷࠸࠹࠯࠳࠵࠶࠿࠾࠰࠹࠲ࠪ⢗"))	# HTTPS l111l111111_ll_	4383kB/s 100% 657ms
		,15:(l111lll_ll_ (u"ࠫฬ๊๊ศสส๊ࠬ⢘")			,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠺࠵࠯࠵࠵࠲࠸࠹࠮࠹࠹࠽࠷࠶࠸࠸ࠨ⢙"))		# HTTPS l1111llllll_ll_	664kB/s 100% 963ms
		,16:(l111lll_ll_ (u"࠭สี์็๎ࠬ⢚")			,l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠲࠺࠹࠲࠶࠶࠳࠯࠳࠺࠹࠳࠷࠵࠹࠼࠶࠵࠷࠾ࠧ⢛"))	# HTTPS l111ll11l1l_ll_	595kB/s 100% 700ms
		,17:(l111lll_ll_ (u"ࠨใิุ๊อࠠ࠴ࠩ⢜")			,l111lll_ll_ (u"ࠩ࡫ࡸࡹࡶ࠺࠰࠱࠸࠵࠳࠽࠷࠯࠴࠴࠹࠳࠻࠱࠻࠵࠴࠶࠽࠭⢝"))	# HTTPS l111lll1ll1_ll_	902kB/s 100% 775ms
		,18:(l111lll_ll_ (u"ࠪห้ษัอ่อ๎๋࠭⢞")			,l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳࠶࠿࠰࠯࠴࠴࠻࠳࠾࠱࠯࠸࠽࠼࠵࠾࠰ࠨ⢟"))	# HTTPS l111lll11l1_ll_ 812kB/s 100% 634ms
		,19:(l111lll_ll_ (u"ࠬํ่็ฮࠣ็ํ์ฬࠨ⢠")		,l111lll_ll_ (u"࠭ࡨࡵࡶࡳ࠾࠴࠵࠴࠸࠰࠸࠶࠳࠸࠹࠯࠳࠻࠸࠿࠹࠱࠳࠺ࠪ⢡"))	# HTTPS l111llll111_ll_ l111l111l1l_ll_ 476kB/s 100% 1143ms
		,20:(l111lll_ll_ (u"ࠧศ็ํี่อࠠไ๊็์ึอฯ้ࠩ⢢")	,l111lll_ll_ (u"ࠨࡪࡷࡸࡵࡀ࠯࠰࠳࠹࠻࠳࠾࠶࠯࠺࠼࠲࠶࠶࠸࠻࠵࠴࠶࠽࠭⢣"))	# HTTPS l111ll11l11_ll_  938kB/s 100% 659ms
		,21:(l111lll_ll_ (u"ࠩสฺ่๐ๆࠨ⢤")			,l111lll_ll_ (u"ࠪ࡬ࡹࡺࡰ࠻࠱࠲࠸࠾࠴࠵࠲࠰࠴࠹࠺࠴࠴࠶࠼࠻࠴࠽࠷ࠧ⢥"))	# HTTPS l111ll111l1_ll_			  92.2% 473ms
		,22:(l111lll_ll_ (u"๊ࠫ฻ัࠨ⢦")				,l111lll_ll_ (u"ࠬ࡮ࡴࡵࡲ࠽࠳࠴࠺࠱࠯࠵࠶࠲࠷࠷࠲࠯࠸࠻࠾࠹࠷࠴࠶ࠩ⢧"))	# HTTPS
		#,23:(l111lll_ll_ (u"࠭สาๅํหࠬ⢨")			,l111lll_ll_ (u"ࠧࡩࡶࡷࡴ࠿࠵࠯࠵࠷࠱࠶࠸࠶࠮࠳࠳࠸࠲࠹࠼࠺࠹࠲࠻࠴ࠬ⢩"))	# HTTPS l111ll111l1_ll_	368kB/s 100% 1300ms
		}
# open file l1ll11l1l1l_ll_ one line l11ll1l1l11_ll_
l111lll_ll_ (u"ࠣࠤࠥࠑࠏࡽࡩࡵࡪࠣࡳࡵ࡫࡮ࠩࠩࡖ࠾ࡡࡢࡥ࡮ࡣࡧ࠷࠳࡮ࡴ࡮࡮ࠪ࠰ࠥ࠭ࡷࠨࠫࠣࡥࡸࠦࡦ࠻ࠢࡩ࠲ࡼࡸࡩࡵࡧࠫࡩࡲࡧࡤࠪࠏࠍࡻ࡮ࡺࡨࠡࡱࡳࡩࡳ࠮ࠧࡔ࠼࡟ࡠࡹ࡫ࡳࡵ࠴࠱ࡱ࠸ࡻ࠸ࠨ࠮ࠣࠫࡷ࠭ࠩࠡࡣࡶࠤ࡫ࡀࠠࡦ࡯ࡤࡨࠥࡃࠠࡧ࠰ࡵࡩࡦࡪࠨࠪࠏࠍࠦࠧࠨ⢪")
# open file l1ll11l1l1l_ll_ l111l11l11l_ll_ line l11ll1l1l11_ll_
l111lll_ll_ (u"ࠤࠥࠦࠒࠐࠣࡧ࡫࡯ࡩࠥࡃࠠࡰࡲࡨࡲ࠭࠭࠯ࡥࡣࡷࡥ࠴࡫࡭ࡢࡦ࠱࡬ࡹࡳ࡬ࠨ࠮ࠣࠫࡼ࠭ࠩࠎࠌࠦࡪ࡮ࡲࡥ࠯ࡹࡵ࡭ࡹ࡫ࠨࡩࡶࡰࡰ࠮ࠓࠊࠤࡨ࡬ࡰࡪ࠴ࡣ࡭ࡱࡶࡩ࠭࠯ࠍࠋࠤࠥࠦ⢫")
# encode & decode l111lll11ll_ll_
l111lll_ll_ (u"ࠥࠦࠧࠓࠊࡥࡧࡦࡳࡩ࡫ࠨࠨࡷࡷࡪ࠽࠭ࠩࠎࠌࡧࡩࡨࡵࡤࡦࠪࠪࡹࡳ࡯ࡣࡰࡦࡨࡣࡪࡹࡣࡢࡲࡨࠫ࠮ࠓࠊࡥࡧࡦࡳࡩ࡫ࠨࠨࡣࡶࡧ࡮࡯ࠧࠪࠏࠍࡨࡪࡩ࡯ࡥࡧࠫࠫࡼ࡯࡮ࡥࡱࡺࡷ࠲࠷࠲࠶࠸ࠪ࠭ࠒࠐࠢࠣࠤ⢬")
# l111l1l1111_ll_ l1ll11l1l1l_ll_ time.time()
l111lll_ll_ (u"ࠦࠧࠨࠍࠋࡶ࠴ࠤࡂࠦࡴࡪ࡯ࡨ࠲ࡹ࡯࡭ࡦࠪࠬࠑࠏࡺ࠲ࠡ࠿ࠣࡸ࡮ࡳࡥ࠯ࡶ࡬ࡱࡪ࠮ࠩࠎࠌࡇࡍࡆࡒࡏࡈࡡࡒࡏ࠭ࡹࡴࡳࠪࡷ࠶࠲ࡺ࠱ࠪ࠮ࠣࠫࠬ࠯ࠍࠋࠤࠥࠦ⢭")
# l111l1l1111_ll_ l1ll11l1l1l_ll_ l1l1ll111ll_ll_.l1l1ll111ll_ll_()
l111lll_ll_ (u"ࠧࠨࠢࠎࠌࡷ࡭ࡲ࡫ࡩࡵ࠰ࡷ࡭ࡲ࡫ࡩࡵࠪࠪ࡭ࡲࡶ࡯ࡳࡶࠣࡐࡎࡈࡒࡂࡔ࡜ࠫ࠱ࡴࡵ࡮ࡤࡨࡶࡂ࠷ࠩࠎࠌࠥࠦࠧ⢮")
# l1ll11l11ll_ll_ open, read, and close
l111lll_ll_ (u"ࠨࠢࠣࠏࠍࡴࡱࡧࡹࡪࡰࡪࠤࡂࠦࡳࡵࡴࠫࡱࡾࡶ࡬ࡢࡻࡨࡶ࠳࡯ࡳࡑ࡮ࡤࡽ࡮ࡴࡧࠩࠫࠬࠑࠏࡲ࡯ࡨࡨ࡬ࡰࡪࠦ࠽ࠡࡨ࡬ࡰࡪ࠮࡬ࡰࡩࡩ࡭ࡱ࡫࡮ࡢ࡯ࡨ࠰ࠥ࠭ࡲࡣࠩࠬࠑࠏࡲ࡯ࡨࡨ࡬ࡰࡪ࠴ࡳࡦࡧ࡮ࠬ࠲࠺࠰࠱࠲࠯ࠤࡴࡹ࠮ࡔࡇࡈࡏࡤࡋࡎࡅࠫࠐࠎࡱࡵࡧࡧ࡫࡯ࡩࠥࡃࠠ࡭ࡱࡪࡪ࡮ࡲࡥ࠯ࡴࡨࡥࡩ࠮ࠩࠎࠌ࡯ࡳ࡬࡬ࡩ࡭ࡧ࠵ࠤࡂࠦ࡬ࡰࡩࡩ࡭ࡱ࡫࠮ࡴࡲ࡯࡭ࡹ࠮ࡌࡐࡉࡊࡍࡓࡍࠨࡴࡥࡵ࡭ࡵࡺ࡟࡯ࡣࡰࡩ࠮࠱ࠧࠡࠢࠣࡗࡹࡧࡲࡵࡧࡧࠤࡵࡲࡡࡺ࡫ࡱ࡫ࠥࡼࡩࡥࡧࡲ࠾ࠬ࠯ࠍࠋ࡫ࡩࠤࡱ࡫࡮ࠩ࡮ࡲ࡫࡫࡯࡬ࡦ࠴ࠬࡁࡂ࠷࠺ࠡࡥࡲࡲࡹ࡯࡮ࡶࡧࠐࠎࡪࡲࡳࡦ࠼ࠣࡰࡴ࡭ࡦࡪ࡮ࡨ࠶ࠥࡃࠠ࡭ࡱࡪࡪ࡮ࡲࡥ࠳࡝࠰࠵ࡢࠓࠊࡪࡨࠣࠫࡈࡲ࡯ࡴࡧࡉ࡭ࡱ࡫ࠧࠡ࡫ࡱࠤࡱࡵࡧࡧ࡫࡯ࡩ࠷ࠦ࡯ࡳࠢࠪࡅࡹࡺࡥ࡮ࡲࡷࠤࡹࡵࠠࡶࡵࡨࠤ࡮ࡴࡶࡢ࡮࡬ࡨࠥ࡮ࡡ࡯ࡦ࡯ࡩࠬࠦࡩ࡯ࠢ࡯ࡳ࡬࡬ࡩ࡭ࡧ࠵࠾ࠒࠐࠉࡳࡧࡶࡹࡱࡺࠠ࠾ࠢࠪࡪࡦ࡯࡬ࡦࡦࠪࠑࠏࠏࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࡎࡒࡋࡌࡏࡎࡈࠪࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠩࠬࠩࠣࠤࠥࠦࠠࠡࡈࡤ࡭ࡱࡻࡲࡦ࠼࡚ࠣ࡮ࡪࡥࡰࠢࡩࡥ࡮ࡲࡥࡥࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࠤࠬ࠱ࡵࡳ࡮ࡰࡩࡸࡹࡡࡨࡧ࠯ࠤࡱ࡫ࡶࡦ࡮ࡀࡼࡧࡳࡣ࠯ࡎࡒࡋࡓࡕࡔࡊࡅࡈ࠭ࠒࠐࠉࠤࡤࡵࡩࡦࡱࠍࠋࡧ࡯࡭࡫ࠦࠧࡐࡲࡨࡲ࡮ࡴࡧࠡࡵࡷࡶࡪࡧ࡭ࠨࠢ࡬ࡲࠥࡲ࡯ࡨࡨ࡬ࡰࡪ࠸࠺ࠎࠌࠌࡶࡪࡹࡵ࡭ࡶࠣࡁࠥ࠭ࡰ࡭ࡣࡼ࡭ࡳ࡭ࠧࠎࠌࠌࡼࡧࡳࡣ࠯࡮ࡲ࡫࠭ࡒࡏࡈࡉࡌࡒࡌ࠮ࡳࡤࡴ࡬ࡴࡹࡥ࡮ࡢ࡯ࡨ࠭࠰࠭ࠠࠡࠢࠣࠤ࡙ࠥࡵࡤࡥࡨࡷࡸࡀࠠࡗ࡫ࡧࡩࡴࠦࡩࡴࠢࡳࡰࡦࡿࡩ࡯ࡩࠣࡷࡺࡩࡣࡦࡵࡶࡪࡺࡲ࡬ࡺࠢࠣࠫ࠰ࡻࡲ࡭࡯ࡨࡷࡸࡧࡧࡦ࠮ࠣࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡒࡔ࡚ࡉࡄࡇࠬࠑࠏࠏࠣࡣࡴࡨࡥࡰࠓࠊࠣࠤࠥ⢯")
# to l1lll1lll1_ll_ the numbers name to digits
l111lll_ll_ (u"ࠢࠣࠤࠐࠎࡱࡵࡷࡍࡋࡖࡘࠥࡃࠠ࡜ࠢࠣ࡟ࠬ࠭࡝ࠡࠢࡠࠑࠏࡲ࡯ࡸࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨษ็หํ๊้ࠨ࠮ࠪห้ษ่ๅ๋ࠪ࠰ࠬอไฮษา๎ฮ࠭ࠬࠨษ็ัฬี๊่ࠩ࠯ࠫฬ๊่ศฯาอࠬ࠲ࠧศๆ๋หาี็ࠨ࠮ࠪห้ำวะ์ࠪ࠰ࠬอไ้ษะำࠬࡣࠩࠎࠌ࡯ࡳࡼࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬอไฬษ้๎ฮ࠭ࠬࠨษ็ฯฬ์๊่ࠩࡠ࠭ࠒࠐ࡬ࡰࡹࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩส่ะอไฬหࠪ࠰ࠬอไฬษ็ฯ์࠭࡝ࠪࠏࠍࡰࡴࡽࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭วๅำสฬ฾ฯࠧ࠭ࠩส่ึอศฺ้ࠪࡡ࠮ࠓࠊ࡭ࡱࡺࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪห้ิวๆีฬࠫ࠱࠭วๅะสุ้ํࠧ࡞ࠫࠐࠎࡱࡵࡷࡍࡋࡖࡘ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡡࠧศๆึหิูษࠨ࠮ࠪหู้วะี๊ࠫࡢ࠯ࠍࠋ࡮ࡲࡻࡑࡏࡓࡕ࠰ࡤࡴࡵ࡫࡮ࡥࠪ࡞ࠫฬ๊ำศส฼อࠬ࠲ࠧศๆึหอ฿็ࠨ࡟ࠬࠑࠏࡲ࡯ࡸࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨษ็ฯฬ๋ๆสࠩ࠯ࠫฬ๊หศ็้๋ࠬࡣࠩࠎࠌ࡯ࡳࡼࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬอไหษึ฽ฮ࠭ࠬࠨษ็ฮฬูู่ࠩࡠ࠭ࠒࠐ࡬ࡰࡹࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩส่฾อิาหࠪ࠰ࠬอไฺษืี์࠭࡝ࠪࠏࠍࡰࡴࡽࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ࠭วๅ฻ืีํ์ࠧ࠭ࠩส่฾ฺั๋่ࠪࡡ࠮ࠓࠊ࡭ࡱࡺࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡝ࠪห้ัไศอ๋๊ࠬ࠲ࠧศๆฮ่ฬั๊็ࠩࡠ࠭ࠒࠐ࡬ࡰࡹࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡜ࠩส่ฬืศฺ๊้ࠫ࠱࠭วๅษิฬ฾๐ๆࠨ࡟ࠬࠑࠏࡲ࡯ࡸࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨษ็าู๊่็ࠩ࠯ࠫฬ๊ฮๆีํ๊ࠬࡣࠩࠎࠌ࡫࡭࡬࡮ࡌࡊࡕࡗࠤࡂ࡛ࠦࠡࠢ࡞ࠫࠬࡣࠠࠡ࡟ࠐࠎ࡭࡯ࡧࡩࡎࡌࡗ࡙࠴ࡡࡱࡲࡨࡲࡩ࠮࡛ࠨ฻ืีฮ࠭ࠬࠨ฻ืีࠬࡣࠩࠎࠌ࡫࡭࡬࡮ࡌࡊࡕࡗ࠲ࡦࡶࡰࡦࡰࡧࠬࡠ่࠭ࠡษ็฽ูื่็ࠩ࠯ࠫํࠦวๅ฻ืี๏์๋ࠧ࠭ࠩห้฿ิา๊้ࠫ࠱่࠭ศๆ฼ุึ๐ๆࠨ࡟ࠬࠑࠏ࡮ࡩࡨࡪࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨ࡜๋ࠩࠤฬู๊ีำ๋๊ࠬ࠲้ࠧࠢส่฾ฺั๋่ࠪ࠰ࠬ๎วๅ฻ืีํ์๋ࠧ࠭ࠩห้฿ิา์้ࠫࡢ࠯ࠍࠋࡪ࡬࡫࡭ࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬ๎ࠠศๆฮ่ฬั่็ࠩ࠯ࠫํࠦวๅอ็หะ๐ๆࠨ࠮ࠪ์ฬ๊หๅษฮ์๋࠭ࠬࠨ๊ส่ะ๊วฬ์้ࠫࡢ࠯ࠍࠋࡪ࡬࡫࡭ࡒࡉࡔࡖ࠱ࡥࡵࡶࡥ࡯ࡦࠫ࡟ࠬ๎ࠠศๆสีอ฿่็ࠩ࠯ࠫํࠦวๅษิฬ฾๐ๆࠨ࠮ࠪ์ฬ๊วาส฼์๋࠭ࠬࠨ๊ส่ฬืศฺ์้ࠫࡢ࠯ࠍࠋࡥ࡯ࡩࡦࡴࡌࡊࡕࡗࠤࡂ࡛ࠦࠨ๊ࠣห้อฮ๋ำฬࠫ࠱่࠭ࠡษ็หำ๐ั่ࠩ࠯ࠫํอไศะํีฮ࠭ࠬࠨ๊ส่ฬิ๊า้ࠪ࠰ࠬอไศะํีฮ࠭ࠬࠨษ็หำ๐ั่ࠩ࠯่ࠫอๅๅหࠪ࠰้ࠬวๆๆ๊ࠫࡢࠓࠊࠎࠌࡧࡩ࡫ࠦࡃࡍࡇࡄࡒࡤࡋࡐࡔࡋࡒࡈࡊࡥࡎࡂࡏࡈࠬࡹ࡯ࡴ࡭ࡧࠬ࠾ࠒࠐࠉࠤࡴࡨࡸࡺࡸ࡮ࠡࡶ࡬ࡸࡱ࡫ࠍࠋࠋࡷ࡭ࡹࡲࡥ࠳ࠢࡀࠤࡹ࡯ࡴ࡭ࡧ࠱ࡷࡹࡸࡩࡱࠪࠪࠤࠬ࠯࠮ࡳࡧࡳࡰࡦࡩࡥࠩࠩࠣࠤࠬ࠲ࠧࠡࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠩ࠯ࠫࠥ࠭ࠩࠎࠌࠌࡸ࡮ࡺ࡬ࡦ࠴ࠣࡁࠥࡺࡩࡵ࡮ࡨ࠶࠳ࡸࡥࡱ࡮ࡤࡧࡪ࠮ࠧแࠩ࠯ࠫࠬ࠯ࠍࠋࠋࡨࡴ࡮ࡹ࡯ࡥࡧࠣࡁࠥࡸࡥ࠯ࡨ࡬ࡲࡩࡧ࡬࡭ࠪࠪࠬฬ๊อๅไฬࢀฬ๊อๅไ๊࠭ࠥ࠮࡜ࡥ࠭ࠬࠫ࠱ࡺࡩࡵ࡮ࡨ࠶࠱ࡸࡥ࠯ࡆࡒࡘࡆࡒࡌࠪࠏࠍࠍ࡮࡬ࠠࡦࡲ࡬ࡷࡴࡪࡥ࠻ࠏࠍࠍࠎ࡬࡯ࡳࠢࡺࡳࡷࡪࠠࡪࡰࠣࡧࡱ࡫ࡡ࡯ࡎࡌࡗ࡙ࡀࠍࠋࠋࠌࠍࡹ࡯ࡴ࡭ࡧ࠵ࠤࡂࠦࡴࡪࡶ࡯ࡩ࠷࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࡸࡱࡵࡨ࠱࠭ࠧࠪࠏࠍࠍࠎࡴࡵ࡮ࡤࡨࡶࠥࡃࠠࡪࡰࡷࠬࡪࡶࡩࡴࡱࡧࡩࡠ࠶࡝࡜࠳ࡠ࠭ࠒࠐࠉࠊࡪ࡬࡫࡭࠲࡬ࡰࡹࠣࡁࠥ࡯࡮ࡵࠪࡱࡹࡲࡨࡥࡳ࠱࠴࠴࠮࠲ࡩ࡯ࡶࠫࡲࡺࡳࡢࡦࡴࠨ࠵࠵࠯ࠍࠋࠋࠌࡩࡵ࡯ࡳࡰࡦࡨ࠶ࠥࡃࠠ࡜࡟ࠐࠎࠎࠏࡩࡧࠢ࡯ࡳࡼࡃ࠽࠱࠼ࠣ࡬࡮࡭ࡨ࠭࡮ࡲࡻࠥࡃࠠ࠱࠮࡫࡭࡬࡮ࠫ࠺ࠏࠍࠍࠎ࡬࡯ࡳࠢ࡫࡭࡬࡮ࡔࡆ࡚ࡗࠤ࡮ࡴࠠࡩ࡫ࡪ࡬ࡑࡏࡓࡕ࡝࡫࡭࡬࡮࡝࠻ࠏࠍࠍࠎࠏࡩࡧࠢ࡫࡭࡬࡮ࡔࡆ࡚ࡗࠥࡂ࠭ࠧ࠻ࠢ࡫࡭࡬࡮ࡔࡆ࡚ࡗࡁࠬࠦࠧࠬࡪ࡬࡫࡭࡚ࡅ࡙ࡖࠐࠎࠎࠏࠉࡧࡱࡵࠤࡱࡵࡷࡕࡇ࡛ࡘࠥ࡯࡮ࠡ࡮ࡲࡻࡑࡏࡓࡕ࡝࡯ࡳࡼࡣ࠺ࠎࠌࠌࠍࠎࠏࡦࡪࡰࡧࡘࡊ࡞ࡔࠡ࠿ࠣࡩࡵ࡯ࡳࡰࡦࡨ࡟࠵ࡣ࡛࠱࡟࠮ࠫࠥ࠭ࠫࡦࡲ࡬ࡷࡴࡪࡥ࡜࠲ࡠ࡟࠶ࡣࠫࠨࠢࠪ࠯ࡱࡵࡷࡕࡇ࡛ࡘ࠰࡮ࡩࡨࡪࡗࡉ࡝࡚ࠍࠋࠋࠌࠍࠎ࡫ࡰࡪࡵࡲࡨࡪ࠸ࠠ࠾ࠢࡵࡩ࠳࡬ࡩ࡯ࡦࡤࡰࡱ࠮ࡦࡪࡰࡧࡘࡊ࡞ࡔ࠭ࡶ࡬ࡸࡱ࡫࠲࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠊࠋࠌ࡭࡫ࠦࡥࡱ࡫ࡶࡳࡩ࡫࠲࠻ࠢࡥࡶࡪࡧ࡫ࠎࠌࠌࠍࠎ࡯ࡦࠡࡧࡳ࡭ࡸࡵࡤࡦ࠴࠽ࠤࡧࡸࡥࡢ࡭ࠐࠎࠎࠏࡩࡧࠢࡨࡴ࡮ࡹ࡯ࡥࡧ࠵࠾ࠥࡺࡩࡵ࡮ࡨ࠶ࠥࡃࠠࡵ࡫ࡷࡰࡪ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࡧࡳ࡭ࡸࡵࡤࡦ࠴࡞࠴ࡢ࠲ࠧࠨࠫࠐࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡺࡩࡵ࡮ࡨ࠶ࠥࡃࠠࡵ࡫ࡷࡰࡪ࠸࠮ࡳࡧࡳࡰࡦࡩࡥࠩࡧࡳ࡭ࡸࡵࡤࡦ࡝࠳ࡡࡠ࠶࡝ࠬࠩࠣࠫ࠰࡫ࡰࡪࡵࡲࡨࡪࡡ࠰࡞࡝࠴ࡡ࠱࠭ࠧࠪࠏࠍࠍࠎࡺࡩࡵ࡮ࡨ࠶ࠥࡃࠠࡵ࡫ࡷࡰࡪ࠸࠮ࡴࡶࡵ࡭ࡵ࠮ࠧࠡࠩࠬ࠲ࡷ࡫ࡰ࡭ࡣࡦࡩ࠭࠭ࠠࠡࠩ࠯ࠫࠥ࠭ࠩ࠯ࡴࡨࡴࡱࡧࡣࡦࠪࠪࠤࠥ࠭ࠬࠨࠢࠪ࠭ࠒࠐࠉࠤࡆࡌࡅࡑࡕࡇࡠࡑࡎࠬࡹ࡯ࡴ࡭ࡧ࠯ࡸ࡮ࡺ࡬ࡦ࠴ࠬࠑࠏࠏࡲࡦࡶࡸࡶࡳࠦࡴࡪࡶ࡯ࡩ࠷ࠓࠊࠣࠤࠥ⢰")
# threading.Thread l11ll1l1l11_ll_
l111lll_ll_ (u"ࠣࠤࠥࠑࠏ࡯ࡴࡦ࡯ࡶࠤࡂࠦࡲࡦ࠰ࡩ࡭ࡳࡪࡡ࡭࡮ࠫࠫ࡬࡫ࡴࡗ࡫ࡧࡩࡴࡖ࡬ࡢࡻࡨࡶࡡ࠮࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ࠯ࡦࡱࡵࡣ࡬࠮ࡵࡩ࠳ࡊࡏࡕࡃࡏࡐ࠮ࠓࠊࡧࡱࡵࠤࡸ࡫ࡲࡷࡧࡵࠤ࡮ࡴࠠࡪࡶࡨࡱࡸࡀࠍࠋࠋࡳࡥࡾࡲ࡯ࡢࡦࠣࡁࠥࢁࠠࠨࡃ࡭ࡥࡽ࠭ࠠ࠻ࠢࠪ࠵ࠬࠦࠬࠡࠩࡤࡶࡹ࠭ࠠ࠻ࠢࡤࡶࡹࡏࡄࠡ࠮ࠣࠫࡸ࡫ࡲࡷࡧࡵࠫࠥࡀࠠࡴࡧࡵࡺࡪࡸࠠࡾࠏࠍࠍࡩࡧࡴࡢࠢࡀࠤ࡚ࡘࡌࡆࡐࡆࡓࡉࡋࠨࡱࡣࡼࡰࡴࡧࡤࠪࠏࠍࠍࠨࡪࡡࡵࡣࡏࡍࡘ࡚࠮ࡢࡲࡳࡩࡳࡪࠨࡥࡣࡷࡥ࠮ࠓࠊࠊࡶࠣࡁࠥࡺࡨࡳࡧࡤࡨ࡮ࡴࡧ࠯ࡖ࡫ࡶࡪࡧࡤࠩࡶࡤࡶ࡬࡫ࡴ࠾࡮࡬ࡲࡰࡌࡕࡏࡅ࠯ࡥࡷ࡭ࡳ࠾ࠪࡧࡥࡹࡧࠬ࡭࡫ࡱ࡯ࡑࡏࡓࡕࠫࠬࠑࠏࠏࡴ࠯ࡵࡷࡥࡷࡺࠨࠪࠏࠍࠍࡹ࡮ࡲࡦࡣࡧࡷ࠳ࡧࡰࡱࡧࡱࡨ࠭ࡺࠩࠎࠌࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡹ࡮ࡲࡦࡣࡧࡷ࠿ࠓࠊࠊ࡫࠱࡮ࡴ࡯࡮ࠩࠫࠐࠎࠧࠨࠢ⢱")
# concurrent.l111l111ll1_ll_ threading l11ll1l1l11_ll_
l111lll_ll_ (u"ࠤࠥࠦࠒࠐࡣࡰࡷࡱࡸࠥࡃࠠ࡭ࡧࡱࠬࡩࡧࡴࡢࡎࡌࡗ࡙࠯ࠍࠋ࡫ࡰࡴࡴࡸࡴࠡࡥࡲࡲࡨࡻࡲࡳࡧࡱࡸ࠳࡬ࡵࡵࡷࡵࡩࡸࠓࠊࡸ࡫ࡷ࡬ࠥࡩ࡯࡯ࡥࡸࡶࡷ࡫࡮ࡵ࠰ࡩࡹࡹࡻࡲࡦࡵ࠱ࡘ࡭ࡸࡥࡢࡦࡓࡳࡴࡲࡅࡹࡧࡦࡹࡹࡵࡲࠩ࡯ࡤࡼࡤࡽ࡯ࡳ࡭ࡨࡶࡸࡃ࠲࠱ࠫࠣࡥࡸࠦࡥࡹࡧࡦࡹࡹࡵࡲ࠻ࠏࠍࠍࡷ࡫ࡳࡱࡱࡱࡧࡪࡹࡄࡊࡅࡗࠤࡂࠦࡤࡪࡥࡷࠬࠥ࠮ࡥࡹࡧࡦࡹࡹࡵࡲ࠯ࡵࡸࡦࡲ࡯ࡴࠩࡱࡳࡩࡳ࡛ࡒࡍ࠮ࠣࡹࡷࡲ࠲࠭ࠢࡧࡥࡹࡧࡌࡊࡕࡗ࡟࡮ࡣࠬࠡࡪࡨࡥࡩ࡫ࡲࡴ࠮ࠪࠫ࠱࠭ࡈࡂࡎࡄࡇࡎࡓࡁ࠮ࡒࡏࡅ࡞࠳࠳ࡳࡦࠪ࠭࠱ࠦࡩࠪࠢࡩࡳࡷࠦࡩࠡ࡫ࡱࠤࡷࡧ࡮ࡨࡧࠫࡧࡴࡻ࡮ࡵࠫࠣ࠭ࠒࠐࡦࡰࡴࠣࡶࡪࡹࡰࡰࡰࡶࡩࠥ࡯࡮ࠡࡥࡲࡲࡨࡻࡲࡳࡧࡱࡸ࠳࡬ࡵࡵࡷࡵࡩࡸ࠴ࡡࡴࡡࡦࡳࡲࡶ࡬ࡦࡶࡨࡨ࠭ࡸࡥࡴࡲࡲࡲࡨ࡫ࡳࡅࡋࡆࡘ࠮ࡀࠍࠋࠋ࡫ࡸࡲࡲࠠ࠾ࠢࡵࡩࡸࡶ࡯࡯ࡵࡨ࠲ࡷ࡫ࡳࡶ࡮ࡷࠬ࠮ࠓࠊࠊࡪࡷࡱࡱࠦ࠽ࠡࡪࡷࡱࡱ࠴ࡲࡦࡲ࡯ࡥࡨ࡫ࠨࠨࡕࡕࡇࡂ࠭ࠬࠨࡵࡵࡧࡂ࠭ࠩࠎࠌࠌࡰ࡮ࡴ࡫ࡴࠢࡀࠤࡷ࡫࠮ࡧ࡫ࡱࡨࡦࡲ࡬ࠩࠩࡶࡶࡨࡃ࡜ࠨࠪ࠱࠮ࡄ࠯࡜ࠨࠩ࠯࡬ࡹࡳ࡬࠭ࡴࡨ࠲ࡉࡕࡔࡂࡎࡏ࠭ࠒࠐࠉࠤ࡫ࡩࠤࠬ࡮ࡴࡵࡲࠪࠤࡳࡵࡴࠡ࡫ࡱࠤࡱ࡯࡮࡬࠼ࠣࡰ࡮ࡴ࡫ࠡ࠿ࠣࠫ࡭ࡺࡴࡱ࠼ࠪࠤ࠰ࠦ࡬ࡪࡰ࡮ࠑࠏࠏ࡬ࡪࡰ࡮ࡐࡎ࡙ࡔ࠯ࡣࡳࡴࡪࡴࡤࠩ࡮࡬ࡲࡰࡹ࡛࠱࡟ࠬࠑࠏࠨࠢࠣ⢲")
l111lll_ll_ (u"ࠥࠦࠧࠓࠊࡤ࡮ࡤࡷࡸࠦࡍࡺࡊࡗࡘࡕࡉ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠪ࡫ࡸࡹࡶ࡬ࡪࡤ࠱ࡌ࡙࡚ࡐࡄࡱࡱࡲࡪࡩࡴࡪࡱࡱ࠭࠿ࠓࠊࠊࡦࡨࡪࠥࡩ࡯࡯ࡰࡨࡧࡹ࠮ࡳࡦ࡮ࡩ࠭࠿ࠓࠊࠊࠋ࡬ࡴࠥࡃࠠࡅࡐࡖࡣࡗࡋࡓࡐࡎ࡙ࡉࡗ࠮ࡳࡦ࡮ࡩ࠲࡭ࡵࡳࡵࠫࠐࠎࠎࠏࡩࡧࠢ࡬ࡴ࠿ࠦࡳࡦ࡮ࡩ࠲࡭ࡵࡳࡵࠢࡀࠤ࡮ࡶ࡛࠱࡟ࠐࠎࠎࠏࡥ࡭ࡵࡨ࠾ࠥࡾࡢ࡮ࡥ࠱ࡰࡴ࡭ࠨࡍࡑࡊࡋࡎࡔࡇࠩࡵࡦࡶ࡮ࡶࡴࡠࡰࡤࡱࡪ࠯ࠫࠨࠢࠣࠤࠥࠦࠠࡆࡴࡵࡳࡷࡀࠠࡎࡻࡋࡘ࡙ࡖࡃࡰࡰࡱࡩࡨࡺࡩࡰࡰࠣࡪࡦ࡯࡬ࡦࡦࠣ࡫ࡪࡺࡴࡪࡰࡪࠤ࡮ࡶࠠࠡࠢࡘࡖࡑࡀ࡛ࠨ࠭ࡶࡩࡱ࡬࠮ࡩࡱࡶࡸ࠰࠭࡝ࠨ࠮ࠣࡰࡪࡼࡥ࡭࠿ࡻࡦࡲࡩ࠮ࡍࡑࡊࡉࡗࡘࡏࡓࠫࠐࠎࠎࠏࡳࡦ࡮ࡩ࠲ࡸࡵࡣ࡬ࠢࡀࠤࡸࡵࡣ࡬ࡧࡷ࠲ࡨࡸࡥࡢࡶࡨࡣࡨࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮ࠩࠪࡶࡩࡱ࡬࠮ࡩࡱࡶࡸ࠱ࡹࡥ࡭ࡨ࠱ࡴࡴࡸࡴࠪࠫࠐࠎࠒࠐࡣ࡭ࡣࡶࡷࠥࡓࡹࡉࡖࡗࡔࡘࡉ࡯࡯ࡰࡨࡧࡹ࡯࡯࡯ࠪ࡫ࡸࡹࡶ࡬ࡪࡤ࠱ࡌ࡙࡚ࡐࡔࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲ࠮ࡀࠍࠋࠋࡧࡩ࡫ࠦࡣࡰࡰࡱࡩࡨࡺࠨࡴࡧ࡯ࡪ࠮ࡀࠍࠋࠋࠌ࡭ࡵࠦ࠽ࠡࡆࡑࡗࡤࡘࡅࡔࡑࡏ࡚ࡊࡘࠨࡴࡧ࡯ࡪ࠳࡮࡯ࡴࡶࠬࠑࠏࠏࠉࡪࡨࠣ࡭ࡵࡀࠠࡴࡧ࡯ࡪ࠳࡮࡯ࡴࡶࠣࡁࠥ࡯ࡰ࡜࠲ࡠࠑࠏࠏࠉࡦ࡮ࡶࡩ࠿ࠦࡸࡣ࡯ࡦ࠲ࡱࡵࡧࠩࡎࡒࡋࡌࡏࡎࡈࠪࡶࡧࡷ࡯ࡰࡵࡡࡱࡥࡲ࡫ࠩࠬࠩࠣࠤࠥࠦࠠࠡࡇࡵࡶࡴࡸ࠺ࠡࡏࡼࡌ࡙࡚ࡐࡔࡅࡲࡲࡳ࡫ࡣࡵ࡫ࡲࡲࠥ࡬ࡡࡪ࡮ࡨࡨࠥ࡭ࡥࡵࡶ࡬ࡲ࡬ࠦࡩࡱࠢࠣࠤ࡚ࡘࡌ࠻࡝ࠪ࠯ࡸ࡫࡬ࡧ࠰࡫ࡳࡸࡺࠫࠨ࡟ࠪ࠰ࠥࡲࡥࡷࡧ࡯ࡁࡽࡨ࡭ࡤ࠰ࡏࡓࡌࡋࡒࡓࡑࡕ࠭ࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡳࡰࡥ࡮ࠤࡂࠦࡳࡰࡥ࡮ࡩࡹ࠴ࡣࡳࡧࡤࡸࡪࡥࡣࡰࡰࡱࡩࡨࡺࡩࡰࡰࠫࠬࡸ࡫࡬ࡧ࠰࡫ࡳࡸࡺࠬࡴࡧ࡯ࡪ࠳ࡶ࡯ࡳࡶࠬ࠰ࠥࡹࡥ࡭ࡨ࠱ࡸ࡮ࡳࡥࡰࡷࡷ࠭ࠒࠐࠉࠊࡵࡨࡰ࡫࠴ࡳࡰࡥ࡮ࠤࡂࠦࡳࡴ࡮࠱ࡻࡷࡧࡰࡠࡵࡲࡧࡰ࡫ࡴࠩࡵࡨࡰ࡫࠴ࡳࡰࡥ࡮࠰ࠥࡹࡥ࡭ࡨ࠱࡯ࡪࡿ࡟ࡧ࡫࡯ࡩ࠱ࠦࡳࡦ࡮ࡩ࠲ࡨ࡫ࡲࡵࡡࡩ࡭ࡱ࡫ࠩࠎࠌࠐࠎࡨࡲࡡࡴࡵࠣࡑࡾࡎࡔࡕࡒࡋࡥࡳࡪ࡬ࡦࡴࠫࡹࡷࡲ࡬ࡪࡤ࠵࠲ࡍ࡚ࡔࡑࡊࡤࡲࡩࡲࡥࡳࠫ࠽ࠑࠏࠏࡤࡦࡨࠣ࡬ࡹࡺࡰࡠࡱࡳࡩࡳ࠮ࡳࡦ࡮ࡩ࠰ࡷ࡫ࡱࠪ࠼ࠐࠎࠎࠏࡲࡦࡶࡸࡶࡳࠦࡳࡦ࡮ࡩ࠲ࡩࡵ࡟ࡰࡲࡨࡲ࠭ࡓࡹࡉࡖࡗࡔࡈࡵ࡮࡯ࡧࡦࡸ࡮ࡵ࡮࠭ࡴࡨࡵ࠮ࠓࠊࠎࠌࡦࡰࡦࡹࡳࠡࡏࡼࡌ࡙࡚ࡐࡔࡊࡤࡲࡩࡲࡥࡳࠪࡸࡶࡱࡲࡩࡣ࠴࠱ࡌ࡙࡚ࡐࡔࡊࡤࡲࡩࡲࡥࡳࠫ࠽ࠑࠏࠏࡤࡦࡨࠣ࡬ࡹࡺࡰࡴࡡࡲࡴࡪࡴࠨࡴࡧ࡯ࡪ࠱ࡸࡥࡲࠫ࠽ࠑࠏࠏࠉࡳࡧࡷࡹࡷࡴࠠࡴࡧ࡯ࡪ࠳ࡪ࡯ࡠࡱࡳࡩࡳ࠮ࡍࡺࡊࡗࡘࡕ࡙ࡃࡰࡰࡱࡩࡨࡺࡩࡰࡰ࠯ࡶࡪࡷࠩࠎࠌࠥࠦࠧ⢳")
#url = l111lll_ll_ (u"ࠫ࡭ࡺࡴࡱ࠼࠲࠳ࡪࡾࡡ࡮ࡲ࡯ࡩ࠳ࡩ࡯࡮࠱ࡱࡥࡲ࡫࠮࡮ࡲ࠷ࠫ⢴")
#l1l11ll11ll_ll_(l111lll_ll_ (u"ࠬࡍࡅࡕࠩ⢵"),url)
#import l1_ll_ ; l1_ll_.l111l1ll1ll_ll_(url)
#l111lll1_ll_(url)
#traceback.print_exc(file=sys.stderr)
def l111l11l111_ll_(url):
	l1111l_ll_:	http://l111lll1lll_ll_.l1lll1l11_ll_/l111lll111l_ll_.l1lllll11_ll_
	GET:		http://l111lll1lll_ll_.l1lll1l11_ll_/loc/redirect.l1lllll11_ll_?l111ll11111_ll_=y&l111l1ll11l_ll_=l1ll1l1l_ll_%3A%2F%2Femadmahdi.l111l1111ll_ll_.l1lll1l11_ll_
	l111ll11ll1_ll_:	http://l111lll1lll_ll_.l1lll1l11_ll_
	return html