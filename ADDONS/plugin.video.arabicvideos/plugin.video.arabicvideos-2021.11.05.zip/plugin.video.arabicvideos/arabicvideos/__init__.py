# -*- coding: utf-8 -*-
import sys
l11llll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1llll_l1_ (l1_l1_):
    global l1l1ll1_l1_
    l1111_l1_ = ord (l1_l1_ [-1])
    l11ll1_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l11llll_l1_:
        l1l1lll_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1lll_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1lll_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l1llll_l1_ (u"ࠧࡏࡑࡗࡍࡈࡋࠧ佯"),l1llll_l1_ (u"ࠨ࠿ࠪ佰")*150)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠩࡶࡸࡦࡸࡴࠨ佱"))
try: l1111ll_l1_()
except Exception as error: l1l11111ll1_l1_(error)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠪࡷࡹࡵࡰࠨ佲"))
#xbmc.executebuiltin(l1llll_l1_ (u"࡚ࠫࡶࡤࡢࡶࡨࡐࡴࡩࡡ࡭ࡃࡧࡨࡴࡴࡳࠨ佳"))
#result = l1ll11llll1l_l1_(l1llll_l1_ (u"ࠬࡿࡡࡩࡱࡲ࠲ࡨࡵ࡭ࠨ佴"),l1llll_l1_ (u"࠭࠸࠯࠺࠱࠼࠳࠾ࠧ併"))
#l1ll11_l1_(l1llll_l1_ (u"ࠧࠨ佶"),l1llll_l1_ (u"ࠨࠩ佷"),l1llll_l1_ (u"ࠩࠪ佸"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1ll111_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11ll11_l1_,l1l11l1ll_l1_,l11ll111l_l1_,l111l1lll_l1_,l1lll1l1ll_l1_,l1ll1l111l_l1_,l11llll1l1_l1_,l111llll1l_l1_,l11111llll_l1_,l1lll11llll_l1_,l1ll111lll1_l1_,l1111l1l11l_l1_,l11lll1111l_l1_,l11111l1111_l1_,l11llllllll_l1_,l11111111l1_l1_,l1l11111lll_l1_,l1l1ll11l1l_l1_,l1l1l1l11ll_l1_,l1l11lll1l1_l1_,l111l1lll1_l1_
#import ll_l1_,l1l11l_l1_,l1l1l1ll1l_l1_,l1lll111l1ll_l1_,l111l111ll_l1_,l1lll1l11l1l_l1_,l11ll111l1l_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l1llll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡺࡷ࡬ࡰࡣࡧ࠲ࡨࡵ࡭࠰ࡧࡰࡦࡪࡪ࠭࠹ࡪ࡭࠴࠸࠼ࡺࡣ࡯ࡶ࠷࠹࠴ࡨࡵ࡯࡯ࠫ佹")
#url = l1llll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡪࡸࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡨ࡬ࡰࡪ࠵ࡤ࠰࠲ࡅ࠵࡞ࡺࡆ࠮ࡸࡤࡩ࠺ࡿ࡭ࡎࡆࡧࡊࡗ࠸࡯࠵ࡕࡇ࡚ࡗࡓࡕ࡬࠱ࡳࡶࡪࡼࡩࡦࡹࠪ佺")
#import l111ll1111l1_l1_
#results = l111ll1111l1_l1_.resolve(url)
#l1llll11l_l1_(l1llll_l1_ (u"ࠬ࠭佻"),l1llll_l1_ (u"࠭ࡒࡆࡕࡒ࡚ࡊ࡛ࡒࡍࡡࡄ࡚ࠥࡀࠠࠡࠢࠪ佼")+str(results))
#import l111ll1111ll_l1_
#l1l11l1lll11_l1_ = l111ll1111ll_l1_.YoutubeDL({l1llll_l1_ (u"ࠧ࡯ࡱࡢࡧࡴࡲ࡯ࡳࠩ佽"): True})
#results = l1l11l1lll11_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l1llll_l1_ (u"ࠨࠩ佾"),l1llll_l1_ (u"ࠩ࡜ࡓ࡚࡚ࡕࡃࡇࡇࡐࡤࡇࡖࠡ࠼ࠣࠤࠥ࠭使")+str(results))
#l1ll11_l1_(l1llll_l1_ (u"ࠪࠫ侀"),l1llll_l1_ (u"ࠫࠬ侁"),str(results))
#sys.exit()