# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
l111lll_ll_ (u"ࠧࠨࠢࠋࠌࠣࠤࠥࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࠫࡇ࠮ࠦ࠲࠱࠳࠷࠱࠷࠶࠱࠷ࠢࡥࡶࡴࡳࡩࡹࠢࠫࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠬࠎࠥࠦࠠࠡࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤ࠭ࡉࠩࠡ࠴࠳࠵࠻࠳࠲࠱࠳࠻ࠤࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠎࠏࠦࠠࠡࠢࡖࡔࡉ࡞࠭ࡍ࡫ࡦࡩࡳࡹࡥ࠮ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶ࠿ࠦࡇࡑࡎ࠰࠶࠳࠶࠭ࡰࡰ࡯ࡽࠏࠦࠠࠡࠢࡖࡩࡪࠦࡌࡊࡅࡈࡒࡘࡋࡓ࠰ࡉࡓࡐ࠲࠸࠮࠱࠯ࡲࡲࡱࡿࠠࡧࡱࡵࠤࡲࡵࡲࡦࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴ࠮ࠋࠤࠥࠦ䤀")
#from six.moves import range
class l1ll111ll1l1_ll_(object):
    def __init__(self, l1l1llll11l1_ll_):
        self._11l11l111ll_ll_ = l1l1llll11l1_ll_
    def execute(self, signature):
        _signature = signature
        _11l11l11111_ll_ = self._11l11l111ll_ll_[l111lll_ll_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡹࠧ䤁")]
        for action in _11l11l11111_ll_:
            func = l111lll_ll_ (u"ࠧࠨ䤂").join([l111lll_ll_ (u"ࠨࡡࠪ䤃"), action[l111lll_ll_ (u"ࠩࡩࡹࡳࡩࠧ䤄")]])
            params = action[l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ䤅")]
            if func == l111lll_ll_ (u"ࠫࡤࡸࡥࡵࡷࡵࡲࠬ䤆"):
                break
            for i in range(len(params)):
                param = params[i]
                if param == l111lll_ll_ (u"ࠬࠫࡓࡊࡉࠨࠫ䤇"):
                    param = _signature
                    params[i] = param
                    break
            method = getattr(self, func)
            if method:
                _signature = method(*params)
            else:
                raise Exception(l111lll_ll_ (u"ࠨࡕ࡯࡭ࡱࡳࡼࡴࠠ࡮ࡧࡷ࡬ࡴࡪࠠࠨࠧࡶࠫࠧ䤈") % func)
        return _signature
    @staticmethod
    def _11l11l11l11_ll_(signature):
        return l111lll_ll_ (u"ࠧࠨ䤉").join(signature)
    @staticmethod
    def _11l11l11lll_ll_(signature):
        return list(signature)
    @staticmethod
    def _11l11l111l1_ll_(signature, b):
        del signature[b:]
        return signature
    @staticmethod
    def _11l11l11l1l_ll_(signature, a, b):
        del signature[a:b]
        return signature
    @staticmethod
    def _11l11l11ll1_ll_(signature):
        return signature[::-1]
    @staticmethod
    def _11l11l1111l_ll_(signature, b):
        c = signature[0]
        signature[0] = signature[b % len(signature)]
        signature[b] = c
        return signature