# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
l111lll_ll_ (u"ࠧࠨࠢࠋࠌࠣࠤࠥࠦࡃࡰࡲࡼࡶ࡮࡭ࡨࡵࠢࠫࡇ࠮ࠦ࠲࠱࠳࠷࠱࠷࠶࠱࠷ࠢࡥࡶࡴࡳࡩࡹࠢࠫࡴࡱࡻࡧࡪࡰ࠱ࡺ࡮ࡪࡥࡰ࠰ࡼࡳࡺࡺࡵࡣࡧࠬࠎࠥࠦࠠࠡࡅࡲࡴࡾࡸࡩࡨࡪࡷࠤ࠭ࡉࠩࠡ࠴࠳࠵࠻࠳࠲࠱࠳࠻ࠤࡵࡲࡵࡨ࡫ࡱ࠲ࡻ࡯ࡤࡦࡱ࠱ࡽࡴࡻࡴࡶࡤࡨࠎࠏࠦࠠࠡࠢࡖࡔࡉ࡞࠭ࡍ࡫ࡦࡩࡳࡹࡥ࠮ࡋࡧࡩࡳࡺࡩࡧ࡫ࡨࡶ࠿ࠦࡇࡑࡎ࠰࠶࠳࠶࠭ࡰࡰ࡯ࡽࠏࠦࠠࠡࠢࡖࡩࡪࠦࡌࡊࡅࡈࡒࡘࡋࡓ࠰ࡉࡓࡐ࠲࠸࠮࠱࠯ࡲࡲࡱࡿࠠࡧࡱࡵࠤࡲࡵࡲࡦࠢ࡬ࡲ࡫ࡵࡲ࡮ࡣࡷ࡭ࡴࡴ࠮ࠋࠤࠥࠦ䢞")
import re
class Cipher(object):
    def _1ll11llllll_ll_(self, l11l11l1lll1_ll_):
        l11l1111l1l_ll_ = self._11l11lll11l_ll_(l11l11l1lll1_ll_)
        if not l11l1111l1l_ll_:
            raise Exception(l111lll_ll_ (u"࠭ࡓࡪࡩࡱࡥࡹࡻࡲࡦࠢࡩࡹࡳࡩࡴࡪࡱࡱࠤࡳࡵࡴࠡࡨࡲࡹࡳࡪࠧ䢟"))
        _11l11l1llll_ll_ = self._11l11ll11l1_ll_(l11l1111l1l_ll_, l11l11l1lll1_ll_)
        l11l11l1ll11_ll_ = _11l11l1llll_ll_[0].replace(l111lll_ll_ (u"ࠧ࡝ࡰࠪ䢠"), l111lll_ll_ (u"ࠨࠩ䢡")).split(l111lll_ll_ (u"ࠩ࠯ࠫ䢢"))
        l11l11l1l11l_ll_ = _11l11l1llll_ll_[1].replace(l111lll_ll_ (u"ࠪࡠࡳ࠭䢣"), l111lll_ll_ (u"ࠫࠬ䢤")).split(l111lll_ll_ (u"ࠬࡁࠧ䢥"))
        l1l1llll11l1_ll_ = {l111lll_ll_ (u"࠭ࡡࡤࡶ࡬ࡳࡳࡹࠧ䢦"): []}
        for line in l11l11l1l11l_ll_:
            l11l11ll1111_ll_ = re.match(l111lll_ll_ (u"ࡲࠨࠧࡶࡠࡸࡅ࠽࡝ࡵࡂࠩࡸ࠴ࡳࡱ࡮࡬ࡸࡡ࠮ࠢࠣ࡞ࠬࠫ䢧") % (l11l11l1ll11_ll_[0], l11l11l1ll11_ll_[0]), line)
            if l11l11ll1111_ll_:
                l1l1llll11l1_ll_[l111lll_ll_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࡴࠩ䢨")].append({l111lll_ll_ (u"ࠩࡩࡹࡳࡩࠧ䢩"): l111lll_ll_ (u"ࠪࡰ࡮ࡹࡴࠨ䢪"),
                                               l111lll_ll_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ䢫"): [l111lll_ll_ (u"ࠬࠫࡓࡊࡉࠨࠫ䢬")]})
            l11l11ll1ll1_ll_ = re.match(l111lll_ll_ (u"ࡸࠧࡳࡧࡷࡹࡷࡴ࡜ࡴ࠭ࠨࡷ࠳ࡰ࡯ࡪࡰ࡟ࠬࠧࠨ࡜ࠪࠩ䢭") % l11l11l1ll11_ll_[0], line)
            if l11l11ll1ll1_ll_:
                l1l1llll11l1_ll_[l111lll_ll_ (u"ࠧࡢࡥࡷ࡭ࡴࡴࡳࠨ䢮")].append({l111lll_ll_ (u"ࠨࡨࡸࡲࡨ࠭䢯"): l111lll_ll_ (u"ࠩ࡭ࡳ࡮ࡴࠧ䢰"),
                                               l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡵࠪ䢱"): [l111lll_ll_ (u"࡙ࠫࠪࡉࡈࠧࠪ䢲")]})
            l11l11ll111l_ll_ = re.match(
                l111lll_ll_ (u"ࡷ࠭ࠨࡀࡒ࠿ࡳࡧࡰࡥࡤࡶࡢࡲࡦࡳࡥ࠿࡝ࠧࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡣࠫࠪ࡞࠱ࡃࡡࡡ࠿ࠣࡁࠫࡃࡕࡂࡦࡶࡰࡦࡸ࡮ࡵ࡮ࡠࡰࡤࡱࡪࡄ࡛ࠥࡣ࠰ࡾࡆ࠳࡚࠱࠯࠼ࡡ࠰࠯ࠢࡀ࡞ࡠࡃࡡ࠮ࠨࡀࡒ࠿ࡴࡦࡸࡡ࡮ࡧࡷࡩࡷࡄ࡛࡟ࠫࡠ࠯࠮ࡢࠩࠨ䢳"),
                line)
            if l11l11ll111l_ll_:
                l11l11ll11ll_ll_ = l11l11ll111l_ll_.group(l111lll_ll_ (u"࠭࡯ࡣ࡬ࡨࡧࡹࡥ࡮ࡢ࡯ࡨࠫ䢴"))
                l11l1111l1l_ll_ = l11l11ll111l_ll_.group(l111lll_ll_ (u"ࠧࡧࡷࡱࡧࡹ࡯࡯࡯ࡡࡱࡥࡲ࡫ࠧ䢵"))
                l1ll1lll1lll_ll_ = l11l11ll111l_ll_.group(l111lll_ll_ (u"ࠨࡲࡤࡶࡦࡳࡥࡵࡧࡵࠫ䢶")).split(l111lll_ll_ (u"ࠩ࠯ࠫ䢷"))
                for i in range(len(l1ll1lll1lll_ll_)):
                    param = l1ll1lll1lll_ll_[i].strip()
                    if i == 0:
                        param = l111lll_ll_ (u"ࠪࠩࡘࡏࡇࠦࠩ䢸")
                    else:
                        param = int(param)
                    l1ll1lll1lll_ll_[i] = param
                _11l11l1llll_ll_ = self._11l11l1l1l1_ll_(l11l11ll11ll_ll_, l11l1111l1l_ll_, l11l11l1lll1_ll_)
                l11l11ll1l11_ll_ = re.match(l111lll_ll_ (u"ࡶࠬࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫ࠯ࡵ࡯࡭ࡨ࡫࡜ࠩࠪࡂࡔࡁࡧ࠾࡝ࡦ࠮࠭࠱ࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫ࡝ࠫࠪ䢹"), _11l11l1llll_ll_[l111lll_ll_ (u"ࠬࡨ࡯ࡥࡻࠪ䢺")][0])
                if l11l11ll1l11_ll_:
                    a = int(l11l11ll1l11_ll_.group(l111lll_ll_ (u"࠭ࡡࠨ䢻")))
                    params = [l111lll_ll_ (u"ࠧࠦࡕࡌࡋࠪ࠭䢼"), a, l1ll1lll1lll_ll_[1]]
                    l1l1llll11l1_ll_[l111lll_ll_ (u"ࠨࡣࡦࡸ࡮ࡵ࡮ࡴࠩ䢽")].append({l111lll_ll_ (u"ࠩࡩࡹࡳࡩࠧ䢾"): l111lll_ll_ (u"ࠪࡷࡱ࡯ࡣࡦࠩ䢿"),
                                                   l111lll_ll_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ䣀"): params})
                l11l11l1ll1l_ll_ = re.match(l111lll_ll_ (u"ࡷ࡛࠭ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬ࠰ࡶࡴࡱ࡯ࡣࡦ࡞ࠫࠬࡄࡖ࠼ࡢࡀ࡟ࡨ࠰࠯ࠬ࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠭࡟࠭ࠬ䣁"), _11l11l1llll_ll_[l111lll_ll_ (u"࠭ࡢࡰࡦࡼࠫ䣂")][0])
                if l11l11l1ll1l_ll_:
                    a = int(l11l11l1ll1l_ll_.group(l111lll_ll_ (u"ࠧࡢࠩ䣃")))
                    params = [l111lll_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䣄"), a, l1ll1lll1lll_ll_[1]]
                    l1l1llll11l1_ll_[l111lll_ll_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࡵࠪ䣅")].append({l111lll_ll_ (u"ࠪࡪࡺࡴࡣࠨ䣆"): l111lll_ll_ (u"ࠫࡸࡶ࡬ࡪࡥࡨࠫ䣇"),
                                                   l111lll_ll_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ䣈"): params})
                l11l11lll111_ll_ = re.match(l111lll_ll_ (u"ࡸࠧࡷࡣࡵࡠࡸࡅ࡛ࡢ࠯ࡽࡅ࠲ࡠ࡝ࠬ࠿࡟ࡷࡄࡡࡡ࠮ࡼࡄ࠱࡟ࡣࠫ࡝࡝࠳ࡠࡢ࠭䣉"), _11l11l1llll_ll_[l111lll_ll_ (u"ࠧࡣࡱࡧࡽࠬ䣊")][0])
                if l11l11lll111_ll_:
                    params = [l111lll_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䣋"), l1ll1lll1lll_ll_[1]]
                    l1l1llll11l1_ll_[l111lll_ll_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࡵࠪ䣌")].append({l111lll_ll_ (u"ࠪࡪࡺࡴࡣࠨ䣍"): l111lll_ll_ (u"ࠫࡸࡽࡡࡱࠩ䣎"),
                                                   l111lll_ll_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ䣏"): params})
                l11l11ll1l1l_ll_ = re.match(l111lll_ll_ (u"ࡸࠧ࡜ࡣ࠰ࡾࡆ࠳࡚࡞࠰ࡵࡩࡻ࡫ࡲࡴࡧ࡟ࠬࡡ࠯ࠧ䣐"), _11l11l1llll_ll_[l111lll_ll_ (u"ࠧࡣࡱࡧࡽࠬ䣑")][0])
                if l11l11ll1l1l_ll_:
                    params = [l111lll_ll_ (u"ࠨࠧࡖࡍࡌࠫࠧ䣒")]
                    l1l1llll11l1_ll_[l111lll_ll_ (u"ࠩࡤࡧࡹ࡯࡯࡯ࡵࠪ䣓")].append({l111lll_ll_ (u"ࠪࡪࡺࡴࡣࠨ䣔"): l111lll_ll_ (u"ࠫࡷ࡫ࡶࡦࡴࡶࡩࠬ䣕"),
                                                   l111lll_ll_ (u"ࠬࡶࡡࡳࡣࡰࡷࠬ䣖"): params})
        return l1l1llll11l1_ll_
    @staticmethod
    def _11l11lll11l_ll_(l11l11l1lll1_ll_):
        l11l11l1l111_ll_ = [
            l111lll_ll_ (u"ࡸࠧ࡝ࡤ࡞ࡧࡸࡣ࡜ࡴࠬࠩࠪࡡࡹࠪ࡜ࡣࡧࡪࡢࡢ࠮ࡴࡧࡷࡠ࠭ࡡ࡞࠭࡟࠮ࡠࡸ࠰ࠬ࡝ࡵ࠭ࡩࡳࡩ࡯ࡥࡧࡘࡖࡎࡉ࡯࡮ࡲࡲࡲࡪࡴࡴ࡝ࡵ࠭ࡠ࠭ࡢࡳࠫࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞࠭ࠬࡠ࠭࠭䣗"),
            l111lll_ll_ (u"ࡲࠨ࡞ࡥ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡝ࠬ࡞ࡶ࠮ࠫࠬ࡜ࡴࠬ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡣࠫ࡝࠰ࡶࡩࡹࡢࠨ࡜ࡠ࠯ࡡ࠰ࡢࡳࠫ࠮࡟ࡷ࠯࡫࡮ࡤࡱࡧࡩ࡚ࡘࡉࡄࡱࡰࡴࡴࡴࡥ࡯ࡶ࡟ࡷ࠯ࡢࠨ࡝ࡵ࠭ࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠯࠮ࡢࠨࠨ䣘"),
            l111lll_ll_ (u"ࡳࠩࠫࡃ࠿ࡢࡢࡽ࡝ࡡࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠪࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞ࡽ࠵ࢁ࠮ࡢࡳࠫ࠿࡟ࡷ࠯࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩ࡞ࡶ࠮ࡦࡢࡳࠫ࡞ࠬࡠࡸ࠰ࡻ࡝ࡵ࠭ࡥࡡࡹࠪ࠾࡞ࡶ࠮ࡦࡢ࠮ࡴࡲ࡯࡭ࡹࡢࠨ࡝ࡵ࠭ࠦࠧࡢࡳࠫ࡞ࠬࠫ䣙"),
            l111lll_ll_ (u"ࡴࠪࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡࡡ࠮ࡼࡄ࠱࡟࠶࠭࠺ࠦࡠ࠯࠮ࡢࡳࠫ࠿࡟ࡷ࠯࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩ࡞ࡶ࠮ࡦࡢࡳࠫ࡞ࠬࡠࡸ࠰ࡻ࡝ࡵ࠭ࡥࡡࡹࠪ࠾࡞ࡶ࠮ࡦࡢ࠮ࡴࡲ࡯࡭ࡹࡢࠨ࡝ࡵ࠭ࠦࠧࡢࡳࠫ࡞ࠬࠫ䣚"),
            l111lll_ll_ (u"ࡵࠫ࠭ࡡࠢ࡝ࠩࡠ࠭ࡸ࡯ࡧ࡯ࡣࡷࡹࡷ࡫࡜࠲࡞ࡶ࠮࠱ࡢࡳࠫࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞࠭ࠬࡠ࠭࠭䣛"),
            l111lll_ll_ (u"ࡶࠬࡢ࠮ࡴ࡫ࡪࡠࢁࡢࡼࠩࡁࡓࡀࡳࡧ࡭ࡦࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠬࠫ࡟ࠬࠬ䣜"),
            l111lll_ll_ (u"ࡷ࠭ࡹࡵ࡞࠱ࡥࡰࡧ࡭ࡢ࡫ࡽࡩࡩࡢ࠮࡯ࡧࡷ࠳ࡡ࠯࡜ࡴࠬ࡟ࢀࡡࢂ࡜ࡴࠬ࠱࠮ࡄࡢࡳࠫ࡝ࡦࡷࡢࡢࡳࠫࠨࠩࡠࡸ࠰࡛ࡢࡦࡩࡡࡡ࠴ࡳࡦࡶ࡟ࠬࡠࡤࠬ࡞࠭࡟ࡷ࠯࠲࡜ࡴࠬࠫࡃ࠿࡫࡮ࡤࡱࡧࡩ࡚ࡘࡉࡄࡱࡰࡴࡴࡴࡥ࡯ࡶ࡟ࡷ࠯ࡢࠨࠪࡁ࡟ࡷ࠯࠭䣝")
            l111lll_ll_ (u"ࡸࠧࠩࡁࡓࡀࡳࡧ࡭ࡦࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠬࠫ࡟ࠬࠬ䣞"),
            l111lll_ll_ (u"ࡲࠨ࡞ࡥ࡟ࡨࡹ࡝࡝ࡵ࠭ࠪࠫࡢࡳࠫ࡝ࡤࡨ࡫ࡣ࡜࠯ࡵࡨࡸࡡ࠮࡛࡟࠮ࡠ࠯ࡡࡹࠪ࠭࡞ࡶ࠮࠭ࡅࡐ࠽ࡰࡤࡱࡪࡄ࡛ࡢ࠯ࡽࡅ࠲ࡠ࠰࠮࠻ࠧࡡ࠰࠯࡜ࠩࠩ䣟"),
            l111lll_ll_ (u"ࡳࠩ࡟ࡦࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹࡞࠭࡟ࡷ࠯ࠬࠦ࡝ࡵ࠭࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿࡝ࠬ࡞࠱ࡷࡪࡺ࡜ࠩ࡝ࡡ࠰ࡢ࠱࡜ࡴࠬ࠯ࡠࡸ࠰ࠨࡀࡒ࠿ࡲࡦࡳࡥ࠿࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࠩࡣࠫࠪ࡞ࠫࠫ䣠"),
            l111lll_ll_ (u"ࡴࠪࡠࡧࡩ࡜ࡴࠬࠩࠪࡡࡹࠪࡢ࡞࠱ࡷࡪࡺ࡜ࠩ࡝ࡡ࠰ࡢ࠱࡜ࡴࠬ࠯ࡠࡸ࠰࡜ࠩ࡝ࡡ࠭ࡢ࠰࡜ࠪ࡞ࡶ࠮ࡡ࠮࡜ࡴࠬࠫࡃࡕࡂ࡮ࡢ࡯ࡨࡂࡠࡧ࠭ࡻࡃ࠰࡞࠵࠳࠹ࠥ࡟࠮࠭ࡡ࠮ࠧ䣡"),
            l111lll_ll_ (u"ࡵࠫࡡࡨࡣ࡝ࡵ࠭ࠪࠫࡢࡳࠫ࡝ࡤ࠱ࡿࡇ࡛࠭࠲࠰࠽ࡢ࠱࡜࠯ࡵࡨࡸࡡ࠮࡛࡟࠮ࡠ࠯ࡡࡹࠪ࠭࡞ࡶ࠮ࡡ࠮࡛࡟ࠫࡠ࠮ࡡ࠯࡜ࡴࠬ࡟ࠬࡡࡹࠪࠩࡁࡓࡀࡳࡧ࡭ࡦࡀ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࠪ࡝ࠬࠫ࡟ࠬࠬ䣢"),
            l111lll_ll_ (u"ࡶࠬࡢࡢࡤ࡞ࡶ࠮ࠫࠬ࡜ࡴࠬ࡞ࡥ࠲ࢀࡁ࠮࡜࠳࠱࠾ࡣࠫ࡝࠰ࡶࡩࡹࡢࠨ࡜ࡠ࠯ࡡ࠰ࡢࡳࠫ࠮࡟ࡷ࠯ࡢࠨ࡜ࡠࠬࡡ࠯ࡢࠩ࡝ࡵ࠭ࡠ࠭ࡢࡳࠫࠪࡂࡔࡁࡴࡡ࡮ࡧࡁ࡟ࡦ࠳ࡺࡂ࠯࡝࠴࠲࠿ࠤ࡞࠭ࠬࡠ࠭࠭䣣")
        ]
        for pattern in l11l11l1l111_ll_:
            match = re.search(pattern, l11l11l1lll1_ll_)
            if match:
                return match.group(l111lll_ll_ (u"ࠬࡴࡡ࡮ࡧࠪ䣤"))
        return l111lll_ll_ (u"࠭ࠧ䣥")
    @staticmethod
    def _11l11ll11l1_ll_(l11l1111l1l_ll_, l11l11l1lll1_ll_):
        l11l1111l1l_ll_ = l11l1111l1l_ll_.replace(l111lll_ll_ (u"ࠧࠥࠩ䣦"), l111lll_ll_ (u"ࠨ࡞࡟ࠨࠬ䣧"))
        match = re.search(l111lll_ll_ (u"ࡴࠪࡠࡸࡅࠥࡴ࠿ࡩࡹࡳࡩࡴࡪࡱࡱࡠ࠭࠮࠿ࡑ࠾ࡳࡥࡷࡧ࡭ࡦࡶࡨࡶࡃࡡ࡞ࠪ࡟࠮࠭ࡡ࠯࡜ࡴࡁࡾࡠࡸࡅࠨࡀࡒ࠿ࡦࡴࡪࡹ࠿࡝ࡡࢁࡢ࠱ࠩ࡝ࡵࡂࡠࢂ࠭䣨") % l11l1111l1l_ll_, l11l11l1lll1_ll_)
        if match:
            return match.group(l111lll_ll_ (u"ࠪࡴࡦࡸࡡ࡮ࡧࡷࡩࡷ࠭䣩")), match.group(l111lll_ll_ (u"ࠫࡧࡵࡤࡺࠩ䣪"))
        return l111lll_ll_ (u"ࠬ࠭䣫"), l111lll_ll_ (u"࠭ࠧ䣬")
    @staticmethod
    def _11l11ll1lll_ll_(l11l11ll11ll_ll_, l11l11l1lll1_ll_):
        l11l11ll11ll_ll_ = l11l11ll11ll_ll_.replace(l111lll_ll_ (u"ࠧࠥࠩ䣭"), l111lll_ll_ (u"ࠨ࡞࡟ࠨࠬ䣮"))
        match = re.search(l111lll_ll_ (u"ࡴࠪࡺࡦࡸࠠࠦࡵࡀࡿ࠭ࡅࡐ࠽ࡱࡥ࡮ࡪࡩࡴࡠࡤࡲࡨࡾࡄ࠮ࠫࡁࢀ࠭ࢂࡁࠧ䣯") % l11l11ll11ll_ll_, l11l11l1lll1_ll_, re.S)
        if match:
            return match.group(l111lll_ll_ (u"ࠪࡳࡧࡰࡥࡤࡶࡢࡦࡴࡪࡹࠨ䣰"))
        return l111lll_ll_ (u"ࠫࠬ䣱")
    def _11l11l1l1l1_ll_(self, l11l11ll11ll_ll_, l11l1111l1l_ll_, l11l11l1lll1_ll_):
        if l11l11ll11ll_ll_ not in self._1l1l1ll11l1_ll_:
            self._1l1l1ll11l1_ll_[l11l11ll11ll_ll_] = {}
        else:
            if l11l1111l1l_ll_ in self._1l1l1ll11l1_ll_[l11l11ll11ll_ll_]:
                return self._1l1l1ll11l1_ll_[l11l11ll11ll_ll_][l11l1111l1l_ll_]
        _11l11l1l1ll_ll_ = self._11l11ll1lll_ll_(l11l11ll11ll_ll_, l11l11l1lll1_ll_)
        _11l11l1l1ll_ll_ = _11l11l1l1ll_ll_.split(l111lll_ll_ (u"ࠬࢃࠬࠨ䣲"))
        for _11l11l1llll_ll_ in _11l11l1l1ll_ll_:
            if not _11l11l1llll_ll_.endswith(l111lll_ll_ (u"࠭ࡽࠨ䣳")):
                _11l11l1llll_ll_ = l111lll_ll_ (u"ࠧࠨ䣴").join([_11l11l1llll_ll_, l111lll_ll_ (u"ࠨࡿࠪ䣵")])
            _11l11l1llll_ll_ = _11l11l1llll_ll_.strip()
            match = re.match(l111lll_ll_ (u"ࡴࠪࠬࡄࡖ࠼࡯ࡣࡰࡩࡃࡡ࡞࠻࡟࠭࠭࠿࡬ࡵ࡯ࡥࡷ࡭ࡴࡴ࡜ࠩࠪࡂࡔࡁࡶࡡࡳࡣࡰࡩࡹ࡫ࡲ࠿࡝ࡡ࠭ࡢ࠰ࠩ࡝ࠫࡾࠬࡄࡖ࠼ࡣࡱࡧࡽࡃࡡ࡞ࡾ࡟࠮࠭ࢂ࠭䣶"), _11l11l1llll_ll_)
            if match:
                name = match.group(l111lll_ll_ (u"ࠪࡲࡦࡳࡥࠨ䣷")).replace(l111lll_ll_ (u"ࠫࠧ࠭䣸"), l111lll_ll_ (u"ࠬ࠭䣹"))
                l1ll1lll1lll_ll_ = match.group(l111lll_ll_ (u"࠭ࡰࡢࡴࡤࡱࡪࡺࡥࡳࠩ䣺"))
                body = match.group(l111lll_ll_ (u"ࠧࡣࡱࡧࡽࠬ䣻")).split(l111lll_ll_ (u"ࠨ࠽ࠪ䣼"))
                self._1l1l1ll11l1_ll_[l11l11ll11ll_ll_][name] = {l111lll_ll_ (u"ࠩࡱࡥࡲ࡫ࠧ䣽"): name,
                                                         l111lll_ll_ (u"ࠪࡦࡴࡪࡹࠨ䣾"): body,
                                                         l111lll_ll_ (u"ࠫࡵࡧࡲࡢ࡯ࡶࠫ䣿"): l1ll1lll1lll_ll_}
        return self._1l1l1ll11l1_ll_[l11l11ll11ll_ll_][l11l1111l1l_ll_]