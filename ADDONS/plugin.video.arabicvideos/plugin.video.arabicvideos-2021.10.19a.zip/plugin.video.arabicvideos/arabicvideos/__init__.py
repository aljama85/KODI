# -*- coding: utf-8 -*-
import sys
l111ll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l111l1l_l1_ = 7
def l11111_l1_ (ll_l1_):
    global l11ll1l_l1_
    l1111_l1_ = ord (ll_l1_ [-1])
    l11ll1_l1_ = ll_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l111ll_l1_:
        l1l1ll1_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1ll1_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1ll1_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l11111_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ佛"),l11111_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ作"))
l1l1ll1l1_l1_(l11111_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ佝"))
try: l1111ll_l1_()
except Exception as error: l1ll1ll11ll1_l1_(error)
l1l1ll1l1_l1_(l11111_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ佞"))
#xbmc.executebuiltin(l11111_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ佟"))
#result = l1ll1l1lll11_l1_(l11111_l1_ (u"࠭ࡹࡢࡪࡲࡳ࠳ࡩ࡯࡮ࠩ你"),l11111_l1_ (u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ佡"))
#l1ll11_l1_(l11111_l1_ (u"ࠨࠩ佢"),l11111_l1_ (u"ࠩࠪ佣"),l11111_l1_ (u"ࠪࠫ佤"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1l1lll_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll1l111l_l1_,l11llll11l_l1_,l111llll11_l1_,l1111l111l_l1_,l1lll1l11l1_l1_,l1ll111ll1l_l1_,l1111ll1l1l_l1_,l11lll1ll11_l1_,l11111llll1_l1_,l1l1111l11l_l1_,l1llll11llll_l1_,l1l1111ll1l_l1_,l1l1ll11lll_l1_,l1l1l1l11ll_l1_,l1l11lll1ll_l1_,l111ll1111_l1_
#import l1_l1_,l1l11l_l1_,l1l1l1ll11_l1_,l1lll1l111ll_l1_,l111l11l1l_l1_,l1lll1lllll1_l1_,l11ll1l111l_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
l11111_l1_ (u"ࠦࠧࠨࠍࠋࡷࡵࡰࠥࡃࠠࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡸࡵࡱࡵࡡࡥ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠲࠾ࡨ࡫࠲࠶࠺ࡿࡨ࡭ࡴ࠵࠷࠲࡭ࡺ࡭࡭ࠩࠐࠎࡺࡸ࡬ࠡ࠿ࠣࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡪࡲࡪࡸࡨ࠲࡬ࡵ࡯ࡨ࡮ࡨ࠲ࡨࡵ࡭࠰ࡨ࡬ࡰࡪ࠵ࡤ࠰࠲ࡅ࠵࡞ࡺࡆ࠮ࡸࡤࡩ࠺ࡿ࡭ࡎࡆࡧࡊࡗ࠸࡯࠵ࡕࡇ࡚ࡗࡓࡕ࡬࠱ࡳࡶࡪࡼࡩࡦࡹࠪࠑࠏ࡯࡭ࡱࡱࡵࡸࠥࡸࡥࡴࡱ࡯ࡺࡪࡻࡲ࡭ࡡࡤࡺࠒࠐࡲࡦࡵࡸࡰࡹࡹࠠ࠾ࠢࡵࡩࡸࡵ࡬ࡷࡧࡸࡶࡱࡥࡡࡷ࠰ࡵࡩࡸࡵ࡬ࡷࡧࠫࡹࡷࡲࠩࠎࠌࡏࡓࡌࡥࡔࡉࡋࡖࠬࠬ࠭ࠬࠨࡔࡈࡗࡔ࡜ࡅࡖࡔࡏࡣࡆ࡜ࠠ࠻ࠢࠣࠤࠬ࠱ࡳࡵࡴࠫࡶࡪࡹࡵ࡭ࡶࡶ࠭࠮ࠓࠊࡪ࡯ࡳࡳࡷࡺࠠࡺࡱࡸࡸࡺࡨࡥࡥ࡮ࡢࡥࡻࠓࠊࡺࡦ࡯ࠤࡂࠦࡹࡰࡷࡷࡹࡧ࡫ࡤ࡭ࡡࡤࡺ࠳࡟࡯ࡶࡶࡸࡦࡪࡊࡌࠩࡽࠪࡲࡴࡥࡣࡰ࡮ࡲࡶࠬࡀࠠࡕࡴࡸࡩࢂ࠯ࠍࠋࡴࡨࡷࡺࡲࡴࡴࠢࡀࠤࡾࡪ࡬࠯ࡧࡻࡸࡷࡧࡣࡵࡡ࡬ࡲ࡫ࡵࠨࡶࡴ࡯࠰ࡩࡵࡷ࡯࡮ࡲࡥࡩࡃࡆࡢ࡮ࡶࡩ࠮ࠓࠊࡍࡑࡊࡣ࡙ࡎࡉࡔࠪࠪࠫ࠱࡙࠭ࡐࡗࡗ࡙ࡇࡋࡄࡍࡡࡄ࡚ࠥࡀࠠࠡࠢࠪ࠯ࡸࡺࡲࠩࡴࡨࡷࡺࡲࡴࡴࠫࠬࠑࠏࠩࡄࡊࡃࡏࡓࡌࡥࡏࡌࠪࠪࠫ࠱࠭ࠧ࠭ࡵࡷࡶ࠭ࡸࡥࡴࡷ࡯ࡸࡸ࠯ࠩࠎࠌࡶࡽࡸ࠴ࡥࡹ࡫ࡷࠬ࠮ࠓࠊࠣࠤࠥ佥")