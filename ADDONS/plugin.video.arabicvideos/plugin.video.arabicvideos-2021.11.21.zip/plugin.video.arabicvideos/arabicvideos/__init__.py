# -*- coding: utf-8 -*-
import sys
l11llll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1llll_l1_ (l1_l1_):
    global l1l1ll1_l1_
    l1111_l1_ = ord (l1_l1_ [-1])
    l11ll1_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l11llll_l1_:
        l1l1lll_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1lll_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1lll_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l1llll_l1_ (u"࠭ࡎࡐࡖࡌࡇࡊ࠭你"),l1llll_l1_ (u"ࠧ࠾ࠩ佡")*150)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠨࡵࡷࡥࡷࡺࠧ佢"))
try: l1111ll_l1_()
except Exception as error: l1l11111lll_l1_(error)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠩࡶࡸࡴࡶࠧ佣"))
#xbmc.executebuiltin(l1llll_l1_ (u"࡙ࠪࡵࡪࡡࡵࡧࡏࡳࡨࡧ࡬ࡂࡦࡧࡳࡳࡹࠧ佤"))
#result = l1ll11llllll_l1_(l1llll_l1_ (u"ࠫࡾࡧࡨࡰࡱ࠱ࡧࡴࡳࠧ佥"),l1llll_l1_ (u"ࠬ࠾࠮࠹࠰࠻࠲࠽࠭佦"))
#l1ll11_l1_(l1llll_l1_ (u"࠭ࠧ佧"),l1llll_l1_ (u"ࠧࠨ佨"),l1llll_l1_ (u"ࠨࠩ佩"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1ll111_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11ll11_l1_,l1l11l1ll_l1_,l11ll111l_l1_,l111l1lll_l1_,l1lll11lll_l1_,l1ll11ll1l_l1_,l11lll11l1_l1_,l111ll1ll1_l1_,l11111ll11_l1_,l1lll11ll11_l1_,l1ll111ll11_l1_,l1111l1l1l1_l1_,l11lll111ll_l1_,l11111l111l_l1_,l1l11111111_l1_,l11111111ll_l1_,l1l1111l111_l1_,l1l1ll111ll_l1_,l1l1l1l111l_l1_,l1l11lll111_l1_,l111l11lll_l1_
#import ll_l1_,l1l11l_l1_,l1l1l11l11_l1_,l1lll111ll11_l1_,l1111lll11_l1_,l1lll1l11lll_l1_,l11ll111lll_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l1llll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡹࡶࡲ࡯ࡢࡦ࠱ࡧࡴࡳ࠯ࡦ࡯ࡥࡩࡩ࠳࠸ࡩ࡬࠳࠷࠻ࢀࡢ࡮ࡵ࠶࠸࠳࡮ࡴ࡮࡮ࠪ佪")
#url = l1llll_l1_ (u"ࠪ࡬ࡹࡺࡰࡴ࠼࠲࠳ࡩࡸࡩࡷࡧ࠱࡫ࡴࡵࡧ࡭ࡧ࠱ࡧࡴࡳ࠯ࡧ࡫࡯ࡩ࠴ࡪ࠯࠱ࡄ࠴࡝ࡹࡌ࠭ࡷࡣࡨ࠹ࡾࡳࡍࡅࡦࡉࡖ࠷ࡵ࠴ࡔࡆ࡙ࡖࡒ࡛࡫࠰ࡲࡵࡩࡻ࡯ࡥࡸࠩ佫")
#import l111ll111l1l_l1_
#results = l111ll111l1l_l1_.resolve(url)
#l1llll11l_l1_(l1llll_l1_ (u"ࠫࠬ佬"),l1llll_l1_ (u"ࠬࡘࡅࡔࡑ࡙ࡉ࡚ࡘࡌࡠࡃ࡙ࠤ࠿ࠦࠠࠡࠩ佭")+str(results))
#import l111ll111ll1_l1_
#l1l11l1llll1_l1_ = l111ll111ll1_l1_.YoutubeDL({l1llll_l1_ (u"࠭࡮ࡰࡡࡦࡳࡱࡵࡲࠨ佮"): True})
#results = l1l11l1llll1_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l1llll_l1_ (u"ࠧࠨ佯"),l1llll_l1_ (u"ࠨ࡛ࡒ࡙࡙࡛ࡂࡆࡆࡏࡣࡆ࡜ࠠ࠻ࠢࠣࠤࠬ佰")+str(results))
#l1ll11_l1_(l1llll_l1_ (u"ࠩࠪ佱"),l1llll_l1_ (u"ࠪࠫ佲"),str(results))
#sys.exit()