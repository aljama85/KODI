from .getmac import __version__, get_mac_address

__all__ = ["get_mac_address"]
