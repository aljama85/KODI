# -*- coding: utf-8 -*-
import sys
l11llll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1llll_l1_ (l1_l1_):
    global l1l1ll1_l1_
    l1111_l1_ = ord (l1_l1_ [-1])
    l11ll1_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l11llll_l1_:
        l1l1lll_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1lll_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1lll_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l1llll_l1_ (u"ࠬࡔࡏࡕࡋࡆࡉࠬ佭"),l1llll_l1_ (u"࠭࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂ࠭佮"))
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠧࡴࡶࡤࡶࡹ࠭佯"))
try: l1111ll_l1_()
except Exception as error: l11llllll11_l1_(error)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠨࡵࡷࡳࡵ࠭佰"))
#xbmc.executebuiltin(l1llll_l1_ (u"ࠩࡘࡴࡩࡧࡴࡦࡎࡲࡧࡦࡲࡁࡥࡦࡲࡲࡸ࠭佱"))
#result = l1ll11ll1ll1_l1_(l1llll_l1_ (u"ࠪࡽࡦ࡮࡯ࡰ࠰ࡦࡳࡲ࠭佲"),l1llll_l1_ (u"ࠫ࠽࠴࠸࠯࠺࠱࠼ࠬ佳"))
#l1ll11_l1_(l1llll_l1_ (u"ࠬ࠭佴"),l1llll_l1_ (u"࠭ࠧ併"),l1llll_l1_ (u"ࠧࠨ佶"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1ll111_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll11llll_l1_,l11lll1ll1_l1_,l111lll11l_l1_,l11111l1ll_l1_,l1lll11ll11_l1_,l1ll111l111_l1_,l11111llll1_l1_,l11ll1l1lll_l1_,l1111111ll1_l1_,l11llll1lll_l1_,l1lllllll111_l1_,l11llllll1l_l1_,l1l1l1lll1l_l1_,l1l1l11l1l1_l1_,l1l11ll111l_l1_,l111l1l1l1_l1_
#import ll_l1_,l1l11l_l1_,l1l1l1l1l1_l1_,l1lll11111l1_l1_,l1111lllll_l1_,l1lll11lll11_l1_,l11l1lll1ll_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l1llll_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡸࡵࡱࡵࡡࡥ࠰ࡦࡳࡲ࠵ࡥ࡮ࡤࡨࡨ࠲࠾ࡨ࡫࠲࠶࠺ࡿࡨ࡭ࡴ࠵࠷࠲࡭ࡺ࡭࡭ࠩ佷")
#url = l1llll_l1_ (u"ࠩ࡫ࡸࡹࡶࡳ࠻࠱࠲ࡨࡷ࡯ࡶࡦ࠰ࡪࡳࡴ࡭࡬ࡦ࠰ࡦࡳࡲ࠵ࡦࡪ࡮ࡨ࠳ࡩ࠵࠰ࡃ࠳࡜ࡸࡋ࠳ࡶࡢࡧ࠸ࡽࡲࡓࡄࡥࡈࡕ࠶ࡴ࠺ࡓࡅࡘࡕࡑ࡚ࡱ࠯ࡱࡴࡨࡺ࡮࡫ࡷࠨ佸")
#import l111l1lll1l1_l1_
#results = l111l1lll1l1_l1_.resolve(url)
#l1llll11l_l1_(l1llll_l1_ (u"ࠪࠫ佹"),l1llll_l1_ (u"ࠫࡗࡋࡓࡐࡘࡈ࡙ࡗࡒ࡟ࡂࡘࠣ࠾ࠥࠦࠠࠨ佺")+str(results))
#import l111l1lll1ll_l1_
#l1l11l1l1ll1_l1_ = l111l1lll1ll_l1_.YoutubeDL({l1llll_l1_ (u"ࠬࡴ࡯ࡠࡥࡲࡰࡴࡸࠧ佻"): True})
#results = l1l11l1l1ll1_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l1llll_l1_ (u"࠭ࠧ佼"),l1llll_l1_ (u"࡚ࠧࡑࡘࡘ࡚ࡈࡅࡅࡎࡢࡅ࡛ࠦ࠺ࠡࠢࠣࠫ佽")+str(results))
#l1ll11_l1_(l1llll_l1_ (u"ࠨࠩ佾"),l1llll_l1_ (u"ࠩࠪ使"),str(results))
#sys.exit()