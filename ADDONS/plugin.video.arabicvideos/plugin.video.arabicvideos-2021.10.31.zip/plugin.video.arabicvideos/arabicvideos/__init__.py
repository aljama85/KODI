# -*- coding: utf-8 -*-
import sys
l11llll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l1l11_l1_ = 7
def l1llll_l1_ (l1_l1_):
    global l1l1ll1_l1_
    l1111_l1_ = ord (l1_l1_ [-1])
    l11ll1_l1_ = l1_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l11llll_l1_:
        l1l1lll_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1lll_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l1l11_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1lll_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l1llll_l1_ (u"ࠨࡐࡒࡘࡎࡉࡅࠨ伸"),l1llll_l1_ (u"ࠩࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾ࠩ伹"))
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠪࡷࡹࡧࡲࡵࠩ伺"))
try: l1111ll_l1_()
except Exception as error: l1l1ll11ll1_l1_(error)
l1l1ll1l1_l1_(l1llll_l1_ (u"ࠫࡸࡺ࡯ࡱࠩ伻"))
#xbmc.executebuiltin(l1llll_l1_ (u"࡛ࠬࡰࡥࡣࡷࡩࡑࡵࡣࡢ࡮ࡄࡨࡩࡵ࡮ࡴࠩ似"))
#result = l1ll1l11l1l1_l1_(l1llll_l1_ (u"࠭ࡹࡢࡪࡲࡳ࠳ࡩ࡯࡮ࠩ伽"),l1llll_l1_ (u"ࠧ࠹࠰࠻࠲࠽࠴࠸ࠨ伾"))
#l1ll11_l1_(l1llll_l1_ (u"ࠨࠩ伿"),l1llll_l1_ (u"ࠩࠪ佀"),l1llll_l1_ (u"ࠪࠫ佁"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1ll111_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll11llll_l1_,l11lll1ll1_l1_,l111lll11l_l1_,l11111l1ll_l1_,l1lll11ll11_l1_,l1ll111l111_l1_,l1111l1l11l_l1_,l11lll11111_l1_,l11111l11l1_l1_,l11llllllll_l1_,l1111111l1l_l1_,l1l11111l11_l1_,l1l1l1lllll_l1_,l1l1l11ll11_l1_,l1l11ll1l11_l1_,l111l1l1l1_l1_
#import ll_l1_,l1l11l_l1_,l1l1l1l1l1_l1_,l1lll11l11ll_l1_,l1111lllll_l1_,l1lll1l1ll1l_l1_,l11ll111l11_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l1llll_l1_ (u"ࠫ࡭ࡺࡴࡱࡵ࠽࠳࠴ࡻࡱ࡭ࡱࡤࡨ࠳ࡩ࡯࡮࠱ࡨࡱࡧ࡫ࡤ࠮࠺࡫࡮࠵࠹࠶ࡻࡤࡰࡷ࠸࠺࠮ࡩࡶࡰࡰࠬ佂")
#url = l1llll_l1_ (u"ࠬ࡮ࡴࡵࡲࡶ࠾࠴࠵ࡤࡳ࡫ࡹࡩ࠳࡭࡯ࡰࡩ࡯ࡩ࠳ࡩ࡯࡮࠱ࡩ࡭ࡱ࡫࠯ࡥ࠱࠳ࡆ࠶࡟ࡴࡇ࠯ࡹࡥࡪ࠻ࡹ࡮ࡏࡇࡨࡋࡘ࠲ࡰ࠶ࡖࡈ࡛ࡘࡍࡖ࡭࠲ࡴࡷ࡫ࡶࡪࡧࡺࠫ佃")
#import l111ll11ll1l_l1_
#results = l111ll11ll1l_l1_.resolve(url)
#l1llll11l_l1_(l1llll_l1_ (u"࠭ࠧ佄"),l1llll_l1_ (u"ࠧࡓࡇࡖࡓ࡛ࡋࡕࡓࡎࡢࡅ࡛ࠦ࠺ࠡࠢࠣࠫ佅")+str(results))
#import l111ll11lll1_l1_
#l1l11ll1l1l1_l1_ = l111ll11lll1_l1_.YoutubeDL({l1llll_l1_ (u"ࠨࡰࡲࡣࡨࡵ࡬ࡰࡴࠪ但"): True})
#results = l1l11ll1l1l1_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l1llll_l1_ (u"ࠩࠪ佇"),l1llll_l1_ (u"ࠪ࡝ࡔ࡛ࡔࡖࡄࡈࡈࡑࡥࡁࡗࠢ࠽ࠤࠥࠦࠧ佈")+str(results))
#l1ll11_l1_(l1llll_l1_ (u"ࠫࠬ佉"),l1llll_l1_ (u"ࠬ࠭佊"),str(results))
#sys.exit()