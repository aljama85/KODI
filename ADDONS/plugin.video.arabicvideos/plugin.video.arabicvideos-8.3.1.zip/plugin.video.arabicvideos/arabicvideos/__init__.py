# -*- coding: utf-8 -*-
import sys
l11ll11_ll_ = sys.version_info [0] == 2
l11111_ll_ = 2048
l11l1_ll_ = 7
def l111lll_ll_ (ll_ll_):
    global l11llll_ll_
    l11ll_ll_ = ord (ll_ll_ [-1])
    l11lll_ll_ = ll_ll_ [:-1]
    l1l1_ll_ = l11ll_ll_ % len (l11lll_ll_)
    l11l_ll_ = l11lll_ll_ [:l1l1_ll_] + l11lll_ll_ [l1l1_ll_:]
    if l11ll11_ll_:
        l1l1ll1_ll_ = unicode () .join ([unichr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    else:
        l1l1ll1_ll_ = str () .join ([chr (ord (char) - l11111_ll_ - (l1l11l_ll_ + l11ll_ll_) % l11l1_ll_) for l1l11l_ll_, char in enumerate (l11l_ll_)])
    return eval (l1l1ll1_ll_)
from l1l1l1_ll_ import *
l1111l1l_ll_(l111lll_ll_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ䢖"),l111lll_ll_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ䢗"))
#import l1l_ll_,l1l1lll1_ll_,l1l1lll_ll_,l11l111l_ll_,l1ll1lll1_ll_,l1ll11111_ll_,l1l1lll1l_ll_,l1l111l11_ll_,l11l1l1l1_ll_,l11l111ll_ll_,l111l1111_ll_,l1lll1llll_ll_,l1ll111lll_ll_,l1l11l1ll1_ll_,l11llllll1_ll_,l11l1ll1ll_ll_,l1111lllll_ll_,l1lll1ll111_ll_,l1l1l1l1ll1_ll_,l11l1l1ll1l_ll_,l11l1ll11l1_ll_,l1l11l111l1_ll_,l11l1ll1l1l_ll_,l1ll1ll11l1_ll_,l1l111ll111_ll_,l1ll1l1ll11_ll_,l11ll11llll_ll_,l1ll1lll111_ll_,l1l1lll11ll_ll_,l1l11lll1l1_ll_,l1_ll_,l1l111ll11_ll_,l1l1l1_ll_
l1ll1ll11_ll_(l111lll_ll_ (u"࠭ࡳࡵࡣࡵࡸࠬ䢘"))
try: l111l1l_ll_()
except Exception as error: l1l111llll1_ll_(error)
l1ll1ll11_ll_(l111lll_ll_ (u"ࠧࡴࡶࡲࡴࠬ䢙"))
#a = l1llll11l1l_ll_(l111lll_ll_ (u"ࠨࡏࡌࡗࡈ࠭䢚"),l111lll_ll_ (u"ࠩࡘࡗࡊࡘࡁࡈࡇࡑࡘ࠶࠸࠳ࠨ䢛"))
#l1ll1l_ll_(str(a),str(a))
#import l11ll111l1_ll_,l11llll1l_ll_,l1l1l1111l_ll_,l11l1lll1l_ll_,l11ll1ll1ll_ll_,l1lll11ll11_ll_