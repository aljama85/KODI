# -*- coding: utf-8 -*-
import sys
l111ll_l1_ = sys.version_info [0] == 2
l1l1_l1_ = 2048
l111l1l_l1_ = 7
def l11111_l1_ (ll_l1_):
    global l11ll1l_l1_
    l1111_l1_ = ord (ll_l1_ [-1])
    l11ll1_l1_ = ll_l1_ [:-1]
    l1lll_l1_ = l1111_l1_ % len (l11ll1_l1_)
    l1ll1_l1_ = l11ll1_l1_ [:l1lll_l1_] + l11ll1_l1_ [l1lll_l1_:]
    if l111ll_l1_:
        l1l1ll1_l1_ = unicode () .join ([unichr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    else:
        l1l1ll1_l1_ = str () .join ([chr (ord (char) - l1l1_l1_ - (l1l111_l1_ + l1111_l1_) % l111l1l_l1_) for l1l111_l1_, char in enumerate (l1ll1_l1_)])
    return eval (l1l1ll1_l1_)
from l1l11l_l1_ import *
l1llll11l_l1_(l11111_l1_ (u"ࠫࡓࡕࡔࡊࡅࡈࠫ俜"),l11111_l1_ (u"ࠬࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࡂࡃ࠽࠾࠿ࡀࡁࠬ保"))
l1l1ll1l1_l1_(l11111_l1_ (u"࠭ࡳࡵࡣࡵࡸࠬ俞"))
try: l1111ll_l1_()
except Exception as error: l1ll1lll1l11_l1_(error)
l1l1ll1l1_l1_(l11111_l1_ (u"ࠧࡴࡶࡲࡴࠬ俟"))
#xbmc.executebuiltin(l11111_l1_ (u"ࠨࡗࡳࡨࡦࡺࡥࡍࡱࡦࡥࡱࡇࡤࡥࡱࡱࡷࠬ俠"))
#result = l1ll1ll1l11l_l1_(l11111_l1_ (u"ࠩࡼࡥ࡭ࡵ࡯࠯ࡥࡲࡱࠬ信"),l11111_l1_ (u"ࠪ࠼࠳࠾࠮࠹࠰࠻ࠫ俢"))
#l1ll11_l1_(l11111_l1_ (u"ࠫࠬ俣"),l11111_l1_ (u"ࠬ࠭俤"),l11111_l1_ (u"࠭ࠧ俥"),str(result))
#import l11_l1_,l1l1l11l_l1_,l1l1lll_l1_,l1111lll_l1_,l1l1lll11_l1_,l1l11l1ll_l1_,l1l11l1l1_l1_,l11ll1111_l1_,l111l1ll1_l1_,l1lll1l11l_l1_,l1ll1l111l_l1_,l11llll111_l1_,l111lll1ll_l1_,l11111ll1l_l1_,l1lll11lll1_l1_,l1ll111l1l1_l1_,l1111llll11_l1_,l11lll11ll1_l1_,l1111l11l11_l1_,l1l11111lll_l1_,l1llll1lll11_l1_,l1l1111ll11_l1_,l1l1ll111ll_l1_,l1l1l1l11l1_l1_,l1l11lll1l1_l1_,l111l1ll11_l1_
#import l1_l1_,l1l11l_l1_,l1l1l1ll11_l1_,l1lll1ll11ll_l1_,l111l1111l_l1_,l1llll11ll1l_l1_,l11ll11ll1l_l1_,EXCLUDES
#import youtube_signature.cipher,youtube_signature.json_script_engine
#url = l11111_l1_ (u"ࠧࡩࡶࡷࡴࡸࡀ࠯࠰ࡷࡴࡰࡴࡧࡤ࠯ࡥࡲࡱ࠴࡫࡭ࡣࡧࡧ࠱࠽࡮ࡪ࠱࠵࠹ࡾࡧࡳࡳ࠴࠶࠱࡬ࡹࡳ࡬ࠨ俦")
#url = l11111_l1_ (u"ࠨࡪࡷࡸࡵࡹ࠺࠰࠱ࡧࡶ࡮ࡼࡥ࠯ࡩࡲࡳ࡬ࡲࡥ࠯ࡥࡲࡱ࠴࡬ࡩ࡭ࡧ࠲ࡨ࠴࠶ࡂ࠲࡛ࡷࡊ࠲ࡼࡡࡦ࠷ࡼࡱࡒࡊࡤࡇࡔ࠵ࡳ࠹࡙ࡄࡗࡔࡐ࡙ࡰ࠵ࡰࡳࡧࡹ࡭ࡪࡽࠧ俧")
#import resolveurl_av
#results = resolveurl_av.resolve(url)
#l1llll11l_l1_(l11111_l1_ (u"ࠩࠪ俨"),l11111_l1_ (u"ࠪࡖࡊ࡙ࡏࡗࡇࡘࡖࡑࡥࡁࡗࠢ࠽ࠤࠥࠦࠧ俩")+str(results))
#import youtubedl_av
#l1l11lllllll_l1_ = youtubedl_av.YoutubeDL({l11111_l1_ (u"ࠫࡳࡵ࡟ࡤࡱ࡯ࡳࡷ࠭俪"): True})
#results = l1l11lllllll_l1_.extract_info(url,download=False)
#l1llll11l_l1_(l11111_l1_ (u"ࠬ࠭俫"),l11111_l1_ (u"࡙࠭ࡐࡗࡗ࡙ࡇࡋࡄࡍࡡࡄ࡚ࠥࡀࠠࠡࠢࠪ俬")+str(results))
#l1ll11_l1_(l11111_l1_ (u"ࠧࠨ俭"),l11111_l1_ (u"ࠨࠩ修"),str(results))
#sys.exit()